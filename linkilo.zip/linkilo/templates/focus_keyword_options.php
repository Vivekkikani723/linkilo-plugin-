<input type="hidden" name="wp_screen_options[option]" value="focus_keyword_options" />
<input type="hidden" name="wp_screen_options[value]" value="yes" />
<fieldset class="screen-options">
    <legend>Options</legend>
    <input type="checkbox" name="focus_keyword_options[show_date]" id="show_date" <?php echo $show_date ? 'checked' : ''; ?>/>
    <label for="show_date"><?php _e("Show the post publish date", 'linkilo'); ?> </label>
    <input type="hidden" name="focus_keyword_options[show_traffic]" value="off"/>
    <input type="checkbox" name="focus_keyword_options[show_traffic]" id="show_traffic" <?php echo $show_traffic ? 'checked' : ''; ?>/>
    <label for="show_traffic"><?php _e("Show the organic traffic", 'linkilo'); ?></label>
    <input type="hidden" name="focus_keyword_options[remove_obviated_keywords]" value="off"/>
    <input type="checkbox" name="focus_keyword_options[remove_obviated_keywords]" id="remove_obviated_keywords" <?php echo $remove_obviated_keywords ? 'checked' : ''; ?>/>
    <label for="remove_obviated_keywords"><?php _e("Hide large GSC keywords when there's a full text match with an active keyword of the same size or smaller", 'linkilo'); ?></label>
</fieldset>
<fieldset class="screen-options">
    <legend><?php _e("Pagination", 'linkilo'); ?></legend>
    <label for="per_page"><?php _e("Entries per page", 'linkilo'); ?></label>
    <input type="number" step="1" min="1" max="999" maxlength="3" name="focus_keyword_options[per_page]" id="per_page" value="<?php echo esc_attr($per_page); ?>" />
</fieldset>
<br>
<?php echo $button; ?>
<?php wp_nonce_field( 'screen-options-nonce', 'screenoptionnonce', false, false ); ?>