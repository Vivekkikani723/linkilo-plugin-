<?php
$options = get_user_meta(get_current_user_id(), 'report_options', true); 
$show_date = (!empty($options['show_date']) && $options['show_date'] == 'on') ? true : false;
$taxonomies = get_taxonomies(array('public' => true, 'show_ui' => true), 'names', 'or');
$taxonomies = (!empty($taxonomies)) ? array_keys($taxonomies): array();
?>
<?php if (!empty($groups)) : ?>
    <?php foreach ($groups as $post_id => $group) : $phrase = $group[0]; ?>
        <tr class="linkilo-incoming-sentence" data-linkilo-sentence-id="<?php echo esc_attr($post_id); ?>" data-linkilo-post-published-date="<?php echo strtotime(get_the_date('F j, Y', $post_id)); ?>">
            <td class="sentences" data-colname="<?php _e('Phrase', 'linkilo'); ?>" style="display: flex;align-items: center;">
                <div>
                    <input type="checkbox" name="link_keywords[]" class="chk-keywords" linkilo-link-new="">
                </div>
                <?php if (count($group) > 1) : ?>
                    <div class="linkilo-collapsible-wrapper">
                        <div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count">
                            <div class="sentence top-level-sentence" data-id="<?php echo esc_attr($post_id); ?>" data-type="<?php echo esc_attr($phrase->suggestions[0]->post->type); ?>">
                                <div class="linkilo_edit_sentence_form">
                                    <textarea class="linkilo_content"><?php echo $phrase->suggestions[0]->sentence_src_with_anchor; ?></textarea>
                                    <span class="button-primary">Save</span>
                                    <span class="button-secondary">Cancel</span>
                                </div>
                                <span class="linkilo_sentence_with_anchor" title="<?php _e('Double clicking a word will select it.', 'linkilo'); ?>"><?php echo $phrase->suggestions[0]->sentence_with_anchor; ?></span>
                                <span class="linkilo_edit_sentence link-form-button">| <a href="javascript:void(0)">Edit <span class="dashicons dashicons-edit"></span></a></span>
                                <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($phrase->suggestions[0]->anchor_score).')':''; ?>
                                <input type="hidden" name="sentence" value="<?php echo base64_encode($phrase->sentence_src); ?>">
                                <input type="hidden" name="custom_sentence" value="">
                            </div>
                        </div>
                        <div class="linkilo-content" style="display: none;">
                            <ul>
                                <?php foreach ($group as $key_phrase => $phrase) : ?>
                                    <li>
                                        <div class="linkilo-incoming-sentence-data-container" data-container-id="<?php echo $key_phrase; ?>">
                                            <input type="radio" <?php echo !$key_phrase?'checked':''; ?> data-id="<?php echo $key_phrase; ?>">
                                            <div class="data">
                                                <div class="linkilo_edit_sentence_form">
                                                    <textarea class="linkilo_content"><?php echo $phrase->suggestions[0]->sentence_src_with_anchor; ?></textarea>
                                                    <span class="button-primary">Save</span>
                                                    <span class="button-secondary">Cancel</span>
                                                </div>
                                                <span class="linkilo_sentence_with_anchor" title="<?php _e('Double clicking a word will select it.', 'linkilo'); ?>"><?php echo $phrase->suggestions[0]->sentence_with_anchor; ?></span>
                                                <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($phrase->suggestions[0]->anchor_score).')':''; ?>
                                                <input type="hidden" name="sentence" value="<?php echo  base64_encode($phrase->sentence_src); ?>">
                                                <input type="hidden" name="custom_sentence" value="">
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>

                    <?php if (Linkilo_Build_AdminSettings::fullHTMLSuggestions()) : ?>
                        <?php foreach ($group as $key_phrase => $phrase) : ?>
                            <div class="raw_html" <?php echo $key_phrase > 0 ? 'style="display:none"' : ''; ?> data-id="<?php echo $key_phrase; ?>"><?php echo htmlspecialchars($phrase->suggestions[0]->sentence_src_with_anchor); ?></div>
                        <?php endforeach; ?>
                        <div class="raw_html custom-text" style="display:none" data-id="custom-text"></div>
                    <?php endif; ?>
                <?php else : ?>
                    <div class="sentence top-level-sentence" data-id="<?php echo esc_attr($post_id); ?>" data-type="<?php echo esc_attr($phrase->suggestions[0]->post->type); ?>">
                        <div class="linkilo_edit_sentence_form">
                            <textarea class="linkilo_content"><?php echo $phrase->suggestions[0]->sentence_src_with_anchor; ?></textarea>
                            <span class="button-primary">Save</span>
                            <span class="button-secondary">Cancel</span>
                        </div>
                        <span class="linkilo_sentence_with_anchor" title="<?php _e('Double clicking a word will select it.', 'linkilo'); ?>"><?php echo $phrase->suggestions[0]->sentence_with_anchor; ?></span>
                        <span class="linkilo_edit_sentence link-form-button">| <a href="javascript:void(0)">Edit <span class="dashicons dashicons-edit"></span></a></span>
                        <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($phrase->suggestions[0]->anchor_score).')':''; ?>
                        <input type="hidden" name="sentence" value="<?php echo base64_encode($phrase->sentence_src); ?>">
                        <input type="hidden" name="custom_sentence" value="">

                        <?php if (Linkilo_Build_AdminSettings::fullHTMLSuggestions()) : ?>
                            <div class="raw_html"><?php echo htmlspecialchars($phrase->suggestions[0]->sentence_src_with_anchor); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </td>
            <td data-colname="<?php _e('Post', 'linkilo'); ?>">
                <div style="opacity:<?php echo $phrase->suggestions[0]->opacity; ?>" class="suggestion" data-id="<?php echo esc_attr($phrase->suggestions[0]->post->id); ?>" data-type="<?php echo esc_attr($phrase->suggestions[0]->post->type); ?>">
                    <?php
                    $categories = get_terms(array(
                        'taxonomy' => $taxonomies,
                        'hide_empty' => false,
                        'object_ids' => $phrase->suggestions[0]->post->id,
                    ));

                    if(!is_wp_error($categories) && !empty($categories)){
                        $mapped = array_map(function($obj){ if(isset($obj->name)){return $obj->name;} }, $categories);
                        $categories = implode(', ', $mapped);
                        $found = count($mapped);
                    }else{
                        $categories = false;
                    }
                    ?>    
                    <?php echo '<b>' . __('Title: ', 'linkilo') . '</b>' . esc_attr($phrase->suggestions[0]->post->getTitle()) . '<br>'; ?>
                    <?php echo '<b>' . __('Type: ', 'linkilo') . '</b>' . $phrase->suggestions[0]->post->getType() . '<br>'; ?>
                    <?php echo (!empty($categories)) ? '<b>' . _n(__('Category: ', 'linkilo'), __('Categories: ', 'linkilo'), $found) . '</b>' . $categories : ''; ?>
                    <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($phrase->suggestions[0]->post_score).')':''; ?>
                    <br>

                    <?php echo '<b style="vertical-align: top;">' . __('Item Link:', 'linkilo') . '</b>'?>
                    <a class="post-slug incoming-slug" target="_blank" href="<?php echo $phrase->suggestions[0]->post->getLinks()->view; ?>">
                        <?php 
                        $decode_url = $phrase->suggestions[0]->post->getLinks()->view; 
                        echo urldecode($decode_url); 
                        ?>
                    </a>

                    <span class="linkilo_add_feed_url_to_ignore link-form-button"><a style="margin-left: 5px 0px;" href="javascript:void(0)"><?php echo _e(ucwords('add your own'), 'linkilo'); ?></a></span>
                </div>
            </td>
            <?php if($show_date){ ?>
                <td data-colname="<?php _e('Date Published', 'linkilo'); ?>">
                    <?php echo ($phrase->suggestions[0]->post->type=='post'?get_the_date('', $phrase->suggestions[0]->post->id):'not set'); ?>
                </td>
            <?php } ?>
        </tr>
    <?php endforeach; ?>
    <tr class="linkilo-no-posts-in-range" style="display:none">
        <td>No suggestions found</td>
    </tr>
<?php else : ?>
    <tr>
        <td>No suggestions found</td>
    </tr>
<?php endif; ?>
<script>
    var incoming_internal_link = '<?php echo $post->getLinks()->view;?>';
</script>