<div class="wrap linkilo-report-page linkilo_styles">
    <?php echo Linkilo_Build_Root::showVersion(); ?>
    <h1 class="wp-heading-inline">
        <?php _e('Update URL','linkilo'); ?>
    </h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <div id="linkilo_url_changer_table">
                    <form method="post" id="add_url_change_form">
                        <div method="post" style="float:left;">
                            <input type="text" name="old" placeholder="Old URL">
                            <input type="text" name="new" placeholder="New URL">
                            <input type="submit" value="Add URL" class="button-primary">
                        </div>
                    </form>
                    <div style="clear: both"></div>
                    <a href="javascript:void(0)" class="button-primary" id="linkilo_url_changer_reset_button" style="display: none; float:right;"><?php _e('Refresh Changed URL Report', 'linkilo'); ?></a>

                    <?php if (!$reset) : ?>
                        <div class="table url_replce">
                            <?php $table->display(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="progress" <?php echo $reset?'style="display:block;"':'' ?>>
                        <h4 class="linkilo_progress_panel_msg "><?php _e('Synchronizing your data..','linkilo'); ?></h4>
                        <div class="linkilo_progress_panel loader">
                            <div class="progress_count"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    var linkilo_url_changer_nonce = '<?=wp_create_nonce($user->ID . 'linkilo_url_changer')?>';
    var is_linkilo_url_changer_reset = <?=$reset?'true':'false'?>;
</script>

