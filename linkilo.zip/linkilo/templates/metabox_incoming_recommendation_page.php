<?php $same_category = !empty(get_user_meta(get_current_user_id(), 'linkilo_same_category_selected', true)) ? '&same_category=true': ''; ?>
<div class="wrap linkilo-report-page linkilo_styles" id="incoming_suggestions_page" data-id="<?php echo $post->id; ?>" data-type="<?php echo $post->type; ?>" data-page_type="<?php echo 'edit' ?>">
    <div class="linkilo_meta_box_row">
        <div class="linkilo_meta_box_column1">
            <span style="font-style: italic; font-size: 15px !important;font-weight: 550;">
                <?php _e("By default, Linkilo suggestions are based on your settings.", 'linkilo'); ?> 
                <a href="<?php echo admin_url('admin.php?page=linkilo_settings'); ?>" target="_blank"> 
                    <?php _e("Click here to go to settings.", 'linkilo'); ?> 
                </a>
                <br>
                <?php _e("OR", 'linkilo'); ?> 
                <br>                          
                <?php _e("Select the following criteria for link suggestions.", 'linkilo'); ?> 
            </span>
        </div>
        <div class="linkilo_meta_box_column2">
            <?php echo Linkilo_Build_Root::showVersion(); ?>
        </div>
    </div>
    <div>
        <div id="linkilo_link-articles" class="postbox">
            <div class="tbl-link-reports">
                <?php $user = wp_get_current_user(); ?>
                <div data-linkilo-ajax-container data-linkilo-ajax-container-url="<?php echo esc_url(admin_url('admin.php?page=linkilo&type=meta_incoming_suggestions_page_container&'.($post->type=='term'?'term_id=':'post_id=').$post->id.(!empty($user->ID) ? '&nonce='.wp_create_nonce($user->ID . 'linkilo_suggestion_nonce') : '')).Linkilo_Build_UrlRecommendation::getKeywordsUrl() . $same_category); ?>" data-linkilo-manual-suggestions="<?php echo ($manually_trigger_suggestions) ? 1: 0;?>" <?php echo ($manually_trigger_suggestions) ? 'style="display:none"': ''; ?>>
                    <div class='linkilo_progress_panel loader'>
                        <div class='progress_count' style='width: 100%'></div>
                    </div>
                    <div class="linkilo_progress_panel_center" >
                        <?php _e('Loading', 'linkilo'); ?> 
                    </div>
                </div>
                <div data-linkilo-page-incoming-links=1> </div>
            </div>
        </div>
    </div>
</div>