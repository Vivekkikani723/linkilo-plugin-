<div>
	<span style="font-size: 20px;font-weight: 500;"><?php _e('Overview','linkilo') ?></span>
	<table class="wp-list-table widefat fixed striped" id="tbl_link_analysis_overview">
		<thead>
			<tr>
				<th> 
					<?php echo ucfirst('internal links'); ?>
				</th>
				<th> 
					<?php echo ucfirst('external links'); ?>
				</th>
				<th> 
					<?php echo ucfirst('nofollow'); ?>
				</th>
				<th> 
					<?php echo ucfirst('sponsored link'); ?>
				</th>
				<th> 
					<?php echo ucfirst('open new tab'); ?>
				</th>
				<th> 
					<?php echo ucfirst('open same window'); ?>
				</th>
			</tr>
		</thead>
		<tbody data-tbody="analysis-overview">
			<tr>
				<td><?php echo $posts_internal_links_count; ?></td>
				<td><?php echo $posts_external_links_count; ?></td>
				<td><?php echo $posts_nofollow_links_count; ?></td>
				<td><?php echo $posts_sponsered_links_count; ?></td>
				<td><?php echo $posts_new_tab_links_count; ?></td>
				<td><?php echo $posts_same_tab_links_count; ?></td>
			</tr>
		</tbody>
	</table>
</div>

<div class="linkilo_anchor_analysis_wrap">
	<div style="margin-bottom: 5px;">
		<span style="font-size: 20px;font-weight: 500;"><?php _e('Analysis','linkilo') ?></span>
	</div>
	<table class="wp-list-table widefat fixed striped" id="tbl_link_analysis_list">
		<thead>
			<tr>
				<th> 
					<?php echo ucfirst('type'); ?>
				</th>
				<th> 
					<?php echo ucfirst('anchor'); ?>
				</th>
				<th> 
					<?php echo ucfirst('href'); ?>
				</th>
				<th> 
					<?php echo ucfirst('follow'); ?>
				</th>
				<th>
					<div class="linkilo-toggle-btn-wrap">
						<input type="checkbox" name="linkilo_check_all_toggle" class="linkilo-check-all-toggle" title="<?php _e('Check All', 'linkilo'); ?> ">
					</div>
					<button type="button" class="button button-primary" name="linkilo_save_attribute_changes" disabled="disabled" title="<?php _e('Update attributes of checked links' , 'linkilo'); ?>">
						<?php echo ucfirst('save changes'); ?>
					</button>
				</th>
			</tr>
		</thead>
		<tbody data-tbody="analysis-detailed-list">
			<?php if (sizeof($current_post_links_analysis) > 0): ?>
				<?php foreach ($current_post_links_analysis as $index => $link_data) :?>
					<tr>
						<td>
							<?php 
							echo ($link_data['internal'] == 1) ? ucfirst("internal") : ucfirst("external"); 
							?>
						</td>
						<td>
							<?php 
							echo !empty($link_data['anchor']) ? $link_data['anchor'] : ""; 
							?>
						</td>
						<td>
							<?php 
							if ($link_data['internal'] == 1) {
								// it is internal link and show path of it
								echo parse_url(urldecode($link_data['raw_url']),PHP_URL_PATH);
							}else{
								echo urldecode($link_data['raw_url']); 
							}
							?>
						</td>
						<td>
							<?php 
							echo ($link_data['nofollow'] == 1) ? ucfirst("nofollow") : ucfirst("follow");  
							?>
						</td>
						<td>
							<?php 
								// nofollow = 1
								// follow = 0
							$label = ($link_data['nofollow'] == 1) ? ucfirst("follow") : ucfirst("nofollow");

							$checkbox_val = ($link_data['nofollow'] == 1) ? 0 : 1;

							$attr_id_name = "linkilo_toggle_follow_" . $link_data['link_id'] . "_" . $link_data['post_id'];

							$row = $link_data['link_id'];

							$raw_url = base64_encode($link_data['raw_url']);
							$post_id = $link_data['post_id'];
							$anchor = base64_encode($link_data['anchor']);
							?>
							<div style="display:flex; flex-direction: row; justify-content: flex-start; align-items: center">
								<input 
								type="checkbox" 
								name="<?php echo $attr_id_name; ?>" 
								id="<?php echo $attr_id_name; ?>" 
								class="linkilo_toggle_follow_post_link" 
								value="<?php echo $checkbox_val; ?>" 
								data-id="<?php echo $row; ?>"
								data-url="<?php echo $raw_url; ?>"
								data-anchor="<?php echo $anchor; ?>"
								title="<?php _e("Check and click save changes to add rel='".$label."' attribute to this anchor tag." , 'linkilo'); ?>"
								/>
								<input type="hidden" id="linkilo_current_post" value="<?php echo $post_id; ?>">
								<label for="<?php echo $attr_id_name; ?>">
									<?php 
									echo esc_attr($label);
									?>
								</label>
							</div>
						</td>
					</tr>
				<?php endforeach; ?> 
			<?php else: ?>
				<tr>
					<td colspan="4">
						<?php _e(ucwords("no data to display"), 'linkilo'); ?>
					</td>
				</tr>
			<?php endif; ?>
		</tbody>
		<tfoot>
			<tr>
				<th> 
					<?php echo ucfirst('type'); ?>

				</th>
				<th> 
					<?php echo ucfirst('anchor'); ?>

				</th>
				<th> 
					<?php echo ucfirst('href'); ?>

				</th>
				<th>  
					<?php echo ucfirst('follow'); ?>

				</th>
				<th>
					<div class="linkilo-toggle-btn-wrap">
						<input type="checkbox" name="linkilo_check_all_toggle" class="linkilo-check-all-toggle" title="<?php _e('Check All', 'linkilo'); ?> ">
					</div>
					<button type="button" class="button button-primary" name="linkilo_save_attribute_changes" disabled="disabled" title="<?php _e('Update attributes of checked links' , 'linkilo'); ?>">
						<?php echo ucfirst('save changes'); ?>
					</button>
				</th>
			</tr>
		</tfoot>
	</table>
</div>