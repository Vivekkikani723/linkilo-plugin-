<div class="wrap linkilo-loading-screen">
    <h1 class="wp-heading-inline"><?php _e("Summary","linkilo"); ?></h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <div>
                    <h3>
                        <?php _e('Organizing your data...', 'linkilo'); ?> 
                    </h3>

                    <span class="linkilo-loading-status-message">
                        <?php _e('Please let this process run and do not close this tab until it is completed. <br> Otherwise you will need to perform the scan again.', 'linkilo'); ?>
                    </span>
                </div>
                <?php 
                // get if the user has enabled site interlinking
                $site_linking_enabled = get_option('linkilo_link_external_sites', false);
                if ($site_linking_enabled) {
                $sites = Linkilo_Build_ConnectMultipleSite::get_linked_sites(); 
                foreach($sites as $site){ ?>
                <div class="syns_div linkilo_report_need_prepare processing" data-linked-url="<?php echo esc_url($site); ?>" data-page="0" data-saved="0" data-total="0" data-nonce="<?php echo wp_create_nonce(wp_get_current_user()->ID . 'download-site-data-nonce'); ?>">
                    <h4 class="linkilo_progress_panel_msg"> 
                        <?php echo $site; ?> 
                    </h4>
                    <div class="linkilo_progress_panel">
                        <div class="progress_count" style="width: 0%">
                            <span class="linkilo-loading-status"></span>
                        </div>
                    </div>
                    <div class="linkilo_progress_panel_center" > Loading </div>
                </div>
                <?php } }?>
            </div>
        </div>
    </div>
</div>