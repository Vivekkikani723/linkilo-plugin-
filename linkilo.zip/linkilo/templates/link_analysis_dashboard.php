<main class="linkilo-anchor-report-main-div-wrapper">
    <div class="linkilo-anchor-report-container-main">
        <div class="linkilo-anchor-report-main-row">
            <!-- total-links-div -->
            <div class="linkilo-anchor-report-total-div-main-div">
                <div class="linkilo-anchor-report-total-links-main-div-inner">
                    <div class="linkilo-anchor-report-total-links-heading-upper">
                        <h6>
                            <?php _e('Total links', 'linkilo'); ?> 
                        </h6>
                        <p class="linkilo-anchor-report-number-data-total">
                            <?php echo $posts_total_links_count; ?>
                        </p>
                    </div>
                    <div class="linkilo-anchor-report-total-descripton-data">
                        <p>
                            <?php _e('Links listed on the Analyzed Page.', 'linkilo'); ?>
                        </p>
                        <p>
                            <?php _e('We include all Anchor tags and anchor Element.', 'linkilo'); ?> 
                        </p>
                    </div>
                </div>
                <div class="post-analysis-dashboard-row-wrapper">
                    <div class="post-analysis-dashboard-row-1">
                        <!-- Internal Links -->
                        <div class="linkilo-anchor-report-total-links-main-div-inner">
                            <div class="linkilo-anchor-report-total-links-heading-upper">
                                <h6>
                                    <?php _e('Internal links', 'linkilo'); ?>
                                </h6>
                                <p class="linkilo-anchor-report-number-data-total"> 
                                    <?php echo $posts_internal_links_count; ?> 
                                </p>
                            </div>
                        </div>
                        <!-- Internal Links -->

                        <!-- External Links -->
                        <div class="linkilo-anchor-report-total-links-main-div-inner">
                            <div class="linkilo-anchor-report-total-links-heading-upper">
                                <h6>
                                    <?php _e('External links', 'linkilo'); ?>
                                </h6>
                                <p class="linkilo-anchor-report-number-data-total"> 
                                    <?php echo $posts_external_links_count; ?> 
                                </p>
                            </div>
                        </div>
                        <!-- Internal Links -->

                        <!-- NoFollow Links -->
                        <div class="linkilo-anchor-report-total-links-main-div-inner">
                            <div class="linkilo-anchor-report-total-links-heading-upper">
                                <h6>
                                    <?php _e('Nofollow', 'linkilo'); ?>                            
                                </h6>
                                <p class="linkilo-anchor-report-number-data-total"> 
                                    <?php echo $posts_nofollow_links_count; ?> 
                                </p>
                            </div>
                        </div>
                        <!-- NoFollow Links -->
                    </div>
                    <div class="post-analysis-dashboard-row-1">
                        <!-- Sponsored Links -->
                        <div class="linkilo-anchor-report-total-links-main-div-inner">
                            <div class="linkilo-anchor-report-total-links-heading-upper">
                                <h6>
                                    <?php _e('Sponsored link', 'linkilo'); ?>
                                </h6>
                                <p class="linkilo-anchor-report-number-data-total"> 
                                    <?php echo $posts_sponsered_links_count; ?> 
                                </p>
                            </div>
                        </div>
                        <!-- Sponsored Links -->

                        <!-- Open new tab Links -->
                        <div class="linkilo-anchor-report-total-links-main-div-inner">
                            <div class="linkilo-anchor-report-total-links-heading-upper">
                                <h6>
                                    <?php _e('Open new tab', 'linkilo'); ?>
                                </h6>
                                <p class="linkilo-anchor-report-number-data-total"> 
                                    <?php echo $posts_new_tab_links_count; ?> 
                                </p>
                            </div>
                        </div>
                        <!-- Open new tab Links -->

                        <!-- Open same window Links -->
                        <div class="linkilo-anchor-report-total-links-main-div-inner">
                            <div class="linkilo-anchor-report-total-links-heading-upper">
                                <h6>
                                    <?php _e('Open same window', 'linkilo'); ?>
                                </h6>
                                <p class="linkilo-anchor-report-number-data-total"> 
                                    <?php echo $posts_same_tab_links_count; ?> 
                                </p>
                            </div>
                        </div>
                        <!-- Open same window Links -->
                    </div>
                </div>
            </div>
            <!-- total-links-div -->

            <!-- Internal Links-->
            <?php 
            if (sizeof($internal_rows) > 0):
                $anchor_rows = $internal_rows;
                $title = 'Internal list';
                $row_checkbox_class = 'linkilo_toggle_follow_post_link_internal';
                $tbl_chekall_toggle = 'linkilo_check_all_toggle_internal';
                $tbl_save_button = 'linkilo_save_attribute_changes_internal';

                $tbl_loader = 'anchor_dashboard_loader_internal';

                $tbl_id = "linkilo_anchor_dash_table_internal";
                $tbl_class = (sizeof($internal_rows) > 5) ? 'linkilo-anchor-analysis-dash-table overflow' : 'linkilo-anchor-analysis-dash-table';

                include LINKILO_PLUGIN_DIR_PATH . '/templates/post_analysis_dashboard_template.php';
            endif; 
            ?>
            <!-- Internal Links-->

            <!-- External Links-->
            <?php
            if (sizeof($external_rows) > 0):
                $anchor_rows = $external_rows;
                $title = 'External list';
                $row_checkbox_class = 'linkilo_toggle_follow_post_link_external';
                $tbl_chekall_toggle = 'linkilo_check_all_toggle_external';
                $tbl_save_button = 'linkilo_save_attribute_changes_external';

                $tbl_loader = 'anchor_dashboard_loader_internal';
                
                $tbl_id = "linkilo_anchor_dash_table_external";
                $tbl_class = (sizeof($external_rows) > 5) ? 'linkilo-anchor-analysis-dash-table overflow' : 'linkilo-anchor-analysis-dash-table';

                include LINKILO_PLUGIN_DIR_PATH . '/templates/post_analysis_dashboard_template.php';
            endif; 
            ?> 
            <!-- External Links-->
        </div>
    </div>
</main>