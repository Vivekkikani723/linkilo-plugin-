<div class="wrap linkilo-report-page linkilo_styles">
    <style type="text/css">
        <?php
        $sources = Linkilo_Build_FocusKeyword::get_active_keyword_sources();
        $num = count($sources);

        switch ($num) {
            case '6':
        ?>tr .linkilo-dropdown-column:nth-of-type(6n+5) .linkilo-content {
            width: calc(600% + 70px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+5) .update-post-keywords {
            width: calc(600% + 80px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+0) .linkilo-content {
            width: calc(600% + 70px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+0) .update-post-keywords {
            width: calc(600% + 80px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+1) .linkilo-content {
            width: calc(600% + 70px);
            position: relative;
            right: calc(200% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+1) .update-post-keywords {
            width: calc(600% + 80px);
            position: relative;
            right: calc(200% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+2) .linkilo-content {
            width: calc(600% + 70px);
            position: relative;
            right: calc(300% + 60px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+2) .update-post-keywords {
            width: calc(600% + 80px);
            position: relative;
            right: calc(300% + 60px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+3) .linkilo-content {
            width: calc(600% + 70px);
            position: relative;
            right: calc(400% + 80px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+3) .update-post-keywords {
            width: calc(600% + 80px);
            position: relative;
            right: calc(400% + 80px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+4) .linkilo-content {
            width: calc(600% + 190px);
            position: relative;
            right: calc(500% + 200px);
        }

        tr .linkilo-dropdown-column:nth-of-type(6n+4) .create-post-keywords {
            width: calc(600% + 200px);
            position: relative;
            right: calc(500% + 200px);
        }

        <?php
                break;
            case '5':
        ?>tr .linkilo-dropdown-column:nth-of-type(5n+0) .linkilo-content {
            width: calc(500% + 50px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+0) .update-post-keywords {
            width: calc(500% + 60px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+1) .linkilo-content {
            width: calc(500% + 50px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+1) .update-post-keywords {
            width: calc(500% + 60px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+2) .linkilo-content {
            width: calc(500% + 50px);
            position: relative;
            right: calc(200% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+2) .update-post-keywords {
            width: calc(500% + 60px);
            position: relative;
            right: calc(200% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+3) .linkilo-content {
            width: calc(500% + 50px);
            position: relative;
            right: calc(300% + 60px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+3) .update-post-keywords {
            width: calc(500% + 60px);
            position: relative;
            right: calc(300% + 60px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+4) .linkilo-content {
            width: calc(500% + 150px);
            position: relative;
            right: calc(400% + 160px);
        }

        tr .linkilo-dropdown-column:nth-of-type(5n+4) .create-post-keywords {
            width: calc(500% + 160px);
            position: relative;
            right: calc(400% + 160px);
        }

        <?php
                break;
            case '4':
        ?>tr .linkilo-dropdown-column:nth-of-type(4n+1) .linkilo-content {
            width: calc(400% + 30px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+1) .update-post-keywords {
            width: calc(400% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+2) .linkilo-content {
            width: calc(400% + 30px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+2) .update-post-keywords {
            width: calc(400% + 40px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+3) .linkilo-content {
            width: calc(400% + 30px);
            position: relative;
            right: calc(200% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+3) .update-post-keywords {
            width: calc(400% + 40px);
            position: relative;
            right: calc(200% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+4) .linkilo-content {
            width: calc(400% + 110px);
            position: relative;
            right: calc(300% + 120px);
        }

        tr .linkilo-dropdown-column:nth-of-type(4n+4) .create-post-keywords {
            width: calc(400% + 120px);
            position: relative;
            right: calc(300% + 120px);
        }

        <?php
                break;
            case '3':
        ?>tr .linkilo-dropdown-column:nth-of-type(3n+2) .linkilo-content {
            width: calc(300% + 10px);
        }

        tr .linkilo-dropdown-column:nth-of-type(3n+2) .update-post-keywords {
            width: calc(300% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(3n+3) .linkilo-content {
            width: calc(300% + 10px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(3n+3) .update-post-keywords {
            width: calc(300% + 20px);
            position: relative;
            right: calc(100% + 20px);
        }

        tr .linkilo-dropdown-column:nth-of-type(3n+1) .linkilo-content {
            width: calc(300% + 70px);
            position: relative;
            right: calc(200% + 80px);
        }

        tr .linkilo-dropdown-column:nth-of-type(3n+1) .create-post-keywords {
            width: calc(300% + 80px);
            position: relative;
            right: calc(200% + 80px);
        }

        <?php
                break;
            case '2':
        ?>tr .linkilo-dropdown-column:nth-of-type(2n+1) .linkilo-content {
            width: calc(200% - 10px);
            position: relative;
            right: 0;
        }

        tr .linkilo-dropdown-column:nth-of-type(2n+1) .update-post-keywords {
            width: 200%;
        }

        tr .linkilo-dropdown-column:nth-of-type(2n+2) .linkilo-content {
            width: calc(200% + 30px);
            position: relative;
            right: calc(100% + 40px);
        }

        tr .linkilo-dropdown-column:nth-of-type(2n+2) .create-post-keywords {
            width: calc(200% + 40px);
            position: relative;
            right: calc(100% + 40px);
        }

        <?php
                break;
            case '1':
        ?>.column-custom .linkilo-content {
            width: calc(100% - 10px);
        }

        .column-custom .create-post-keywords {
            width: 100%;
        }

        <?php
                break;
        }
        ?>
    </style>
    <?php echo Linkilo_Build_Root::showVersion(); ?>
    <h1 class="wp-heading-inline"><?php _e('Focus Keyword', 'linkilo'); ?></h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <?php include_once 'records_tabs.php'; ?>
                <div id="linkilo_focus_keyword_table">
                    <form>
                        <input type="hidden" name="page" value="linkilo_focus_keywords" />
                        <?php $table->search_box('Search', 'search'); ?>
                    </form>
                    <div style="clear: both"></div>
                    <input type="hidden" id="linkilo_focus_keyword_gsc_authenticated" value="<?php echo (Linkilo_Build_GscAppConsole::linkilo_app_console_check_authorized()) ? 1 : 0; ?>">
                    <input type="hidden" id="linkilo_focus_keyword_reset_notice" value="<?php _e('Please confirm refreshing the focus keywords. If you\'ve authenticated the connection to Google Search Console, this will refresh the keyword data.', 'linkilo'); ?>">
                    <input type="hidden" id="linkilo_focus_keyword_gsc_not_authtext_a" value="<?php _e('Linkilo can not connect to Google Search Console because it has not been authorized yet.', 'linkilo'); ?>">
                    <input type="hidden" id="linkilo_focus_keyword_gsc_not_authtext_b" value="<?php _e('Please go to the Linkilo Settings and authorize access.', 'linkilo'); ?>">
                    <div class="linkilo_help" style="float:right">
                        <i class="dashicons dashicons-editor-help"></i>
                        <div><?php _e('Clicking Refresh Focus Keyword will clear and re-import any Yoast or Rank Math keywords, and all inactive Google Search Console keywords. If you have just installed Linkilo, authorized the GSC connect, or don\'t see Yoast/Rank Math keywords, please click this button.', 'linkilo'); ?></div>
                    </div>

                    <a href="javascript:void(0)" class="button-primary" id="linkilo_focus_keyword_reset_button"><?php _e('Perform Scan', 'linkilo'); ?></a>

                    <div class="alignright actions bulkactions" id="linkilo_comparison_table_filter">
                        <select name="keyword_comparison">
                            <option value="7"><?php _e('7 days', 'linkilo'); ?></option>
                            <option value="15"><?php _e('14 days', 'linkilo'); ?></option>
                            <option value="30"><?php _e('1 month', 'linkilo'); ?></option>
                            <option value="90"><?php _e('3 months', 'linkilo'); ?></option>
                            <option value="180"><?php _e('6 months', 'linkilo'); ?></option>
                        </select>
                    </div>
                    <div class="pop">
                        <label for="linkilo_focus_keyword_bulk_add_button" id="linkilo_focus_keyword_bulk_add_label" class="open btn button-primary"><?php _e('Bulk Import keywords', 'linkilo'); ?></label>
                        <input type="checkbox" id="linkilo_focus_keyword_bulk_add_button" class="hidden_c" />
                        <div class="modal">
                            <div class="modal__inner">
                                <div class="close_d">
                                    <div class="key_b"><img src="<?php echo LINKILO_PLUGIN_DIR_URL; ?>images/imp.svg" alt="import_keywords">
                                        <p class="key_w">Import Keywords</p>
                                    </div>
                                </div>
                                <div class="cross"><label for="linkilo_focus_keyword_bulk_add_button" class="linkilo_focus_keyword_bulk_close_button"><img src="<?php echo LINKILO_PLUGIN_DIR_URL; ?>images/close-outline.svg" class="w-6" alt=""></label></div>
                                <div class="main">
                                    <div class="inner_main">
                                        <form enctype="multipart/form-data">
                                            <label class="f_label">
                                                <div class="text_holder">
                                                    <span class="s_text">Slelect CSV/XLSX file</span>
                                                </div>
                                                <input type="file" accept=".csv" name="file" id="choose_file">
                                            </label>
                                            <label for="linkilo_bulk_upload_keywords_first_row" class="w-full" style="margin-top: 10px; max-width: 19rem">
                                                <input type="checkbox" name="linkilo_bulk_upload_keywords_first_row" id="linkilo_bulk_upload_keywords_first_row"> Use first row as header
                                            </label>
                                        </form>
                                        <a href="<?php echo LINKILO_PLUGIN_DIR_URL; ?>keywords.csv" class="f_an underline text-sm mt-4 font-semibold">Need help? Download a template here.</a>
                                    </div>
                                    <div class="button_holder">
                                        <label for="linkilo_focus_keyword_bulk_add_button" class="linkilo_focus_keyword_bulk_close_button btn-close">Cancel</label>
                                        <button for="Upload" id="Upload1" class="linkilo-bulk-upload-focus-keywords btn-close" style="padding: 8px 24px!important;" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'bulk-upload-focus-keywords-0'); ?>" data-page="focus_keywords" data-post-id="0" data-post-type="all">Upload</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if (!$reset) : ?>
                        <div class="table">
                            <?php $table->display(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="progress focus_keyword_table" <?php echo $reset ? 'style="display:block"' : ''; ?>>
                        <h4 class="linkilo_progress_panel_msg" style="font-size: 15px;"><?php _e('Synchronizing your data..', 'linkilo'); ?></h4>
                        <div class="linkilo_progress_panel loader">
                            <div class="progress_count"></div>
                        </div>
                        <div class="linkilo_progress_panel_center"> Loading </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script>
        var linkilo_focus_keyword_nonce = '<?php echo wp_create_nonce($user->ID . 'linkilo_focus_keyword'); ?>';
        var is_linkilo_focus_keyword_reset = <?php echo $reset ? 'true' : 'false'; ?>;
        var admin_url = '<?php echo admin_url(); ?>';
    </script>