<div class="linkilo-anchor-report-links-div-data">
	<div class="linkilo-anchor-report-main-row">
		<div class="linkilo-anchor-report-links-div-connecting-main-div">
			<div class="linkilo-anchor-report-internal-links-list">
				<div class="linkilo-anchor-report-heading-div-list">
					<h6>
						<?php _e($title, 'linkilo'); ?>
					</h6>
				</div>
				<div class="linkilo-anchor-report-internal-links-main-table">
					<table class="<?php echo $tbl_class; ?>" id="<?php echo trim($tbl_id); ?>">
						<thead>
							<tr>
								<th>
									<?php echo ucfirst('anchor'); ?>
								</th>
								<th>
									<?php echo ucfirst('href'); ?>
								</th>
								<th>
									<?php echo ucfirst('follow'); ?>
								</th>
								<th>
									<div class="linkilo-toggle-btn-wrap">
										<input type="checkbox" name="<?php echo $tbl_chekall_toggle; ?>" class="linkilo-check-all-toggle" data-row="<?php echo trim($row_checkbox_class); ?>" data-save-btn="<?php echo trim($tbl_save_button); ?>" title="<?php _e('Check All', 'linkilo'); ?> ">
									</div>
									<button type="button" class="button button-primary" name="<?php echo trim($tbl_save_button); ?>" data-row="<?php echo trim($row_checkbox_class); ?>" data-tbl="<?php echo trim($tbl_id); ?>" data-tbl-loader="<?php echo trim($tbl_loader); ?>" disabled="disabled" title="<?php _e('Update attributes of checked links' , 'linkilo'); ?>">
										<?php echo ucfirst('save changes'); ?>
									</button>
								</th>
							</tr>
						</thead>
						<tbody> 
							<?php foreach ($anchor_rows as $index => $link_data): ?>
								<tr class="linkilo-anchor-report-list-div">
									<td>
										<span class="anchor-analysis-text-td">
											<?php echo trim($link_data['anchor']); ?> 
										</span> 
									</td>
									<td>
										<span class="anchor-analysis-link-td">
											<?php echo trim(urldecode($link_data['raw_url'])); ?>
										</span>
									</td>
									<td> 
										<?php echo ($link_data['nofollow'] == 1) ? ucfirst("nofollow") : ucfirst("follow"); ?>
									</td>
									<td> 
										<?php
										// nofollow = 1
										// follow = 0
										$label = ($link_data['nofollow'] == 1) ? ucfirst("follow") : ucfirst("nofollow");

										$title_att_text = "Check and click save changes to add rel='";
										$title_att_text .= ($link_data['nofollow'] == 1)?'dofollow':'nofollow';
										$title_att_text .= "' attribute to this link.";

										$checkbox_val = ($link_data['nofollow'] == 1) ? 0 : 1;
										$attr_id_name = "linkilo_toggle_follow_" . $link_data['link_id'] . "_" . $link_data['post_id'];
										$row = $link_data['link_id'];
										$raw_url = base64_encode($link_data['raw_url']);
										$post_id = $link_data['post_id'];
										$anchor = base64_encode($link_data['anchor']);
										?> 
										<div style="display:flex; flex-direction: row; justify-content: flex-start; align-items: center">
											<input 
											type="checkbox" 
											name="<?php echo $attr_id_name; ?>" 
											id="<?php echo $attr_id_name; ?>" 
											class="<?php echo $row_checkbox_class; ?>" 
											value="<?php echo $checkbox_val; ?>" 
											data-id="<?php echo $row; ?>"
											data-url="<?php echo $raw_url; ?>"
											data-anchor="<?php echo $anchor; ?>"
											data-tbl-checkbox="<?php echo $tbl_chekall_toggle; ?>"
											data-tbl-save-btn="<?php echo trim($tbl_save_button); ?>"
											title="<?php _e($title_att_text , 'linkilo'); ?>"
											/>

											<input type="hidden" id="linkilo_current_post" value="<?php echo $post_id; ?>">
											<label for="<?php echo $attr_id_name; ?>"> 
												<?php echo esc_attr($label); ?> 
											</label>
										</div>
									</td>
								</tr> 
							<?php endforeach; ?>
						</tbody>
						<tfoot class="linkilo-anchor-ftr">
							<tr>
								<th>
									<?php echo ucfirst('anchor'); ?>
								</th>
								<th>
									<?php echo ucfirst('href'); ?>
								</th>
								<th>
									<?php echo ucfirst('follow'); ?>
								</th>
								<th>
									<div class="linkilo-toggle-btn-wrap">
										<input type="checkbox" name="<?php echo $tbl_chekall_toggle; ?>" class="linkilo-check-all-toggle" data-row="<?php echo trim($row_checkbox_class); ?>" data-save-btn="<?php echo trim($tbl_save_button); ?>" title="<?php _e('Check All', 'linkilo'); ?> ">
									</div>
									<button type="button" class="button button-primary" name="<?php echo trim($tbl_save_button); ?>" data-row="<?php echo trim($row_checkbox_class); ?>" data-tbl="<?php echo trim($tbl_id); ?>" data-tbl-loader="<?php echo trim($tbl_loader); ?>" disabled="disabled" title="<?php _e('Update attributes of checked links' , 'linkilo'); ?>">
										<?php echo ucfirst('save changes'); ?>
									</button>
								</th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div> 
	</div>
</div>