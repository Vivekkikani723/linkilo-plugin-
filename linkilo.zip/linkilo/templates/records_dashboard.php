<?php
// anchor variables
$dashboard_page = admin_url('admin.php?page=linkilo');
$add_urls_page = admin_url('admin.php?page=linkilo&type=links');
$domain_list_page = admin_url('admin.php?page=linkilo&type=domains');

$dasboard_active = "";
$add_urls_active = "";
$domain_list_active = "";

if (
    isset( $_GET['page'] ) && !empty( trim( $_GET['page'] ) ) && 
    isset( $_GET['type'] ) && !empty( trim( $_GET['type'] ) ) 
) {
    // apply class active according to page and type
    if ( $_GET['type'] === "link" ) {
        $add_urls_active = 'active';
    }

    if ( $_GET['type'] === "domains" ) {
        $domain_list_active = 'active';
    }
}

if (
    isset( $_GET['page'] ) && 
    !empty( trim( $_GET['page'] ) ) && 
    $_GET['page'] === 'linkilo' &&
    !isset( $_GET['type'] )
) {
    $dasboard_active = 'active';
}

// filter_settings starts 
// get any filter settings from the user's report selection and apply the settings to the Link Report tab url
$filter_settings = get_user_meta(get_current_user_id(), 'linkilo_filter_settings', true);
$filter_vars = '';

if( LINKILO_STATUS_HAS_RUN_SCAN ) {
    if(isset($filter_settings['report'])){
        $filtering = array();
        if(isset($filter_settings['report']['post_type']) && !empty($filter_settings['report']['post_type'])){
            $filtering['post_type'] = $filter_settings['report']['post_type'];
        }

        if(isset($filter_settings['report']['category']) && !empty($filter_settings['report']['category'])){
            $filtering['category'] = $filter_settings['report']['category'];
        }

        if(isset($filter_settings['report']['location']) && !empty($filter_settings['report']['location'])){
            $filtering['location'] = $filter_settings['report']['location'];
        }

        if(!empty($filtering)){
            $filter_vars = '&' . http_build_query($filtering);
        }
    }

    $add_urls_page .= $filter_vars;
}
?>
<div class="page-container">
    <div class="page-content">
        <div class="page-inner no-page-title">
            <!-- heading -->
            <div id="main-wrapper">
                <div class="content-header">
                    <h1 class="page-title">
                        <!-- Page Title -->
                        <?php _e( intval( LINKILO_STATUS_HAS_RUN_SCAN ) ? "Summary" : "Initial Setup", 'linkilo'); ?>  
                        <!-- Page Title -->
                    </h1>
                    <h4 class="version-main float-right">
                        <?php echo Linkilo_Build_Root::showVersion();?>
                    </h4>
                </div>
                <!-- heading close -->
                <!-- Navigation -->
                <?php include_once 'records_tabs.php'; ?>
                <!-- Navigation -->

                <?php if(LINKILO_STATUS_HAS_RUN_SCAN ) : ?>
                    <!-- Data -->
                    <?php include_once 'dashboard_template_default.php'; ?>
                    <!-- Data -->
                <?php else : ?>
                    <!-- welcome message -->
                    <?php //include_once 'dashboard_welcome.php'; ?>
                    <?php include_once 'dashboard_wizard.php'; ?>
                    <!-- welcome message -->
                <?php endif; ?>
            </div><!-- Main Wrapper -->
        </div>
    </div>
</div>