<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>

</head>
<body>
	<div class="linkilo-welcome-section">
		<div class="linkilo-welcome-inner">
			<div class="linkilo-welcome-left">
				<!-- <h1>Welcome to <br><span>Linkilo!</span></h1> -->
				<h4>Welcome to Linkilo! </h4>
				<p>Before we dive in, we need to perform an initial setup to tailor Linkilo to your needs. <br>Please click.&nbsp;<span style="font-weight:600;">'Run Scan'</span></p>
				<h4>What does this do?</h4>
				<p>Well, Linkilo carries out a comprehensive crawl and scan of your site to identify opportunities for internal linking, analyze link metrics, and unlock a range of advanced features.</p>
				<p>This includes checking for any errors and many more functionalities that we've designed just for you.</p>
				<!-- Important form to process on very first setup of plugin -->
				
				<!-- Important form to process on very first setup of plugin -->

			</div>
			<div class="linkilo-welcome-right">
				<div class="linkilo-welcome-right-vector">
					<img src="<?php echo LINKILO_PLUGIN_DIR_URL.'images/dashboard/pngvector.png'; ?>">
				</div>
			</div>
		</div>
		<div class="linkilo-third-welcome-note">
			<h5>If you've already initiated a scan, kindly wait for it to finish.</h5>
			<p>In case you had to exit prematurely, please start a new scan. This process ensures that our database is updated accurately, and don't worry, none of your settings will be impacted.</p>
			<br>
			<p>Get started with Linkilo today, and unlock the power of seamless linking!</p>
		</div>
	</div>      
</body>
</html>