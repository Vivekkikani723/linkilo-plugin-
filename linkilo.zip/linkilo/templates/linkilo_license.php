<?php
/**
 * This file is a template file of license checking page
 * */

// get the license status data
$license    = get_option(LINKILO_LICENSE_KEY_OPTION, '');
$status     = get_option(LINKILO_STATUS_OF_LICENSE_OPTION);
$last_error = get_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, '');
$last_state = get_option('linkilo_license_error_state', '');

// get the current licensing state
$licensing_state;
if(empty($license) && empty($last_error) || ('invalid' === $status && 'Deactivated manually' === $last_error)){
    $licensing_state = 'not_activated';
}elseif(!empty($license) && 'valid' === $status){
    $licensing_state = 'activated';
}elseif(!empty($license) && 'inactive' === $status){
    $licensing_state = 'not_activated';
}elseif(!empty($license) && 'site_inactive' === $status){
    $licensing_state = 'not_activated';
}elseif(!empty($license) && 'expired' === $status){
    $licensing_state = 'not_activated';
}else{
    $licensing_state = 'error';
}

if ($last_state === "state_1") {
    update_option('linkilo_license_error_state', 'state_2');
}

if ($last_state === "state_2") {
    $licensing_state = 'not_activated';
    delete_option(LINKILO_LICENSE_CHECK_TIME_OPTION);
    delete_option(LINKILO_STATUS_OF_LICENSE_OPTION);
    delete_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION);
    delete_option('linkilo_license_error_state');
    delete_option(LINKILO_LICENSE_KEY_OPTION);
    delete_option(LINKILO_CURRENT_LICENSE_DATA_OPTION);
    delete_option('linkilo_2_license_activation');
    delete_option('linkilo_2_license_next_check');
}elseif (!$last_state && $licensing_state === "error" && !empty($last_error)) {
    delete_option(LINKILO_LICENSE_CHECK_TIME_OPTION);
    delete_option(LINKILO_STATUS_OF_LICENSE_OPTION);
    delete_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION);
    delete_option('linkilo_license_error_state');
    delete_option(LINKILO_LICENSE_KEY_OPTION);
    delete_option(LINKILO_CURRENT_LICENSE_DATA_OPTION);
    delete_option('linkilo_2_license_activation');
    delete_option('linkilo_2_license_next_check');
}

// create titles for the license statuses
$status_titles   = array(
    'not_activated' => __('License Not Active', 'linkilo'),
    'activated'     => __('License Active', 'linkilo'),
    'error'         => __('Activation Error', 'linkilo')
);

// create some helpful text to tell the user what's going on
$status_messages = array(
    'not_activated' => __('Please enter your Linkilo License Key to activate Linkilo.', 'linkilo'),
    'activated'     => __('Congratulations! Your Linkilo License Key has been confirmed and Linkilo is now active!', 'linkilo'),
    'error'         => $last_error
);
?>
<div class="wrap linkilo_styles" id="licensing_page">
    <?php //echo Linkilo_Build_Root::showVersion(); ?>
    <div class='version-main' style='float: right;font-size: 1.5rem; font-family: Rubik, sans-serif;margin-top: 20px;margin-right:50px;'><span  ><?php _e('Version ', 'linkilo'); ?><b> <?php echo LINKILO_PLUGIN_VERSION ?></b></span></div>
    <h1 class="wp-heading-inline">
        <?php echo ucwords( __('Initial Setup', 'linkilo') );?>
    </h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <h2 class="nav-tab-wrapper" style="margin-bottom:10px;">
                <a class="nav-tab nav-tab-active" id="linkilo-licensing" href="#"><?php _e('INITIAL SETUP', 'linkilo'); ?></a>
            </h2>
    </div>
            <section>
                <div class="linkilo_wizard_container">
                <div class="linkilo_wizard_main-content">
                    <div class=" linkilo_wizard_ustify_content_center">
                    <div class="col-lg-7 col-md-8">
                        <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                        <symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                        </symbol>
                        </svg>
                    </div>
                    </div>
                    <div class=" linkilo_wizard_ustify_content_center " id="wizardRow limkilo_wizard_row">
                    <div class="text-center">
                        <div class="wizard-form py-4 my-2">
                        <ul id="progressBar" class="progressbar px-lg-5 px-0 linki_wizard_license">
                            <li id="progressList-1"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list  active" data-step="1">
                            <?php _e('Licensing', 'linkilo'); ?></li>
                            <li id="progressList-2"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="2">
                            <?php _e('Global Setting', 'linkilo'); ?></li>
                            <li id="progressList-3"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="3">
                            <?php _e('Google Search Console', 'linkilo'); ?></li>
                            <?php
                                if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                                {         
                                    if( defined('RANK_MATH_VERSION') && !defined('WPSEO_VERSION'))
                                    {
                                        ?>
                                        <li id="progressList-4"
                                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="4">
                                        <?php _e('Rankmath Configuration', 'linkilo'); ?></li>
                                    <?php
                                    }
                                    else if( !defined('RANK_MATH_VERSION') && defined('WPSEO_VERSION'))
                                    {
                                        ?>
                                        <li id="progressList-4"
                                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="4">
                                        <?php _e('Yoast Configuration', 'linkilo'); ?></li>
                                        <?php
                                    }
                                    else if(defined('RANK_MATH_VERSION') && defined('WPSEO_VERSION'))
                                    {
                                        ?>
                                        <li id="progressList-4"
                                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="4">
                                        <?php _e('Rankmath/Yoast', 'linkilo'); ?></li>
                                        <?php
                                    }
                                    ?>
                                <?php

                                }
                                if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
                                {
                                    if( defined('AIOSEO_DIR') && !defined('SQ_VERSION') || defined('AIOSEO_PLUGIN_DIR') && !defined('SQ_VERSION'))
                                    {
                                        ?>
                                        <li id="progressList-5"
                                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="6">
                                        <?php _e('AIOSEO Configuration', 'linkilo'); ?></li> 
                                    <?php
                                    }
                                    else if( !defined('AIOSEO_DIR') && !defined('AIOSEO_PLUGIN_DIR') && defined('SQ_VERSION') )
                                    {
                                        ?>
                                        <li id="progressList-5"
                                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="6">
                                        <?php _e('Squirrly Configuration', 'linkilo'); ?></li>
                                        <?php
                                    }
                                    else if(defined('AIOSEO_DIR') && defined('SQ_VERSION') || defined('AIOSEO_PLUGIN_DIR') && defined('SQ_VERSION'))
                                    {
                                        ?>
                                        <li id="progressList-5"
                                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="6">
                                        <?php _e('All in One Seo/Squirrly', 'linkilo'); ?></li>
                                        <?php
                                    }
                                }
                                if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
                                {
                                    ?>

                                    <li id="progressList-6"
                                    class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="5">
                                    <?php _e('Link Design', 'linkilo'); ?></li>
                                    <?php
                                }
                                else
                                {
                                    ?>

                                    <li id="progressList-5"
                                    class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list" data-step="5">
                                    <?php _e('Link Design', 'linkilo'); ?></li>
                            <?php
                                }
                                if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
                                {
                                    ?>

                                        <li id="progressList-7"
                                    class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list">
                                    <?php _e('Welcome', 'linkilo'); ?></li>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                    <li id="progressList-6"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list linki_license_wizard_prog_list">
                            <?php _e('Welcome', 'linkilo'); ?></li>
                            <?php
                                }
                                ?>
                        </ul>
                        </div>
                    </div>
                    </div>
                    
                    </div>
                </div>
             </section>
            <div id="post-body-content" style="position: relative;">
                <div class="linkilo_licensing_background">
                    <div class="wrap linkilo_licensing_wrap postbox">
                        <div class="linkilo_licensing_container">
                            <div class="linkilo_licensing" style="">
                                <h2 class="linkilo_licensing_header hndle ui-sortable-handle">
                                    <span>Linkilo Licensing</span>
                                </h2>
                                <div class="linkilo_licensing_content inside">
                                    <form method="post">
                                        <?php settings_fields('linkilo_license'); ?>
                                        <input type="hidden" name="hidden_action" value="activate_license">
                                        <table class="form-table">
                                            <tbody>
                                                <tr>
                                                    <td class="linkilo_license_table_title" style="font-size: 18px !important;"><?php _e('License Key:', 'linkilo');?></td>
                                                    <td>    
                                                        <input 
                                                            id="linkilo_license_key"
                                                            name="linkilo_license_key" 
                                                            type="text"
                                                            placeholder="<?php echo _e(ucwords('enter your license key'), 'linkilo'); ?>" 
                                                            class="regular-text" 
                                                            value="" 
                                                            required
                                                            autocomplete="off" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="linkilo_license_table_title" style="font-size: 18px !important;"><?php _e('License Status:', 'linkilo');?></td>
                                                    <td><span class="linkilo_licensing_status_text <?php echo esc_attr($licensing_state); ?>"><?php echo esc_attr($status_titles[$licensing_state]); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td class="linkilo_license_table_title" style="font-size: 18px !important;"><?php _e('License Message:', 'linkilo');?></td>
                                                    <td><p class="linkilo_licensing_status_text <?php echo $licensing_state; ?>"><?php echo ucwords($status_messages[$licensing_state]); ?></p></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <?php wp_nonce_field( 'linkilo_activate_license_nonce', 'linkilo_activate_license_nonce' ); ?>
                                        <button type="submit" class="button button-primary linkilo_licensing_activation_button">
                                            <?php _e('Activate License', 'linkilo'); ?> 
                                        </button>
                                        <div class="linkilo_licensing_version_number">
                                            <?php echo Linkilo_Build_Root::showVersion(); ?> 
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!--/frmSaveSettings-->
            </div>
        </div>
   
</div>