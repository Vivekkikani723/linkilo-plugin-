<form method="post" action="">
    <div id="linkilo-incoming-suggestions-head-controls">
        <div style="margin-bottom: 15px;">
            <div>
                
            <input type="checkbox" style="margin:0px !important" name="same_category" id="field_same_category" <?php echo (isset($same_category) && !empty($same_category)) ? 'checked' : ''; ?>> 
            <label for="field_same_category">
                <?php _e('Show Links Based on Category', 'linkilo'); ?> 
            </label>
            </div>
            <!-- <br> -->
            <div>
                
            <input type="checkbox" style="margin:0px !important" name="same_tag" id="field_same_tag" <?php echo !empty($same_tag) ? 'checked' : ''; ?>> 
            <label for="field_same_tag">
                <?php _e('Show Links Based on Tags', 'linkilo'); ?> 
            </label>
            </div>

            <div>
            <input type="checkbox" style="margin:0px !important" name="same_title_chk" id="field_same_title_chk_in_metabox" <?php echo $same_title_option_checked_meta; ?> data-post_title_chk_in_meta = "<?php echo get_the_title( $post->id ); ?>"> 
            <label for="field_same_title_chk_in_metabox">
                <?php _e('Show Links Based on Title Tags', 'linkilo'); ?> 
            </label>
            </div>

            <div>   
            <input type="checkbox" style="margin:0px !important" name="exact_match_keyword_in_meta" id="exact_match_keyword_post_in_metabox" <?php echo $exact_match_keyword_checked_in_meta; ?>> 
            <label for="exact_match_keyword_post_in_metabox"> 
                <?php _e('Show Links Based on Exact Match Keywords', 'linkilo'); ?> 
            </label>
            </div>
            <div>
                
            <input type="checkbox" style="margin:0px !important" name="exact_match_url" id="exact_match_url_slug_in_metabox" <?php echo $exact_match_slug_checked_in_meta; ?>>
            <label for="exact_match_url_slug_in_metabox">
                <?php _e('Show Links Based on URL','linkilo'); ?> 
            </label>
            </div>
            <?php if (!empty($phrases)){ ?>
                <div>
                    <label for="linkilo-incoming-daterange" style="font-weight: bold; font-size: 16px !important; margin: 18px 0 8px; display: block; display: inline-block;">
                        <?php _e('Show Links Based On Published Date', 'linkilo'); ?> 
                    </label> 
                    <br/>
                    <input id="linkilo-incoming-daterange" type="text" name="daterange" class="linkilo-date-range-filter" value="<?php echo '01/01/2000 - ' . date('m/d/Y', strtotime('today')); ?>" style="width: 180px;text-align: center;">
                </div>
                <script>
                    var sentences = jQuery('.linkilo-incoming-sentence');
                    jQuery('#linkilo-incoming-daterange').on('apply.daterangepicker, hide.daterangepicker', function(ev, picker) {
                        jQuery(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
                        var start = picker.startDate.unix();
                        var end = picker.endDate.unix();

                        sentences.each(function(index, element){
                            var elementTime = jQuery(element).data('linkilo-post-published-date');
                            if(!start || (start < elementTime && elementTime < end)){
                                jQuery(element).css({'display': 'table-row'});
                            }else{
                                jQuery(element).css({'display': 'none'}).find('input.chk-keywords').prop('checked', false);
                            }
                        });
                    
                        // handle the results of hiding any posts
                        handleHiddenPosts();
                    });

                    jQuery('#linkilo-incoming-daterange').on('cancel.daterangepicker', function(ev, picker) {
                        jQuery(this).val('');
                        sentences.each(function(index, element){
                            jQuery(element).css({'display': 'table-row'});
                        });
                    });

                    jQuery('#linkilo-incoming-daterange').daterangepicker({
                        autoUpdateInput: false,
                        linkedCalendars: false,
                        locale: {
                            cancelLabel: 'Clear'
                        }
                    });

                    /**
                     * Handles the table display elements when the date range changes
                     **/
                    function handleHiddenPosts(){
                        if(jQuery('.incoming-checkbox:visible').length < 1){
                            // hide the table elements
                            jQuery('.wp-list-table thead, #incoming_suggestions_button, #incoming_suggestions_button_2').css({'display': 'none'});
                            // make sure the "Check All" box is unchecked
                            jQuery('.incoming-check-all-col input').prop('checked', false);
                            // show the "No matches" message
                            jQuery('.linkilo-no-posts-in-range').css({'display': 'table-row'});
                        }else{
                            // show the table elements
                            jQuery('.wp-list-table thead').css({'display': 'table-header-group'});
                            jQuery('#incoming_suggestions_button, #incoming_suggestions_button_2').css({'display': 'inline-block'});
                            // hide the "No matches" message
                            jQuery('.linkilo-no-posts-in-range').css({'display': 'none'});
                        }
                    }
                </script>
            <?php } ?>
            <?php if ($same_category && !empty($categories)) : ?>
                <br>
                <select name="linkilo_selected_category">
                    <option value="0"><?php _e('All categories', 'linkilo'); ?></option>
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?php echo $category->term_id; ?>" <?php echo $category->term_id==$selected_category?'selected':'';?>> 
                            <?php echo $category->name; ?> 
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>
            <?php if ($same_tag && !empty($tags)) : ?>
                <br>
                <select name="linkilo_selected_tag">
                    <option value="0">All tags</option>
                    <?php foreach ($tags as $tag) : ?>
                        <option value="<?php echo $tag->term_id; ?>" <?php echo  $tag->term_id==$selected_tag?'selected':''; ?>>
                            <?php echo $tag->name; ?> </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>
            <br>
        </div>
        <?php if (!empty($phrases)) { ?>
            <button id="incoming_suggestions_button" class="sync_linking_keywords_list button-primary cst-btn-clr" data-id="<?php echo esc_attr($post->id); ?>" data-type="<?php echo esc_attr($post->type); ?>" data-page="incoming"> 
                <?php _e(strtoupper('Save Changes'), 'linkilo'); ?> 
                <span class="dashicons dashicons-arrow-right-alt2" style="margin-top: 3px;font-size: 21px;"></span>
            </button>
        <?php } ?>
        <?php $same_category = !empty(get_user_meta(get_current_user_id(), 'linkilo_same_category_selected', true)); ?>
    </div>
    <?php require LINKILO_PLUGIN_DIR_PATH . 'templates/metabox_table_incoming_recommendations.php'; ?>
    <?php if (!empty($phrases)) { ?>
        <button id="incoming_suggestions_button_2" class="sync_linking_keywords_list button-primary cst-btn-clr" data-id="<?php echo esc_attr($post->id); ?>" data-type="<?php echo esc_attr($post->type); ?>" data-page="incoming"> 
            <?php _e(strtoupper('Save Changes'), 'linkilo'); ?>
            <span class="dashicons dashicons-arrow-right-alt2" style="margin-top: 3px;font-size: 21px;"></span>
        </button>
    <?php } ?>
</form>