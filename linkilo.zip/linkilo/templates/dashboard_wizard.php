<!DOCTYPE html>
<html>
<head>

</head>
<body>
     <section>
    <div class="linkilo_wizard_container">
      <div class="linkilo_wizard_main-content">
        <div class=" linkilo_wizard_ustify_content_center">
          <div class="col-lg-7 col-md-8">
            <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
              <symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
              </symbol>
            </svg>
          </div>
        </div>
        <div class=" linkilo_wizard_ustify_content_center " id="wizardRow">
          <div class="text-center">
            <div class="wizard-form py-4 my-2">
              <ul id="progressBar" class="progressbar px-lg-5 px-0">
                <li id="progressList-1"
                  class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list  active" data-step="1">
                  <?php _e('Licensing', 'linkilo'); ?></li>
                  <?php
                     $linkilo_completed_steps_wizard = get_option('completed_steps');

                     if( empty( $linkilo_completed_steps_wizard ) && $linkilo_completed_steps_wizard !== '0')
                     {
                        ?>
                         <li id="progressList-2"
                  class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list active" data-step="2">
                  <?php _e('Global Setting', 'linkilo'); ?></li>
                        <?php
                     }
                     else
                     {
                  ?>
                        <li id="progressList-2"
                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="2">
                        <?php _e('Global Setting', 'linkilo'); ?></li>
                        <?php
                     }
                  ?>
                <li id="progressList-3"
                  class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="3">
                  <?php _e('Google Search Console', 'linkilo'); ?></li>
                  <?php
                    if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                    {         
                        if( defined('RANK_MATH_VERSION') && !defined('WPSEO_VERSION'))
                        {
                            ?>
                            <li id="progressList-4"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="4">
                            <?php _e('Rankmath Configuration', 'linkilo'); ?></li>
                         <?php
                        }
                        else if( !defined('RANK_MATH_VERSION') && defined('WPSEO_VERSION'))
                        {
                            ?>
                            <li id="progressList-4"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="4">
                            <?php _e('Yoast Configuration', 'linkilo'); ?></li>
                            <?php
                        }
                        else if(defined('RANK_MATH_VERSION') && defined('WPSEO_VERSION'))
                        {
                            ?>
                            <li id="progressList-4"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="4">
                            <?php _e('Rankmath/Yoast', 'linkilo'); ?></li>
                            <?php
                        }
                        ?>
                    <?php

                    }
                    if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
                    {
                        if( defined('AIOSEO_DIR') && !defined('SQ_VERSION') || defined('AIOSEO_PLUGIN_DIR') && !defined('SQ_VERSION'))
                        {
                            ?>
                            <li id="progressList-5"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="6">
                            <?php _e('AIOSEO Configuration', 'linkilo'); ?></li> 
                         <?php
                        }
                        else if( !defined('AIOSEO_DIR') && !defined('AIOSEO_PLUGIN_DIR') && defined('SQ_VERSION') )
                        {
                            ?>
                            <li id="progressList-5"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="6">
                            <?php _e('Squirrly Configuration', 'linkilo'); ?></li>
                            <?php
                        }
                        else if(defined('AIOSEO_DIR') && defined('SQ_VERSION') || defined('AIOSEO_PLUGIN_DIR') && defined('SQ_VERSION'))
                        {
                            ?>
                            <li id="progressList-5"
                            class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="6">
                            <?php _e('All in One Seo/Squirrly', 'linkilo'); ?></li>
                            <?php
                        }
                    }
                    if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
                    {
                        ?>

                        <li id="progressList-6"
                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="5">
                        <?php _e('Link Design', 'linkilo'); ?></li>
                        <?php
                    }
                    else
                    {
                        ?>

                        <li id="progressList-5"
                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list" data-step="5">
                        <?php _e('Link Design', 'linkilo'); ?></li>
                  <?php
                    }
                    if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
                    {
                        ?>

                            <li id="progressList-7"
                        class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list">
                        <?php _e('Welcome', 'linkilo'); ?></li>
                        <?php
                    }
                    else
                    {
                        ?>
                        <li id="progressList-6"
                  class="d-inline-block fw-bold linkilo_wizard_progrbar_wid position-relative text-center float-start progressbar-list">
                  <?php _e('Welcome', 'linkilo'); ?></li>
                  <?php
                    }
                    ?>
              </ul>
            </div>
          </div>
        </div>
        <div class="linkilo_wizard_content_container_wrapper">
            <span class="linkilo_wizard_err_message"></span>
            <div class=" linkilo_wizard_ustify_content_center linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step1" id="cardSection">
                <div class="linkilo_wizard_tab_main_wrapper">
                    <div class="linkilo_wizard_licensing linkilo_wizard_same_class">
                        <div class="linkilo_licensing_wizard_backgroungd">
                            <div class="wrap linkilo_licensing_wrap postbox">
                                <div class="linkilo_licensing_container">
                                    <div class="linkilo_licensing" style="">
                                        <h2 class="linkilo_licensing_header hndle ui-sortable-handle">
                                            <span>Linkilo Licensing</span>
                                        </h2>
                                        <div class="linkilo_licensing_wizard_content inside">
                                            <?php
                                                    $status_titles   = array(
                                                        'not_activated' => __('License Not Active', 'linkilo'),
                                                        'activated'     => __('License Active', 'linkilo'),
                                                        'error'         => __('Activation Error', 'linkilo')
                                                    );
                                                    $license    = get_option(LINKILO_LICENSE_KEY_OPTION, '');
                                                    $status     = get_option(LINKILO_STATUS_OF_LICENSE_OPTION);
                                                    $last_error = get_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, '');
                                                    $last_state = get_option('linkilo_license_error_state', '');

                                                    // get the current licensing state
                                                    $licensing_state;
                                                    if(empty($license) && empty($last_error) || ('invalid' === $status && 'Deactivated manually' === $last_error)){
                                                        $licensing_state = 'not_activated';
                                                    }elseif(!empty($license) && 'valid' === $status){
                                                        $licensing_state = 'activated';
                                                    }elseif(!empty($license) && 'inactive' === $status){
                                                        $licensing_state = 'not_activated';
                                                    }elseif(!empty($license) && 'site_inactive' === $status){
                                                        $licensing_state = 'not_activated';
                                                    }elseif(!empty($license) && 'expired' === $status){
                                                        $licensing_state = 'not_activated';
                                                    }else{
                                                        $licensing_state = 'error';
                                                    }

                                                    if ($last_state === "state_1") {
                                                        update_option('linkilo_license_error_state', 'state_2');
                                                    }

                                                    if ($last_state === "state_2") {
                                                        $licensing_state = 'not_activated';
                                                        delete_option(LINKILO_LICENSE_CHECK_TIME_OPTION);
                                                        delete_option(LINKILO_STATUS_OF_LICENSE_OPTION);
                                                        delete_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION);
                                                        delete_option('linkilo_license_error_state');
                                                        delete_option(LINKILO_LICENSE_KEY_OPTION);
                                                        delete_option(LINKILO_CURRENT_LICENSE_DATA_OPTION);
                                                        delete_option('linkilo_2_license_activation');
                                                        delete_option('linkilo_2_license_next_check');
                                                    }elseif (!$last_state && $licensing_state === "error" && !empty($last_error)) {
                                                        delete_option(LINKILO_LICENSE_CHECK_TIME_OPTION);
                                                        delete_option(LINKILO_STATUS_OF_LICENSE_OPTION);
                                                        delete_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION);
                                                        delete_option('linkilo_license_error_state');
                                                        delete_option(LINKILO_LICENSE_KEY_OPTION);
                                                        delete_option(LINKILO_CURRENT_LICENSE_DATA_OPTION);
                                                        delete_option('linkilo_2_license_activation');
                                                        delete_option('linkilo_2_license_next_check');
                                                    }

                                                    // create titles for the license statuses
                                                    $status_titles   = array(
                                                        'not_activated' => __('License Not Active', 'linkilo'),
                                                        'activated'     => __('License Active', 'linkilo'),
                                                        'error'         => __('Activation Error', 'linkilo')
                                                    );

                                                    // create some helpful text to tell the user what's going on
                                                    $status_messages = array(
                                                        'not_activated' => __('Please enter your Linkilo License Key to activate Linkilo.', 'linkilo'),
                                                        'activated'     => __('Congratulations! Your Linkilo License Key has been confirmed and Linkilo is now active!', 'linkilo'),
                                                        'error'         => $last_error
                                                    );
                                            ?>

                                            
                                            <div class="wrap linkilo_licensing_wrap postbox">
                                                <div class="linkilo_licensing_container">
                                                    <div class="linkilo_licensing" style="">
                                                        <div class="linkilo_licensing_content_wizard inside">
                                                            <?php settings_fields('linkilo_license'); ?>
                                                            <input type="hidden" id="linkilo_license_action_input" name="hidden_action" value="activate_license" disabled="disabled">
                                                            <table class="form-table">
                                                                <tbody>
                                                                    <tr style="display:none;">
                                                                        <td class="linkilo_license_table_title">
                                                                            <?php _e('License Key:', 'linkilo');?>
                                                                        </td>
                                                                        <td>
                                                                            <input id="linkilo_license_key" name="linkilo_license_key" type="text" class="regular-text" value="" />
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="linkilo_license_table_title" style="font-size: 18px !important;">
                                                                            <?php _e('License Status:', 'linkilo');?>
                                                                        </td>
                                                                        <td>
                                                                            <span class="linkilo_licensing_status_text <?php echo esc_attr($licensing_state); ?>">
                                                                                <?php echo esc_attr($status_titles[$licensing_state]); ?>
                                                                            </span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="linkilo_license_table_title" style="font-size: 18px !important;">
                                                                            <?php _e('License Message:', 'linkilo');?>
                                                                        </td>
                                                                        <td>
                                                                            <span class="linkilo_licensing_status_text <?php echo esc_attr($licensing_state); ?>">
                                                                                <?php echo esc_attr(ucwords(trim($status_messages[$licensing_state]))); ?>
                                                                            </span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr></tr>
                                                                    <tr>
                                                                        <td colspan="2">
                                                                            <?php 
                                                                            $login = esc_url("https://www.linkilo.co/login/"); 
                                                                            ?>
                                                                            <span class="linkilo_license_manage_text">
                                                                                <?php _e('To deactivate this site goto your managed site section','linkilo'); ?>
                                                                                <a href="<?php echo $login;?>" target="_blank" class="linkilo_license_manage_link">
                                                                                    <?php _e('Manage Sites','linkilo'); ?>
                                                                                    <img src="<?php echo LINKILO_PLUGIN_DIR_URL.'images/target.png'; ?>" style="width: 15px; height: 15px; margin-top: 5px;"
                                                                                    style="width: 15px; height: 15px; margin-top: 5px;">
                                                                                </a>
                                                                            </span>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <?php wp_nonce_field( 'linkilo_activate_license_nonce', 'linkilo_activate_license_nonce' ); ?>
                                                            <div class="linkilo_licensing_version_number">
                                                                <?php //echo Linkilo_Build_Root::showVersion(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                    <button type="button" class="btn text-white float-right  linkilo_next_wizard  bg-color-info" data-step="1"><?php _e('Next', 'linkilo'); ?></button>
                                            
                                        </div>
                                    </div>
                                </div>
                                
                            </div>

                        </div>
                    </div>

                <!-- <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="false"><?php //_e('Skip', 'linkilo'); ?></button> -->

                </div>
            </div>

            <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step2">
            <div class="linkilo_wizard_tab_main_wrapper">
                <div class="linkilo_wizard_setting linkilo_wizard_same_class">
                    <table class="form-table">
                        <tbody>
                            <tr class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <?php
                                $types_active = Linkilo_Build_AdminSettings::getPostTypes();
                                $term_types_active = Linkilo_Build_AdminSettings::getTermTypes();
                                    if(empty(get_option('linkilo_2_show_all_post_types', false))){
                                        $types_available = get_post_types(['public' => true]);
                                    }else{
                                        $types_available = get_post_types();
                                    }
                                    $max_links_per_post = get_option('linkilo_max_links_per_post', 0);
                                    $max_words_match_per_suggest = get_option('linkilo_max_words_match_per_suggest', 0);

                                ?>
                                <td scope='row' class="linkilo_glbl_settin_wiz"><?php _e('Find Suggested URLs in these Post Types Only', 'linkilo'); ?></td>
                                <td>
                                    <div style="display: inline-block;">
                                        <div class="linkilo_help" style="float:right;position: inherit;margin-right: 90px;">
                                            <i class="dashicons dashicons-editor-help"></i>
                                            <div class="linkilo_wizard_help_cl"><p><?php _e('After changing the post type selection, please go to the Records Page and click the "Perform Scan" button to clear the old link data.', 'linkilo'); ?></p></div>
                                        </div>
                                        <?php foreach ($types_available as $type) : ?>
                                            <input type="checkbox" name="linkilo_2_post_types[]" value="<?php echo $type; ?>" <?php echo in_array($type, $types_active) ? 'checked' : ''; ?>><label><?php echo ucfirst($type); ?></label><br>
                                        <?php endforeach; ?>
                                        <input type="hidden" name="linkilo_2_show_all_post_types" value="0">
                                        <input type="checkbox" name="linkilo_2_show_all_post_types" value="1" <?php echo !empty(get_option('linkilo_2_show_all_post_types', false)) ? 'checked' : ''; ?>><label><?php _e('Show Non-Public Post Types', 'linkilo'); ?></label><br>
                                    </div>
                                </td>
                            </tr>
                            <tr class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope="row"><?php _e('Sentence length to skip', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_skip_sentences" style="float:left; max-width:100px">
                                        <?php for($i = 0; $i <= 10; $i++) : ?>
                                            <option value="<?php echo $i; ?>"   <?php echo $i==Linkilo_Build_AdminSettings::getSkipSentences() ? 'selected' : '' ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div class="linkilo_wizard_help_cl">
                                            <p><?php _e('Skip the amount of sentences before suggesting links', 'linkilo'); ?>
                                        <p></div>
                                    </div>
                                </td>
                            </tr>
                            <tr class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope="row">
                                    <?php _e('Set limit amount of link per post', 'linkilo'); ?>
                                </td>
                                <td>
                                    <select name="linkilo_max_links_per_post" style="float:left; max-width:100px">
                                        <option value="0" <?php echo 0===(int)$max_links_per_post ? 'selected' : ''; ?>>
                                            <?php _e('No Limit', 'linkilo'); ?>
                                        </option>
                                        <?php for($i = 1; $i <= 100; $i++) : ?>
                                            <option value="<?php echo $i; ?>" <?php echo $i===(int)$max_links_per_post ? 'selected' : ''; ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div class="linkilo_wizard_help_cl"><p><?php _e('This is used to set limit of links in a post content. After limit is reached it will show a message "Post has reached the max link limit. To enable suggestions, please increase the Max Links Per Post setting from the Linkilo Settings."', 'linkilo'); ?></p></div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Restrict Link Suggestions -->
                            <tr class="linkilo-general-settings linkilo-setting-row ">
                                <td scope="row">
                                    <?php _e('Words limit for a link suggestion', 'linkilo'); ?>
                                </td>
                                <td>
                                    <select name="linkilo_max_words_match_per_suggest" style="float:left; max-width:100px">
                                        <option value="0" <?php echo 0===(int)$max_words_match_per_suggest ? 'selected' : ''; ?>>
                                            <?php _e('No Limit', 'linkilo'); ?>
                                        </option>
                                        <?php for($i = 1; $i <= 5; $i++) : ?>
                                            <option value="<?php echo $i; ?>" <?php echo $i === (int)$max_words_match_per_suggest ? 'selected' : ''; ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div class="linkilo_wizard_help_cl linkilo_wizard_wrd_link"><p><?php _e('Limit the amout of words in suggestions to be taken in count while matching and populating that string as a valid suggestion.', 'linkilo'); ?></p></div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="0"><?php _e('Prev', 'linkilo'); ?></button>
                <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="2"><?php _e('Skip', 'linkilo'); ?></button>
                <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="2"><?php _e('Next', 'linkilo'); ?></button>
                </div>
               
            </div>
            </div>
            <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step3">
            <div class="linkilo_wizard_tab_main_wrapper">

                <div class="linkilo_wizard_gsc linkilo_wizard_same_class">
                <table class="form-table">
                        <?php
                        $is_linkilo_authorized = get_option('linkilo_app_console_authorized', false);
                        $is_site_selected = get_option('linkilo_app_console_selected', false);
                        ?>
                        <tbody>
                        <tr class="linkilo-advanced-settings linkilo-setting-row ">
                            <?php if(!empty($is_linkilo_authorized)){ ?>
                                <td scope='row' class="linkilo_yoast_or_rank_td">
                                    <?php _e('Connect Linkilo To Google Search Console', 'linkilo'); ?> 
                                </td>
                                <td>
                                    <div class="linkilo_gsc_app_inputs">
                                        <!-- google app user authentication link -->
                                        <a class="button-primary" href="<?php echo Linkilo_Build_GscAppConsole::linkilo_app_console_user_auth_url(); ?>">  
                                            <?php _e('Authenticate Linkilo', 'linkilo'); ?> 
                                        </a>
                                    </div>
                                </td>
                            <?php }else{ 
                                
                                ?>
                                <td scope='row' class="linkilo_yoast_or_rank_td">
                                    <?php _e('Search Console Connected', 'linkilo'); ?> 
                                </td>
                                <td>
                                    <!-- Deactivate button -->
                                    <a class="linkilo-app-console-deactivate button-primary deactivate_button" data-nonce="<?php echo wp_create_nonce('linkilo-app-console-disconnect'); ?>"> 
                                        <?php _e('Deactivate', 'linkilo'); ?> 
                                    </a>

                                    <!-- Site fetch button -->
                                    <?php $disabled = Linkilo_Build_GscAppConsole::linkilo_app_console_check_token_expired() ? "disabled" : "" ;?>
                                    <a class="linkilo-app-console-get-sites button-primary" data-nonce="<?php echo wp_create_nonce('linkilo-app-console-fetch-sites'); ?>" <?php echo $disabled; ?>> 
                                        <?php _e('Fetch Sites', 'linkilo'); ?> 
                                    </a>
                                    <span id="site_fetching_status"></span>

                                    <!-- Refresh auth token button -->
                                    <?php if (Linkilo_Build_GscAppConsole::linkilo_app_console_check_token_expired()): ?>
                                        <a class="linkilo-app-console-refresh-auth-token button-primary" data-nonce="<?php echo wp_create_nonce('linkilo-app-console-refresh-auth-token'); ?>"> 
                                            <?php _e('Refresh Token', 'linkilo'); ?> 
                                        </a>
                                    <?php endif; ?>
                                </td>
                            <?php } ?>
                        </tr>

                        <tr>
                            <!-- show when authorized but site is not selected -->
                            <?php if (!empty($is_linkilo_authorized) && false === $is_site_selected): ?>
                                <?php
                                $fetched_sites_list = get_option('linkilo_app_console_fetched_sites_data', false);
                                ?>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <?php _e('Select a site from list', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <?php if ($fetched_sites_list !== false): ?>
                                            <select name="linkilo_app_console_select_site" style="float:left; max-width:400px">
                                                <option value="0">
                                                    <?php _e('Select Site', 'linkilo'); ?>
                                                </option>
                                                <?php foreach ($fetched_sites_list as $list_site): ?>
                                                    <option value="<?php echo base64_encode(trim($list_site['option_value'])); ?>">
                                                        <?php echo trim($list_site['option_lable']); ?>
                                                    </option>
                                                <?php endforeach ?>
                                            </select>
                                        <?php else: ?>
                                            <span>
                                                <?php _e( "No sites to display please try fetching site again.", 'linkilo'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php if (!empty($is_linkilo_authorized) && false !== $is_site_selected): ?>

                                    <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                        <td scope='row'>
                                            <?php _e('Selected site :', 'linkilo'); ?>
                                        </td>
                                        <td>
                                            <?php if (false !== get_option('linkilo_app_console_selected_site', false)): ?>
                                                <?php echo get_option('linkilo_app_console_selected_site', "Please fetch or select again"); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif ?>
                            <?php endif; ?>
                        </tr>

                        <tr class="linkilo-general-settings linkilo-setting-row ">
                                <td scope="row"><?php _e('Set limit for google search console keywords', 'linkilo'); ?></td> 
                                <td>
                                    <select name="linkilo_google_search_console_limit" style="float:left; max-width:100px">
                                        <?php for($i = 1; $i <= 10; $i++) : ?>
                                            <option value="<?php echo $i; ?>"   <?php echo $i==Linkilo_Build_AdminSettings::getGoogleconsole() ? 'selected' : '' ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div class="linkilo_wizard_help_cl linkilo_wizard_gsc_keywords linkilo_wizard_wrd_link">
                                            <p><?php _e('Set limit for fetched google search console keywords. This limit will be applied while insertion of keywords is being done.', 'linkilo'); ?>
                                        </p></div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php
                if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                { 
                    ?>
                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                    <?php
                }
                else
                {
                    ?>
                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                    <?php
                }
            ?>
                
                <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="3"><?php _e('Skip', 'linkilo'); ?></button>
                <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="3"><?php _e('Next', 'linkilo'); ?></button>
                </div>
                
            </div>
            </div>
            <?php
            if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
            {      
                $linkilo_yoastseo_keyword_enable = get_option('linkilo_yoastseo_keyword_enable');
                $linkilo_rankmath_keyword_enable = get_option('linkilo_rankmath_keyword_enable');

                if( defined('RANK_MATH_VERSION') && !defined('WPSEO_VERSION'))
                {
                    ?>
                    <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step4">
                    <div class="linkilo_wizard_tab_main_wrapper">

                    <div class="linkilo_wizard_rank_match_yost linkilo_wizard_same_class">
                        <table class="form-table">
                            <tbody>
                                <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                    <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('Rankmath Keywords Enable', 'linkilo'); ?></td>
                                    <td>
                                        <div style="display: inline-block;">
                                        
                                            <?php
                                            if ($linkilo_rankmath_keyword_enable == '1') {
                                                $checked_show = 'checked="checked"';
                                            }else{
                                                $checked_show = "";
                                            }
                                            ?>
                                            <input
                                            type="checkbox"
                                            name="linkilo_rankmath_keyword_enable"
                                            value="1"
                                            <?php echo $checked_show; ?>
                                            >
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <?php
                                if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                                { 
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                            ?>
                            
                            <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="4"><?php _e('Skip', 'linkilo'); ?></button>
                            <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="4"><?php _e('Next', 'linkilo'); ?></button>
                            </div>
                           
                        </div>
                    </div>
                    <?php
                }
                else if( !defined('RANK_MATH_VERSION') && defined('WPSEO_VERSION'))
                {
                    ?>
                    <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step4">
                        <div class="linkilo_wizard_tab_main_wrapper">

                            <div class="linkilo_wizard_rank_match_yost linkilo_wizard_same_class">
                                <table class="form-table">
                                    <tbody>
                                        <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                            <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('Yoast SEO Keywords Enable', 'linkilo'); ?></td>
                                            <td>
                                                <div style="display: inline-block;">
                                                
                                                    <?php
                                                    if ($linkilo_yoastseo_keyword_enable == '1') {
                                                        $checked_show = 'checked="checked"';
                                                    }else{
                                                        $checked_show = "";
                                                    }
                                                    ?>
                                                    <input
                                                    type="checkbox"
                                                    name="linkilo_yoastseo_keyword_enable"
                                                    value="1"
                                                    <?php echo $checked_show; ?>
                                                    >
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php
                                if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                                { 
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                            ?>
                            
                            <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="4"><?php _e('Skip', 'linkilo'); ?></button>
                            <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="4"><?php _e('Next', 'linkilo'); ?></button>
                            </div>
                           
                        </div>
                    </div>
                    <?php
                }
                elseif(defined('RANK_MATH_VERSION') && defined('WPSEO_VERSION'))
                {
                    ?>
                    <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step4">
                    <div class="linkilo_wizard_tab_main_wrapper">

                            <div class="linkilo_wizard_rank_match_yost linkilo_wizard_same_class">
                                <table class="form-table">
                                    <tbody>
                                        <tr class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                            <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('Rankmath Keywords Enable', 'linkilo'); ?></td>
                                            <td>
                                                <div style="display: inline-block;">
                                                
                                                    <?php
                                                    if ($linkilo_rankmath_keyword_enable == '1') {
                                                        $checked_show = 'checked="checked"';
                                                    }else{
                                                        $checked_show = "";
                                                    }
                                                    ?>
                                                    <input
                                                    type="checkbox"
                                                    name="linkilo_rankmath_keyword_enable"
                                                    value="1"
                                                    <?php echo $checked_show; ?>
                                                    >
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                            <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('Yoast SEO Keywords Enable', 'linkilo'); ?></td>
                                            <td>
                                                <div style="display: inline-block;">
                                                
                                                    <?php
                                                    if ($linkilo_yoastseo_keyword_enable == '1') {
                                                        $checked_show = 'checked="checked"';
                                                    }else{
                                                        $checked_show = "";
                                                    }
                                                    ?>
                                                    <input
                                                    type="checkbox"
                                                    name="linkilo_yoastseo_keyword_enable"
                                                    value="1"
                                                    <?php echo $checked_show; ?>
                                                    >
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php
                                if( defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                                { 
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                            ?>
                            
                            <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="4"><?php _e('Skip', 'linkilo'); ?></button>
                            <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="4"><?php _e('Next', 'linkilo'); ?></button>
                            </div>
                            
                        </div>
                    </div>
                    <?php
                }  
            }

            if(defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION'))
            {
                $linkilo_aloseo_keyword_enable = get_option('linkilo_aloseo_keyword_enable');
                $linkilo_squirrly_seo_keyword_enable = get_option('linkilo_squirrly_seo_keyword_enable');
                

                if( (defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR')) && !defined('SQ_VERSION'))
                {
                   
                    ?>
                    <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step6">
                    <div class="linkilo_wizard_tab_main_wrapper">

                    <div class="linkilo_wizard_aioseo_and_sq linkilo_wizard_same_class">
                        <table class="form-table">
                            <tbody>
                                <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                    <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('All In One Seo Keywords Enable', 'linkilo'); ?></td>
                                    <td>
                                        <div style="display: inline-block;">
                                        
                                            <?php
                                            if ($linkilo_aloseo_keyword_enable == '1') {
                                                $checked_show = 'checked="checked"';
                                            }else{
                                                $checked_show = "";
                                            }
                                            ?>
                                            <input
                                            type="checkbox"
                                            name="linkilo_aloseo_keyword_enable"
                                            value="1"
                                            <?php echo $checked_show; ?>
                                            >
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            <?php
                              if( (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) && (defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                              { 
                                  
                                  ?>
                                      <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="3"><?php _e('Prev', 'linkilo'); ?></button>
                                  <?php
                              }
                              elseif(defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                              {
                                  ?>
                                      <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                  <?php
                              }
                              elseif((defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                              {
                                  ?>
                                      <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                  <?php
                              }
                              else
                              {
                                  ?>
                                      <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                                  <?php
                              }
                            ?>
                            
                            <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="6"><?php _e('Skip', 'linkilo'); ?></button>
                            <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="6"><?php _e('Next', 'linkilo'); ?></button>
                        </table>
                            </div>
                           
                        </div>
                    </div>
                    <?php
                }
                else if( (!defined('AIOSEO_DIR')  && defined('SQ_VERSION')) )
                {
                    ?>
                    <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step6">
                        <div class="linkilo_wizard_tab_main_wrapper">

                            <div class="linkilo_wizard_aioseo_and_sq linkilo_wizard_same_class">
                                <table class="form-table">
                                    <tbody>
                                        <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                            <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('Squirrly SEO Keywords Enable', 'linkilo'); ?></td>
                                            <td>
                                                <div style="display: inline-block;">
                                                
                                                    <?php
                                                    if ($linkilo_squirrly_seo_keyword_enable == '1') {
                                                        $checked_show = 'checked="checked"';
                                                    }else{
                                                        $checked_show = "";
                                                    }
                                                    ?>
                                                    <input
                                                    type="checkbox"
                                                    name="linkilo_squirrly_seo_keyword_enable"
                                                    value="1"
                                                    <?php echo $checked_show; ?>
                                                    >
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php
                                if( (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) && (defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                                { 
                                    
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="3"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                                elseif(defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                                elseif((defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                            ?>
                            
                            <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="6"><?php _e('Skip', 'linkilo'); ?></button>
                            <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="6"><?php _e('Next', 'linkilo'); ?></button>
                            </div>
                          
                        </div>
                    </div>
                    <?php
                }
                elseif(defined('AIOSEO_DIR') && defined('SQ_VERSION') || defined('AIOSEO_PLUGIN_DIR') && defined('SQ_VERSION'))
                {

                    ?>
                    <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step6">
                    <div class="linkilo_wizard_tab_main_wrapper">

                            <div class="linkilo_wizard_aioseo_and_sq linkilo_wizard_same_class">
                                <table class="form-table">
                                    <tbody>
                                        <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                            <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('All In One Seo Keywords Enable', 'linkilo'); ?></td>
                                            <td>
                                                <div style="display: inline-block;">
                                                
                                                    <?php
                                                    if ($linkilo_aloseo_keyword_enable == '1') {
                                                        $checked_show = 'checked="checked"';
                                                    }else{
                                                        $checked_show = "";
                                                    }
                                                    ?>
                                                    <input
                                                    type="checkbox"
                                                    name="linkilo_aloseo_keyword_enable"
                                                    value="1"
                                                    <?php echo $checked_show; ?>
                                                    >
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="linkilo-advanced-settings linkilo-setting-row ">
                                            <td scope='row' class="linkilo_yoast_or_rank_td"><?php _e('Squirrly SEO Keywords Enable', 'linkilo'); ?></td>
                                            <td>
                                                <div style="display: inline-block;">
                                                
                                                    <?php
                                                    if ($linkilo_squirrly_seo_keyword_enable == '1') {
                                                        $checked_show = 'checked="checked"';
                                                    }else{
                                                        $checked_show = "";
                                                    }
                                                    ?>
                                                    <input
                                                    type="checkbox"
                                                    name="linkilo_squirrly_seo_keyword_enable"
                                                    value="1"
                                                    <?php echo $checked_show; ?>
                                                    >
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php
                               if( (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) && (defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                               { 
                                   
                                   ?>
                                       <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="3"><?php _e('Prev', 'linkilo'); ?></button>
                                   <?php
                               }
                               elseif(defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                               {
                                   ?>
                                       <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                   <?php
                               }
                               elseif((defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                                {
                                    ?>
                                        <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                                    <?php
                                }
                               else
                               {
                                   ?>
                                       <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="1"><?php _e('Prev', 'linkilo'); ?></button>
                                   <?php
                               }
                            ?>
                            
                            <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="6"><?php _e('Skip', 'linkilo'); ?></button>
                            <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="6"><?php _e('Next', 'linkilo'); ?></button>
                            </div>
                            
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
            <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class linkilo_wizard_all_tab_common_class_step5">
            <div class="linkilo_wizard_tab_main_wrapper">

                    <div class="linkilo_wizard_link_design linkilo_wizard_same_class">
                        <table class="form-table">
                            <?php
                                $linkilo_ext_opt_external_set = get_option('linkilo_external_setting_ext_field');

                                $linkilo_icon_type = isset($linkilo_ext_opt_external_set['linkilo_icon_type']) ? $linkilo_ext_opt_external_set['linkilo_icon_type'] : '';
                                $linkilo_ext_opt_external_set = get_option('linkilo_external_setting_ext_field');

                              $linkilo_icon_type = isset($linkilo_ext_opt_external_set['linkilo_icon_type']) ? $linkilo_ext_opt_external_set['linkilo_icon_type'] : '';
                              
                              $linkilo_icon_position = isset($linkilo_ext_opt_external_set['linkilo_icon_position']) ? $linkilo_ext_opt_external_set['linkilo_icon_position'] : '';
                              $linkilo_selectedClass =  isset($linkilo_ext_opt_external_set['linkilo_selectedClass']) ? $linkilo_ext_opt_external_set['linkilo_selectedClass'] : '';
                            ?>
                            <tbody>
                                <tr class="linkilo-external-url linkilo-setting-row">
                                    <td scope='row'><?php _e('Select Icon Type for External Links', 'linkilo'); ?></td>
                                    <td>
                                        <select name="linkilo_icon_type" id="linkilo_icon_type" >
                                            <option value=""><?php _e('No Icon (Default)', 'linkilo'); ?></option>
                                            <option value="linkilo_external_icon" <?php selected( "linkilo_external_icon",$linkilo_icon_type ); ?>><?php _e('External', 'linkilo'); ?></option>
                                            <option value="linkilo_verified_icon" <?php selected( "linkilo_verified_icon",$linkilo_icon_type ); ?>><?php _e('Verified', 'linkilo'); ?></option>
                                        </select>
                                    </td>
                                </tr>

                                <?php
                                    // External Link Iocn
                                    $options = array(
                                        'option1' => 'fas fa-external-link-square-alt',
                                        'option2' => 'fa-solid fa-arrow-up-right-from-square',
                                        'option3' => 'fas fa-external-link-alt',
                                        'option4' => 'fa-solid fa-square-arrow-up-right',
                                    );

                                    // verified icons
                                    $options1 = array(
                                        'option5' => 'fa-solid fa-check',
                                        'option6' => 'fa-solid fa-check-to-slot',
                                        'option7' => 'fa-solid fa-check-double',
                                        'option8' => 'fa-solid fa-square-check',
                                        'option9' => 'fa-regular fa-square-check',
                                        'option10' => 'fa-solid fa-circle-check',
                                        'option11' => 'fa-regular fa-circle-check',
                                        'option12' => 'fa-solid fa-user-check'
                                    );
                                ?>
                                  <tr class="linkilo-external-url linkilo-setting-row settings-row-border linkilo_icon_image_row" >
                                    <td scope='row'><?php _e('Select Icon For External Links', 'linkilo'); ?></td>
                                    <td class="linkilo_radio_icons">
                                        <?php
                                        $row_counter = 0;
                                        $row_counter1 = 0;

                                        //for external link icons
                                        foreach ( $options as $value => $icon_class ) 
                                        {
                                            $checked = ( $icon_class == $linkilo_selectedClass ) ? 'checked' : '';
                                            if ( $row_counter > 0 && $row_counter % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_lbl1">
                                                <input type="radio" name="linkilo_external_icon" value="<?php echo esc_attr( $icon_class ); ?>" <?php echo esc_attr( $checked ); ?>>
                                                <i class="<?php echo esc_attr( $icon_class ); ?>"></i>
                                            </label>
                                                
                                            
                                            <?php
                                            $row_counter++;
                                        }
                                        
                                        // for verified icons 
                                        foreach ( $options1 as $value1 => $icon_class1 ) 
                                        {
                                            $checked = ( $icon_class1 == $linkilo_selectedClass ) ? 'checked' : '';
                                            if ( $row_counter1 > 0 && $row_counter1 % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_lbl2">
                                                <input type="radio" name="linkilo_verified_icon" value="<?php echo esc_attr( $icon_class1 ); ?>" <?php echo esc_attr( $checked ); ?>>
                                                <i class="<?php echo esc_attr( $icon_class1 ); ?>"></i>
                                            </label>

                                            <?php
                                            $row_counter1++;
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                $linkilo_ext_opt_external_set = get_option('linkilo_external_setting_ext_field');

                                $linkilo_icon_type = isset($linkilo_ext_opt_external_set['linkilo_icon_type']) ? $linkilo_ext_opt_external_set['linkilo_icon_type'] : '';
                                
                                $linkilo_icon_position = isset($linkilo_ext_opt_external_set['linkilo_icon_position']) ? $linkilo_ext_opt_external_set['linkilo_icon_position'] : '';
                                $linkilo_selectedClass =  isset($linkilo_ext_opt_external_set['linkilo_selectedClass']) ? $linkilo_ext_opt_external_set['linkilo_selectedClass'] : '';
                                $linkilo_skip_check =  isset($linkilo_ext_opt_external_set['linkilo_skip_isChecked']) ? $linkilo_ext_opt_external_set['linkilo_skip_isChecked'] : '';
                                $linkilo_exclude_iconfordmn_name =  isset($linkilo_ext_opt_external_set['linkilo_exclude_iconfordmn_name']) ? $linkilo_ext_opt_external_set['linkilo_exclude_iconfordmn_name'] : '';

                                $specific_dmnname_and_cls_arr =  isset($linkilo_ext_opt_external_set['spc_dmn_name_and_cls_arr']) ? $linkilo_ext_opt_external_set['spc_dmn_name_and_cls_arr'] : '';

                                $linkilo_internal_icon_type         = get_option('linkilo_internal_icon_type');
                                $linkilo_interlanl_icon_position    = get_option('linkilo_interlanl_icon_position');
                                $linkilo_internal_icon         = get_option('linkilo_internal_icon');
                                $linkilo_internal_verified_icon = get_option('linkilo_internal_verified_icon')
                                ?>
                                <!-- Coose Icon Image -->
                                    <tr class="linkilo-external-url linkilo-setting-row settings-row-border">
                                        <td scope='row'><?php _e(' Select External Link Icon Position', 'linkilo'); ?></td>
                                        <td>
                                            <select name="linkilo_icon_position" id="linkilo_icon_position" >
                                                <option value="right" <?php selected("right",$linkilo_icon_position); ?>><?php _e('Right side of the link', 'linkilo'); ?></option>
                                                <option value="left" <?php selected("left",$linkilo_icon_position); ?>><?php _e('Left side of the link', 'linkilo'); ?></option>
                                            </select>
                                        </td>
                                    </tr>
                                <tr class="linkilo-internal-url linkilo-setting-row">
                                    <td scope='row'><?php _e('Select Icon Type for Internal Links', 'linkilo'); ?></td>
                                    <td>
                                        <select name="linkilo_internal_icon_type" id="linkilo_internal_icon_type" >
                                            <option value=""><?php _e('No Icon (Default)', 'linkilo'); ?></option>
                                            <option value="linkilo_internal_icon" <?php selected( "linkilo_internal_icon",$linkilo_internal_icon_type ); ?>><?php _e('Internal', 'linkilo'); ?></option>
                                            <option value="linkilo_internal_verified_icon" <?php selected( "linkilo_internal_verified_icon",$linkilo_internal_icon_type ); ?>><?php _e('Verified', 'linkilo'); ?></option>
                                        </select>
                                    </td>
                            </tr>
                            <?php
                                    // Internal Link Iocn
                                    $linkilo_internal_icon_arr = array(
                                        'option1' => 'fas fa-external-link-square-alt',
                                        'option2' => 'fa-solid fa-arrow-up-right-from-square',
                                        'option3' => 'fas fa-external-link-alt',
                                        'option4' => 'fa-solid fa-square-arrow-up-right',
                                    );

                                    // verified icons
                                    $linkilo_internal_verified_icon_arr = array(
                                        'option5' => 'fa-solid fa-check',
                                        'option6' => 'fa-solid fa-check-to-slot',
                                        'option7' => 'fa-solid fa-check-double',
                                        'option8' => 'fa-solid fa-square-check',
                                        'option9' => 'fa-regular fa-square-check',
                                        'option10' => 'fa-solid fa-circle-check',
                                        'option11' => 'fa-regular fa-circle-check',
                                        'option12' => 'fa-solid fa-user-check'
                                    );
                                ?>
                                <tr class="linkilo-internal-url linkilo-setting-row settings-row-border linkilo_icon_image_row" >
                                    <td scope='row'><?php _e('Select Icon for Internal Links ', 'linkilo'); ?></td>
                                    <td class="linkilo_radio_icons_internal">
                                        <?php
                                        $row_counter = 0;
                                        $row_counter1 = 0;

                                        //for internal link icons
                                        foreach ( $linkilo_internal_icon_arr as $value => $icon_class ) 
                                        {
                                            $checked = ( $icon_class == $linkilo_internal_icon ) ? 'checked' : '';
                                            if ( $row_counter > 0 && $row_counter % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_internal_lbl1">
                                                <input type="radio" name="linkilo_internal_icon" value="<?php echo esc_attr( $icon_class ); ?>" <?php if(!empty( $linkilo_internal_icon )) { echo esc_attr( $checked  ); } ?>>
                                                <i class="<?php echo esc_attr( $icon_class ); ?>"></i>
                                            </label>
                                                
                                            
                                            <?php
                                            $row_counter++;
                                        }
                                        
                                        // for verified icons 
                                        foreach ( $linkilo_internal_verified_icon_arr as $value1 => $icon_class1 ) 
                                        {
                                            $checked = ( $icon_class1 == $linkilo_internal_verified_icon ) ? 'checked' : '';
                                            if ( $row_counter1 > 0 && $row_counter1 % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_internal_lbl2">
                                                <input type="radio" name="linkilo_internal_verified_icon" value="<?php echo esc_attr( $icon_class1 ); ?>" <?php if(!empty( $linkilo_internal_verified_icon )) { echo esc_attr( $checked );} ?>>
                                                <i class="<?php echo esc_attr( $icon_class1 ); ?>"></i>
                                            </label>

                                            <?php
                                            $row_counter1++;
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <tr class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e(' Select Internal Link Icon Position', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_interlanl_icon_position" id="linkilo_internal_icon_position" >
                                        <option value="right" <?php selected("right",$linkilo_interlanl_icon_position); ?>><?php _e('Right side of the link', 'linkilo'); ?></option>
                                        <option value="left" <?php selected("left",$linkilo_interlanl_icon_position); ?>><?php _e('Left side of the link', 'linkilo'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <!-- Link preview Enable/Disable -->
                            <tr class="linkilo-linkpreview-settings linkilo-setting-row ">
                                <td scope='row'>
                                    <label for="label_linkilo_links_preview">
                                        <?php _e('Enable Link Preview', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <!-- <input type="hidden" name="linkilo_links_preview" value="0" /> -->
                                        <input type="checkbox" name="linkilo_links_preview" id="label_linkilo_links_preview" <?php echo get_option('linkilo_links_preview')==1 ? 'checked' :''; ?>/>
                                        <div class="linkilo_help linkilo_wizard_enbl_preview" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div class="linkilo_wizard_help_cl linkilo_wizard_wrd_link">
                                                <p><?php
                                                _e('Do you want to enable link preview? When a user hover overs your links, it will show a preview of that page to help them see the image, title and description of that page before clicking. Note: if you cancel Linkilo, you  will no longer have this feature.', 'linkilo');
                                                ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php //if (get_option('linkilo_links_preview', '') == 1): ?>
                            <tr class="linkilo-linkpreview-settings linkilo-setting-row" id="linkilo_internal_link_preview">
                                <td scope='row'>
                                    <label for="label_linkilo_preview_internal_enable_disable"> 
                                        <?php _e('Enable link preview for internal links', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="display: inline-block;">
                                        <input type="checkbox" name="linkilo_preview_internal_enable_disable" id="label_linkilo_preview_internal_enable_disable" <?php echo get_option('linkilo_preview_internal_enable_disable')==1 ? 'checked' :''; ?> />
                                    </div>
                                </td>
                            </tr>
                            <tr class="linkilo-linkpreview-settings linkilo-setting-row " id="linkilo_external_link_preview">
                                <td scope='row'>
                                    <label for="label_linkilo_preview_external_enable_disable">
                                        <?php _e('Enable link preview for external links', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="display: inline-block;">
                                        <input type="checkbox" name="linkilo_preview_external_enable_disable" id="label_linkilo_preview_external_enable_disable" <?php echo get_option('linkilo_preview_external_enable_disable')==1 ? 'checked' :''; ?> />
                                    </div>
                                </td>
                            </tr>
                            <?php //endif ?>

                            <!-- Link preview Enable/Disable -->
                            </tbody>
                        </table>
                        <?php
                    
                    if( (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) && (defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                    { 
                        
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="4"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                    elseif(defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                    {
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="3"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                    elseif((defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                    {
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="3"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                    else
                    {
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="2"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                ?>
                <button type="button" class="btn btn-dark text-white linkilo_skip_wizard" data-skip="true" data-step="5"><?php _e('Skip', 'linkilo'); ?></button>
                    <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_next_wizard" data-step="5"><?php _e('Next', 'linkilo'); ?></button>
                    </div>

                    
                    
                    
                </div>
            </div>

        
            <div class=" linkilo_wizard_ustify_content_center form-business linkilo_wizard_all_tab_common_class">
            <div class="linkilo_wizard_tab_main_wrapper">

                <div class="linkilo_wizard_link_design linkilo_wizard_same_class">
                    <h4>Welcome to Linkilo – Your Internal Linking Assistant!</h4>
                    <p>&nbsp;<span style="font-weight:600;">Congratulations</span> on completing the setup wizard! 🎉 You've taken the first step in enhancing your WordPress website with our easy-to-use internal linking plugin.</p>
                    <p>With Linkilo at your side, managing internal links on your website will become a seamless process. You'll discover how effortlessly you can create connections between relevant content, driving engagement, and improving your site's SEO.</p>
                    <p>We're here to help you every step of the way! Should you have any questions, our support team is just a click away.</p> <p>Contact Us <a href="https://linkilo.co/contact-us/">(https://linkilo.co/contact-us/)</a></p>
                    <p>&nbsp;<span style="font-weight:600;">Are you ready?</span> Click the <u>Perform Scan</u> button For wizard.</p>
                    <?php
                // defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')
                    if( (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) && (defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                    { 
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="6"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                    elseif(defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION'))
                    {
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="4"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                    elseif((defined('AIOSEO_DIR') || defined('AIOSEO_PLUGIN_DIR') || defined('SQ_VERSION')))
                    {
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="6"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                    else
                    {
                        ?>
                            <button type="button" class="btn btn-dark text-white float-start linkilo_wizard_back rounded-3" data-step="3"><?php _e('Prev', 'linkilo'); ?></button>
                        <?php
                    }
                ?>
                  <form action='' method="post" id="linkilo_report_reset_data_form_wizard">
                            <input type="hidden" name="reset_data_nonce" value="<?php echo wp_create_nonce($user->ID . 'linkilo_refresh_record_data'); ?>">
                            <input type="hidden" name="wizard_run_scan" value="true">
                            <?php if ((trim($_GET['page']) === "linkilo"))  { ?>
                            <button type="submit">
                                <?php _e("Perform Scan", 'linkilo'); ?>
                            </button>
                        <?php }
                        ?>

                    </form>
                </div>
                
                
                <!-- <button type="submit" class="btn text-white float-end submit-button rounded-3 bg-color-info linkilo_perform_scan"><?php //_e('Run Scan', 'linkilo'); ?></button> -->
                <!-- <div class="wizard_right"> -->
                  
                <!-- </div> -->
            </div>
            </div>

        </div>
        </div>
    </div>
  </section>
  <!-- /section -->
</body>
</html>