<!-- Dashboard Menu -->
<div class="top-menu">
    <div class="left">
        <?php
        if (
            $_GET['page'] == 'cannibalization' ||
            $_GET['page'] == 'linkilo_focus_keywords' ||
            $_GET['page'] == 'anchor_analysis'
        ) {
            $class = 'class=""';
        }

        if($_GET['page'] == 'linkilo' && empty($_GET['type'])){
            $class = 'class="active"';
        }else{
            $class = 'class=""';
        }
        ?>
        <a <?php echo $class;?> id="general-tab" href="<?php echo admin_url('admin.php?page=linkilo'); ?>">
            <?php
            $tab_heading = (LINKILO_STATUS_HAS_RUN_SCAN == 1)? "SUMMARY" : "INITIAL SETUP";
            _e( $tab_heading, 'linkilo' );
            ?>
        </a>
        <?php /*If starts*/ ?>
        <?php if(LINKILO_STATUS_HAS_RUN_SCAN){ ?>
            <?php /*filter_settings starts*/ ?>
            <?php
            #get any filter settings from the user's report selection and apply the settings to the Link Report tab url
            $filter_settings = get_user_meta(get_current_user_id(), 'linkilo_filter_settings', true);
            $filter_vars = '';
            if(isset($filter_settings['report'])){
                $filtering = array();
                if(isset($filter_settings['report']['post_type']) && !empty($filter_settings['report']['post_type'])){
                    $filtering['post_type'] = $filter_settings['report']['post_type'];
                }

                if(isset($filter_settings['report']['category']) && !empty($filter_settings['report']['category'])){
                    $filtering['category'] = $filter_settings['report']['category'];
                }

                if(isset($filter_settings['report']['location']) && !empty($filter_settings['report']['location'])){
                    $filtering['location'] = $filter_settings['report']['location'];
                }

                if(!empty($filtering)){
                    $filter_vars = '&' . http_build_query($filtering);
                }
            }
            ?>
            <?php /*filter_settings ends*/ ?>


            <?php
            if ( current_user_can('publish_posts') )
            {
                ?>
                <a class="<?php echo (!empty($_GET['type']) && $_GET['type']=='links')?'active':''; ?>" id="home-tab" href="<?php echo admin_url('admin.php?page=linkilo&type=links' . $filter_vars); ?>">
                    <?php  _e( "ADD URLS", 'linkilo' ); ?>
                </a>
                <a class="<?php echo (!empty($_GET['type']) && $_GET['type']=='domains')?'active':''; ?>" id="home-tab" href="<?php echo admin_url('admin.php?page=linkilo&type=domains'); ?>">
                    <?php  _e( "LINKED DOMAINS", 'linkilo' ); ?>
                </a>
                <?php

            }
            ?>

        <?php } ?>
        <?php /*If ends */ ?>
    </div>

    <?php
    if ( current_user_can('publish_posts') )
    {              
        ?>
        <div class="right">
            <?php if(LINKILO_STATUS_HAS_RUN_SCAN){ ?>
                <form action='' method="post" id="linkilo_report_reset_data_form">
                    <input type="hidden" name="reset_data_nonce" value="<?php echo wp_create_nonce($user->ID . 'linkilo_refresh_record_data'); ?>">
                    <?php if ((trim($_GET['page']) === "linkilo"))  { ?>

                        <?php if (isset($_GET['type'])) { ?>

                            <a
                            href="javascript:void(0)"
                            class="csv_button"
                            data-type="<?php echo $_GET['type']; ?>"
                            id="linkilo_cvs_export_button"
                            >
                            <?php _e('Export CSV', 'linkilo'); ?>
                        </a>
                    <?php } ?>
                    <button type="submit">
                        <?php _e("Perform Scan", 'linkilo'); ?>
                    </button>
                <?php }
                // elseif(isset($_GET['page']))
                elseif(isset($_GET['page']) && $_GET['page'] == 'anchor_analysis')
                {
                    ?>
                    <a
                    href="javascript:void(0)"
                    class="csv_button"
                    data-type="<?php echo $_GET['page']; ?>"
                    id="linkilo_cvs_export_button"
                    >
                    <?php _e('Export CSV', 'linkilo'); ?>
                </a>
            <?php   }
            ?>

        </form>
    <?php } ?>
</div>
<?php } ?>

</div>
<!-- Dashboard Menu -->