<?php if (get_option('linkilo_disable_outgoing_suggestions')) : ?>
    <div style="min-height: 200px">
        <p style="display: inline-block;"><?php _e('Outbound Link Suggestions Disabled', 'linkilo') ?></p>
        <a style="float: right; margin: 15px 0px;" href="<?php echo admin_url("admin.php?{$post->type}_id={$post->id}&page=linkilo&type=incoming_suggestions_page&ret_url=" . base64_encode($post->getLinks()->edit)); ?>" class="button-primary"><?php _e('Add Incoming links', 'linkilo'); ?></a>
    </div>
    <?php 
else : 
    ?>
    <div class="linkilo_notice" id="linkilo_message" style="display: none">
        <p></p>
    </div>
    <div class="linkilo_meta_box_row">
        <div class="linkilo_meta_box_column1">
            <span style="font-style: italic; font-size: 15px !important;font-weight: 550;">
                <?php _e("By default, Linkilo suggestions are based on your settings.", 'linkilo'); ?> 
                <a href="<?php echo admin_url('admin.php?page=linkilo_settings'); ?>" target="_blank"> 
                    <?php _e("Click here to go to settings.", 'linkilo'); ?> 
                </a>
                <br>
                <?php _e("OR", 'linkilo'); ?> 
                <br>
                <?php echo get_post_type(); ?>
                <?php _e("Select the following criteria for link suggestions.", 'linkilo'); ?> 
            </span>
        </div>
        <div class="linkilo_meta_box_column2">
            <?php echo Linkilo_Build_Root::showVersion(); ?>
        </div>
    </div>
    <div class="best_keywords outgoing">
        <div style="margin-bottom: 15px;">
            <div style="margin-bottom: 20px;">
                <!-- Category Wrap -->
                <div style="display: flex;">
                    <div>
                        <input style="margin: 0px;" type="checkbox" name="same_category" id="multi_field_same_category" <?php echo !empty($same_category) ? 'checked' : ''; ?>> 
                        <label for="multi_field_same_category">
                            <?php _e('Show Links Based on Category', 'linkilo'); ?> 
                        </label> 
                    </div>
                    <div class="linkilo_help" style="float: right;position: relative;">
                        <i class="dashicons dashicons-editor-help" style="font-size: 20px;"></i>
                        <div style="display: none;position: absolute;top: 50%;left: 100%;transform: translate(0%, -50%); width:300px;margin: 0px;"> 
                            <?php _e('If you do not see a dropdown selection, it means that we could not find any links. Please add more categories/tags to each post.', 'linkilo'); ?> 
                        </div>
                    </div>
                </div>
                <?php if ($same_category && !empty($categories)) : $default_cat = 0;?>
                    <div>
                        <input type="hidden" name="count" value="<?php echo sizeof($categories); ?>">
                        <select name="multi_linkilo_selected_category" id="linkilo_selected_category_multi">
                            <option value="<?php echo $default_cat; ?>" <?php echo $default_cat==$selected_category?'selected':''; ?>>
                                <?php _e('All categories', 'linkilo'); ?> 
                            </option>
                            <?php foreach ($categories as $category) : ?>
                                <option value="<?php echo $category->term_id; ?>" <?php echo $category->term_id==$selected_category?'selected':''; ?>><?php echo $category->name; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php 
                        if (is_array($mutliselected_cat_list)) {

                            $show_cat_options_selected = "style=\"display:none;\""; 

                            $display_selected_cats = "";
                            $show_cats_div = false;

                            foreach ($mutliselected_cat_list as $cat_id) {
                                foreach ($categories as $category) {
                                    if (
                                        $selected_category != 0 &&
                                        $category->term_id == $cat_id
                                    ) {
                                        $display_selected_cats .= "<a href=\"javascript:void(0);\" class=\"linkilo_multi_select_options button-primary\" id=\"cat_remove_btn_".$cat_id."\">".$category->name."<span class=\"remove_option_value\" data-id=\"".$cat_id."\" data-checked=\"cats\">x</span></a>";
                                        $show_cats_div = true;
                                    }
                                }
                            }

                            if ($show_cats_div) { 
                                $show_cat_options_selected = "style=\"display:inline-block;\"";
                            ?>  <br>
                            <div class="linkilo_multi_wrap" <?php echo $show_cat_options_selected; ?>>
                                <?php  echo $display_selected_cats; ?>
                                </div><?php 
                            }
                        } ?>
                    </div>
                <?php endif; ?>
                <!-- Category Wrap -->

                <!-- Tag Wrap -->
                <div style="display: flex;">
                    <div>
                        <input style="margin: 0px;" type="checkbox" name="same_tag" id="multi_field_same_tag" <?php echo !empty($same_tag) ? 'checked' : ''; ?>>
                        <label for="multi_field_same_tag">
                            <?php _e('Show Links Based on Tags', 'linkilo'); ?> 
                        </label>
                    </div>
                    <div class="linkilo_help" style="float: right;position: relative;">
                        <i class="dashicons dashicons-editor-help" style="font-size: 20px;"></i>
                        <div style="display: none;position: absolute;top: 50%;left: 100%;transform: translate(0%, -50%); width:300px;margin: 0px;"> 
                            <?php _e('If you do not see a dropdown selection, it means that we could not find any links. Please add more categories/tags to each post.', 'linkilo'); ?> 
                        </div>
                    </div>
                </div>
                <?php if ($same_tag && !empty($tags)) : $default_tag = 0;?>
                    <div>
                        <input type="hidden" name="count" value="<?php echo sizeof($tags); ?>">
                        <select name="multi_linkilo_selected_tag" id="linkilo_selected_tag_multi">
                            <option value="<?php echo $default_tag; ?>" <?php echo $default_tag==$selected_tag?'selected':''; ?>>
                                <?php _e('All tags', 'linkilo'); ?> 
                            </option>
                            <?php foreach ($tags as $tag) : ?>
                                <option value="<?php echo $tag->term_id; ?>" <?php echo $tag->term_id==$selected_tag?'selected':''; ?>> 
                                    <?php echo $tag->name; ?> 
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php 
                        if (is_array($mutliselected_tag_list)) {

                            $show_tag_options_selected = "style=\"display:none;\""; 

                            $display_selected_tags = "";
                            $show_tags_div = false;

                            foreach ($mutliselected_tag_list as $tag_id) {
                                foreach ($tags as $tag) {
                                    if (
                                        $selected_tag != 0 &&
                                        $tag->term_id == $tag_id
                                    ) {
                                        $display_selected_tags .= "<a href=\"javascript:void(0);\" class=\"linkilo_multi_select_options button-primary\" id=\"tag_remove_btn_".$tag_id."\">".$tag->name."<span class=\"remove_option_value\" data-id=\"".$tag_id."\" data-checked=\"tags\">x</span></a>";
                                        $show_tags_div = true;
                                    }
                                }
                            }

                            if ($show_tags_div) { 
                                $show_tag_options_selected = "style=\"display:inline-block;\"";
                            ?>  <br>
                            <div class="linkilo_multi_wrap" <?php echo $show_tag_options_selected; ?>>
                                <?php  echo $display_selected_tags; ?>
                                </div><?php 
                            } 
                        } ?>
                    </div>
                <?php endif; ?>
                <!-- Tag Wrap -->

                <!-- Title Tags Wrap -->
                <div style="display: flex;">
                    <div>
                        <input type="checkbox" style="margin:0px !important" name="same_title_chk" id="field_same_title_chk" <?php echo $same_title_option_checked; ?> data-post_title_chk = "<?php echo get_the_title( $post->id ); ?>"> 
                        <label for="field_same_title_chk">
                            <?php _e('Show Links Based on Title Tags', 'linkilo'); ?> 
                        </label>
                    </div>
                </div>
                <!-- Title Tags Wrap -->

                <!-- Exact Match Wrap -->
                <div style="display: flex;">
                    <div>
                        <input style="margin: 0px;" type="checkbox" name="exact_match_keyword" id="exact_match_keyword_post" <?php echo $exact_match_keyword_checked;?>> 
                        <label for="exact_match_keyword_post"> 
                            <?php _e('Show Links Based on Exact Match Keywords', 'linkilo'); ?> 
                        </label>
                    </div>
                </div>
                <!-- Exact Match Wrap -->

                <!-- URL Wrap -->
                <div style="display: flex;">
                    <div>
                        <input type="checkbox" style="margin:0px !important" name="exact_match_url" id="exact_match_url_slug" <?php echo $exact_match_slug_checked; ?>>  
                        <label for="exact_match_url_slug"> 
                            <?php _e('Show Links Based on URL', 'linkilo'); ?> 
                        </label>
                    </div>
                </div>
                <!-- URL Wrap -->

                <!-- Contextual Related Articles Wrap -->
                <div style="display: flex;">
                    <div>
                        <input type="checkbox" style="margin:0px !important" name="links_based_on_related_posts" id="links_based_on_related_posts" <?php echo $match_article_checked; ?>> 
                        <label for="links_based_on_related_posts"> 
                            <?php _e('Show Links Based on Contextual Related Articles', 'linkilo'); ?> 
                        </label>
                    </div>
                </div>
                <!-- Contextual Related Articles Wrap -->
                <!-- Sub Heading wrap -->
                <div style="display: flex;">
                    <div>
                        <input type="checkbox" style="margin:0px !important" name="links_based_on_sub_headings" id="links_based_on_sub_headings" <?php echo $match_sub_heading_checked; ?>> 
                        <label for="links_based_on_sub_headings"> 
                            <?php _e('Show Links Based on Sub Heading', 'linkilo'); ?> 
                        </label>
                    </div>
                </div>
                <!-- Sub Heading wrap -->
            </div>

            <?php if (!empty($phrase_groups)): ?>
                <div>
                    <button class="sync_linking_keywords_list button-primary cst-btn-clr" data-id="<?php echo esc_attr($post->id); ?>" data-type="<?php echo esc_attr($post->type); ?>"  data-page="outgoing">
                        <?php _e('Save Changes', 'linkilo') ?>
                        <span class="dashicons dashicons-arrow-right-alt2" style="margin-top: 3px;font-size: 21px;"></span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if (!empty($phrase_groups)) : ?>
                <div>
                    <label for="linkilo-outgoing-daterange" style="font-weight: bold; font-size: 16px !important; margin: 18px 0 8px; display: block; display: inline-block;">
                        <?php _e('Show Links Based On Published Date', 'linkilo'); ?> 
                    </label> 
                    <br/>
                    <input id="linkilo-outgoing-daterange" type="text" name="daterange" class="linkilo-date-range-filter" value="<?php echo '01/01/2000 - ' . date('m/d/Y', strtotime('today')); ?>" style="width: 180px;text-align: center;">
                </div>
                <script>
                    var rows = jQuery('tr[data-linkilo-sentence-id]');
                    jQuery('#linkilo-outgoing-daterange').on('apply.daterangepicker, hide.daterangepicker', function(ev, picker) {
                        jQuery(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
                        var start = picker.startDate.unix();
                        var end   = picker.endDate.unix();

                        rows.each(function(index, element){
                            var suggestions = jQuery(element).find('.dated-outgoing-suggestion');
                            var first = true;
                            suggestions.each(function(index, element2){
                                var elementTime = jQuery(element2).data('linkilo-post-published-date');
                                var checkbox = jQuery(element2).find('input'); 
                                /*linkilo_dropdown checkbox for the current suggestion, not the suggestion's checkbox*/

                                if(!start || (start < elementTime && elementTime < end)){
                                    jQuery(element2).removeClass('linkilo-outgoing-date-filtered');
                                    /*check the first visible suggested post*/ 
                                    if(first && checkbox.length > 0){
                                        checkbox.trigger('click');
                                        first = false;
                                    }
                                }else{
                                    jQuery(element2).addClass('linkilo-outgoing-date-filtered');

                                    /*if this is a suggestion in a collapsible box, uncheck it*/
                                    if(checkbox.length > 0){
                                        checkbox.prop('checked', false);
                                    }
                                }
                            });

                            /*if all of the suggestions have been hidden*/
                            if(suggestions.length === jQuery(element).find('.dated-outgoing-suggestion.linkilo-outgoing-date-filtered').length){
                                /*hide the suggestion row and uncheck it's checkboxes*/
                                jQuery(element).css({'display': 'none'});
                                jQuery(element).find('.chk-keywords').prop('checked', false);
                            }else{
                                /*if not, make sure the suggestion row is showing*/
                                jQuery(element).css({'display': 'table-row'});
                            }
                        });

                        /*handle the results of hiding any posts*/
                        handleHiddenPosts();
                    });

                    jQuery('#linkilo-outgoing-daterange').on('cancel.daterangepicker', function(ev, picker) {
                        jQuery(this).val('');
                        jQuery('.linkilo-outgoing-date-filtered').removeClass('linkilo-outgoing-date-filtered');
                    });

                    jQuery('#linkilo-outgoing-daterange').daterangepicker({
                        autoUpdateInput: false,
                        linkedCalendars: false,
                        locale: {
                            cancelLabel: 'Clear'
                        }
                    });
                    /*Handles the table display elements when the date range changes*/
                    function handleHiddenPosts(){
                        if(jQuery('.chk-keywords:visible').length < 1){
                            /*hide the table elements*/
                            jQuery('.wp-list-table thead, .sync_linking_keywords_list, .linkilo_incoming_links_button').css({'display': 'none'});
                            /*make sure the "Check All" box is unchecked*/
                            jQuery('.incoming-check-all-col input, #select_all').prop('checked', false);
                            /*show the "No matches" message*/
                            jQuery('.linkilo-no-posts-in-range').css({'display': 'table-row'});
                        }else{
                            /*show the table elements*/
                            jQuery('.wp-list-table thead').css({'display': 'table-header-group'});
                            jQuery('.sync_linking_keywords_list, .linkilo_incoming_links_button').css({'display': 'inline-block'});
                            /*hide the "No matches" message*/
                            jQuery('.linkilo-no-posts-in-range').css({'display': 'none'});
                        }
                    }
                </script>
            <?php endif; ?>
            <?php require LINKILO_PLUGIN_DIR_PATH . 'templates/table_recommendations.php'; ?>
        </div>
        <?php if (!empty($phrase_groups)): ?>
            <div>
                <button class="sync_linking_keywords_list button-primary cst-btn-clr" data-id="<?php echo esc_attr($post->id); ?>" data-type="<?php echo esc_attr($post->type); ?>"  data-page="outgoing">
                    <?php _e('Save Changes', 'linkilo') ?>
                    <span class="dashicons dashicons-arrow-right-alt2" style="margin-top: 3px;font-size: 21px;"></span>
                </button>
            </div>
        <?php endif; ?>
    </div>
    <?php 
endif; 
?>