<div class="wrap linkilo-report-page linkilo_styles linkilo-lists linkilo_post_links_count_update_page">
    <br>
    <a href="<?php echo admin_url("admin.php?page=linkilo"); ?>" class="page-title-action"> 
        <?php _e('Return to Report', 'linkilo'); ?> 
    </a>
    <h1 class='wp-heading-inline'> 
        Updating links stats for <?php echo $post->type?> #<?php echo $post->id; ?>, `<?php echo $post->getTitle(); ?>` 
    </h1>
    <p>
        <a href="<?php echo $post->getLinks()->edit; ?>" target="_blank">[edit]</a>
        <a href="<?php echo $post->getLinks()->view; ?>" target="_blank">[view]</a>
        <a href="<?php echo $post->getLinks()->export; ?>" target="_blank">[export]</a>
    </p>
    <h2>Previous data:</h2>
    <p>Date of previous analysis: <?php echo !empty($prev_t) ? $prev_t : '- not set -'; ?></p>
    <ul>
        <li>
            <b>Outgoing Internal Links:</b> <?php echo $prev_count['outgoing_internal']; ?>
        </li>
        <li>
            <b>Incoming Internal Links:</b> <?php echo $prev_count['incoming_internal']; ?>
        </li>
        <li>
            <b>Outgoing External Links:</b> <?php echo $prev_count['outgoing_external']; ?>
        </li>
    </ul>

    <h2>New data:</h2>
    <p>Date of analysis: <?php echo $new_time; ?></p>
    <p>Time spent: <?php echo number_format($time, 3); ?> seconds</p>
    <ul>
        <li>
            <b>Outgoing Internal Links:</b> <?php echo $count['outgoing_internal']; ?> (difference: <?php echo $count['outgoing_internal'] - $prev_count['outgoing_internal']; ?>)
        </li>
        <li>
            <b>Incoming Internal Links:</b> <?php echo $count['incoming_internal']; ?> (difference: <?php echo $count['incoming_internal'] - $prev_count['incoming_internal']; ?>)
        </li>
        <li>
            <b>Outgoing External Links:</b> <?php echo $count['outgoing_external']; ?> (difference: <?php echo $count['outgoing_external'] - $prev_count['outgoing_external']; ?>)
        </li>
    </ul>

    <h3>Outgoing Internal Links (links count: <?php echo $count['outgoing_internal']; ?>)</h3>
    <ul>
        <?php foreach ($links_data['outgoing_internal'] as $link) : ?>
            <li>
                <a href="<?php echo esc_url($link->url)?>" target="_blank" style="text-decoration: underline">
                    <?php echo esc_url($link->url); ?><br> <b>[<?php echo esc_attr($link->anchor); ?>]</b>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

    <h3>Incoming Internal Links (links count: <?php echo $count['incoming_internal']; ?>)</h3>
    <ul>
        <?php foreach ($links_data['incoming_internal'] as $link) : ?>
            <li>
                [<?php echo $link->post->id; ?>] <?php echo $link->post->getTitle(); ?> <b>[<?php echo esc_attr($link->anchor); ?>]</b>
                <br>
                <a href="<?php echo $link->post->getLinks()->edit; ?>" target="_blank">[edit]</a>
                <a href="<?php echo $link->post->getLinks()->view; ?>" target="_blank">[view]</a>
                <br>
                <br>
            </li>
        <?php endforeach; ?>
    </ul>

    <h3>Outgoing External Links (links count: <?php echo $count['outgoing_external']; ?>)</h3>
    <ul>
        <?php foreach ($links_data['outgoing_external'] as $link) : ?>
            <li>
                <a href="<?php echo esc_url($link->url); ?>" target="_blank" style="text-decoration: underline">
                    <?php echo esc_url($link->url); ?>
                    <br>
                    <b>[<?php echo esc_attr($link->anchor); ?>]</b>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>