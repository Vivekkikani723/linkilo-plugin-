<input type="hidden" name="wp_screen_options[option]" value="linkilo_keyword_options" />
<input type="hidden" name="wp_screen_options[value]" value="yes" />
<fieldset class="screen-options">
    <legend><?php _e('Options', 'linkilo'); ?></legend>
    <input type="hidden" name="linkilo_keyword_options[hide_select_links_column]" value="off"/>
    <input type="checkbox" name="linkilo_keyword_options[hide_select_links_column]" id="hide_select_links_column" <?php echo $hide_select_links ? 'checked' : ''; ?>/>
    <label for="hide_select_links_column"><?php _e("Hide Possible Links Column?", 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>
</fieldset>
<fieldset class="screen-options">
    <legend><?php _e("Pagination", 'linkilo'); ?></legend>
    <label for="per_page"><?php _e("Entries per page", 'linkilo'); ?></label>
    <input type="number" step="1" min="1" max="999" maxlength="3" name="linkilo_keyword_options[per_page]" id="per_page" value="<?php echo esc_attr($per_page); ?>" />
</fieldset>
<br>
<?php echo $button; ?>
<?php wp_nonce_field( 'screen-options-nonce', 'screenoptionnonce', false, false ); ?>