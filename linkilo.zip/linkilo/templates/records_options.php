<?php 
    if (
    isset($_GET['page']) && $_GET['page'] === "linkilo" &&
        isset($_GET['type']) && $_GET['type'] === "links" ||
        isset($_GET['type']) && $_GET['type'] === "domains"
    ) { ?>
<input type="hidden" name="wp_screen_options[option]" value="report_options" />
<input type="hidden" name="wp_screen_options[value]" value="yes" />
<fieldset class="screen-options">
        <legend><?php _e('Options', 'linkilo'); ?></legend>
        <input type="checkbox" name="report_options[show_categories]" id="show_categories" <?php echo $show_categories ? 'checked' : ''; ?> <?php echo ('links' !== $report && !empty($report)) ? $hide : ''?>/>
        <label for="show_categories" <?php echo ('links' !== $report && !empty($report)) ? $hide : ''; ?>><?php _e('Show categories', 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>
        <input type="checkbox" name="report_options[show_type]" id="show_type" <?php echo $show_type ? 'checked' : ''?> <?php echo 'links' !== $report ? $hide : ''; ?>/>
        <label for="show_type" <?php echo 'links' !== $report ? $hide : ''; ?>><?php _e('Show post type', 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>
        <input type="checkbox" name="report_options[show_date]" id="show_date" <?php echo $show_date ? 'checked' : ''; ?> <?php echo 'links' !== $report ? $hide : ''; ?>/>
        <label for="show_date" <?php echo 'links' !== $report ? $hide : ''; ?>><?php _e('Show the post publish date', 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>

        <?php if(Linkilo_Build_GscAppConsole::linkilo_app_console_check_authorized()){ ?>
            <input type="checkbox" name="report_options[show_traffic]" id="show_traffic" <?php echo $show_traffic ? 'checked' : ''; ?> <?php echo  'links' !== $report ? $hide : ''; ?>/>
            <label for="show_traffic" <?php echo 'links' !== $report ? $hide : ''; ?>><?php _e('Show the organic traffic', 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>
        <?php } ?>

        <input type="checkbox" name="report_options[hide_ignore]" id="hide_ignore" <?php echo $hide_ignore ? 'checked' : ''; ?> <?php echo ('links' !== $report && !empty($report)) ? $hide : ''; ?>/>
        <label for="hide_ignore" <?php echo ('links' !== $report && !empty($report)) ? $hide : ''; ?>><?php _e("Don't show posts that have been ignored", 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>
        <input type="checkbox" name="report_options[hide_noindex]" id="hide_noindex" <?php echo $hide_noindex ? 'checked' : ''; ?> <?php echo ('links' !== $report && !empty($report)) ? $hide : ''; ?>/>
        <label for="hide_noindex" <?php echo ('links' !== $report && !empty($report)) ? $hide : ''; ?>><?php _e("Don't show posts that have been set to noindex", 'linkilo'); ?>&nbsp;&nbsp;&nbsp;</label>
</fieldset>
<fieldset class="screen-options">
    <legend><?php _e('Pagination', 'linkilo'); ?></legend>
    <label for="per_page"><?php _e('Entries per page', 'linkilo'); ?></label>
    <input type="number" step="1" min="1" max="999" maxlength="3" name="report_options[per_page]" id="per_page" value="<?php echo esc_attr($per_page); ?>" />
</fieldset>
<br>
<?php echo $button; ?>
<?php wp_nonce_field( 'screen-options-nonce', 'screenoptionnonce', false, false ); ?>
<?php } ?>