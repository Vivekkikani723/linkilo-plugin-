<div class="wrap linkilo-report-page linkilo_styles">
    <?php echo Linkilo_Build_Root::showVersion(); ?>
    <?php $user = wp_get_current_user(); ?>
    <?php 
        if( isset( $_GET['orphaned'] ) ){
            $main_title = __('Orphan URLs Records', 'linkilo'); 
        }elseif( isset( $_GET['ssl_status'] ) ){
            $main_title = __('Non HTTPS URLs Records', 'linkilo'); 
        }
        elseif (isset($_GET['same_urls'])) {
            $main_title = __('Same URLs Records', 'linkilo'); 
        }else{
            $main_title = __('Add New URLs', 'linkilo');             
        }
    ?>
    <h1 class="wp-heading-inline"><?php echo $main_title; ?></h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <?php include_once 'records_tabs.php'; ?>
                <div class="tbl-link-reports">
                    <form>
                        <input type="hidden" name="page" value="linkilo" />
                        <input type="hidden" name="type" value="links" />
                        <?php $tbl->search_box('Search', 'search_posts'); ?>
                    </form>
                    <?php $tbl->display(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    var admin_url = '<?php echo admin_url(); ?>';
</script>
