<?php include_once 'records_tabs.php'; ?>
<?php if(LINKILO_STATUS_HAS_RUN_SCAN): ?>
    <div class="row" style="display:flex !important;">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-4" style="display:flex !important;">
                        <div class="col-lg-12">
                            <h4 class="mb-4" style="color: #1078C7;">
                                <?php _e('General Statistics', 'linkilo'); ?> 
                            </h4>
                        </div>
                        <!--All URLs-->
                        <div class="col-lg-3 col-md-6">
                            <div class="ds-stat" style="background-color: #EBF4FF;padding: 15px;border-radius: 10px;">
                                <a href="<?php echo admin_url('admin.php?page=linkilo&type=links'); ?>">
                                    <span class="ds-stat-name">
                                        <?php _e('All URLs','linkilo'); ?>
                                    </span>
                                    <h3 class="ds-stat-number" style="color: #1078C7;">
                                        <?php echo $count_all_urls; ?> 
                                    </h3>
                                </a>
                            </div>
                        </div>
                        <!--All URLs-->

                        <!--Total Links Found-->
                        <div class="col-lg-3 col-md-6">
                            <div class="ds-stat" style="background-color: #c2f5d5;padding: 15px;border-radius: 10px;">
                                <a href="<?php echo admin_url('admin.php?page=linkilo&type=links'); ?>">
                                    <span class="ds-stat-name">
                                        <?php _e('Total Links Found', 'linkilo'); ?>
                                    </span>
                                    <h3 class="ds-stat-number" style="color: #0f843a;">
                                        <?php echo $count_total_links_found; ?>
                                    </h3>
                                </a>
                            </div>
                        </div>
                        <!--Total Links Found-->

                        <!--Total internal links-->
                        <div class="col-lg-3 col-md-6">
                            <div class="ds-stat" style="background-color: #ffe7bd;padding: 15px;border-radius: 10px;">
                                <a href="<?php echo admin_url('admin.php?page=linkilo&type=links&orderby=linkilo_links_incoming_internal_count&order=desc'); ?>">
                                    <span class="ds-stat-name">
                                        <?php _e('Total internal links', 'linkilo'); ?>
                                    </span>
                                    <h3 class="ds-stat-number" style="color: #c18014;">
                                        <?php echo $count_total_internal_links; ?>
                                    </h3>
                                </a>
                            </div>
                        </div>
                        <!--Total internal links-->

                        <!--Pages with internal links-->                       
                        <div class="col-lg-3 col-md-6">                            
                            <div class="ds-stat" style="background-color: #7d71ae3d;padding: 15px;border-radius: 10px;">
                                <a href="<?php echo admin_url('admin.php?page=linkilo&type=links&filter_type=1&link_type=incoming-internal&link_min_count=1'); ?>">
                                    <span class="ds-stat-name">
                                        <?php _e('Pages with internal links', 'linkilo'); ?>
                                    </span>
                                    <h3 class="ds-stat-number" style="color: #625989;">
                                        <?php echo $count_page_w_internal_link; ?>
                                    </h3>
                                </a>
                            </div>
                        </div>
                        <!--Pages with internal links-->
                    </div>
                    
                    <div class="row" style="display:flex !important;">
                        <div class="col-lg-12">
                            <h4 class="mb-4" style="color: #1078C7;">
                                <?php _e('Link Issues', 'linkilo'); ?> 
                            </h4>
                        </div>
                        <div class="linkilo_link_issue_main">
                            <!--Pages without internal links--> 
                            <div class="linkilo_link_issue_box">
                                <?php
                                $pwoinl_card_color = intval($count_page_wo_internal_link) === 0 ? "#ebf4ff" : "#fcd3d3";
                                $pwoinl_count_text_color = intval($count_page_wo_internal_link) === 0 ? "#1078C7" : "#ef4444";
                                ?>
                                <div class="ds-stat" style="background-color: <?php echo $pwoinl_card_color; ?>;padding: 15px;border-radius: 10px;">
                                    <a href="<?php echo admin_url('admin.php?page=linkilo&type=links&filter_type=1&link_type=incoming-internal&link_min_count=0&link_max_count=0'); ?>">
                                        <span class="ds-stat-name">
                                            <?php _e('Pages without internal links','linkilo'); ?>
                                        </span>
                                        <h3 class="ds-stat-number" style="color: <?php echo $pwoinl_count_text_color; ?>;">
                                            <?php echo $count_page_wo_internal_link; ?>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                            <!--Pages without internal links--> 

                            <!--Orphan pages--> 
                            <div class="linkilo_link_issue_box">   
                                <?php
                                $cpwoexl_card_color = intval($count_orphan_pages) === 0 ? "#ebf4ff" : "#fcd3d3";
                                $cpwoexl_count_text_color = intval($count_orphan_pages) === 0 ? "#1078C7" : "#ef4444";
                                ?>                        
                                <div class="ds-stat" style="background-color: <?php echo $cpwoexl_card_color; ?>;padding: 15px;border-radius: 10px;">
                                    <a href="<?php echo admin_url('admin.php?page=linkilo&type=links&orphaned=1'); ?>">
                                        <span class="ds-stat-name">
                                            <?php _e('Orphan pages','linkilo'); ?>
                                        </span>
                                        <h3 class="ds-stat-number" style="color: <?php echo $cpwoexl_count_text_color; ?>;">
                                            <?php echo $count_orphan_pages; ?>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                            <!--Orphan pages--> 

                            <!--Pages without external links-->                         
                            <div class="linkilo_link_issue_box">
                                <?php
                                $cpwoexl_card_color = intval($count_page_wo_external_link) === 0 ? "#ebf4ff" : "#fcd3d3";
                                $cpwoexl_count_text_color = intval($count_page_wo_external_link) === 0 ? "#1078C7" : "#ef4444";
                                ?>
                                <div class="ds-stat" style="background-color: <?php echo $cpwoexl_card_color; ?>;padding: 15px;border-radius: 10px;">
                                    <a href="<?php echo admin_url('admin.php?page=linkilo&type=links&filter_type=1&link_type=outgoing-external&link_min_count=0&link_max_count=0'); ?>">
                                        <span class="ds-stat-name">
                                            <?php _e('Pages without external links', 'linkilo'); ?>
                                        </span>
                                        <h3 class="ds-stat-number" style="color: <?php echo $cpwoexl_count_text_color; ?>;">
                                            <?php echo $count_page_wo_external_link; ?>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                            <!--Pages without external links-->  

                            <!--link cannibalization-->    
                            <div class="linkilo_link_issue_box">
                                <?php
                                $link_cannib_card_color = intval($count_link_cannibalization) === 0 ? "#ebf4ff" : "#fcd3d3";
                                $link_cannib_count_text_color = intval($count_link_cannibalization) === 0 ? "#1078C7" : "#ef4444";
                                ?>
                                <div class="ds-stat" style="background-color: <?php echo $link_cannib_card_color; ?>;padding: 15px;border-radius: 10px;">
                                    <a href="<?php echo admin_url('admin.php?page=link_cannibalization'); ?>">
                                        <span class="ds-stat-name">
                                            <?php _e('link cannibalization', 'linkilo'); ?>
                                        </span>
                                        <h3 class="ds-stat-number" style="color: <?php echo $link_cannib_count_text_color; ?>;">
                                            <?php echo $count_link_cannibalization; ?>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                            <!--link cannibalization-->   

                            <!--Non-https links--> 
                            <div class="linkilo_link_issue_box">
                                <?php
                                $non_http_links_card_color = intval( $count_non_https_links ) === 0 ? "#ebf4ff" : "#fcd3d3";
                                $non_http_links_count_text_color = intval( $count_non_https_links ) === 0 ? "#1078C7" : "#ef4444";
                                $non_https_report_url = add_query_arg( array(
                                    'page' => 'linkilo',
                                    'type' => 'links',
                                    'ssl_status' => intval($count_non_https_links) === 0 ? 0 : 1,
                                ), admin_url('admin.php') );
                                ?>
                                <div class="ds-stat" style="background-color: <?php echo $non_http_links_card_color; ?>;padding: 15px;border-radius: 10px;">
                                    <a href="<?php echo $non_https_report_url; ?>">
                                        <span class="ds-stat-name">
                                            <?php _e('Non-https links','linkilo'); ?>
                                        </span>
                                        <h3 class="ds-stat-number" style="color: <?php echo $non_http_links_count_text_color; ?>;">
                                            <?php echo $count_non_https_links; ?>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                            <!--Non-https links-->

                            <!--same url-->    
                            <div class="linkilo_link_issue_box">
                                <?php
                                $same_url_card_color = intval($count_same_url) === 0 ? "#ebf4ff" : "#fcd3d3";
                                $same_url_count_text_color = intval($count_same_url) === 0 ? "#1078C7" : "#ef4444";

                                $count_same_report_url = add_query_arg( array(
                                    'page' => 'linkilo',
                                    'type' => 'links',
                                    'same_urls' => intval($count_same_url) === 0 ? 0 : 1,
                                    'orderby' => 'linkilo_links_incoming_internal_count',
                                    'order' => 'asc',
                                ), admin_url('admin.php') );
                                ?>
                                <div class="ds-stat" style="background-color: <?php echo $same_url_card_color; ?>;padding: 15px;border-radius: 10px;">
                                    <a href="<?php echo $count_same_report_url; ?>">
                                        <span class="ds-stat-name">
                                            <?php _e('same url', 'linkilo'); ?>
                                        </span>
                                        <h3 class="ds-stat-number" style="color: <?php echo $same_url_count_text_color; ?>;">
                                            <?php echo $count_same_url; ?>
                                        </h3>
                                    </a>
                                </div>
                            </div>
                            <!--same url-->     
                        </div>                    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="display:flex !important;">
        <div class="col-lg-7">
            <!-- Domains -->
            <div class="row" style="display:flex !important;">
                <div class="col-lg-12">
                    <h4 style="color: #1078C7;margin-top: 25px;">
                        <?php echo _e("Frequently Used", "linkilo");?>
                        <a href="<?php echo admin_url('admin.php?page=linkilo&type=domains'); ?>" title="<?php echo _e("View List", "linkilo"); ?>">
                            <span style="color: #000;">
                                <?php echo _e("Domains", "linkilo");?>
                            </span>
                        </a>
                    </h4>
                </div>
                <div class="domain_container_dashboard">
                    <?php
                    $i=0;
                    $prev = isset($domains[0]->cnt) ? $domains[0]->cnt : 0;
                    $domain_counter = 0;
                    $colmd_domain = 4;
                    if (sizeof($domains) < 2) :
                        $colmd_domain = 12;
                    elseif (sizeof($domains) < 3) :
                        $colmd_domain = 6;
                    elseif (sizeof($domains) < 4) :
                        $colmd_domain = 6;
                    elseif (sizeof($domains) > 4) :
                        $colmd_domain = 4;
                    endif;
                    shuffle($domains);
                    
                    foreach ($domains as $domain) : 
                        if (!empty($domain->host) && !is_null($domain->host) && strlen(trim($domain->host)) > 2) :

                            if ($prev != $domain->cnt) : 
                                $i++; $prev = $domain->cnt; 
                            endif; 

                            if ($domain_counter < 9): 
                                ?>
                                <div class="<?php echo "col-".$colmd_domain ?>">
                                    <div class="card dash_card_hover_box_shadow" title="<?php echo $domain->host; ?>">
                                        <div class="card-body">
                                            <div class="info-card">
                                                <div style="display:flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                                                    <h4 class="info-title dash-card-text"> 
                                                        <?php echo $domain->host; ?> 
                                                    </h4>
                                                    <h5 class="info-stats dash-card-count">
                                                        <?php echo $domain->cnt; ?>
                                                    </h5>
                                                </div>
                                                <div class="progress" style="height: 3px;">
                                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo (($domain->cnt/$top_domain)*100); ?>%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php 
                                $domain_counter++; 
                            endif; 
                        endif;
                    endforeach; 
                    ?>
                </div>
            </div>
            <!-- Domains -->
            <!-- Anchor Texts -->
            <div class="row" style="display:flex !important">
                <div class="col-lg-12">
                    <h4 style="color: #1078C7;margin-top: 25px;">
                        <?php echo _e("Frequently Used", "linkilo"); ?>
                        <a href="<?php echo admin_url('admin.php?page=anchor_analysis'); ?>" title="<?php echo _e("View List", "linkilo"); ?>">
                            <span style="color: #000;">
                                <?php echo _e("Anchor Texts", "linkilo"); ?>
                            </span>
                        </a>
                    </h4>
                </div>
                <div class="keyword_container_dashboard">
                    <?php 
                    if (sizeof($anchor_keywords_data) > 0) :

                        $total_cnt = sizeof($anchor_keywords_data);
                        $anchor_counter = 0;
                        $colmd_anchor = 4;
                        if (sizeof($anchor_keywords_data) < 2) :
                            $colmd_anchor = 12;
                        elseif (sizeof($anchor_keywords_data) < 3) :
                            $colmd_anchor = 6;
                        elseif (sizeof($anchor_keywords_data) < 4) :
                            $colmd_anchor = 4;
                        elseif (sizeof($anchor_keywords_data) > 4) :
                            $colmd_anchor = 4;
                        endif;
                        shuffle($anchor_keywords_data);

                        foreach ($anchor_keywords_data as $index => $value) :
                            if (
                                !is_null($value['anchor']) &&
                                !empty($value['anchor']) &&
                                strlen(trim($value['anchor'])) > 2
                            ):
                                if ($anchor_counter < 9) :
                                    $bar_width = (($value['count']/$total_cnt)*100);
                                    ?>
                                    <div class="<?php echo "col-".$colmd_anchor; ?>">
                                        <div class="card dash_card_hover_box_shadow" title="<?php echo $value['anchor'];?>">
                                            <div class="card-body">
                                                <div class="info-card">
                                                    <div style="display:flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                                                        <h4 class="info-title dash-card-text">
                                                            <?php echo $value['anchor'];?> 
                                                        </h4>
                                                        <h5 class="info-stats dash-card-count">
                                                            <?php echo $value['count'];?>
                                                        </h5>
                                                    </div>
                                                    <div class="progress" style="height: 3px;">
                                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $bar_width; ?>%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $anchor_counter++; 
                                endif; 
                            endif; 
                        endforeach; 
                    endif;
                    ?>
                </div>
            </div>
            <!-- Anchor Texts -->
        </div>
        <div class="col-lg-5">
            <div class="row">
                <h4 style="color: #1078C7;margin-top: 25px;">
                    <?php _e('Internal vs External', 'linkilo');  ?>
                    <span style="color: #000;">
                        &nbsp;<?php _e('URL', 'linkilo'); ?> 
                    </span>
                </h4>
                <div class="canvas-container-dashboard">
                    <canvas class="canvas-dashboard-design" id="linkilo_links_chart">
                        <?php _e('Your browser does not support the canvas element.', 'linkilo'); ?>
                    </canvas>
                    <div class="popular-products">
                        <div class="popular-product-list">
                            <ul class="list-unstyled">
                                <li id="popular-product1">
                                    <span> 
                                        <?php _e('External', 'linkilo'); ?> 
                                    </span>
                                    <span class="product-color">
                                        <?php echo $count_external; ?>
                                    </span>
                                    <input type="hidden" name="total_links_count" value="<?php echo $count_external; ?>">
                                </li>
                                <li id="popular-product2">
                                    <span>
                                        <?php _e('Internal', 'linkilo'); ?> 
                                    </span>
                                    <span class="product-color">
                                        <?php echo $count_total_internal_links; ?>
                                    </span>
                                    <input type="hidden" name="internal_links_count" value="<?php echo $count_total_internal_links; ?>">
                                </li>
                                <li id="popular-product3">
                                    <span> 
                                        <?php _e('External Links: NoFollow', 'linkilo'); ?> 
                                    </span>
                                    <span class="product-color">
                                        <?php echo $count_external_nofollow; ?>
                                    </span>
                                    <input type="hidden" name="external_links_count_nofollow" value="<?php echo $count_external_nofollow; ?>">
                                </li>
                                <li id="popular-product4">
                                    <span>
                                        <?php _e('Sponsored', 'linkilo'); ?>
                                    </span>
                                    <span class="product-color" style="background-color:red; color: #fff;">
                                        <?php echo $count_sponsored; ?>
                                    </span>
                                    <input type="hidden" name="sponsored_links_count" value="<?php echo $count_sponsored; ?>">
                                </li>
                                <li id="popular-product5">
                                    <span> 
                                        <?php _e('User Generated content links', 'linkilo'); ?> 
                                    </span>
                                    <span class="product-color" style="background-color:blue; color: #fff;">
                                        <?php echo $count_user_link; ?>
                                    </span>
                                    <input type="hidden" name="user_created_links_count" value="<?php echo $count_user_link; ?>">
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="run-first-scan-wrapper">
        <div class="run-first-scan-container">
            <div>
                <p style="font-weight: 600; font-size: 20px !important;">
                    <?php _e('Welcome to Linkilo!', 'linkilo');?>
                </p>
                <p style="font-weight: 600; font-size: 20px !important;">
                    <?php _e('We’ll need to complete the first time setup, so we can get up and running.', 'linkilo'); ?>
                </p>
                <p style="font-weight: 600; font-size: 17px !important;">
                    <?php _e('Please click on run scan.', 'linkilo'); ?>
                </p>
                <p style="font-weight: 600; font-size: 20px !important;">
                    <?php _e('Why? Because...', 'linkilo');?>
                </p>
                <p style="font-weight: 600; font-size: 17px !important;">
                    <?php _e('Linkilo needs to crawl and scan to identify internal link opportunities, link metrics and other advanced functionality like checking for any error, and other features we’ve provided for you..', 'linkilo'); ?>
                </p>
                <p style="font-weight: 600; font-size: 20px !important;">
                    <?php _e('If you already ran a scan…', 'linkilo'); ?>
                </p>
                <p style="font-weight: 600; font-size: 20px !important;">
                    <?php _e('Please wait for the scan to be completed or if you exit out, please run a new scan. We only need to make sure the database is updated and no settings will be affected.', 'linkilo'); ?>
                </p>
                <form action='' method="post" id="linkilo_report_reset_data_form" style="float:none;margin-top:50px;">
                    <input type="hidden" name="reset_data_nonce" value="<?php echo wp_create_nonce($user->ID . 'linkilo_refresh_record_data'); ?>">
                    
                    <?php if (!empty($_GET['type'])) : ?>
                        <a href="javascript:void(0)" class="button-primary csv_button" data-type="<?php echo $_GET['type']; ?>" id="linkilo_cvs_export_button"> 
                            <?php _e('Export CSV', 'linkilo'); ?> 
                        </a>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-outline-success" style="border: 2px solid #63CD68;color: #63CD68;font-size: 16px;font-weight: 600; padding: 10px 15px; border-radius: 6px;"> 
                        <?php _e('Run Scan');?>
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>