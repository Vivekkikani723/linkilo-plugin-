<div class="wrap linkilo-report-page linkilo_styles link_cannibalization">
    <?php echo Linkilo_Build_Root::showVersion(); ?>
    <?php $user = wp_get_current_user(); ?>
    <h1 class="wp-heading-inline"><?php echo ucwords( __('link cannibalization report', 'linkilo') );?></h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <?php include_once 'records_tabs.php'; ?>
                <div id="cannibalization_report_list">
                    <form>
                        <input type="hidden" name="page" value="link_cannibalization" />
                        <?php $table->search_box('Search', 'search'); ?>
                    </form>
                    <?php $table->display(); ?>
                </div>
            </div>
        </div>
    </div>
</div>