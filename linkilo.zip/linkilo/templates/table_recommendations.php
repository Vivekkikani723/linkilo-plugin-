<?php $link_external = get_option('linkilo_link_external_sites', false);?>
<?php if (!empty($phrase_groups)): ?>
    <?php foreach($phrase_groups as $phrase_group_type => $phrases) : ?> 
        <?php 
        // omit the external section if external linking isn't enabled
        if(empty($link_external) && 'external_site' === $phrase_group_type){
            continue;
        }

        // output the spacer if this is the external suggestions
        if('external_site' === $phrase_group_type && !empty($phrases)){
            echo '<div style="border-top: solid 2px #ccd0d4; margin: 0 -13px;"></div>';
        }   
        ?>
        <div class="tbl_post_edit_outbound">
            <table class="wp-list-table widefat fixed striped posts tbl_keywords_x js-table linkilo-outgoing-links" id="tbl_keywords">
                <?php if (!empty($phrases)) : ?>
                    <thead>
                        <tr>
                            <th>
                                <div>
                                    <b><?php if('internal_site' === $phrase_group_type){ _e('Find & Add New Links', 'linkilo'); }else{ _e('Add Outbound Links to External Sites', 'linkilo'); } ?></b>
                                    <div style="margin:5px 0 0 0; display: none;">
                                        <input type="checkbox" id="select_all"><span style="margin:0 0 0 5px; font-weight:300"><?php _e('Check All', 'linkilo'); ?></span>
                                    </div>
                                </div>
                            </th>
                            <th>
                                <div>
                                    <b><?php _e('Posts to link to', 'linkilo'); ?></b>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody id="the-list" class="linkilo-outgoing-suggestions-table">
                        <?php foreach ($phrases as $key_phrase => $phrase) : ?>
                            <tr data-linkilo-sentence-id="<?php echo esc_attr($key_phrase); ?>">
                                <td class="sentences">
                                    <?php $suggest_init = 0; ?>
                                    <?php foreach ($phrase->suggestions as $suggestion) : ?>
                                        <?php 
                                        $suggestion_div_display = "style=\"display:block\"";
                                        if ($suggest_init > 0) {
                                            $suggestion_div_display = "style=\"display:none\"";
                                        } 
                                        ?>
                                        <div class="sentence top-level-sentence" data-id="<?php echo esc_attr($suggestion->post->id); ?>" data-type="<?php echo esc_attr($suggestion->post->type); ?>" <?php echo $suggestion_div_display; ?>>
                                            <div class="linkilo_edit_sentence_form">
                                                <textarea class="linkilo_content"><?php echo $suggestion->sentence_src_with_anchor; ?></textarea>
                                                <span class="button-primary"><?php _e('Save','linkilo'); ?></span>
                                                <span class="button-secondary"><?php _e('Cancel','linkilo'); ?></span>
                                            </div>
                                            <input type="checkbox" name="link_keywords[]" class="chk-keywords" linkilo-link-new="">
                                            <span class="linkilo_sentence_with_anchor" title="<?php _e('Double clicking a word will select it.', 'linkilo'); ?>"><?php echo $suggestion->sentence_with_anchor; ?></span>
                                            <span class="linkilo_edit_sentence link-form-button">| <a href="javascript:void(0)" class="cst-btn-clr"><?php _e('Edit','linkilo'); ?> <span class="dashicons dashicons-edit"></span></a></span>
                                            <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($suggestion->anchor_score).')':''; ?>
                                            <input type="hidden" name="sentence" value="<?php echo base64_encode($phrase->sentence_src); ?>">
                                            <input type="hidden" name="custom_sentence" value="">

                                            <?php if (Linkilo_Build_AdminSettings::fullHTMLSuggestions()) : ?>
                                                <div class="raw_html"> 
                                                    <?php echo htmlspecialchars($suggestion->sentence_src_with_anchor); ?> 
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <?php $suggest_init++; ?>
                                    <?php endforeach; ?>

                                </td>
                                <td>
                                    <?php if (count($phrase->suggestions) > 1) : ?>
                                        <?php 
                                        $index = key($phrase->suggestions);
                                        $a_post = $phrase->suggestions[$index]->post;
                                        ?>
                                        <div class="linkilo-collapsible-wrapper">
                                            <div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count">
                                                <div style="opacity:<?php echo $phrase->suggestions[$index]->opacity; ?>" data-id="<?php echo esc_attr($a_post->id); ?>" data-type="<?php echo esc_attr($a_post->type); ?>" data-post-origin="<?php echo (!isset($a_post->site_url)) ? 'internal': 'external'; ?>" data-site-url="<?php echo (isset($a_post->site_url)) ? esc_url($a_post->site_url): ''; ?>">
                                                    <?php echo esc_attr($a_post->getTitle()); ?>
                                                    <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($phrase->suggestions[$index]->post_score).')':'';?>
                                                    <br>
                                                    <a class="post-slug cst-href-clr" target="_blank" href="<?php echo $a_post->getLinks()->view; ?>"> 
                                                        <?php echo urldecode($a_post->getSlug()); ?> 
                                                    </a>
                                                    <span class="add_custom_link_button link-form-button"> | <a href="javascript:void(0)" class="cst-btn-clr" ><?php _e('Add Your Own','linkilo'); ?></a></span>
                                                </div>
                                            </div>
                                            <div class="linkilo-content" style="display: none;">
                                                <ul>
                                                    <?php foreach ($phrase->suggestions as $key_suggestion => $suggestion) : ?>
                                                        <li class="dated-outgoing-suggestion" data-linkilo-post-published-date="<?php echo strtotime(get_the_date('F j, Y', $suggestion->post->id)); ?>">
                                                            <div>
                                                                <input type="radio" <?php echo !$key_suggestion?'checked':''; ?> data-id="<?php echo esc_attr($suggestion->post->id); ?>" data-type="<?php echo esc_attr($suggestion->post->type); ?>" data-suggestion="<?php echo esc_attr($key_suggestion); ?>" data-post-origin="<?php echo (!isset($suggestion->post->site_url)) ? 'internal': 'external'; ?>" data-site-url="<?php echo (isset($suggestion->post->site_url)) ? esc_url($suggestion->post->site_url): ''; ?>">
                                                                <span class="data">
                                                                    <span style="opacity:<?php echo $suggestion->opacity; ?>"><?php echo esc_attr($suggestion->post->getTitle()); ?></span>
                                                                    <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($suggestion->post_score).')':''; ?>
                                                                    <br>
                                                                    <a class="post-slug cst-href-clr" target="_blank" href="<?php echo $suggestion->post->getLinks()->view; ?>"> 
                                                                        <?php echo urldecode($suggestion->post->getSlug()); ?> 
                                                                    </a>
                                                                </span>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php else : ?>
                                        <?php
                                        if(!isset($phrase->suggestions[0]->post) || empty($phrase->suggestions[0]->post)){
                                            continue;
                                        }
                                        $a_post = $phrase->suggestions[0]->post
                                        ?>
                                        <div style="opacity:<?php echo $phrase->suggestions[0]->opacity; ?>;padding: 10px;background-color: #f2f2f2;border-radius: 10px" class="suggestion dated-outgoing-suggestion" data-id="<?php echo esc_attr($a_post->id); ?>" data-type="<?php echo esc_attr($a_post->type); ?>" data-linkilo-post-published-date="<?php echo strtotime(get_the_date('F j, Y', $phrase->suggestions[0]->post->id)); ?>" data-post-origin="<?php echo (!isset($a_post->site_url)) ? 'internal': 'external'; ?>" data-site-url="<?php echo (isset($a_post->site_url)) ? esc_url($a_post->site_url): ''; ?>">
                                            <?php echo esc_attr($a_post->getTitle()); ?>
                                            <?php echo !empty(Linkilo_Build_UrlRecommendation::$undeletable)?' ('.esc_attr($phrase->suggestions[0]->post_score).')':''; ?>
                                            <br>
                                            <a class="post-slug cst-href-clr" target="_blank" href="<?php echo $a_post->getLinks()->view; ?>">
                                                <?php echo urldecode($a_post->getSlug()); ?>
                                            </a>
                                            <span class="add_custom_link_button link-form-button"> | <a href="javascript:void(0)" class="cst-btn-clr"><?php _e('Add Your Own','linkilo'); ?></a></span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <button class="button-primary cst-btn-clr outgoing-load-more" style="text-transform: uppercase;" name="linkilo-outgoing-load-more" data-loader="1" data-loop="20">
                                    <?php _e("Load More", "linkilo"); ?>
                                    <span class="dashicons dashicons-arrow-down-alt2" style="margin-top: 2px;font-size: 23px;"></span>
                                </button>
                            </td>
                        </tr>
                        <tr class="linkilo-no-posts-in-range" style="display:none">
                            <td><?php _e('No suggestions found','linkilo'); ?></td>
                        </tr>
                    </tbody>
                <?php else : ?>
                    <?php
                    if('external_site' === $phrase_group_type){
                        echo '<div style="border-top: solid 2px #ccd0d4; margin: 0 -13px;"></div>';
                    }    
                    ?>
                    <thead>
                        <tr>
                            <th>
                                <div>
                                    <b><?php if('internal_site' === $phrase_group_type){ _e('Find & Add New Links', 'linkilo'); }else{ _e('Add Outbound Links to External Sites', 'linkilo'); } ?></b>
                                    <br />
                                </div>
                            </th>
                            <th>
                                <div>
                                    <b><?php _e('Posts to link to', 'linkilo'); ?></b>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody id="the-list" class="linkilo-outgoing-suggestions-table">
                        <tr>
                            <td><?php _e('No suggestions found', 'linkilo'); ?></td>
                        </tr>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="tbl_post_edit_outbound">
        <table class="wp-list-table widefat fixed striped posts tbl_keywords_x js-table linkilo-outgoing-links" id="tbl_keywords">
            <thead>
                <tr>
                    <th>
                        <?php _e('Find & Add New Links', 'linkilo'); ?>
                    </th>
                    <th>
                        <?php _e('Posts to link to', 'linkilo'); ?>
                    </th>
                </tr>
            </thead>
            <tbody id="the-list" class="linkilo-outgoing-suggestions-table">
                <tr class="no-suggestions-outbound">
                    <td colspan="2" style="text-align:center;">
                        <?php _e('No suggestions found', 'linkilo'); ?> 
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <button class="button-primary cst-btn-clr outgoing-load-more" style="text-transform: uppercase;" name="linkilo-outgoing-load-more" data-loader="1" data-loop="20" data-empty="1" data-row="no-suggestions-outbound" data-btn="process-outbound-suggestion">
                            <?php _e("Try loading some!", "linkilo"); ?>
                            <span class="dashicons dashicons-arrow-down-alt2" style="margin-top: 2px;font-size: 23px;"></span>
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div style="display:none;" id="process-outbound-suggestion">
        <button class="sync_linking_keywords_list button-primary cst-btn-clr" data-id="<?php echo esc_attr($post->id); ?>" data-type="<?php echo esc_attr($post->type); ?>"  data-page="outgoing">
            <?php _e('Save Changes', 'linkilo') ?>
            <span class="dashicons dashicons-arrow-right-alt2" style="margin-top: 3px;font-size: 21px;"></span>
        </button>
    </div>
<?php endif; ?>