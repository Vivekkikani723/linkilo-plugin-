<input type="hidden" name="wp_screen_options[option]" value="anar_rep_options" /> 
<input type="hidden" name="wp_screen_options[value]" value="yes" />
<fieldset class="screen-options">
    <legend>Pagination</legend>
    <label for="per_page">Entries per page</label>
    <input type="number" step="1" min="1" max="100" maxlength="3" name="anar_rep_options[per_page]" id="per_page" value="<?php echo esc_attr($per_page); ?>" />
</fieldset>
<br>
<?php echo $button; ?>
<?php wp_nonce_field( 'screen-options-nonce', 'screenoptionnonce', false, false ); ?>