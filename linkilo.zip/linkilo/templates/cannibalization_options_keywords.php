<input type="hidden" name="wp_screen_options[option]" value="cannibalization_keywords"/>
<input type="hidden" name="wp_screen_options[value]" value="yes" />
<fieldset class="screen-options">
    <legend><?php _e('Pagination', 'linkilo'); ?></legend>
    <label for="per_page"><?php _e('Entries per page', 'linkilo') ?></label>
    <input type="number" step="1" min="1" max="100" maxlength="3" name="cannibalization_keywords[per_page]" id="per_page" value="<?php echo esc_attr($per_page); ?>" />
    
    <label for="keywords_dev_mode"><?php _e('Display Un-Cannibalized', 'linkilo') ?></label>
    <input type="checkbox" name="cannibalization_keywords[dev_mode]" id="keywords_dev_mode" <?php echo ($dev_mode === true) ? 'checked' : ''; ?> />
</fieldset>
<br>
<?php echo $button; ?>
<?php wp_nonce_field( 'screen-options-nonce', 'screenoptionnonce', false, false ); ?>