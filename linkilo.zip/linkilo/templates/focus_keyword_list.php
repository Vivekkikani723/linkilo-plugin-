<div id="linkilo-keyword-select-metabox" class="categorydiv linkilo_styles">
    <ul id="keyword-tabs" class="category-tabs">
        <li class="tabs keyword-tab">
            <a href="#keywords-all" data-keyword-tab="keywords-all">
                <?php _e('All Keywords', 'linkilo'); ?>
            </a>
        </li>
        <?php if (in_array('gsc', $keyword_sources)) { ?>
            <li class="hide-if-no-js keyword-tab">
                <a href="#keywords-gsc" data-keyword-tab="keywords-gsc">
                    <?php _e('Google Search Console Keywords', 'linkilo'); ?>
                </a>
            </li>
        <?php } ?>

        <?php if (in_array('yoast', $keyword_sources)) { ?>
            <li class="hide-if-no-js keyword-tab">
                <a href="#keywords-yoast" data-keyword-tab="keywords-yoast">
                    <?php _e('Yoast Keywords', 'linkilo'); ?>
                </a>
            </li>
        <?php } ?>

        <?php if (in_array('rank-math', $keyword_sources)) { ?>
            <li class="hide-if-no-js keyword-tab">
                <a href="#keywords-rank-math" data-keyword-tab="keywords-rank-math">
                    <?php _e('Rank Math Keywords', 'linkilo'); ?>
                </a>
            </li>
        <?php } ?>

        <?php if (in_array('aioseo', $keyword_sources)) { ?>
            <li class="hide-if-no-js keyword-tab">
                <a href="#keywords-aioseo" data-keyword-tab="keywords-aioseo">
                    <?php _e('All in one SEO Keywords', 'linkilo'); ?>
                </a>
            </li>
        <?php } ?>

        <?php if (in_array('seopress', $keyword_sources)) { ?>
            <li class="hide-if-no-js keyword-tab">
                <a href="#keywords-seopress" data-keyword-tab="keywords-seopress">
                    <?php _e('SEOPress Keywords', 'linkilo'); ?>
                </a>
            </li>
        <?php } ?>

        <?php if (in_array('squirrly', $keyword_sources)) { ?>
            <li class="hide-if-no-js keyword-tab">
                <a href="#keywords-squirrly" data-keyword-tab="keywords-squirrly">
                    <?php _e('Squirrly SEO Keywords', 'linkilo'); ?>
                </a>
            </li>
        <?php } ?>

        <li class="hide-if-no-js keyword-tab">
            <a href="#keywords-custom" data-keyword-tab="keywords-custom">
                <?php _e('Custom Keywords', 'linkilo'); ?>
            </a>
        </li>

        <li class="hide-if-no-js keyword-tab">
            <a href="#keywords-googlequery" data-keyword-tab="keywords-googlequery">
                <?php _e('Generate Keywords', 'linkilo'); ?>
            </a>
        </li>

        <li class="hide-if-no-js keyword-tab">
            <a href="#keywords-bulk-upload" data-keyword-tab="keywords-bulk-upload">
                <?php _e('Bulk Upload Keywords', 'linkilo'); ?>
            </a>
        </li>

        <li class="hide-if-no-js keyword-tab">
            <a href="#keywords-negative" data-keyword-tab="keywords-negative">
                <?php _e('Negative Keywords', 'linkilo'); ?>
            </a>
        </li>
    </ul>

    <div id="keywords-all" class="tabs-panel">
        <input type="hidden" value="0">
        <ul id="keywordchecklist" data-wp-lists="list:category" class="categorychecklist form-no-clear">
            <?php foreach ($keywords as $keyword) {
                if ('negative-keyword' === $keyword->keyword_type) {
                    continue;
                }
                $id = $keyword->keyword_index;
            ?>
                <li id="keyword-all-<?php echo $id; ?>" class="all-keyword">
                    <label class="selectit">
                        <input type="checkbox" class="keyword-<?php echo $id; ?>" data-keyword-id="<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> value="<?php echo $id; ?>">
                        <?php echo $keyword->keywords; ?>
                    </label>
                </li>
            <?php } ?>
        </ul>
    </div>
    <?php if (in_array('gsc', $keyword_sources)) { // Show the GSC keywords 
    ?>
        <div id="keywords-gsc" class="tabs-panel" style="display: none;">
            <ul id="keywordchecklist-gsc" class="categorychecklist form-no-clear">
                <?php foreach ($keywords as $keyword) {
                    if ('gsc-keyword' !== $keyword->keyword_type) {
                        continue;
                    }
                    $id = $keyword->keyword_index;
                ?>
                    <li id="keyword-gsc-<?php echo $id; ?>" class="gsc-keyword">
                        <label class="selectit">
                            <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                            <?php echo $keyword->keywords; ?>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    <?php if (in_array('yoast', $keyword_sources)) { // Show the Yoast keywords  
    ?>
        <div id="keywords-yoast" class="tabs-panel" style="display: none;">
            <ul id="keywordchecklist-yoast" class="categorychecklist form-no-clear">
                <?php foreach ($keywords as $keyword) {
                    if ('yoast-keyword' !== $keyword->keyword_type) {
                        continue;
                    }
                    $id = $keyword->keyword_index;
                ?>
                    <li id="keyword-yoast-<?php echo $id; ?>" class="yoast-keyword">
                        <label class="selectit">
                            <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                            <?php echo $keyword->keywords; ?>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    <?php if (in_array('rank-math', $keyword_sources)) { // Show the Rank Math keywords  
    ?>
        <div id="keywords-rank-math" class="tabs-panel" style="display: none;">
            <ul id="keywordchecklist-rank-math" class="categorychecklist form-no-clear">
                <?php foreach ($keywords as $keyword) {
                    if ('rank-math-keyword' !== $keyword->keyword_type) {
                        continue;
                    }
                    $id = $keyword->keyword_index;
                ?>
                    <li id="keyword-rank-math-<?php echo $id; ?>" class="rank-math-keyword">
                        <label class="selectit">
                            <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                            <?php echo $keyword->keywords; ?>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>

    <?php if (in_array('squirrly', $keyword_sources)) { // Show the Squirrly SEO keywords  
    ?>
        <div id="keywords-squirrly" class="tabs-panel" style="display: none;">
            <ul id="keywordchecklist-squirrly" class="categorychecklist form-no-clear">
                <?php foreach ($keywords as $keyword) {
                    if ('squirrly-keyword' !== $keyword->keyword_type) {
                        continue;
                    }
                    $id = $keyword->keyword_index;
                ?>
                    <li id="keyword-squirrly-<?php echo $id; ?>" class="squirrly-keyword">
                        <label class="selectit">
                            <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                            <?php echo $keyword->keywords; ?>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    
    <?php if (in_array('aioseo', $keyword_sources)) { // Show the AIOSEO keywords  
    ?>
        <div id="keywords-aioseo" class="tabs-panel" style="display: none;">
            <ul id="keywordchecklist-aioseo" class="categorychecklist form-no-clear">
                <?php foreach ($keywords as $keyword) {
                    if ('aioseo-keyword' !== $keyword->keyword_type) {
                        continue;
                    }
                    $id = $keyword->keyword_index;
                ?>
                    <li id="keyword-aioseo-<?php echo $id; ?>" class="aioseo-keyword">
                        <label class="selectit">
                            <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                            <?php echo $keyword->keywords; ?>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    <?php if (in_array('seopress', $keyword_sources)) { // Show the SEOPress keywords  
    ?>
        <div id="keywords-seopress" class="tabs-panel" style="display: none;">
            <ul id="keywordchecklist-seopress" class="categorychecklist form-no-clear">
                <?php foreach ($keywords as $keyword) {
                    if ('seopress-keyword' !== $keyword->keyword_type) {
                        continue;
                    }
                    $id = $keyword->keyword_index;
                ?>
                    <li id="keyword-seopress-<?php echo $id; ?>" class="seopress-keyword">
                        <label class="selectit">
                            <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                            <?php echo $keyword->keywords; ?>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    <div id="keywords-custom" class="tabs-panel report-add-internal-links-overflow" style="display: none;">
        <ul id="keywordchecklist-custom" class="categorychecklist form-no-clear">
            <?php foreach ($keywords as $keyword) {
                if ('custom-keyword' !== $keyword->keyword_type) {
                    continue;
                }
                $id = $keyword->keyword_index;
            ?>
                <li id="keyword-custom-<?php echo $id; ?>" class="custom-keyword">
                    <label class="selectit">
                        <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                        <?php echo $keyword->keywords; ?>
                        <i class="linkilo_focus_keyword_delete dashicons dashicons-no-alt" data-keyword-id="<?php echo $id; ?>" data-keyword-type="custom-keyword" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'delete-focus-keywords-' . $id); ?>"></i>
                    </label>
                </li>
            <?php } ?>
        </ul>
        <div class="create-post-keywords report-add-internal-links">
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-create-focus-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'create-focus-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>" data-post-type="<?php echo $post->type; ?>">
                <?php _e('Create New Keyword', 'linkilo'); ?>
            </a>
            <div class="linkilo-create-focus-keywords-row-container" style="width: calc(100% - 300px); display: inline-block;">
                <input style="width: 100%;vertical-align: baseline;" type="text" class="create-custom-focus-keyword-input" placeholder="<?php _e('New Custom Keyword', 'linkilo'); ?>">
            </div>
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-add-focus-keyword-row" style="margin-left:10px;">
                <?php _e('Add Row', 'linkilo'); ?>
            </a>
        </div>
    </div>
    <div id="keywords-googlequery" class="tabs-panel report-add-internal-links-overflow" style="display: none; max-height:250px">
        <ul id="keywordchecklist-googlequery" class="categorychecklist form-no-clear">
            <?php foreach ($keywords as $keyword) {
                if ('googlequery-keyword' !== $keyword->keyword_type) {
                    continue;
                }
                $id = $keyword->keyword_index;
            ?>
                <li id="keyword-googlequery-<?php echo $id; ?>" class="googlequery-keyword">
                    <label class="selectit">
                        <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                        <?php echo $keyword->keywords; ?>
                        <i class="linkilo_focus_keyword_delete dashicons dashicons-no-alt" data-keyword-id="<?php echo $id; ?>" data-keyword-type="googlequery" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'delete-focus-keywords-' . $id); ?>"></i>
                    </label>
                </li>
            <?php } ?>
        </ul>
        <div class="create-post-keywords report-add-internal-links">
            <div class="linkilo-fetch-googlequery-keywords-row-container" style="width: calc(100% - 300px); display: inline-block;">
                <input style="width: 100%;vertical-align: baseline;" type="text" class="fetch-googlequery-focus-keyword-input" placeholder="<?php _e('Type Keyword', 'linkilo'); ?>">
            </div>
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-fetch-googlequery-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'create-focus-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>" data-post-type="<?php echo $post->type; ?>">
                <?php _e('Generate New Keywords', 'linkilo'); ?>
            </a>
        </div>
        <div class="create-post-keywords report-add-internal-links google-suggestions hidden-imp">
            <div class="linkilo-create-googlequery-keywords-row-container" style="width: calc(100% - 300px); display: inline-block;">
                <div class="googlequery-focus-keyword-suggestions"></div>
            </div>
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-create-googlequery-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'create-focus-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>" data-post-type="<?php echo $post->type; ?>">
                <?php _e('Create Selected Keywords', 'linkilo'); ?>
            </a>
        </div>
    </div>
    <div id="keywords-bulk-upload" class="tabs-panel report-add-internal-links-overflow" style="display: none;">
        <ul id="keywordchecklist-bulk-upload" class="categorychecklist form-no-clear">
            <?php foreach ($keywords as $keyword) {
                if ('bulk-upload-keyword' !== $keyword->keyword_type) {
                    continue;
                }
                $id = $keyword->keyword_index;
            ?>
                <li id="keyword-bulk-upload-<?php echo $id; ?>" class="bulk-upload-keyword">
                    <label class="selectit">
                        <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                        <?php echo $keyword->keywords; ?>
                        <i class="linkilo_focus_keyword_delete dashicons dashicons-no-alt" data-keyword-id="<?php echo $id; ?>" data-keyword-type="bulk-upload" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'delete-focus-keywords-' . $id); ?>"></i>
                    </label>
                </li>
            <?php } ?>
        </ul>
        <div class="create-post-keywords report-add-internal-links pop">
            <label for="linkilo_focus_keyword_bulk_add" id="linkilo_focus_keyword_bulk_add_label" class="open btn button-primary"><?php _e('Bulk Import keywords', 'linkilo'); ?></label>
            <input type="checkbox" id="linkilo_focus_keyword_bulk_add" class="hidden_c" />
            <div class="modal">
                <div class="modal__inner">
                    <div class="close_d">
                        <div class="key_b"><img src="<?php echo LINKILO_PLUGIN_DIR_URL; ?>images/imp.svg" alt="import_keywords">
                            <p class="key_w">Import Keywords</p>
                        </div>
                    </div>
                    <div class="cross"><label for="linkilo_focus_keyword_bulk_add" class="linkilo_focus_keyword_bulk_close_button"><img src="<?php echo LINKILO_PLUGIN_DIR_URL; ?>images/close-outline.svg" class="w-6" alt=""></label></div>
                    <div class="main">
                        <div class="inner_main">
                            <label class="f_label">
                                <div class="text_holder">
                                    <span class="s_text">Slelect CSV/XLSX file</span>
                                </div>
                                <input type="file" accept=".csv" name="file" id="choose_file">
                            </label>
                            <label for="linkilo_bulk_upload_keywords_first_row" class="w-full" style="margin-top: 10px; max-width: 19rem">
                                <input type="checkbox" name="linkilo_bulk_upload_keywords_first_row" id="linkilo_bulk_upload_keywords_first_row"> Use first row as header
                            </label>
                            <a href="<?php echo LINKILO_PLUGIN_DIR_URL; ?>keywords.csv" class="f_an underline text-sm mt-4 font-semibold download">Need help? Download a template here.</a>
                        </div>
                        <div class="button_holder">
                            <label for="linkilo_focus_keyword_bulk_add" class="linkilo_focus_keyword_bulk_close_button btn-close">Cancel</label>
                            <button for="Upload" id="Upload1" class="linkilo-bulk-upload-focus-keywords btn-close" style="padding: 8px 24px!important;" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'bulk-upload-focus-keywords-' . $post->id); ?>" data-page="post_editor" data-post-id="<?php echo $post->id; ?>" data-post-type="<?php echo $post->type; ?>">Upload</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="keywords-negative" class="tabs-panel report-add-internal-links-overflow" style="display: none;">
        <ul id="keywordchecklist-negative" class="categorychecklist form-no-clear">
            <?php foreach ($negative_keywords as $negative_keyword) {
                // if('negative-keyword' !== $negative_keyword->keyword_type){
                //     continue;
                // }
                $id = $negative_keyword->keyword_index;
            ?>
                <li id="keyword-negative-<?php echo $id; ?>" class="negative-keyword">
                    <label class="selectit">
                        <input type="checkbox" class="keyword-<?php echo $id; ?>" <?php echo ($negative_keyword->checked) ? 'checked="checked"' : ''; ?> data-keyword-id="<?php echo $id; ?>" value="<?php echo $id; ?>">
                        <?php echo $negative_keyword->keywords; ?>
                        <i class="linkilo_focus_keyword_delete dashicons dashicons-no-alt" data-keyword-id="<?php echo $id; ?>" data-keyword-type="negative" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'delete-focus-keywords-' . $id); ?>"></i>
                    </label>
                </li>
            <?php } ?>
        </ul>
        <div class="create-post-keywords report-add-internal-links">
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-create-negative-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'create-negative-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>" data-post-type="<?php echo $post->type; ?>">
                <?php _e('Create Negative Keyword', 'linkilo'); ?>
            </a>
            <div class="linkilo-create-negative-keywords-row-container" style="width: calc(100% - 300px); display: inline-block;">
                <input style="width: 100%;vertical-align: baseline;" type="text" class="create-negative-keyword-input" placeholder="<?php _e('New Negative Keyword', 'linkilo'); ?>">
            </div>
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-add-negative-keyword-row" style="margin-left:10px;">
                <?php _e('Add Row', 'linkilo'); ?>
            </a>
        </div>
    </div>
    <?php $hide = (empty($keywords)) ? ' display:none; ' : ''; ?>
    <button class="button-primary linkilo-update-selected-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'update-selected-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>" style="margin: 15px 0 0 0;<?php echo $hide; ?>">
        <?php _e('Update Existing Keywords', 'linkilo'); ?>
    </button>
</div>