<div class="linkilo-collapsible-wrapper">
    <div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count"><?php echo count($links);?></div>
    <div class="linkilo-content">
        <ul class="report_links url-update-page">
            <?php if (sizeof($links) > 0): ?>
                <?php foreach ( $links as $link ) : 
                    $post_id =  $link->post->getID();
                    $post_type =  $link->post->getRealType();
                    $post_title =  $link->post->getTitle();
                    $target_anchor = trim(strip_tags($link->anchor));
                    $new_url = $link->url;
                    $old_url = $link->old_url;
                    $word_unique_id = $link->word_unique_id;
                    $url_id = $link->url_id;
                    $status = $link->status;

                    $anchor_small_case = str_ireplace('', '_', strtolower($target_anchor));
                    $li_element_base = str_ireplace("=", '_', substr(strrev(base64_encode('anchor_word_'.$anchor_small_case.'_'.$word_unique_id)), 0, 20));

                    $li_element = str_ireplace('/', '_', trim($li_element_base)); 
                    ?>
                    <li id="<?php echo esc_attr__($li_element); ?>">
                        <div class="linkilo-url-update-table-col-item">
                            <span class="dashicons dashicons-admin-page"></span>
                            <div class="update-url-inner-content-wrapper">
                                <?php echo trim( strip_tags( $post_title ) ); ?>
                            </div>
                        </div>
                        <div class="linkilo-url-update-table-col-item">
                            <span class="dashicons dashicons-edit"></span>
                            <div class="update-url-inner-content-wrapper">
                                <?php echo !empty($link->anchor)? '<span style="color: #1078C7;font-weight: 600;">' . stripslashes(  strip_tags($link->anchor) ) . '</span>' : ''; ?>
                            </div>
                        </div>
                        <div class="linkilo-url-update-table-col-item">
                            <span class="dashicons dashicons-admin-generic"></span>
                            <div class="update-url-inner-content-wrapper anchor">
                                <a class="auto-link-table-edit" href="<?php echo $link->post->getLinks()->edit;?>" target="_blank">edit</a>
                                <a class="auto-link-table-edit" href="<?php echo $link->post->getLinks()->view;?>" target="_blank">view</a>

                                <?php if( $status === '0' ) :?>
                                    <a 
                                    href="javascript:void(0)"
                                    class="auto-link-table-edit linkilo_individual_replace_url"
                                    data-post-id="<?php echo $post_id;?>"
                                    data-url_id="<?php echo $url_id;?>"
                                    data-word_id="<?php echo $word_unique_id;?>"
                                    data-old_url="<?php echo $old_url;?>"
                                    data-new-url="<?php echo $new_url;?>"
                                    data-anchor="<?php echo $target_anchor;?>"
                                    data-posttype=<?php echo $post_type;?>
                                    data-li_element="<?php echo $li_element; ?>"
                                    >replace</a>
                                <?php endif;?>

                                <?php if( $status === '1' ) :?>
                                    <a href="javascript:void(0)"
                                    class="auto-link-table-edit linkilo_individual_undo_url undo"
                                    data-id="<?php echo $url_id;?>"
                                    data-post-id="<?php echo $post_id;?>"
                                    data-url_id="<?php echo $url_id;?>"
                                    data-word_id="<?php echo $word_unique_id;?>"
                                    data-old_url="<?php echo $old_url;?>"
                                    data-new-url="<?php echo $new_url;?> "
                                    data-anchor="<?php echo $target_anchor;?>"
                                    data-posttype=<?php echo $post_type;?>
                                    data-li_element="<?php echo $li_element; ?>"
                                    >undo changes</a>
                                <?php endif;?>
                            </div>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="no-data-urlchanger">
                    <span class="dashicons dashicons-info-outline"></span>
                    <?php _e("No data to display.", 'linkilo'); ?>
                </li>  
            <?php endif; ?>
        </ul>
    </div>
</div>