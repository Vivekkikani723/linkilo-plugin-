<div class="linkilo-collapsible-wrapper">
    <div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count"><?php echo count($links);?></div>
    <?php if( $links ):?>
        <div class="linkilo-content">
            <ul class="report_links">
                <?php foreach ( $links as $link) : ?>
                    <li>
                        <div style="margin-bottom:10px;display:flex;flex-direction:row;">
                            <span class="dashicons dashicons-admin-page add-urls-links-table"></span>
                            <span class="links-row-col-right-text">
                                <?php echo trim(strip_tags($link->post->getTitle())); ?> 
                            </span>
                        </div>     

                        <div style="margin-bottom:10px;display:flex;flex-direction:row;">
                            <span class="dashicons dashicons-edit add-urls-links-table"></span>
                            <span class="links-row-col-right-text">
                                <?php echo !empty($link->anchor)? '<span style="color: #1078C7;">' . stripslashes($link->anchor) . '</span>' : ''; ?>
                            </span>
                        </div>           
                        <div style="margin-bottom:10px;display:flex;flex-direction:row;">
                            <span class="dashicons dashicons-admin-generic add-urls-links-table"></span>
                            <span class="links-row-col-right-text">
                                <a href="<?php echo $link->post->getLinks()->edit; ?>" class="auto-link-table-edit" target="_blank">edit</a>
                                <a href="<?php echo $link->post->getLinks()->view; ?>" class="auto-link-table-view" target="_blank">view</a>
                            </span>
                        </div>  
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif;?>
</div>