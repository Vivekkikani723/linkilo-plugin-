<div class="linkilo-collapsible-wrapper">
    <div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count"><?php echo count($keywords); ?></div>
        <?php if ( !empty( $keywords ) ) :?>
            <div class="linkilo-content">
                <ul class="report_links">
                    <?php foreach ($keywords as $keyword) :
                        
                        if( is_array($keyword) ){  ?>

                                <li id="focus-keyword-<?php echo $keyword[0]->keyword_index; ?>">
                                    <?php
                                    if('custom-keyword' === $keyword[0]->keyword_type){
                                        echo '<div style="display: inline-block;"><label><span>'. $keyword[0]->keywords . '</span></label></div>';
                                        echo '<i class="linkilo_focus_keyword_delete dashicons dashicons-no-alt" data-keyword-id="' . $keyword[0]->keyword_index . '" data-keyword-type="custom-keyword" data-nonce="' . wp_create_nonce(get_current_user_id() . 'delete-focus-keywords-' . $keyword[0]->keyword_index) . '"></i>';
                                    }else{
                                        ?><div style="display: block;"><input id="keyword-<?php echo $keyword[0]->keyword_index; ?>" style="vertical-align: sub;" type="checkbox" name="keyword_active" data-keyword-id="<?php echo $keyword[0]->keyword_index; ?>" <?php echo (!empty($keyword[0]->checked)) ? 'checked="checked"': '';?>><label for="keyword-<?php echo $keyword[0]->keyword_index; ?>"><span><?php echo $keyword[0]->keywords; ?></span></label></div><?php
                                    }

                                    foreach ($keyword as $keyword_gsc) {
                                        $scan_date_start = strtotime($keyword_gsc->scan_date_start);
                                        $scan_date_end = strtotime($keyword_gsc->scan_date_end);
        
                                        $numberOfDays = ($scan_date_end - $scan_date_start) / (60 * 60 * 24);
        
                                        if ('gsc-keyword' === $keyword_gsc->keyword_type) {
        
                                            $display_or_not = $numberOfDays > 7 ? ' none' : ' inline-block';
                                            // Fetch 'Position' data for the current interval
                                            $current_position = $keyword_gsc->position;
                                            // Check if the data point falls within the specified duration
                                            if ($numberOfDays <= 7) {
                                                $previous_position = $previous_position_7days;
                                            } elseif ($numberOfDays <= 14) {
                                                $previous_position = $previous_position_14days;
                                            } elseif ($numberOfDays <= 30) {
                                                $previous_position = $previous_position_1month;
                                            } elseif ($numberOfDays <= 90) {
                                                $previous_position = $previous_position_3months;
                                            } elseif ($numberOfDays <= 180) {
                                                $previous_position = $previous_position_6months;
                                            }
        
                                            // Calculate the difference with the previous interval
                                            $position_difference = $current_position - $previous_position;
        
                                            // Determine the arrow symbol based on the difference
                                            $arrow_symbol = '';
                                            if ($position_difference > 0) {
                                                $arrow_symbol = '<span style="color: green;">&#8593;</span>';
                                            } elseif ($position_difference < 0) {
                                                $arrow_symbol = '<span style="color: red;">&#8595;</span>';
                                            }
        
                                            // Display the data for the current interval
                                            echo
                                            '<div style="display:' . $display_or_not . ';" data-comparison="' . $numberOfDays . '">
                                                <div style="margin: 3px 0;"><i><b>' . date('d F, Y', strtotime($keyword_gsc->scan_date_start)) . ' - ' . date('d F, Y', strtotime($keyword_gsc->scan_date_end)) . '</b></i></div>
                                                <div style="margin: 3px 0;"><b>' . __('Impressions', 'linkilo') . ':</b> ' . $keyword_gsc->impressions . '</div>
                                                <div style="margin: 3px 0;"><b>' . __('Clicks', 'linkilo') . ':</b> ' . $keyword_gsc->clicks . '</div>
                                                <div style="margin: 3px 0;"><b>' . __('Position', 'linkilo') . ':</b> <span>' . $current_position . '</span> ' . $arrow_symbol . '</div>
                                                <div style="margin: 3px 0;"><b>' . __('CTR', 'linkilo') . ':</b> ' . $keyword_gsc->ctr . '</div>
                                            </div>';
        
                                            // Update the previous position for the next iteration based on the number of days
                                            if ($numberOfDays <= 7) {
                                                $previous_position_7days = $current_position;
                                            } elseif ($numberOfDays <= 14) {
                                                $previous_position_14days = $current_position;
                                            } elseif ($numberOfDays <= 30) {
                                                $previous_position_1month = $current_position;
                                            } elseif ($numberOfDays <= 90) {
                                                $previous_position_3months = $current_position;
                                            } elseif ($numberOfDays <= 180) {
                                                $previous_position_6months = $current_position;
                                            }
                                        }
                                    }
                                    ?>
                                    <br>
                                </li>
                        <?php }else{ ?>
                        
                            <li id="focus-keyword-<?php echo $keyword->keyword_index; ?>">
                                <?php
                                if('custom-keyword' === $keyword->keyword_type){
                                    echo '<div style="display: inline-block;"><label><span>'. $keyword->keywords . '</span></label></div>';
                                    echo '<i class="linkilo_focus_keyword_delete dashicons dashicons-no-alt" data-keyword-id="' . $keyword->keyword_index . '" data-keyword-type="custom-keyword" data-nonce="' . wp_create_nonce(get_current_user_id() . 'delete-focus-keywords-' . $keyword->keyword_index) . '"></i>';
                                }else{
                                    ?><div style="display: inline-block;"><input id="keyword-<?php echo $keyword->keyword_index; ?>" style="vertical-align: sub;" type="checkbox" name="keyword_active" data-keyword-id="<?php echo $keyword->keyword_index; ?>" <?php echo (!empty($keyword->checked)) ? 'checked="checked"': '';?>><label for="keyword-<?php echo $keyword->keyword_index; ?>"><span><?php echo $keyword->keywords; ?></span></label></div><?php
                                }
                                
                                if('gsc-keyword' === $keyword->keyword_type){
                                    echo 
                                    '<div>
                                        <div style="margin: 3px 0;"><b>' . __('Impressions', 'linkilo') . ':</b> ' . $keyword->impressions . '</div>
                                        <div style="margin: 3px 0;"><b>' . __('Clicks', 'linkilo') . ':</b> ' . $keyword->clicks . '</div>
                                        <div style="margin: 3px 0;"><b>' . __('Position', 'linkilo') . ':</b> ' . $keyword->position . '</div>
                                        <div style="margin: 3px 0;"><b>' . __('CTR', 'linkilo') . ':</b> ' . $keyword->ctr . '</div>
                                    </div>';
                                } ?>
                                <br>
                            </li>
                        <?php }
                    endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    <?php if(!empty($keywords) && 'custom-keyword' !== $keyword_type){ ?>
    <div class="update-post-keywords">
        <a href="#" class="button-primary linkilo-update-selected-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'update-selected-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>"><?php _e('Update', 'linkilo'); ?></a>
    </div>
    <?php } ?>
    <?php if('custom-keyword' === $keyword_type){ ?>
    <div class="create-post-keywords focus-keywords-page">
        <div class="create-post-keywords-inside">
            <a href="#" style="vertical-align: top;" class="button-primary linkilo-create-focus-keywords" data-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'create-focus-keywords-' . $post->id); ?>" data-post-id="<?php echo $post->id; ?>" data-post-type="<?php echo $post->type; ?>"><?php _e('Create', 'linkilo'); ?></a>
            <div class="linkilo-create-focus-keywords-row-container"  style="display: inline-block; width: calc(100% - 200px);">
                <input type="text" style="width: 100%" class="create-custom-focus-keyword-input" placeholder="<?php _e('New Custom Keyword', 'linkilo'); ?>">
            </div>
            <a href="#" class="button-primary linkilo-add-focus-keyword-row" style="margin-left:0px; vertical-align: top;"><?php _e('Add Row', 'linkilo'); ?></a>
        </div>
    </div>
    <?php } ?>
</div>