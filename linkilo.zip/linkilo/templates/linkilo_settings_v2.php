<div class="wrap linkilo_styles" id="settings_page">
    <?php echo Linkilo_Build_Root::showVersion(); ?>
    <h1 class="wp-heading-inline">
        <?php _e('Settings', 'linkilo'); ?>
    </h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <h2 class="nav-tab-wrapper" style="margin-bottom:1em;justify-content: space-between;">
                <?php
                $active_one = null;
                $active_two = null;
                $active_three = null;
                $active_four = null;
                $active_five = null;
                $active_six = null;
                $active_seven = null;
                $active_eight = null;

                $active_default = null;

                $active_section_id = null;

                if (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-general-settings"
                ) {
                    $active_one = "nav-tab-active";
                    $active_section_id = "linkilo-general-settings";
                } elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-content-ignoring-settings"
                ) {
                    $active_two = "nav-tab-active";
                    $active_section_id = "linkilo-content-ignoring-settings";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-advanced-settings"
                ) {
                    $active_three = "nav-tab-active";
                    $active_section_id = "linkilo-advanced-settings";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-licensing"
                ) {
                    $active_four = "nav-tab-active";
                    $active_section_id = "linkilo-licensing";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-internal-url"
                ) {
                    $active_five = "nav-tab-active";
                    $active_section_id = "linkilo-internal-url";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-external-url"
                ) {
                    $active_six = "nav-tab-active";
                    $active_section_id = "linkilo-external-url";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-sidebar-settings"
                ) {
                    $active_seven = "nav-tab-active";
                    $active_section_id = "linkilo-sidebar-settings";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-linkpreview-settings"
                ) {
                    $active_eight = "nav-tab-active";
                    $active_section_id = "linkilo-linkpreview-settings";
                }elseif (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-gsc-settings"
                ) {
                    $active_nine = "nav-tab-active";
                    $active_section_id = "linkilo-gsc-settings";
                }

                if (
                    is_null($active_one) &&
                    is_null($active_two) &&
                    is_null($active_three) &&
                    is_null($active_four) &&
                    is_null($active_five) &&
                    is_null($active_six) &&
                    is_null($active_seven) &&
                    is_null($active_eight)
                ) {
                    $active_default = "nav-tab-active";
                }
                ?>

                <a class="nav-tab <?php echo (!is_null($active_one)) ? $active_one : $active_default ; ?>" id="linkilo-general-settings" href="#">
                    <?php _e('Global settings', 'linkilo'); ?>
                </a>
                <a class="nav-tab <?php echo (!is_null($active_seven)) ? $active_seven : "" ; ?>" id="linkilo-sidebar-settings" href="#">
                    <?php _e('Sidebar settings', 'linkilo'); ?>
                </a>
                <?php //if (get_option('linkilo_links_preview', '') == 1): ?>
                <a class="nav-tab <?php echo (!is_null($active_eight)) ? $active_eight : "" ; ?>" id="linkilo-linkpreview-settings" href="#">
                    <?php _e('Link Preview settings', 'linkilo'); ?>
                </a>
                <?php //endif ?>
                <a class="nav-tab <?php echo (!is_null($active_five)) ? $active_five : "" ; ?>" id="linkilo-internal-url" href="#">
                    <?php _e('Internal', 'linkilo'); ?>
                </a>
                <a class="nav-tab <?php echo (!is_null($active_six)) ? $active_six : "" ; ?>" id="linkilo-external-url" href="#">
                    <?php _e('External', 'linkilo'); ?>
                </a>

                <a class="nav-tab <?php echo (!is_null($active_two)) ? $active_two : "" ; ?>" id="linkilo-content-ignoring-settings" href="#">
                    <?php _e('ignore URLs', 'linkilo'); ?>
                </a>
                <a class="nav-tab <?php echo (!is_null($active_nine)) ? $active_nine : "" ; ?>" id="linkilo-gsc-settings" href="#">
                    <?php _e('GSC Setting', 'linkilo'); ?>
                </a>
                <a class="nav-tab <?php echo (!is_null($active_three)) ? $active_three : "" ; ?>" id="linkilo-advanced-settings" href="#">
                    <?php _e('Custom Setting', 'linkilo'); ?>
                </a>
                <a class="nav-tab <?php echo (!is_null($active_four)) ? $active_four : "" ; ?>" id="linkilo-licensing" href="#">
                    <?php _e('Licensing', 'linkilo'); ?>
                </a>
            </h2>
            <div class="settings_screen_loader" style="display:none;">
                <div class="linkilo_progress_panel loader">
                    <div class="progress_count" style="width: 100%"></div>
                </div>
                <div class="linkilo_progress_panel_center" >
                    <?php _e('Loading', 'linkilo'); ?>
                </div>
            </div>

            <div id="post-body-content" class="settings_content_section" style="position: relative; display: block;">
                <?php
                $tab_row_one = null;
                $tab_row_two = null;
                $tab_row_three = null;
                $tab_row_four = null;
                $tab_row_five = null;
                $tab_row_six = null;
                $tab_row_seven = null;
                $tab_row_eight = null;
                $tab_row_nine = null;

                $tab_row_default = null;
                if (
                    isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-general-settings"
                ) {
                    $tab_row_one = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-content-ignoring-settings") {
                    $tab_row_two = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-advanced-settings") {
                    $tab_row_three = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-licensing") {
                    $tab_row_four = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-internal-url") {
                    $tab_row_five = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-external-url") {
                    $tab_row_six = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-sidebar-settings") {
                    $tab_row_seven = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-linkpreview-settings") {
                    $tab_row_eight = "style=\"display: table-row;\"";
                }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
                    $_GET['section'] === "linkilo-gsc-settings") {
                    $tab_row_nine = "style=\"display: table-row;\"";
                }

                if (
                    is_null($tab_row_one) &&
                    is_null($tab_row_two) &&
                    is_null($tab_row_three) &&
                    is_null($tab_row_four) &&
                    is_null($tab_row_five) &&
                    is_null($tab_row_six) &&
                    is_null($tab_row_seven) &&
                    is_null($tab_row_eight) &&
                    is_null($tab_row_nine)
                ) {
                    $tab_row_default = "style=\"display: table-row;\"";
                }else{
                    $tab_row_default = "style=\"display: none;\"";
                }
                
                ?>
                <form name="frmSaveSettings" id="frmSaveSettings" action='' method='post'>
                    <?php wp_nonce_field('linkilo_save_settings','linkilo_save_settings_nonce'); ?>
                    <input type="hidden" name="hidden_action" value="linkilo_save_settings" />
                    <input type="hidden" name="active_section" id="active_section_field_value" value="<?php echo (is_null($active_section_id)) ? 'n_v' : $active_section_id; ?>" >
                    <table class="form-table">
                        <tbody>

                            <!-- Google Search Console Update -->
                            <?php
                            $is_linkilo_authorized = get_option('linkilo_app_console_authorized', false);
                            $is_site_selected = get_option('linkilo_app_console_selected', false);
                            ?>
                            <tr <?php echo (!is_null($tab_row_nine)) ? $tab_row_nine : "style=\"display:none\"" ; ?> class="linkilo-gsc-settings linkilo-setting-row settings-row-border">
                                <?php if(empty($is_linkilo_authorized)){ ?>
                                    <td scope='row'>
                                        <?php _e('Connect Linkilo To Google Search Console', 'linkilo'); ?> 
                                    </td>
                                    <td>
                                        <div class="linkilo_gsc_app_inputs">
                                            <!-- google app user authentication link -->
                                            <a class="button-primary" href="<?php echo Linkilo_Build_GscAppConsole::linkilo_app_console_user_auth_url($wizard = true); ?>">  
                                                <?php _e('Authenticate Linkilo', 'linkilo'); ?> 
                                            </a>
                                        </div>
                                    </td>
                                <?php }else{ ?>
                                    <td scope='row'>
                                        <?php _e('Search Console Connected', 'linkilo'); ?> 
                                    </td>
                                    <td>
                                        <!-- Deactivate button -->
                                        <a class="linkilo-app-console-deactivate button-primary" data-nonce="<?php echo wp_create_nonce('linkilo-app-console-disconnect'); ?>"> 
                                            <?php _e('Deactivate', 'linkilo'); ?> 
                                        </a>

                                        <!-- Site fetch button -->
                                        <?php $disabled = Linkilo_Build_GscAppConsole::linkilo_app_console_check_token_expired() ? "disabled" : "" ;?>
                                        <a class="linkilo-app-console-get-sites button-primary" data-nonce="<?php echo wp_create_nonce('linkilo-app-console-fetch-sites'); ?>" <?php echo $disabled; ?>> 
                                            <?php _e('Fetch Sites', 'linkilo'); ?> 
                                        </a>
                                        <span id="site_fetching_status"></span>

                                        <!-- Refresh auth token button -->
                                        <?php if (Linkilo_Build_GscAppConsole::linkilo_app_console_check_token_expired()): ?>
                                            <a class="linkilo-app-console-refresh-auth-token button-primary" data-nonce="<?php echo wp_create_nonce('linkilo-app-console-refresh-auth-token'); ?>"> 
                                                <?php _e('Refresh Token', 'linkilo'); ?> 
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                <?php } ?>
                            </tr>
                            <!-- show when authorized but site is not selected -->
                            <?php if (!empty($is_linkilo_authorized) && false === $is_site_selected): ?>
                                <?php
                                $fetched_sites_list = get_option('linkilo_app_console_fetched_sites_data', false);
                                ?>
                                <tr <?php echo (!is_null($tab_row_nine)) ? $tab_row_nine : "style=\"display:none\"" ; ?> class="linkilo-gsc-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <?php _e('Select a site from list', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <?php if ($fetched_sites_list !== false): ?>
                                            <select name="linkilo_app_console_select_site" style="float:left; max-width:400px">
                                                <option value="0">
                                                    <?php _e('Select Site', 'linkilo'); ?>
                                                </option>
                                                <?php foreach ($fetched_sites_list as $list_site): ?>
                                                    <option value="<?php echo base64_encode(trim($list_site['option_value'])); ?>">
                                                        <?php echo trim($list_site['option_lable']); ?>
                                                    </option>
                                                <?php endforeach ?>
                                            </select>
                                        <?php else: ?>
                                            <span>
                                                <?php _e( "No sites to display please try fetching site again.", 'linkilo'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php if (!empty($is_linkilo_authorized) && false !== $is_site_selected): ?>

                                    <tr <?php echo (!is_null($tab_row_nine)) ? $tab_row_nine : "style=\"display:none\"" ; ?> class="linkilo-gsc-settings linkilo-setting-row settings-row-border">
                                        <td scope='row'>
                                            <?php _e('Selected site :', 'linkilo'); ?>
                                        </td>
                                        <td>
                                            <?php if (false !== get_option('linkilo_app_console_selected_site', false)): ?>
                                                <?php echo get_option('linkilo_app_console_selected_site', "Please fetch or select again"); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif ?>
                            <?php endif; ?>
                            <!-- Google Search Console Update ends -->
                            <?php if(!empty($is_linkilo_authorized)){ ?>
                                <tr <?php echo (!is_null($tab_row_nine)) ? $tab_row_nine : "style=\"display:none\"" ; ?> class="linkilo-gsc-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'><?php _e('Enable Automatic Search Console Updates', 'linkilo'); ?></td>
                                    <td>
                                        <!-- <input type="hidden" name="linkilo_disable_search_update" value="0" /> -->
                                        <input type="checkbox" name="linkilo_disable_search_update" <?php echo get_option('linkilo_disable_search_update', false)==1 ? 'checked' : ''; ?> value="1" />
                                        <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div><?php _e('Linkilo automatically scans for GSC updates via WordPress Cron. Turning this off will stop Linkilo from performing the scan.', 'linkilo'); ?></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>

                            <!-- Link preview Enable/Disable -->
                            <tr <?php echo (!is_null($tab_row_eight)) ? $tab_row_eight : "style=\"display:none\"" ; ?> class="linkilo-linkpreview-settings linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label for="label_linkilo_links_preview">
                                        <?php _e('Enable Link Preview', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_links_preview" value="0" />
                                        <input type="checkbox" name="linkilo_links_preview" id="label_linkilo_links_preview" <?php echo get_option('linkilo_links_preview')==1 ? 'checked' :''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php
                                                _e('Enable/Disable link preview for anchor links.', 'linkilo');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Link preview Enable/Disable -->
                            <!-- Link preview settings starts -->
                            <?php if (get_option('linkilo_links_preview', '') == 1): ?>

                                <tr <?php echo (!is_null($tab_row_eight)) ? $tab_row_eight : "style=\"display:none\"" ; ?> class="linkilo-linkpreview-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <label for="label_linkilo_preview_internal_enable_disable"> 
                                            <?php _e('Enable link preview for internal links', 'linkilo'); ?>
                                        </label>
                                    </td>
                                    <td>
                                        <div style="display: inline-block;">
                                            <input type="hidden" name="linkilo_preview_internal_enable_disable" value="0" />
                                            <input type="checkbox" name="linkilo_preview_internal_enable_disable" id="label_linkilo_preview_internal_enable_disable" <?php echo get_option('linkilo_preview_internal_enable_disable')==1 ? 'checked' :''; ?> value="1" />
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_eight)) ? $tab_row_eight : "style=\"display:none\"" ; ?> class="linkilo-linkpreview-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <label for="label_linkilo_preview_external_enable_disable">
                                            <?php _e('Enable link preview for external links', 'linkilo'); ?>
                                        </label>
                                    </td>
                                    <td>
                                        <div style="display: inline-block;">
                                            <input type="hidden" name="linkilo_preview_external_enable_disable" value="0" />
                                            <input type="checkbox" name="linkilo_preview_external_enable_disable" id="label_linkilo_preview_external_enable_disable" <?php echo get_option('linkilo_preview_external_enable_disable')==1 ? 'checked' :''; ?> value="1" />
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_eight)) ? $tab_row_eight : "style=\"display:none\"" ; ?> class="linkilo-linkpreview-settings linkilo-setting-row">
                                    <td scope='row'>
                                        <?php _e('Domain exclusion list', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <textarea name='linkilo_preivew_exclude_list' id='linkilo_preivew_exclude_list' style="width: auto;float:left;" class='regular-text' rows="5" cols="30"><?php echo get_option('linkilo_preivew_exclude_list', ''); ?></textarea>
                                        <div class="linkilo_help">
                                            <i class="dashicons dashicons-editor-help"></i>
                                            <div>
                                                <?php _e('Enter domain name on new line to exclude it from getting generated preview.', 'linkilo'); ?> 
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif ?>
                            <!-- Link preview settings ends -->
                            <!-- related meta posts -->
                            <tr <?php echo (!is_null($tab_row_seven)) ? $tab_row_seven : "style=\"display:none\"" ; ?> class="linkilo-sidebar-settings linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label for="id_linkilo_relate_meta_post_enable_disable">
                                        <?php _e('Sidebar link suggestions', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="display: inline-block;">
                                        <div class="linkilo_help" style="float:right; position: relative;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php _e('Show or hide sidebar link suggestions', 'linkilo'); ?>
                                            </div>
                                        </div>
                                        <?php
                                        if ($related_meta_posts_enable_disable == '1') {
                                            $checked_show = 'checked="checked"';
                                        }else{
                                            $checked_show = "";
                                        }
                                        ?>
                                        <input
                                        type="checkbox"
                                        name="linkilo_relate_meta_post_enable_disable"
                                        id="id_linkilo_relate_meta_post_enable_disable"
                                        value="1"
                                        <?php echo $checked_show; ?>
                                        >
                                    </div>
                                </td>
                            </tr>
                            <?php if ($related_meta_posts_enable_disable == '1') { ?>
                                <tr <?php echo (!is_null($tab_row_seven)) ? $tab_row_seven :"style=\"display:none\"" ; ?> class="linkilo-sidebar-settings linkilo-setting-row settings-row-border">

                                    <td scope='row'>
                                        <?php _e('Show related meta posts for', 'linkilo'); ?>

                                    </td>
                                    <td>
                                        <div style="display: inline-block;">
                                            <div class="linkilo_help" style="float:right; position: relative;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div>
                                                    <?php _e('Enabling this option will tell Linkilo to show related posts to the selected post type\'s admin edit post screen', 'linkilo'); ?>
                                                </div>
                                            </div>
                                            <?php
                                            foreach ($types_available as $type) : ?>
                                                <?php  if ($type == "post" || $type == "page") : ?>
                                                    <input type="checkbox" name="linkilo_relate_meta_post_types[]" id="<?php echo "linkilo_relate_meta_post_types_".$type; ?>" value="<?php echo $type; ?>" <?php echo in_array($type, $related_meta_posts_types_active)?'checked':''; ?>>
                                                    <label for="<?php echo "linkilo_relate_meta_post_types_".$type; ?>">
                                                        <?php echo ucfirst($type); ?>
                                                    </label>
                                                    <br/>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_seven)) ? $tab_row_seven :"style=\"display:none\"" ; ?> class="linkilo-sidebar-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <?php _e('Include post types', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <div style="display: inline-block;">
                                            <div class="linkilo_help" style="float:right; position: relative;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div>
                                                    <?php _e('Check the post types to include while searching for related posts. Results will differ based on the changes inpost types.', 'linkilo'); ?>
                                                </div>
                                            </div>
                                            <?php
                                            foreach ($types_available as $type) : ?>
                                                <?php  if ($type == "post" || $type == "page") : ?>
                                                    <input type="checkbox" name="linkilo_relate_meta_post_types_include[]" id="<?php echo "linkilo_relate_meta_post_types_include_".$type; ?>" value="<?php echo $type; ?>" <?php echo in_array($type, $related_meta_posts_types_to_include)?'checked':''; ?>><label for="<?php echo "linkilo_relate_meta_post_types_include_".$type; ?>">
                                                        <?php echo ucfirst($type); ?>
                                                    </label><br/>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_seven)) ? $tab_row_seven : "style=\"display:none\"" ; ?> class="linkilo-sidebar-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <?php _e('Show', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <div style="display: inline-block;">
                                            <div class="linkilo_help" style="float:right; position: relative;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div>
                                                    <?php _e('Number of posts to display as related posts', 'linkilo'); ?>
                                                </div>
                                            </div>
                                            <input type="number" min="1" max="20" value="<?php echo $related_meta_posts_limit; ?>" name="linkilo_relate_meta_post_display_limit">
                                            <label>
                                                <?php _e('Related posts', 'linkilo'); ?>
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_seven)) ? $tab_row_seven : "style=\"display:none\"" ; ?> class="linkilo-sidebar-settings linkilo-setting-row meta-post-setting-border-bottom">
                                    <td scope='row'>
                                        <?php _e('Order related posts by', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <div style="display: inline-block;">
                                            <div class="linkilo_help" style="float:right; position: relative;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div>
                                                    <?php _e('Order related posts by date, random order or by relevance while displaying', 'linkilo'); ?>
                                                </div>
                                            </div>
                                            <?php $checked = 'checked="checked"';?>
                                            <input
                                            type="radio"
                                            name="linkilo_relate_meta_post_display_order"
                                            id="linkilo_relate_meta_post_display_order_date"
                                            value="date"
                                            <?php
                                            echo ($related_meta_posts_order == 'date') ? $checked : '';
                                            ?>
                                            >
                                            <label for="linkilo_relate_meta_post_display_order_date">
                                                <?php _e('Date', 'linkilo'); ?>
                                            </label><br/>
                                            <input
                                            type="radio"
                                            name="linkilo_relate_meta_post_display_order"
                                            id="linkilo_relate_meta_post_display_order_random"
                                            value="random"
                                            <?php
                                            echo ($related_meta_posts_order == 'random') ? $checked : '';
                                            ?>
                                            >
                                            <label for="linkilo_relate_meta_post_display_order_random">
                                                <?php _e('Random', 'linkilo'); ?>
                                            </label><br/>
                                            <input
                                            type="radio"
                                            name="linkilo_relate_meta_post_display_order"
                                            id="linkilo_relate_meta_post_display_order_relevance"
                                            value="relevance"
                                            <?php
                                            echo ($related_meta_posts_order == 'relevance') ? $checked : '';
                                            ?>
                                            >
                                            <label for="linkilo_relate_meta_post_display_order_relevance">
                                                <?php _e('Relevance', 'linkilo'); ?>
                                            </label><br/>
											
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                            <!-- related meta posts ends-->

                            <!-- Global settings tab -->

                            <!-- enable/disable inbound suggestions -->
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <?php _e('Enable Inbound Suggestions', 'linkilo'); ?>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_2_show_inbound_metabox_in_post_edit" value="0" />
                                        <?php if (get_option('linkilo_2_show_inbound_metabox_in_post_edit') == 1): ?>
                                            <?php
                                            $enable_inbound_checkbox_title = "Uncheck and save to disable";
                                            $checked_inbound_checkbox = "checked";
                                            ?>
                                        <?php else: ?>
                                            <?php
                                            $enable_inbound_checkbox_title = "Check and save to enable";
                                            $checked_inbound_checkbox = "";
                                            ?>
                                        <?php endif ?>
                                        <input
                                        type="checkbox"
                                        name="linkilo_2_show_inbound_metabox_in_post_edit"
                                        title="<?php echo $enable_inbound_checkbox_title; ?>"
                                        <?php echo $checked_inbound_checkbox; ?>
                                        value="1"/>
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php
                                                _e('When checked/enabled, a metabox for inbound suggestions on post edit screen will be shown.', 'linkilo');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            
                            <?php if (get_option('linkilo_2_show_inbound_metabox_in_post_edit') == 1): ?>
                                <!-- enable/disable inbound loadmore -->
                                <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'>
                                        <?php _e('Enable Load More for Inbound suggestions metabox', 'linkilo'); ?>
                                    </td>
                                    <td>
                                        <div style="max-width:50px;">
                                            <input type="hidden" name="linkilo_2_load_more_inbound_suggestions" value="0" />
                                            <input type="checkbox" name="linkilo_2_load_more_inbound_suggestions" <?php echo get_option('linkilo_2_load_more_inbound_suggestions')==1 ? 'checked' : ''; ?> value="1" />
                                            <div class="linkilo_help" style="float:right;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div>
                                                    <?php
                                                    _e('When checked/enabled, a load more button will appear in inbound suggestions metabox on post edit screen to fetch results in pear.', 'linkilo');
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <!-- enable/disable inbound loadmore -->
                            <?php endif; ?>
                            <!-- enable/disable inbound suggestions -->
                            
                            <!-- enable/disable outbound loadmore -->
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <?php _e('Enable Load More for Outound suggestions metabox', 'linkilo'); ?>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_2_load_more_outbound_suggestions" value="0" />
                                        <input type="checkbox" name="linkilo_2_load_more_outbound_suggestions" <?php echo get_option('linkilo_2_load_more_outbound_suggestions')==1 ? 'checked' : ''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php
                                                _e('When checked/enabled, a load more button will appear in outbound suggestions metabox on post edit screen to fetch results in pear', 'linkilo');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- enable/disable outbound loadmore -->

                            <!-- Global settings tab -->

                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Exclude Numbers in Link Suggestions', 'linkilo'); ?></td>
                                <td>
                                    <input type="hidden" name="linkilo_2_ignore_numbers" value="0" />
                                    <input type="checkbox" name="linkilo_2_ignore_numbers" <?php echo get_option('linkilo_2_ignore_numbers')== 1 ? 'checked' : ''; ?> value="1" />
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Current Language', 'linkilo'); ?></td>
                                <td>
                                    <select id="linkilo-selected-language" name="linkilo_selected_language">
                                        <?php
                                        $languages = Linkilo_Build_AdminSettings::getSupportedLanguages();
                                        $selected_language = Linkilo_Build_AdminSettings::getSelectedLanguage();
                                        ?>
                                        <?php foreach($languages as $language_key => $language_name) : ?>
                                            <option value="<?php echo $language_key; ?>" <?php selected($language_key, $selected_language); ?>><?php echo $language_name; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="hidden" id="linkilo-currently-selected-language" value="<?php echo $selected_language; ?>">
                                    <input type="hidden" id="linkilo-currently-selected-language-confirm-text-1" value="<?php echo esc_attr__('Changing Linkilo\'s language will replace the current Words to be Ignored with a new list of words.', 'linkilo') ?>">
                                    <input type="hidden" id="linkilo-currently-selected-language-confirm-text-2" value="<?php echo esc_attr__('If you\'ve added any words to the Words to be Ignored area, this will erase them.', 'linkilo') ?>">
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Excluded Words', 'linkilo'); ?></td>
                                <td>
                                    <?php
                                    $lang_data = array();
                                    foreach(Linkilo_Build_AdminSettings::getAllIgnoreWordLists() as $lang_id => $words){
                                        $lang_data[$lang_id] = $words;
                                    }
                                    ?>
                                    <textarea name='ignore_words' id='ignore_words' class='regular-text' style="float:left;" rows=10><?php echo esc_textarea(implode("\n", $lang_data[$selected_language])); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will ignore these words when making linking suggestions. Please enter each word on a new line', 'linkilo'); ?></div>
                                    </div>
                                    <input type="hidden" id="linkilo-available-language-word-lists" value="<?php echo esc_attr( wp_json_encode($lang_data, JSON_UNESCAPED_UNICODE) ); ?>">
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_two)) ? $tab_row_two : "style=\"display:none\"" ; ?> class="linkilo-content-ignoring-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Do not recommend URL list', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_ignore_links' id='linkilo_ignore_links' style="width: 650px;float:left;" class='regular-text' rows=10><?php echo get_option('linkilo_ignore_links'); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will not suggest links TO the posts entered here. To ignore a post, enter the post\'s full url on it\'s own line in the text area', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
<tr <?php echo (!is_null($tab_row_two)) ? $tab_row_two : "style=\"display:none\"" ; ?> class="linkilo-content-ignoring-settings linkilo-setting-row settings-row-border">
    <td scope='row'><?php _e('Exclude these Categories when suggesting links', 'linkilo'); ?></td>
    <td>
		
        <div class="category-checkboxes">
            <?php
            $categories = get_categories();
            $selected_categories = get_option('linkilo_selected_categories', array());

            foreach ($categories as $category) {
                $checked = in_array($category->term_id, $selected_categories) ? 'checked' : '';
                $checkbox_id = 'category_' . $category->term_id;

                echo '<label for="'. esc_attr($checkbox_id) .'">';
                echo '<input type="checkbox" id="'. esc_attr($checkbox_id) .'" name="linkilo_selected_categories[]" value="' . esc_attr($category->term_id) . '" ' . $checked . '>';
                echo esc_html($category->name);
                echo '</label><br>';
            }
            ?>
        </div>
        <div style="clear:both;"></div>
    </td>
</tr>

							
							
							
						
                            <tr <?php echo (!is_null($tab_row_two)) ? $tab_row_two : "style=\"display:none\"" ; ?> class="linkilo-content-ignoring-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Ignored Post list for Auto-Linking and Update URL', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_ignore_keywords_posts' id='linkilo_ignore_keywords_posts' style="width: 650px;float:left;" class='regular-text' rows=10><?php echo get_option('linkilo_ignore_keywords_posts'); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will not insert auto-links or change URLs on posts entered in this field. To ignore a post, enter the post\'s full url on it\'s own line in the text area', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_two)) ? $tab_row_two : "style=\"display:none\"" ; ?> class="linkilo-content-ignoring-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Add URL to exclude from Orphan Report', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_ignore_stray_feeds' id='linkilo_ignore_stray_feeds' style="width: 650px;float:left;" class='regular-text' rows=10><?php echo get_option('linkilo_ignore_stray_feeds', ''); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will not show the listed posts on the Orphan URLs Records. To ignore a post, enter a post\'s full url on it\'s own line in the text area', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_two)) ? $tab_row_two : "style=\"display:none\"" ; ?> class="linkilo-content-ignoring-settings linkilo-setting-row">
                                <td scope='row'><?php _e('Disregard ACF fields', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_ignore_acf_fields' id='linkilo_ignore_acf_fields' style="width: 650px;float:left;" class='regular-text' rows=10><?php echo get_option('linkilo_ignore_acf_fields', ''); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will not process content in the ACF fields listed here. To ignore a field, enter each field\'s name on it\'s own line in the text area', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Mark these URL as External Links', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_marked_as_external' id='linkilo_marked_as_external' style="width: 650px;float:left;" class='regular-text' rows=10><?php echo get_option('linkilo_marked_as_external'); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will recognize these links as external on the Records Page. Please enter each link on it\'s own line in the text area', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Provide Suggestion to these External Links', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_suggest_to_outgoing_posts' id='linkilo_suggest_to_outgoing_posts' style="width: 650px;float:left;" class='regular-text' rows=10><?php echo get_option('linkilo_suggest_to_outgoing_posts', ''); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will only suggest outgoing links to the listed posts. Please enter each link on it\'s own line in the text area. If you do not want to limit suggestions to specific posts, leave this empty', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Mark Domains as Internal', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_domains_marked_as_internal' id='linkilo_domains_marked_as_internal' style="width: 650px;float:left;" class='regular-text' rows=5><?php echo get_option('linkilo_domains_marked_as_internal'); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Linkilo will recognize links with these domains as internal on the Records Page. Please enter each domain on it\'s own line in the text area as it appears in your browser', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>

                            <!-- Internal links tab -->

                            <!-- Open new window (for internal links) -->
                            <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label for="id_linkilo_internal_att_blank">
                                        <?php _e('Open New Window for Internal Links', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_internal_att_blank" value="0" />
                                        <input type="checkbox" name="linkilo_internal_att_blank" id="id_linkilo_internal_att_blank" <?php echo get_option('linkilo_internal_att_blank')==1 ? 'checked' : ''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php
                                                _e('Checking this will tell Linkilo to filter post content before displaying to make the links to other pages on this site open in new tabs.', 'linkilo');
                                                echo '<br /><br />';
                                                _e('This will cause existing links, and those not created with Linkilo to open in new tabs.', 'linkilo');
                                                echo '<br /><br />';
                                                _e('This works best with the default WordPress content editors and may not work with some page builders', 'linkilo');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Open new window (for internal links) -->

                            <!-- Open new window (force open links using js) -->
                            <!-- <tr <?php //echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border js-force-open-new-tabs">
                                <td scope='row'>
                                    <label for="id_linkilo_js_open_new_tabs">
                                        <?php //_e('Use JS to force opening in new tabs', 'linkilo'); ?> 
                                    </label>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_js_open_new_tabs" value="0" />
                                        <input type="checkbox" name="linkilo_js_open_new_tabs" id="id_linkilo_js_open_new_tabs" <?php //echo get_option('linkilo_js_open_new_tabs')==1 ? 'checked' : ''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php
                                                //_e('Checking this will tell Linkilo to use frontend scripting to set links to open in new tabs.', 'linkilo');
                                                //echo '<br /><br />';
                                                //_e('This is mainly intended for cases where the options for setting all links to open in new tabs aren\'t working.', 'linkilo');
                                                //echo '<br /><br />';
                                                //_e('This will only apply to links in the content areas. Navigation links will not be affected', 'linkilo');
                                                //echo '<br /><br />';
                                                //echo sprintf(__('This will also cause the %s, %s and %s scripts to be outputted on most pages if they aren\'t already there.', 'linkilo'), 'jQuery', 'jQuery Migrate', 'Linkilo Frontend');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr> -->
                            <!-- Open new window (force open links using js) -->

                            <!-- Nofollow attribute for internal links -->
                            <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label for="id_linkilo_internal_rel_nofollow">
                                        <?php _e('Add "nofollow" to all internal links', 'linkilo'); ?> 
                                    </label>
                                </td>
                                <td>
                                    <input type="hidden" name="linkilo_internal_rel_nofollow" value="0" />
                                    <input type="checkbox" name="linkilo_internal_rel_nofollow" id="id_linkilo_internal_rel_nofollow" <?php echo !empty( get_option( 'linkilo_internal_rel_nofollow', false ) ) ? 'checked' : ''; ?> value="1" />
                                </td>
                            </tr>
                            <!-- Nofollow attribute for internal links -->

                            <!-- Add rel attribute (for internal links) -->
                            <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label>
                                        <?php _e('Add "rel" attribute', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <?php $external_rel_attributes = ['noopener', 'noreferrer']; ?>
                                    <?php foreach ($external_rel_attributes as $external_attribute): ?>
                                        <?php 
                                        $external_att_option = "linkilo_internal_rel_$external_attribute"; 
                                        $label_id = "id_linkilo_internal_rel_$external_attribute";  
                                        $checked_state = intval( get_option( $external_att_option, 0 ) ) === 1 ? "checked" : '';
                                        ?>
                                        <div class="settings-rel-input-checkbox">
                                            <input type="hidden" name="<?php echo esc_attr($external_att_option); ?>" value="0"/>
                                            <input type="checkbox" name="<?php echo esc_attr($external_att_option); ?>" id="<?php echo esc_attr( $label_id ); ?>" value="1" <?php echo esc_attr($checked_state); ?>/>
                                            <label for="<?php echo esc_attr( $label_id ); ?>">
                                                <?php echo $external_attribute; ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                            <!-- Add rel attribute (for internal links) -->
                            <?php

                                $linkilo_internal_icon_type         = get_option('linkilo_internal_icon_type');
                                $linkilo_internal_icon         = get_option('linkilo_internal_icon');
                                $linkilo_internal_verified_icon = get_option('linkilo_internal_verified_icon'); 
                               
                                $linkilo_interlanl_icon_position    = get_option('linkilo_interlanl_icon_position');
                                $linkilo_internal_skip_icon         = get_option('linkilo_internal_skip_icon');
                                $linkilo_intl_excl_domain_from_icon = get_option('linkilo_internal_exclude_domain_from_icon');
                                $linkilo_internal_specific_domain   = get_option('linkilo_internal_specific_domain');
                                $linkilo_internal_spc_dmn_icon      = get_option('linkilo_internal_spc_dmn_icon');

                                $linkilo_spc_dmnname_and_icon_arr= array();
                                if(!empty($linkilo_internal_specific_domain)){
                                    if(is_array($linkilo_internal_specific_domain))
                                    {
                                        foreach ($linkilo_internal_specific_domain as $key => $linki_dmn_name) {
                                            if (isset($linkilo_internal_spc_dmn_icon[$key])) {
                                                $linkilo_icon_class = $linkilo_internal_spc_dmn_icon[$key];
                                                $linkilo_spc_dmnname_and_icon_arr[$linki_dmn_name] = $linkilo_icon_class;
                                            }
                                        }
                                    }
                                }
                               
                            ?>
                            <!-- Choose Icon Type -->
                            <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row">
                                <td scope='row'><?php _e('Select Icon Type for Internal Links', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_internal_icon_type" id="linkilo_internal_icon_type" >
                                        <option value=""><?php _e('No Icon (Default)', 'linkilo'); ?></option>
                                        <option value="linkilo_internal_icon" <?php selected( "linkilo_internal_icon",$linkilo_internal_icon_type ); ?>><?php _e('Internal', 'linkilo'); ?></option>
                                        <option value="linkilo_internal_verified_icon" <?php selected( "linkilo_internal_verified_icon",$linkilo_internal_icon_type ); ?>><?php _e('Verified', 'linkilo'); ?></option>
                                    </select>
                                </td>
                            </tr>
                             <!-- Choose Icon Type -->
                              <!-- Choose Icon -->
                              <?php
                                    // Internal Link Iocn
                                    $linkilo_internal_icon_arr = array(
                                        'option1' => 'fas fa-external-link-square-alt',
                                        'option2' => 'fa-solid fa-arrow-up-right-from-square',
                                        'option3' => 'fas fa-external-link-alt',
                                        'option4' => 'fa-solid fa-square-arrow-up-right',
                                    );

                                    // verified icons
                                    $linkilo_internal_verified_icon_arr = array(
                                        'option5' => 'fa-solid fa-check',
                                        'option6' => 'fa-solid fa-check-to-slot',
                                        'option7' => 'fa-solid fa-check-double',
                                        'option8' => 'fa-solid fa-square-check',
                                        'option9' => 'fa-regular fa-square-check',
                                        'option10' => 'fa-solid fa-circle-check',
                                        'option11' => 'fa-regular fa-circle-check',
                                        'option12' => 'fa-solid fa-user-check'
                                    );
                                ?>
                                <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border linkilo_icon_image_row" >
                                    <td scope='row'><?php _e('Select Icon', 'linkilo'); ?></td>
                                    <td class="linkilo_radio_icons_internal">
                                        <?php
                                        $row_counter = 0;
                                        $row_counter1 = 0;

                                        //for internal link icons
                                        foreach ( $linkilo_internal_icon_arr as $value => $icon_class ) 
                                        {
                                            $checked = ( $icon_class == $linkilo_internal_icon ) ? 'checked' : '';
                                            if ( $row_counter > 0 && $row_counter % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_internal_lbl1">
                                                <input type="radio" name="linkilo_internal_icon" value="<?php echo esc_attr( $icon_class ); ?>" <?php if(!empty( $linkilo_internal_icon )) { echo esc_attr( $checked  ); } ?>>
                                                <i class="<?php echo esc_attr( $icon_class ); ?>"></i>
                                            </label>
                                                
                                            
                                            <?php
                                            $row_counter++;
                                        }
                                        
                                        // for verified icons 
                                        foreach ( $linkilo_internal_verified_icon_arr as $value1 => $icon_class1 ) 
                                        {
                                            $checked = ( $icon_class1 == $linkilo_internal_verified_icon ) ? 'checked' : '';
                                            if ( $row_counter1 > 0 && $row_counter1 % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_internal_lbl2">
                                                <input type="radio" name="linkilo_internal_verified_icon" value="<?php echo esc_attr( $icon_class1 ); ?>" <?php if(!empty( $linkilo_internal_verified_icon )) { echo esc_attr( $checked );} ?>>
                                                <i class="<?php echo esc_attr( $icon_class1 ); ?>"></i>
                                            </label>

                                            <?php
                                            $row_counter1++;
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                    // }
                            ?>
                           <!-- Choose Icon Position -->
                            <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e(' Select Icon Position', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_interlanl_icon_position" id="linkilo_internal_icon_position" >
                                        <option value="right" <?php selected("right",$linkilo_interlanl_icon_position); ?>><?php _e('Right side of the link', 'linkilo'); ?></option>
                                        <option value="left" <?php selected("left",$linkilo_interlanl_icon_position); ?>><?php _e('Left side of the link', 'linkilo'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <!-- Choose Icon Position --> 
                            <!--- Skip Icon Checkbox  -->
                            <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e(htmlentities('Skip Icon With <img> :', ENT_QUOTES, 'UTF-8'), 'linkilo'); ?></td>
                                <td class="linkilo_internal_skip_chkbx_td">
                                    <input type="checkbox" name="linkilo_internal_skip_icon" id="linkilo_internal_skip_icon" <?php  if ($linkilo_internal_skip_icon == 'on') echo 'checked="checked"'; ?>/><span><?php _e(htmlentities('No Icon for links already conatining an  <img>-tag', ENT_QUOTES, 'UTF-8'), 'linkilo');?></span>
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Exclude icons from those internal Links which are already conatining an img tag.', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <!--- Skip Icon Checkbox  -->

                             <!-- Exclude Specific Domains --> 

                             <tr <?php echo (!is_null($tab_row_five)) ? $tab_row_five : "style=\"display:none\"" ; ?> class="linkilo-internal-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Exclude Doamains from Icons', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_internal_exclude_domain_from_icon' id='linkilo_internal_exclude_domain_from_icon' style="float:left;" class='regular-text' rows="5" placeholder="<?php _e('Seprate each domains with comma ( , ).', 'linkilo'); ?>"><?php echo $linkilo_intl_excl_domain_from_icon; ?></textarea>
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Seprate each domains with comma ( , ). Ex sample.com,sample.in', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>

                            <!-- Exclude Specific Domains --> 
                            <!-- specific icons for Specific domain --> 
                            <?php

                                $linkilo_icons_classes_arr = array(
                                    'option1' => 'fas fa-external-link-square-alt',
                                    'option2' => 'fa-solid fa-arrow-up-right-from-square',
                                    'option3' => 'fas fa-external-link-alt',
                                    'option4' => 'fa-solid fa-square-arrow-up-right',
                                    'option5' => 'fa-solid fa-check',
                                    'option6' => 'fa-solid fa-check-to-slot',
                                    'option7' => 'fa-solid fa-check-double',
                                    'option8' => 'fa-solid fa-square-check',
                                    'option9' => 'fa-regular fa-square-check',
                                    'option10' => 'fa-solid fa-circle-check',
                                    'option11' => 'fa-regular fa-circle-check',
                                    'option12' => 'fa-solid fa-user-check'
                                );    
                              ?>
 
                            
                            <!-- Internal links tab -->

                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Find Suggested URLs in these Post Types Only', 'linkilo'); ?></td>
                                <td>
                                    <div style="display: inline-block;">
                                        <div class="linkilo_help" style="float:right; position: relative; left: 30px;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div><?php _e('After changing the post type selection, please go to the Records Page and click the "Perform Scan" button to clear the old link data.', 'linkilo'); ?></div>
                                        </div>
                                        <?php foreach ($types_available as $type) : ?>
                                            <input type="checkbox" name="linkilo_2_post_types[]" value="<?php echo $type; ?>" <?php echo in_array($type, $types_active) ? 'checked' : ''; ?>><label><?php echo ucfirst($type); ?></label><br>
                                        <?php endforeach; ?>
                                        <input type="hidden" name="linkilo_2_show_all_post_types" value="0">
                                        <input type="checkbox" name="linkilo_2_show_all_post_types" value="1" <?php echo !empty(get_option('linkilo_2_show_all_post_types', false)) ? 'checked' : ''; ?>><label><?php _e('Show Non-Public Post Types', 'linkilo'); ?></label><br>
                                    </div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope="row"><?php _e('Sentence length to skip', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_skip_sentences" style="float:left; max-width:100px">
                                        <?php for($i = 0; $i <= 10; $i++) : ?>
                                            <option value="<?php echo $i; ?>"   <?php echo $i==Linkilo_Build_AdminSettings::getSkipSentences() ? 'selected' : '' ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div>
                                            <?php _e('Skip the amount of sentences before suggesting links', 'linkilo'); ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- add by nidhi start -->
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope="row"><?php _e('Set limit for google search console keywords', 'linkilo'); ?></td> 
                                <td>
                                    <select name="linkilo_google_search_console_limit" style="float:left; max-width:100px">
                                        <?php for($i = 1; $i <= 10; $i++) : ?>
                                            <option value="<?php echo $i; ?>"   <?php echo $i==Linkilo_Build_AdminSettings::getGoogleconsole() ? 'selected' : '' ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div>
                                            <?php _e('Set limit for fetched google search console keywords. This limit will be applied while insertion of keywords is being done.', 'linkilo'); ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- end by nidhi end -->
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row settings-row-border">
                                <td scope="row">
                                    <?php _e('Set limit amount of link per post', 'linkilo'); ?>
                                </td>
                                <td>
                                    <select name="linkilo_max_links_per_post" style="float:left; max-width:100px">
                                        <option value="0" <?php echo 0===(int)$max_links_per_post ? 'selected' : ''; ?>>
                                            <?php _e('No Limit', 'linkilo'); ?>
                                        </option>
                                        <?php for($i = 1; $i <= 100; $i++) : ?>
                                            <option value="<?php echo $i; ?>" <?php echo $i===(int)$max_links_per_post ? 'selected' : ''; ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div><?php _e('This is used to set limit of links in a post content. After limit is reached it will show a message "Post has reached the max link limit. To enable suggestions, please increase the Max Links Per Post setting from the Linkilo Settings."', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Restrict Link Suggestions -->
                            <tr <?php echo (!is_null($tab_row_one)) ? $tab_row_one : $tab_row_default ; ?> class="linkilo-general-settings linkilo-setting-row">
                                <td scope="row">
                                    <?php _e('Words limit for a link suggestion', 'linkilo'); ?>
                                </td>
                                <td>
                                    <select name="linkilo_max_words_match_per_suggest" style="float:left; max-width:100px">
                                        <option value="0" <?php echo 0===(int)$max_words_match_per_suggest ? 'selected' : ''; ?>>
                                            <?php _e('No Limit', 'linkilo'); ?>
                                        </option>
                                        <?php for($i = 1; $i <= 5; $i++) : ?>
                                            <option value="<?php echo $i; ?>" <?php echo $i === (int)$max_words_match_per_suggest ? 'selected' : ''; ?>>
                                                <?php echo $i; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 4px;"></i>
                                        <div><?php _e('Limit the amout of words in suggestions to be taken in count while matching and populating that string as a valid suggestion.', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Restrict Link Suggestions -->
                            <?php if(class_exists('ACF')){ ?>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'><?php _e('Disable Linking for Advanced Custom Fields', 'linkilo'); ?></td>
                                    <td>
                                        <input type="hidden" name="linkilo_disable_acf" value="0" />
                                        <div style="max-width: 80px;">
                                            <input type="checkbox" name="linkilo_disable_acf" <?php echo get_option('linkilo_disable_acf', false)==1 ? 'checked' : ''; ?> value="1" />
                                            <div class="linkilo_help" style="float: right;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div style="margin-left: 30px; margin-top: -20px;">
                                                    <p><i><?php _e('Checking this will tell Linkilo to not process any data created by Advanced Custom Fields.', 'linkilo'); ?></i></p>
                                                    <p><i><?php _e('This will speed up the suggestion making and data saving, but will not update the ACF data.', 'linkilo'); ?></i></p>
                                                    <p><i><?php _e('If you don\'t see Advanced Custom Fields in your Installed Plugins list, it may be included as a component in a plugin or your theme.', 'linkilo'); ?></i></p>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Enable Scan for non-content URLs', 'linkilo'); ?></td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_show_all_links" value="0" />
                                        <input type="checkbox" name="linkilo_show_all_links" <?php echo get_option('linkilo_show_all_links')==1 ? 'checked' : ''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div><?php _e('Turning this on will cause menu links, footer links, sidebar links, and links from widgets to be displayed in the link reports.', 'linkilo'); ?></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('HTML Recommendation', 'linkilo'); ?></td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_full_html_suggestions" value="0" />
                                        <input type="checkbox" name="linkilo_full_html_suggestions" <?php echo get_option('linkilo_full_html_suggestions')==1 ? 'checked' : ''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div><?php _e('Turning this on will tell Linkilo to display the raw HTML version of the link suggestions under the suggestion box.', 'linkilo'); ?></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Disable Auto Recommendation', 'linkilo'); ?></td>
                                <td>
                                    <input type="hidden" name="linkilo_manually_trigger_suggestions" value="0" />
                                    <input type="checkbox" name="linkilo_manually_trigger_suggestions" <?php echo get_option('linkilo_manually_trigger_suggestions')==1 ? 'checked' : ''; ?> value="1" />
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                        <div><?php _e('Checking this option will tell Linkilo to not generate suggestions until you tell it to.', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Disable Outgoing Recommendation', 'linkilo'); ?></td>
                                <td>
                                    <input type="hidden" name="linkilo_disable_outgoing_suggestions" value="0" />
                                    <input type="checkbox" name="linkilo_disable_outgoing_suggestions" <?php echo get_option('linkilo_disable_outgoing_suggestions')==1 ? 'checked' : ''; ?> value="1" />
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                        <div><?php _e('Checking this option will prevent Linkilo from doing suggestion scans inside post edit screens.', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <?php if(defined('WPSEO_VERSION')){?>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'><?php _e('Only Create Outbound Links to Yoast Cornerstone Content', 'linkilo'); ?></td>
                                    <td>
                                        <div style="max-width:50px;">
                                            <input type="hidden" name="linkilo_link_to_yoast_cornerstone" value="0" />
                                            <input type="checkbox" name="linkilo_link_to_yoast_cornerstone" <?php echo get_option('linkilo_link_to_yoast_cornerstone', false)==1 ? 'checked' : ''; ?> value="1" />
                                            <div class="linkilo_help" style="float:right;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div><?php _e('Turning this on will tell Linkilo to restrict the outgoing link suggestions to posts marked as Yoast Cornerstone content.', 'linkilo'); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>

                            <!-- Custom settings tab -->

                            <!-- Get Recommendations based on Focus keywords -->
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Get Recommendations based on Focus keywords', 'linkilo'); ?></td>
                                <td>
                                    <input type="hidden" name="linkilo_only_match_focus_keywords" value="0" />
                                    <input type="checkbox" name="linkilo_only_match_focus_keywords" <?php echo !empty(get_option('linkilo_only_match_focus_keywords', false)) ? 'checked' : ''; ?> value="1" />
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Checking this will tell Linkilo to only show suggestions that have matches based on the current post\'s Focus Keyword.', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Get Recommendations based on Focus keywords -->

                            <!-- Custom settings tab -->



                            <!-- //__External links tab__// -->

                            <!-- Open new tab (for external links) -->
                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label for="id_linkilo_external_att_blank">
                                        <?php _e('Open New Window for External Links', 'linkilo'); ?>
                                    </label>
                                </td>
                                <td>
                                    <div style="max-width:50px;">
                                        <input type="hidden" name="linkilo_external_att_blank" value="0" />
                                        <input type="checkbox" name="linkilo_external_att_blank" id="id_linkilo_external_att_blank" <?php echo get_option('linkilo_external_att_blank')==1 ? 'checked' :''; ?> value="1" />
                                        <div class="linkilo_help" style="float:right;">
                                            <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                            <div>
                                                <?php
                                                _e('Checking this will tell Linkilo to filter post content before displaying to make the links to external sites open in new tabs.', 'linkilo');
                                                echo '<br /><br />';
                                                _e('This will cause existing links, and those not created with Linkilo to open in new tabs.', 'linkilo');
                                                echo '<br /><br />';
                                                _e('This works best with the default WordPress content editors and may not work with some page builders', 'linkilo');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Open new tab (for external links) -->

                            <!-- Add rel nofollow (for external links) -->
                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'>
                                    <label for="id_linkilo_external_rel_nofollow">
                                        <?php _e('Add "nofollow" to all external links', 'linkilo'); ?> 
                                    </label>
                                </td>
                                <td>
                                    <input type="hidden" name="linkilo_external_rel_nofollow" value="0" />
                                    <input type="checkbox" name="linkilo_external_rel_nofollow" id="id_linkilo_external_rel_nofollow" <?php echo !empty(get_option('linkilo_external_rel_nofollow', false)) ? 'checked' : ''; ?> value="1" />
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div>
                                            <?php _e('Checking this will tell Linkilo to add the "nofollow" attribute to all external links it creates.', 'linkilo'); ?>
                                            <br />
                                            <br />
                                            <?php _e('However, this does not apply to links to sites you\'ve interlinked', 'linkilo'); ?>
                                            <br />
                                            <br />
                                            <?php _e('Links to those sites won\'t have "nofollow" added.', 'linkilo'); ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Add rel nofollow (for external links) -->

                            <!-- Add rel attribute (for external links) -->
                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Add "rel" attribute', 'linkilo'); ?></td>
                                <td>
                                    <?php $external_rel_attributes = ['noopener', 'noreferrer', 'sponsored', 'UGC']; ?>
                                    <?php foreach ($external_rel_attributes as $external_attribute): ?>
                                        <?php 
                                        $external_att_option = "linkilo_external_rel_$external_attribute"; 
                                        $label_id = "id_linkilo_external_rel_$external_attribute";  
                                        $checked_state = intval( get_option( $external_att_option, 0 ) ) === 1 ? "checked" : '';
                                        ?>
                                        <div class="settings-rel-input-checkbox">
                                            <input type="hidden" name="<?php echo esc_attr($external_att_option); ?>" value="0"/>
                                            <input type="checkbox" name="<?php echo esc_attr($external_att_option); ?>" id="<?php echo esc_attr( $label_id ); ?>" value="1" <?php echo esc_attr($checked_state); ?>/>
                                            <label for="<?php echo esc_attr( $label_id ); ?>">
                                                <?php echo $external_attribute; ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                            <!-- Add rel attribute (for external links) -->

<!-- Exclude domains from sponsored rel -->
<tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
    <td scope='row'>
        <?php _e('Exclude Domains from Sponsored Rel', 'linkilo'); ?>
    </td>
    <td>
        <textarea name='exclude_sponsored_domains' id='exclude_sponsored_domains' class='regular-text' rows="5"><?php echo esc_textarea(get_option('exclude_sponsored_domains')); ?></textarea>
        <div class="linkilo_help">
            <i class="dashicons dashicons-editor-help"></i>
            <div><?php _e('Enter domains to exclude from "sponsored" rel attribute, one per line.', 'linkilo'); ?></div>
        </div>
        <div style="clear:both;"></div>
    </td>
</tr>


<!-- Exclude nofollow domain list -->
<tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
    <td scope='row'>
        <?php _e('Exclude Domains from Nofollow', 'linkilo'); ?>
    </td>
    <td>
        <textarea name='exclude_nofollow_domains' id='exclude_nofollow_domains' class='regular-text' rows="5"><?php echo esc_textarea(get_option('exclude_nofollow_domains')); ?></textarea>
        <div class="linkilo_help">
            <i class="dashicons dashicons-editor-help"></i>
            <div><?php _e('Enter domains to exclude from "nofollow" rel attribute, one per line.', 'linkilo'); ?></div>
        </div>
        <div style="clear:both;"></div>
    </td>
</tr>

<!-- Exclude domains from UGC attribute -->
<tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
    <td scope='row'>
        <?php _e('Exclude Domains from UGC Attribute', 'linkilo'); ?>
    </td>
    <td>
        <textarea name='exclude_ugc_domains' id='exclude_ugc_domains' class='regular-text' rows="5"><?php echo esc_textarea(get_option('exclude_ugc_domains')); ?></textarea>
        <div class="linkilo_help">
            <i class="dashicons dashicons-editor-help"></i>
            <div><?php _e('Enter domains to exclude from "UGC" rel attribute, one per line.', 'linkilo'); ?></div>
        </div>
        <div style="clear:both;"></div>
    </td>
</tr>

							
							
                            <!-- Domain Exception list -->
                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Domains Exception', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_domains_marked_as_internal' id='linkilo_domains_marked_as_internal' class='regular-text' rows="5"><?php echo get_option('linkilo_domains_marked_as_internal'); ?></textarea>
                                    <div class="linkilo_help">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Add external links for who you don\'t want to apply the nofollow', 'linkilo'); ?></div>
                                    </div>
                                    <div style="clear:both;"></div>
                                </td>
                            </tr>
                            <!-- Domain Exception list -->
                             <!-- Coose Icon Type Image -->
                             <?php
                              $linkilo_ext_opt_external_set = get_option('linkilo_external_setting_ext_field');

                              $linkilo_icon_type = isset($linkilo_ext_opt_external_set['linkilo_icon_type']) ? $linkilo_ext_opt_external_set['linkilo_icon_type'] : '';
                              
                              $linkilo_icon_position = isset($linkilo_ext_opt_external_set['linkilo_icon_position']) ? $linkilo_ext_opt_external_set['linkilo_icon_position'] : '';
                              $linkilo_selectedClass =  isset($linkilo_ext_opt_external_set['linkilo_selectedClass']) ? $linkilo_ext_opt_external_set['linkilo_selectedClass'] : '';
                              $linkilo_skip_check =  isset($linkilo_ext_opt_external_set['linkilo_skip_isChecked']) ? $linkilo_ext_opt_external_set['linkilo_skip_isChecked'] : '';
                              $linkilo_exclude_iconfordmn_name =  isset($linkilo_ext_opt_external_set['linkilo_exclude_iconfordmn_name']) ? $linkilo_ext_opt_external_set['linkilo_exclude_iconfordmn_name'] : '';

                              $specific_dmnname_and_cls_arr =  isset($linkilo_ext_opt_external_set['spc_dmn_name_and_cls_arr']) ? $linkilo_ext_opt_external_set['spc_dmn_name_and_cls_arr'] : '';
                              
                             ?>
                           
                            <tr <?php echo ( !is_null( $tab_row_six ) ) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row">
                                <td scope='row'><?php _e('Select Icon Type for External Links', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_icon_type" id="linkilo_icon_type" >
                                        <option value=""><?php _e('No Icon (Default)', 'linkilo'); ?></option>
                                        <option value="linkilo_external_icon" <?php selected( "linkilo_external_icon",$linkilo_icon_type ); ?>><?php _e('External', 'linkilo'); ?></option>
                                        <option value="linkilo_verified_icon" <?php selected( "linkilo_verified_icon",$linkilo_icon_type ); ?>><?php _e('Verified', 'linkilo'); ?></option>
                                    </select>
                                </td>
                            </tr>
                             <!-- Coose Icon Type Image -->
                              <!-- Coose Icon Image -->
                              <?php
                                    // External Link Iocn
                                    $options = array(
                                        'option1' => 'fas fa-external-link-square-alt',
                                        'option2' => 'fa-solid fa-arrow-up-right-from-square',
                                        'option3' => 'fas fa-external-link-alt',
                                        'option4' => 'fa-solid fa-square-arrow-up-right',
                                    );

                                    // verified icons
                                    $options1 = array(
                                        'option5' => 'fa-solid fa-check',
                                        'option6' => 'fa-solid fa-check-to-slot',
                                        'option7' => 'fa-solid fa-check-double',
                                        'option8' => 'fa-solid fa-square-check',
                                        'option9' => 'fa-regular fa-square-check',
                                        'option10' => 'fa-solid fa-circle-check',
                                        'option11' => 'fa-regular fa-circle-check',
                                        'option12' => 'fa-solid fa-user-check'
                                    );
                                ?>

                                <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border linkilo_icon_image_row" >
                                    <td scope='row'><?php _e('Select Icon', 'linkilo'); ?></td>
                                    <td class="linkilo_radio_icons">
                                        <?php
                                        $row_counter = 0;
                                        $row_counter1 = 0;

                                        //for external link icons
                                        foreach ( $options as $value => $icon_class ) 
                                        {
                                            $checked = ( $icon_class == $linkilo_selectedClass ) ? 'checked' : '';
                                            if ( $row_counter > 0 && $row_counter % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_lbl1">
                                                <input type="radio" name="linkilo_external_icon" value="<?php echo esc_attr( $icon_class ); ?>" <?php echo esc_attr( $checked ); ?>>
                                                <i class="<?php echo esc_attr( $icon_class ); ?>"></i>
                                            </label>
                                                
                                            
                                            <?php
                                            $row_counter++;
                                        }
                                        
                                        // for verified icons 
                                        foreach ( $options1 as $value1 => $icon_class1 ) 
                                        {
                                            $checked = ( $icon_class1 == $linkilo_selectedClass ) ? 'checked' : '';
                                            if ( $row_counter1 > 0 && $row_counter1 % 4 === 0 ) {
                                                echo '<br>'; 
                                            }
                                            ?>
                                            <label class="linkilo_radio_lbl linkilo_radio_lbl2">
                                                <input type="radio" name="linkilo_verified_icon" value="<?php echo esc_attr( $icon_class1 ); ?>" <?php echo esc_attr( $checked ); ?>>
                                                <i class="<?php echo esc_attr( $icon_class1 ); ?>"></i>
                                            </label>

                                            <?php
                                            $row_counter1++;
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                    // }
                            ?>
                           <!-- Coose Icon Image -->
                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e(' Select Icon Position', 'linkilo'); ?></td>
                                <td>
                                    <select name="linkilo_icon_position" id="linkilo_icon_position" >
                                        <option value="right" <?php selected("right",$linkilo_icon_position); ?>><?php _e('Right side of the link', 'linkilo'); ?></option>
                                        <option value="left" <?php selected("left",$linkilo_icon_position); ?>><?php _e('Left side of the link', 'linkilo'); ?></option>
                                    </select>
                                </td>
                            </tr>
                           
                            <!-- Coose Icon Image --> 
                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e(htmlentities('Skip Icon With <img> :', ENT_QUOTES, 'UTF-8'), 'linkilo'); ?></td>
                                <td class="linkilo_skip_chkbx_td">
                                    <input type="checkbox" name="linkilo_skip_icon" id="linkilo_skip_icon" <?php  if ($linkilo_skip_check == 'true') echo 'checked="checked"'; ?>/><span><?php _e(htmlentities('No Icon for links already conatining an  <img>-tag', ENT_QUOTES, 'UTF-8'), 'linkilo');?></span>
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Exclude icons from those external Links which are already conatining an img tag.', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>
                            <!-- Coose Icon Image --> 

                             <!-- Exclude Specific Domains --> 

                             <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Exclude Doamains from Icons', 'linkilo'); ?></td>
                                <td>
                                    <textarea name='linkilo_exclude_domain_from_icon' id='linkilo_exclude_domain_from_icon' style="float:left;" class='regular-text' rows="5" placeholder="<?php _e('Seprate each domains with comma ( , ).', 'linkilo'); ?>"><?php echo $linkilo_exclude_iconfordmn_name; ?></textarea>
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div><?php _e('Seprate each domains with comma ( , ). Ex sample.com,sample.in', 'linkilo'); ?></div>
                                    </div>
                                </td>
                            </tr>

                            <!-- Exclude Specific Domains --> 
                            <!-- specific icons for Specific domain --> 
                            <?php

                                $linkilo_icons_classes_arr = array(
                                    'option1' => 'fas fa-external-link-square-alt',
                                    'option2' => 'fa-solid fa-arrow-up-right-from-square',
                                    'option3' => 'fas fa-external-link-alt',
                                    'option4' => 'fa-solid fa-square-arrow-up-right',
                                    'option5' => 'fa-solid fa-check',
                                    'option6' => 'fa-solid fa-check-to-slot',
                                    'option7' => 'fa-solid fa-check-double',
                                    'option8' => 'fa-solid fa-square-check',
                                    'option9' => 'fa-regular fa-square-check',
                                    'option10' => 'fa-solid fa-circle-check',
                                    'option11' => 'fa-regular fa-circle-check',
                                    'option12' => 'fa-solid fa-user-check'
                                );    
                              ?>

                            <tr <?php echo (!is_null($tab_row_six)) ? $tab_row_six : "style=\"display:none\"" ; ?> class="linkilo-external-url linkilo-setting-row">
                                <td scope='row'><?php _e('Specific Icon for Specific Domain', 'linkilo'); ?></td>
                                <td id="linkilo_num_inputdmn_fields">
                                    
                                    <?php  
                                        if(!empty( $specific_dmnname_and_cls_arr ))
                                        {

                                            foreach($specific_dmnname_and_cls_arr as $k =>$dmn_name_and_icon)
                                            {
                                                $dmn_name = isset($dmn_name_and_icon['domain_name']) ? $dmn_name_and_icon['domain_name'] : '';
                                                $icon_classs = isset($dmn_name_and_icon['icon_class']) ? $dmn_name_and_icon['icon_class'] : '';
                                                ?>
                                                <div class="linkilo_domain_row linkilo_row<?php echo esc_attr($k); ?>">
                                                    <input type="text" name="linkilo_specific_domain[<?php echo esc_attr($k); ?>]" class="linkilo_specifc_domains linkilo_specific_dmn_inputbox" value="<?php echo esc_attr($dmn_name);  ?>" placeholder ="<?php  _e('Enter Your Domain Name ex. sample.com', 'linkilo'); ?>"/>
                                                    
                                                        <select name="linkilo_spc_dmn_icon[<?php echo esc_attr($k); ?>]" class="linkilo_spc_domain_icon">
                                                        <option value="" data-icon-class = ""><?php _e('No Icon (Default)', 'linkilo'); ?></option>
                                                        <?php
                                                            $row_counter = 0;
                                                            
                                                        foreach ( $linkilo_icons_classes_arr as $value => $icon_class ) 
                                                        {
                                                            ?>
                                                            <option value="<?php echo esc_attr( $icon_class ); ?>" data-icon-class="<?php echo esc_attr( $icon_class ); ?>"  <?php selected($icon_class,$icon_classs); ?>><i class="<?php echo esc_attr( $icon_class ); ?>"></i></option>
                                                            <?php
                                                            $row_counter++;
                                                        }
                                                        ?>
                                                        </select>
                                                        <input type="button" value="Remove" class="linkilo_domain_icon_setting_remove_row" id="linkilo_domain_icon_setting_remove_row">
                                                </div>
                                                <?php
                                             }
                                            }
                                            else
                                            {
                                                ?>
                                                <div class="linkilo_domain_row">
                                                    <input type="text" name="linkilo_specific_domain[0]" class="linkilo_specifc_domains linkilo_specific_dmn_inputbox" placeholder ="<?php  _e('Enter Your Domain Name ex. sample.com', 'linkilo'); ?>"/>
                                                    
                                                        <select name="linkilo_spc_dmn_icon[0]" class="linkilo_spc_domain_icon" id="slect_icon_class">
                                                        <option value="" data-icon-class=""><?php _e('No Icon (Default)', 'linkilo'); ?></option>
                                                        <?php
                                                            $row_counter = 0;
                                                        
                                                        foreach ( $linkilo_icons_classes_arr as $value => $icon_class ) 
                                                        {
                                                            ?>
                                                            
                                                            <option value="<?php echo esc_attr( $icon_class ); ?>" data-icon-class="<?php echo esc_attr( $icon_class ); ?>"  ><i class="<?php echo esc_attr( $icon_class ); ?>"></i></option>
                                                            <?php
                                                            $row_counter++;
                                                        }
                                                        ?>
                                                    </select>
                                                    <input type="button" value="Remove" class="linkilo_domain_icon_setting_remove_row" id="linkilo_domain_icon_setting_remove_row">
                                                </div>
                                                <?php
                                            }
                                        ?>
                                        <div class="insert_new_field">
                                            <input type="button" value="Add New" id="linkilo_add_new_rowdmn"/>

                                        </div>
                                </td>
                            </tr>
                            
                            <!-- specific icons for Specific domain --> 

                            <!-- //__External links tab__// -->

                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <td scope='row'><?php _e('Exclude image URLs from anchor', 'linkilo'); ?></td>
                                <td>
                                    <input type="hidden" name="linkilo_ignore_image_urls" value="0" />
                                    <input type="checkbox" name="linkilo_ignore_image_urls" <?php echo !empty(get_option('linkilo_ignore_image_urls', false)) ? 'checked' : ''; ?> value="1" />
                                    <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                        <i class="dashicons dashicons-editor-help"></i>
                                        <div>
                                            <?php _e('Checking this will tell Linkilo to ignore image URLs in the Links Report.', 'linkilo'); ?>
                                            <br />
                                            <br />
                                            <?php _e('This will include image URLs inside anchor href attributes.', 'linkilo'); ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                <?php if(current_user_can('activate_plugins')){ ?>
                                    <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                        <td scope='row'><?php _e('Show connection requests', 'linkilo'); ?></td>
                                        <td>
                                            <div style="display: inline-block;">
                                                <div class="linkilo_help" style="float:right; position: relative; /*left: 30px;*/">
                                                    <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                    <div><?php _e('Show or hide connection requests entries display notice.', 'linkilo'); ?></div>
                                                </div>
                                                <?php
                                                if ($connection_entry_notice_enable_disable == '1') {
                                                    $checked_show = 'checked="checked"';
                                                }else{
                                                    $checked_show = "";
                                                }
                                                ?>
                                                <input
                                                type="checkbox"
                                                name="linkilo_site_connection_entries_notice"
                                                value="1"
                                                <?php echo $checked_show; ?>
                                                >
                                            </div>
                                        </td>
                                    </tr>
                                    <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                        <td scope='row'><?php _e('Add external site for link suggestions', 'linkilo'); ?></td>
                                        <td>
                                            <input type="hidden" name="linkilo_link_external_sites" value="0" />
                                            <input type="checkbox" name="linkilo_link_external_sites" <?php echo $site_linking_enabled==1 ? 'checked' : ''; ?> value="1" />
                                            <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                                <i class="dashicons dashicons-editor-help"></i>
                                                <div>
                                                    <?php _e('Checking this will allow you to make links to external sites that you own.', 'linkilo'); ?>
                                                    <br/>
                                                    <?php _e('All sites must have Linkilo installed and be in the same licensing plan.', 'linkilo'); ?>
                                                </div>
                                            </div>
                                            <div style="clear:both;"></div>
                                        </td>
                                    </tr>
                                    <?php $access_code = get_option('linkilo_link_external_sites_access_code', false); ?>
                                    <tr class="linkilo-site-linking-setting-row linkilo-advanced-settings linkilo-setting-row settings-row-border" <?php echo ($site_linking_enabled === '1') ? '': 'style="display:none;"'; ?>>
                                        <td scope='row' style="display:none;"><?php _e('Site Interlinking Access Code', 'linkilo'); ?></td>
                                        <td style="display:none;">
                                            <input type="hidden" name="linkilo_link_external_sites_access_code" value="0" />
                                            <input type="text" name="linkilo_link_external_sites_access_code" style="width:400px;" <?php echo (!empty($access_code)) ? 'value="' . $access_code . '"': 'placeholder="' . __('Enter Access Code', 'linkilo') . '"';?> />
                                            <a href="#" class="linkilo-generate-id-code button-primary" data-linkilo-id-code="1" data-linkilo-base-id-string="<?php echo Linkilo_Build_ConnectMultipleSite::generate_random_id_string(); ?>"><?php _e('Generate Code', 'linkilo'); ?></a>
                                            <div class="linkilo_help" style="display: inline-block; float: none; margin: 0px 0 0 5px;">
                                                <i class="dashicons dashicons-editor-help"></i>
                                                <div><?php _e('This code is used to secure the connection between all linked sites. Use the same code on all sites you want to link', 'linkilo'); ?></div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                    $home_url_display = 'style="display:none;"';
                                    if($site_linking_enabled === '1' && !is_null($tab_row_three)){
                                        $home_url_display = 'style="display:table-row;"';
                                    }
                                    ?>
                                    <tr class="linkilo-linked-sites-row linkilo-site-linking-setting-row linkilo-advanced-settings linkilo-setting-row settings-row-border" <?php echo $home_url_display; ?>>
                                        <td scope='row'><?php ; _e('Home URLs of Linked Sites', 'linkilo'); ?></td>
                                        <td class="linkilo-linked-sites-cell">
                                            <?php
                                            $unregister_text = __('Unregister Site', 'linkilo');
                                            $remove_text    = __('Remove Site', 'linkilo');
                                            $import_text   = __('Import Post Data', 'linkilo');
                                            $refresh_text = __('Refresh Post Data', 'linkilo');
                                            $link_site_text = __('Attempt Site Linking', 'linkilo');
                                            $disable_external_linking = __('Disable Suggestions', 'linkilo');
                                            $enable_external_linking = __('Enable Suggestions', 'linkilo');
                                            $sites = Linkilo_Build_ConnectMultipleSite::get_registered_sites();
                                            $linked_sites = Linkilo_Build_ConnectMultipleSite::get_linked_sites();
                                            $stringu =Linkilo_Build_ConnectMultipleSite::generate_random_id_string();
                                            $disabled_suggestion_sites = get_option('linkilo_disable_external_site_suggestions', array());

                                            foreach($sites as $site){
                                                if(in_array($site, $linked_sites, true)){
                                                    $sites_meta = Linkilo_Build_ConnectMultipleSite::get_connected_entries_meta($site);
                                                    $meta_id = (is_null($sites_meta)) ? 0 : $sites_meta;
                                                    $button_text = (Linkilo_Build_ConnectMultipleSite::check_for_stored_data($site)) ? $refresh_text: $import_text;
                                                    $suggestions_disabled = isset($disabled_suggestion_sites[$site]);
                                                    echo '<div class="linkilo-linked-site-input settings-url-fields-mw-limit">
                                                    <input type="text" name="linkilo_linked_site_url[]" style="width:600px" value="' . $site . '" autocomplete="off" disabled />
                                                    <div class="settings-url-fields-labels-c-t">
                                                    <label>
                                                    <a href="#" class="linkilo-refresh-post-data button-primary site-linking-button" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'download-site-data-nonce') . '" data-id="'.$meta_id.'">' . $button_text . '</a>
                                                    <a href="#" class="linkilo-external-site-suggestions-toggle button-primary site-linking-button" data-suggestions-enabled="' . ($suggestions_disabled ? 0: 1) . '" data-site-url="' . esc_url($site) . '" data-enable-text="' . $enable_external_linking . '" data-disable-text="' . $disable_external_linking . '" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'toggle-external-site-suggestions-nonce') . '">' . ($suggestions_disabled ? $enable_external_linking: $disable_external_linking) . '</a>
                                                    <a href="#" class="linkilo-unlink-site-button button-primary button-purple site-linking-button" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'unlink-site-nonce') . '" data-id="'.$meta_id.'">' . $remove_text . '</a>
                                                    </label></div>

                                                    </div>';
                                                }else{
                                                    echo '<div class="linkilo-linked-site-input">
                                                    <input type="text" name="linkilo_linked_site_url[]" style="width:600px" value="' . $site . '" autocomplete="off"/>
                                                    <label>
                                                    <a href="#" class="linkilo-link-site-button button-primary" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'link-site-nonce') . '">' . $link_site_text . '</a>
                                                    <a href="#" class="linkilo-unregister-site-button button-primary button-purple site-linking-button" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'unregister-site-nonce') . '">' . $unregister_text . '</a>
                                                    </label>
                                                    </div>';
                                                }
                                            }
                                            echo '<div class="linkilo-linked-site-add-button-container">
                                            <a href="#" class="button-primary linkilo-linked-site-add-button">' . __('Add Site Row', 'linkilo') . '</a>
                                            </div>';

                                            echo '<div class="linkilo-linked-site-input template-input hidden">
                                            <input type="text" name="linkilo_linked_site_url[]" style="width:600px;" autocomplete="off"/>
                                            <label>
                                            <a href="#" class="linkilo-register-site-button button-primary" data-linkilo-id-code="1"
                                            data-linkilo-base-id-string=' .$stringu .' data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'register-site-nonce') . '">' . __('Register Site', 'linkilo') . '</a>
                                            </label>
                                            </div>';
                                            ?>
                                            <input type="hidden" id="linkilo-site-linking-initial-loading-message" value="<?php echo esc_attr__('Importing Post Data', 'linkilo'); ?>">
                                        </td>
                                    </tr>
                                    <?php if(!empty($access_code)){ ?>
                                    <?php } ?>
                                <?php }else{ ?>
                                    <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                        <td scope='row'><?php _e('Interlink External Sites', 'linkilo'); ?></td>
                                        <td>
                                            <p><i><?php _e('Only admins can access the site linking settings.', 'linkilo'); ?></i></p>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'><?php _e('Remove Click Data Older Than', 'linkilo'); ?></td>
                                    <td>
                                        <div style="display: flex;">
                                            <select name="linkilo_delete_old_click_data" style="float:left;">
                                                <?php $day_count = get_option('linkilo_delete_old_click_data', '0'); ?>
                                                <option value="0" <?php selected('0', $day_count) ?>><?php _e('Never Delete'); ?></option>
                                                <option value="1" <?php selected('1', $day_count) ?>><?php _e('1 Day'); ?></option>
                                                <option value="3" <?php selected('3', $day_count) ?>><?php _e('3 Days'); ?></option>
                                                <option value="7" <?php selected('7', $day_count) ?>><?php _e('7 Days'); ?></option>
                                                <option value="14" <?php selected('14', $day_count) ?>><?php _e('14 Days'); ?></option>
                                                <option value="30" <?php selected('30', $day_count) ?>><?php _e('30 Days'); ?></option>
                                                <option value="180" <?php selected('180', $day_count) ?>><?php _e('180 Days'); ?></option>
                                                <option value="365" <?php selected('365', $day_count) ?>><?php _e('1 Year'); ?></option>
                                            </select>
                                            <div class="linkilo_help" style="float:right;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div style="margin: -50px 0 0 30px;">
                                                    <?php _e("Linkilo will delete tracked clicks that are older than this setting.", 'linkilo'); ?>
                                                    <br />
                                                    <br />
                                                    <?php _e("By default, Linkilo doesn't delete tracked click data.", 'linkilo'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_nine)) ? $tab_row_nine : "style=\"display:none\"" ; ?> class="linkilo-gsc-settings linkilo-setting-row settings-row-border">
                                    <!-- <td scope='row'><?php // _e('Remove GSC Data Older Than', 'linkilo'); ?></td> -->
                                    <!-- <td> -->
                                        <!-- <div style="display: flex;"> -->
                                        <?php /* ?>
                                            <select name="linkilo_delete_old_gsc_data" style="float:left;">
                                                <?php $day_count = get_option('linkilo_delete_old_gsc_data', '0'); ?>
                                                <option value="0" <?php selected('0', $day_count) ?>><?php _e('Never Delete'); ?></option>
                                                <option value="1" <?php selected('1', $day_count) ?>><?php _e('1 Day'); ?></option>
                                                <option value="3" <?php selected('3', $day_count) ?>><?php _e('3 Days'); ?></option>
                                                <option value="7" <?php selected('7', $day_count) ?>><?php _e('7 Days'); ?></option>
                                                <option value="14" <?php selected('14', $day_count) ?>><?php _e('14 Days'); ?></option>
                                                <option value="30" <?php selected('30', $day_count) ?>><?php _e('30 Days'); ?></option>
                                                <option value="180" <?php selected('180', $day_count) ?>><?php _e('180 Days'); ?></option>
                                                <option value="365" <?php selected('365', $day_count) ?>><?php _e('1 Year'); ?></option>
                                            </select>
                                            <?php */ ?>
                                            <div class="linkilo_help" style="float:right;">
                                                <!-- <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i> -->
                                                <!-- <div style="margin: -50px 0 0 30px;"> -->
                                                    <?php // _e("Linkilo will delete stored GSC data that is older than this setting.", 'linkilo'); ?>
                                                    <br />
                                                    <br />
                                                    <?php // _e("By default, Linkilo doesn't delete stored GSC data.", 'linkilo'); ?>
                                                <!-- </div> -->
                                            </div>
                                        <!-- </div> -->
                                    <!-- </td> -->
                                </tr>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'><?php _e('Disable Click Tracking', 'linkilo'); ?></td>
                                    <td>
                                        <div style="max-width:50px;">
                                            <input type="hidden" name="linkilo_disable_click_tracking" value="0" />
                                            <input type="checkbox" name="linkilo_disable_click_tracking" <?php echo get_option('linkilo_disable_click_tracking', false)==1 ? 'checked' : ''; ?> value="1" />
                                            <div class="linkilo_help" style="float:right;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div style="margin: -180px 0 0 30px;">
                                                    <?php _e("Activating this will disable the Click Tracking and will remove the Click Report from the Summary", 'linkilo'); ?>
                                                    <br>
                                                    <br>
                                                    <?php _e("The Click Tracking uses frontend scripts to track clicks. The scripts are jQuery, jQuery migrate and the Linkilo Frontend script.", 'linkilo'); ?>
                                                    <br>
                                                    <br>
                                                    <?php _e("Disabling the Click Tracking will remove these scripts.", 'linkilo'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row settings-row-border">
                                    <td scope='row'><?php _e('Remove Linkilo Data', 'linkilo'); ?></td>
                                    <td>
                                        <div style="max-width:50px;">
                                            <input type="hidden" name="linkilo_delete_all_data" value="0" />
                                            <input type="checkbox" class="danger-zone" name="linkilo_delete_all_data" <?php echo get_option('linkilo_delete_all_data', false)==1 ? 'checked' : '';?> value="1" />
                                            <input type="hidden" class="linkilo-delete-all-data-message" value="<?php echo sprintf(__('Activating this will tell Linkilo to delete ALL Linkilo related data when the plugin is deleted. %s This will remove all settings and stored data. Links inserted into content by Linkilo will still exist. %s Undoing actions like URL changes will be impossible since the records of what the url used to be will be deleted as well. %s Please only activate this option if you\'re sure you want to delete all data.', 'linkilo'), '&lt;br&gt;&lt;br&gt;', '&lt;br&gt;&lt;br&gt;', '&lt;br&gt;&lt;br&gt;'); ?>">
                                            <div class="linkilo_help" style="float:right;">
                                                <i class="dashicons dashicons-editor-help" style="margin-top: 6px;"></i>
                                                <div style="margin: -50px 0 0 30px;">
                                                    <?php _e("Activating this will tell Linkilo to delete ALL Linkilo related data when the plugin is deleted.", 'linkilo'); ?>
                                                    <br>
                                                    <br>
                                                    <?php _e("Please only activate this option if you're sure you want to delete ALL Linkilo data.", 'linkilo'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr <?php echo (!is_null($tab_row_three)) ? $tab_row_three : "style=\"display:none\"" ; ?> class="linkilo-advanced-settings linkilo-setting-row">
                                    <td scope='row'>
                                        <span class="settings-carrot">
                                            <?php _e('Debug Settings', 'linkilo'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="setting-control">
                                            <input type="hidden" name="linkilo_2_debug_mode" value="0" />
                                            <input type='checkbox' name="linkilo_2_debug_mode" <?php echo get_option('linkilo_2_debug_mode')==1 ? 'checked' : ''; ?> value="1" />
                                            <label><?php _e('Enable Debug Mode?', 'linkilo'); ?></label>
                                            <p><i><?php _e('If you\'re having errors, or it seems that data is missing, activating Debug Mode may be useful in diagnosing the problem.', 'linkilo'); ?></i></p>
                                            <p><i><?php _e('Enabling Debug Mode will cause your site to display any errors or code problems it\'s expiriencing instead of hiding them from view.', 'linkilo'); ?></i></p>
                                            <p><i><?php _e('These error notices may be visible to your site\'s visitors, so it\'s recommended to only use this for limited periods of time.', 'linkilo'); ?></i></p>
                                            <p><i><?php _e('(If you are already debugging with WP_DEBUG, then there\'s no need to activate this.)', 'linkilo'); ?></i></p>
                                            <br>
                                        </div>
                                        <div class="setting-control">
                                            <input type="hidden" name="linkilo_option_update_reporting_data_on_save" value="0" />
                                            <input type='checkbox' name="linkilo_option_update_reporting_data_on_save" <?php echo get_option('linkilo_option_update_reporting_data_on_save')==1 ? 'checked' : ''; ?> value="1" />
                                            <label><?php _e('Run a check for un-indexed posts on each post save?', 'linkilo'); ?></label>
                                            <p><i><?php _e('Checking this will tell Linkilo to look for any posts that haven\'t been indexed for the link reports every time a post is saved.', 'linkilo'); ?></i></p>
                                            <p><i><?php _e('In most cases this isn\'t necessary, but if you\'re finding that some of your posts aren\'t displaying in the reports screens, this may fix it.', 'linkilo'); ?></i></p>
                                            <p><i><?php _e('One word of caution: If you have many un-indexed posts on the site, this may cause memory / timeout errors.', 'linkilo'); ?></i></p>
                                            <br>
                                        </div>
                                        <div class="setting-control">
                                            <input type="hidden" name="linkilo_include_post_meta_in_support_export" value="0" />
                                            <input type='checkbox' name="linkilo_include_post_meta_in_support_export" <?php echo get_option('linkilo_include_post_meta_in_support_export')==1 ? 'checked' : ''; ?> value="1" />
                                            <label><?php _e('Include post meta in support data export?', 'linkilo'); ?></label>
                                            <p><i><?php _e('Checking this will tell Linkilo to include additional post data in the data for support export.', 'linkilo'); ?></i></p>
                                            <p><i><?php _e('This isn\'t needed for most support cases. It\'s most commonly used for troubleshooting issues with page builders', 'linkilo'); ?></i></p>
                                            <br>
                                        </div>
                                    </td>
                                </tr>
                            </tr>
                            <tr <?php echo (!is_null($tab_row_four)) ? $tab_row_four : "style=\"display:none\"" ; ?> class="linkilo-licensing linkilo-setting-row">
                                <td>
                                    <div class="wrap linkilo_licensing_wrap postbox">
                                        <div class="linkilo_licensing_container">
                                            <div class="linkilo_licensing" style="">
                                                <h2 class="linkilo_licensing_header hndle ui-sortable-handle">
                                                    <span>Linkilo Licensing</span>
                                                </h2>
                                                <div class="linkilo_licensing_content inside">
                                                    <?php settings_fields('linkilo_license'); ?>
                                                    <input type="hidden" id="linkilo_license_action_input" name="hidden_action" value="activate_license" disabled="disabled">
                                                    <table class="form-table">
                                                        <tbody>
                                                            <tr style="display:none;">
                                                                <td class="linkilo_license_table_title">
                                                                    <?php _e('License Key:', 'linkilo');?>
                                                                </td>
                                                                <td>
                                                                    <input id="linkilo_license_key" name="linkilo_license_key" type="text" class="regular-text" value="" />
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="linkilo_license_table_title" style="font-size: 18px !important;">
                                                                    <?php _e('License Status:', 'linkilo');?>
                                                                </td>
                                                                <td>
                                                                    <span class="linkilo_licensing_status_text <?php echo esc_attr($licensing_state); ?>">
                                                                        <?php echo esc_attr($status_titles[$licensing_state]); ?>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="linkilo_license_table_title" style="font-size: 18px !important;">
                                                                    <?php _e('License Message:', 'linkilo');?>
                                                                </td>
                                                                <td>
                                                                    <span class="linkilo_licensing_status_text <?php echo esc_attr($licensing_state); ?>">
                                                                        <?php echo esc_attr(ucwords(trim($status_messages[$licensing_state]))); ?>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                            <tr></tr>
                                                            <tr>
                                                                <td colspan="2">
                                                                    <?php 
                                                                    $login = esc_url("https://www.linkilo.co/login/"); 
                                                                    ?>
                                                                    <span class="linkilo_license_manage_text">
                                                                        <?php _e('To deactivate this site goto your managed site section','linkilo'); ?>
                                                                        <a href="<?php echo $login;?>" target="_blank" class="linkilo_license_manage_link">
                                                                            <?php _e('Manage Sites','linkilo'); ?>
                                                                            <img src="<?php echo LINKILO_PLUGIN_DIR_URL.'images/target.png'; ?>" style="width: 15px; height: 15px; margin-top: 5px;"
                                                                            style="width: 15px; height: 15px; margin-top: 5px;">
                                                                        </a>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <?php wp_nonce_field( 'linkilo_activate_license_nonce', 'linkilo_activate_license_nonce' ); ?>
                                                    <div class="linkilo_licensing_version_number">
                                                        <?php echo Linkilo_Build_Root::showVersion(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php if (isset($_GET['section']) && $_GET['section'] === "linkilo-licensing") {
                        $hide_settings_btn = 'style="display:none;"';
                    }else{
                        $hide_settings_btn = 'style="display:block;"';
                    } ?>
                    <p class='submit linkilo-setting-button save-settings' <?php echo $hide_settings_btn; ?>>
                        <input type='submit' name='btnsave' id='btnsave' value='Save Settings' class='button-primary' />
                    </p>
                    <p class='submit linkilo-setting-button activate-license' style="display:none;">
                        <button type="submit" class="button button-primary linkilo_licensing_activation_button">
                            <?php _e('Activate License', 'linkilo'); ?>
                        </button>
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>
