<?php
/**
 * Plugin Name: Linkilo
 * Version: 1.9.2
 * Requires at least: 5.6
 * Requires PHP: 7.0
 * Description: Set internal links in post for other posts and pages, check for report for each link and export data to excel.
 * Author: Linkilo
 * Author URI: https://linkilo.co
 * Text Domain: linkilo
 */
spl_autoload_register( 'linkilo_autoloader_advanced' );
function linkilo_autoloader_advanced( $class_name ) {
    if ( false !== strpos( $class_name, 'Linkilo' ) ) {
        $classes_dir = realpath( plugin_dir_path( __FILE__ ) ) . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR;
        $class_name = str_replace( '_Build', '', $class_name );
        $class_file = str_replace( '_', DIRECTORY_SEPARATOR, $class_name ) . '.php';
        require_once $classes_dir . $class_file;
    }
}

// Default Constant
define( 'LINKILO_SHOP_URL', 'https://linkilo.co');
define( 'LINKILO_PLUGIN_BASE_NAME', plugin_basename( __FILE__ ));
define( 'LINKILO_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));
define( 'LINKILO_PLUGIN_DIR_URL', plugin_dir_url(__FILE__));
define( 'LINKILO_HIDE_OPTION', 'LINKILO_HIDE_OPTION');
define( 'LINKILO_PAIRS_MODE_OPTION', 'linkilo_2_ll_pairs_mode');
define( 'LINKILO_PAIRS_MODE_NO_OPTION', 'linkilo_2_ll_pairs_mode_no');
define( 'LINKILO_PAIRS_MODE_EXACT_OPTION', 'linkilo_2_ll_pairs_mode_exact');
define( 'LINKILO_PAIRS_MODE_ANYWHERE_OPTION', 'linkilo_2_ll_pairs_mode_anywhere');
define( 'LINKILO_WORDS_LIST_TO_IGNORE_OPTIONS', 'linkilo_2_ignore_words');
define( 'LINKILO_NUMBERS_TO_IGNORE_OPTIONS', 'linkilo_2_ignore_numbers');
define( 'LINKILO_CHECK_DEBUG_MODE_OPTION', 'linkilo_2_debug_mode');
define( 'LINKILO_UPDATE_REPORT_AT_SAVE_OPTIONS', 'linkilo_option_update_reporting_data_on_save');
define( 'LINKILO_CASCADE_UPDATING_OPTION_REDUCE', 'linkilo_option_reduce_cascade_updating');
define( 'LINKILO_DO_NOT_COUNT_INCOMING_LINKS_OPTIONS', 'linkilo_option_dont_count_incoming_links');
define( 'LINKILO_LICENSE_KEY_OPTION', 'linkilo_2_license_key');
define( 'LINKILO_LICENSE_CHECK_TIME_OPTION', 'linkilo_2_license_check_time');
define( 'LINKILO_STATUS_OF_LICENSE_OPTION', 'linkilo_2_license_status');
define( 'LINKILO_CURRENT_LICENSE_DATA_OPTION', 'linkilo_2_license_data');
define( 'LINKILO_LAST_ERROR_FOR_LICENSE_OPTION', 'linkilo_2_license_last_error');
define( 'LINKILO_SELECTED_POST_TYPES_OPTIONS', 'linkilo_2_post_types');
define( 'LINKILO_RELATE_META_POST_TYPES_OPTIONS', 'linkilo_relate_meta_post_types');
define( 'LINKILO_RELATE_META_POST_DISPLAY_LIMIT_OPTIONS', 'linkilo_relate_meta_post_display_limit');
define( 'LINKILO_RELATE_META_POST_DISPLAY_ORDER_OPTIONS', 'linkilo_relate_meta_post_display_order');
define( 'LINKILO_RELATE_META_POST_ENABLE_DISABLE_OPTIONS', 'linkilo_relate_meta_post_enable_disable');
define( 'LINKILO_RELATE_META_POST_TYPES_INCLUDE_OPTIONS', 'linkilo_relate_meta_post_types_include');
define( 'LINKILO_SITE_CONNECTION_ENTRIES_NOTICE_OPTIONS', 'linkilo_site_connection_entries_notice');
define( 'LINKILO_R_A_K_OPTIONS', 'linkilo_r_a_k_store_version');
define( 'LINKILO_R_A_I_V_OPTIONS', 'linkilo_r_a_i_v_store_version');
define( 'LINKILO_B_K_OPTIONS', 'linkilo_b_k_store_version');
define( 'LINKILO_SHOW_INBOUND_METABOX_IN_POST_EDIT', 'linkilo_2_show_inbound_metabox_in_post_edit');
define( 'LINKILO_LOAD_MORE_INBOUND_SUGGESTIONS', 'linkilo_2_load_more_inbound_suggestions');
define( 'LINKILO_LOAD_MORE_OUTBOUND_SUGGESTIONS', 'linkilo_2_load_more_outbound_suggestions');
define( 'LINKILO_PREVIOUS_REPORT_RESET_DATE_TIME_OPTIONS', 'linkilo_2_report_last_updated');
define( 'LINKILO_VERSION_DEVLOP_DATE', '01-August-2021');
define( 'LINKILO_SHOW_DEVELOP_DETAILS', true);
define( 'LINKILO_TOTAL_COUNT_OF_OUTGOING_INTERNAL_LINKS', 'linkilo_links_outgoing_internal_count');
define( 'LINKILO_TOTAL_COUNT_OF_INCOMING_INTERNAL_LINKS', 'linkilo_links_incoming_internal_count');
define( 'LINKILO_TOTAL_COUNT_OF_OUTGOING_EXTERNAL_LINKS', 'linkilo_links_outgoing_external_count');
define( 'LINKILO_SYNC_POST_META_KEY', 'linkilo_sync_report3');
define( 'LINKILO_SYNC_POST_META_KEY_TIME', 'linkilo_sync_report2_time');
define( 'LINKILO_POST_META_KEY_ADD_LINKS', 'linkilo_add_links');
define( 'LINKILO_IS_LINKS_TABLE_CREATED', 'linkilo_link_table_is_created');
define( 'LINKILO_IS_LINKS_TABLE_EXISTS', get_option(LINKILO_IS_LINKS_TABLE_CREATED, false));
define( 'LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_PLUGIN', '1.6.2');
define( 'LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_SITE', get_option('linkilo_site_db_version', '0'));
define( 'LINKILO_STATUS_PROCESSING_START', microtime(true));
define( 'LINKILO_STATUS_HAS_RUN_SCAN', get_option('linkilo_has_run_initial_scan', false));
define( 'LINKILO_DEBUG_CURL', false);

if ( is_admin() ) {
    if( ! function_exists('get_plugin_data') ){
        require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }
    $plugin_data = get_plugin_data( __FILE__ );
    $plugin_version = $plugin_data['Version'];

    define( 'LINKILO_PLUGIN_VERSION', $plugin_version);
}

Linkilo_Build_Initialize::register_services();

register_activation_hook(__FILE__, [Linkilo_Build_Root::class, 'activate'] );
register_uninstall_hook(__FILE__, array(Linkilo_Build_Root::class, 'delete_linkilo_data'));
if (is_admin()) {
    if(!class_exists( 'LCO_Plugin_Updater')) {
        // load our custom updater if it doesn't already exist
        include (dirname(__FILE__).'/vendor/LCO_Plugin_Updater.php');
    }

    if (Linkilo_Build_ActiveLicense::isValid()) {

        $license_key = trim(get_option( LINKILO_LICENSE_KEY_OPTION));
        $product = Linkilo_Build_ActiveLicense::getItemId($license_key);
        $license = Linkilo_Build_ActiveLicense::getKey($license_key);

        // setup the updater
        $edd_updater = new LCO_Plugin_Updater( LINKILO_SHOP_URL, __FILE__, array(
            'version' => LINKILO_PLUGIN_VERSION, // current version number
            'license' => $license,  // license key (used get_option above to retrieve from DB)
            'item_id' => $product,  // id of this plugin
            'author' => 'Linkilo', // author of this plugin
            'url' => home_url(),
            'beta' => false, // set to true if you wish customers to receive update notifications of beta releases
        ));
    }
}

if (!function_exists('linkilo_init')) {
    function linkilo_init()
    {
        $locale = is_admin() && function_exists('get_user_locale') ? get_user_locale() : get_locale();
        $locale = apply_filters('plugin_locale', $locale, 'linkilo');
        unload_textdomain('linkilo');
        load_textdomain('linkilo', LINKILO_PLUGIN_DIR_PATH . 'languages/' . "linkilo-" . $locale . '.mo');
        load_plugin_textdomain('linkilo', false, LINKILO_PLUGIN_DIR_PATH . 'languages');
    }
}
add_action('plugins_loaded', 'linkilo_init');

if(!function_exists('LINKILO_LOG_TEXT')) {
    function LINKILO_LOG_TEXT($content){
        $file = fopen(trailingslashit(LINKILO_PLUGIN_DIR_PATH) . 'linkilo_text_log.txt', 'a');
        fwrite($file, print_r($content, true));
        fclose($file);
    }
}

/**
 * Add texts and links for linkilo plugin on to display on plugins page
 * Add Changelog URL on plugin list screen for Likilo Plugin
 * */
function linkilo_filter_plugin_row_meta( array $plugin_meta, $plugin_file ) {
    if ( 'linkilo/linkilo.php' !== $plugin_file ) {
        return $plugin_meta;
    }

    $plugin_meta[] = sprintf(
        '<a href="%1$s" target="_blank"><span></span>%2$s</a>',
        'https://linkilo.co/changelog/wordpress-versions/',
        esc_html_x( 'Changelog', 'Verb: Changelogs', 'linkilo' )
    );
    return $plugin_meta;
}
add_filter( 'plugin_row_meta','linkilo_filter_plugin_row_meta', 10, 4);

/**
 * Show notice on activation
 * */
function linkilo_notice_for_non_dependent_plugins() {
    if ( is_plugin_active( 'link-whisper-premium/link-whisper.php' ) ) {
        $deactivate_url = wp_nonce_url( site_url( $_SERVER['REQUEST_URI'] ), 'linkilo_deactivate_link_whisper', '_delw' );
        ?>
        <div class="<?php echo esc_attr( 'notice notice-warning is-dismissible' ); ?>">
            <p>
                <?php esc_html_e( "Link Whisper is active! Please deactivate Link Whisper prior to activating Linkilo.", 'linkilo' ); ?>
                <a href="<?php echo esc_url( $deactivate_url ); ?>" style="float: right; background-color: orange;padding: 0px 10px; color: white; border-radius: 20px; text-decoration: none;">
                    <?php esc_html_e( 'Deactiate Link Whisper.', 'linkilo' ); ?>
                </a>
            </p>
        </div>
        <?php
    }
}
// Hook the function to the plugin activation event
register_activation_hook( __FILE__, 'redirect_to_plugin_menu_on_activation' );

// Function to set the activation redirect flag
function redirect_to_plugin_menu_on_activation() {
    if( !LINKILO_STATUS_HAS_RUN_SCAN ){

        set_transient( 'my_plugin_activation_redirect', true, 60 ); // Redirect for 60 seconds
    }
}

// Check for the activation redirect flag and perform the redirection
add_action( 'admin_init', 'redirect_after_activation' );

function redirect_after_activation() {
    if ( get_transient( 'my_plugin_activation_redirect' ) ) {
        delete_transient( 'my_plugin_activation_redirect' ); // Clean up the transient
        wp_redirect( admin_url( 'admin.php?page=linkilo' ) ); // Redirect to your plugin's menu page
        exit;
    }
}

add_filter( 'unzip_file_use_ziparchive', '__return_false' );
// Your plugin's code goes here


// add_action('admin_notices', 'linkilo_notice_for_non_dependent_plugins');



