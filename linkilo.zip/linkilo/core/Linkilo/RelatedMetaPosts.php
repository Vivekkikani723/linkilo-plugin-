<?php

/**
 * Work with keywords
 */
class Linkilo_Build_RelatedMetaPosts {
    private $relate_meta_post_types;
    private $enable_disable_meta_posts;
    private $limit;
    private $order;

    public function __construct() {
        if (Linkilo_Build_ActiveLicense::isValid()) {
            $this->enable_disable_meta_posts = Linkilo_Build_AdminSettings::getRelatedMetaPostEnableDisable();
            if ($this->enable_disable_meta_posts == "1") {
                $post_types_active = Linkilo_Build_AdminSettings::getPostTypes();
                $this->relate_meta_post_types = $post_types_active;
                self::create_fulltext_indices();
                $posts_limit = Linkilo_Build_AdminSettings::getRelatedMetaPostLimit();
                $posts_order = Linkilo_Build_AdminSettings::getRelatedMetaPostOrder();
                $this->limit = intval($posts_limit);
                $this->order = $posts_order;
                add_action('add_meta_boxes', array($this, 'linkilo_meta_box_side_bar_settings'));
                self::add_default_option();
                add_action('wp_ajax_update_related_posts_same_title', array($this, 'ajax_update_related_posts_same_title'));
            }
        }
    }

    public function ajax_update_related_posts_same_title() {
        $option = $_POST['same_title_option'];
        if (isset($_POST['same_title_option']) && !empty($_POST['same_title_option'])) {
            update_option('linkilo_relate_meta_post_same_title', $option);
            $return = array('flag' => 'success');
        } else {
            $return = array('flag' => 'error', 'msg' => 'Option not updated');
        }
        wp_send_json($return);
    }

    public function add_default_option() {
        $same_title_option = get_option('linkilo_relate_meta_post_same_title');
        if ($same_title_option == false && empty($same_title_option)) {
            update_option('linkilo_relate_meta_post_same_title', 'hide');
        }
    }

    public function linkilo_meta_box_side_bar_settings() {
        $screens = get_option('linkilo_relate_meta_post_types', true);
        if (!empty($screens) && sizeof($screens) > 0) {
            $context = 'side';
            $priority = 'default';
            foreach ($screens as $screen) {
                add_meta_box(
                    'linkilo-related-meta-posts-settings',
                    __('Linkilo Related Posts', 'linkilo'),
                    array($this, 'linkilo_meta_box_side_bar_settings_callback'),
                    $screen,
                    $context,
                    $priority
                );
            }
        }
    }

    public function linkilo_meta_box_side_bar_settings_callback($post) {
        $post_obj = new Linkilo_Build_Model_Feed($post->ID);
        $related_urls = $this->linkilo_related_meta_posts($post_obj);
        if (!empty($related_urls) && sizeof($related_urls) > 0) {
            $loop_count = 0;
            if ($this->order == 'random') {
                $this->limit = $this->limit / 3;
                shuffle($related_urls);
            }
            echo "<div class='wrap_linkilo_sidebar_suggestion'>";
            echo '<p id="copy_url_alert" style="display:none">Url Copied!</p>';
            foreach ($related_urls as $index => $post) {
                if ($this->limit != $loop_count) {
                    $link = get_permalink($post->ID);
                    $title = $post->post_title;
                    echo '<div style="display: flex;margin-bottom: 10px;max-width: 250px;">';
                    echo '<div style="margin-top: 4px; padding-right: 10px;">';
                    echo '<button title="Copy Url" onclick="linkilo_copy_related_posts(event,\'related_posts_url_'.$post->ID.'\')" style="cursor: pointer;">';
                    echo '<span class="dashicons dashicons-admin-page"></span>';
                    echo '</button>';
                    echo '</div>';
                    echo '<div style="font-size: 15px;">';
                    echo '<a href="javascript:void(0);" id="related_posts_url_'.$post->ID.'" data-post_link="'.$link.'">'.$title.'</a>';
                    echo '</div>';
                    echo '</div>';
                    $loop_count++;
                }
            }
            echo "</div>";
            ?>
            <script>
                function linkilo_copy_related_posts(event, copyId) {
                    let inputElement = document.createElement("input");
                    inputElement.type = "text";
                    let copyText = document.getElementById(copyId).dataset.post_link;
                    inputElement.value = copyText;
                    document.body.appendChild(inputElement);
                    inputElement.select();
                    document.execCommand('copy');
                    document.body.removeChild(inputElement);
                    document.getElementById("copy_url_alert").style.display = "block";
                    setTimeout(function() {
                        document.getElementById("copy_url_alert").style.display = "none";
                    }, 1000);
                    event.preventDefault();
                    return false;
                }
            </script>
            <?php
        } else {
            echo '<p class="components-form-token-field__help">No related urls found for this post.</p>';
        }
    }

    public function create_fulltext_indices() {
        global $wpdb;
        $post_table = $wpdb->prefix . 'posts';
        $index_one = 'linkilo_related';
        $index_two = 'linkilo_related_title';
        $get_indexes = $wpdb->get_results($wpdb->prepare("SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND (INDEX_NAME = %s OR INDEX_NAME = %s)", DB_NAME, $post_table, $index_one, $index_two));
        if (sizeof($get_indexes) == 0 && empty($get_indexes)) {
            $sql1 = "ALTER TABLE {$post_table} ADD FULLTEXT linkilo_related (post_title, post_content);";
            $sql2 = "ALTER TABLE {$post_table} ADD FULLTEXT linkilo_related_title (post_title);";
            $result1 = $wpdb->query($sql1);
            $result2 = $wpdb->query($sql2);
            if (false === $result1 || false === $result2) {
                $class = 'notice notice-error';
                $message = __('Query error', 'linkilo');
            } else {
                $class = 'notice notice-success';
                $message = __('Success ', 'linkilo');
            }
        }
    }

    public function get_article_words_array($post) {
        $word_array = array();
        $related_posts = $this->linkilo_related_meta_posts($post);
        foreach ($related_posts as $arr_index => $list_post) {
            $title = trim(strtolower($list_post->post_title));
            $conv_title = Linkilo_Build_UrlRecommendation::getConvertedArrayOfInput($title);
            foreach ($conv_title as $i => $v) {
                array_push($word_array, $v);
            }
        }
        return array_unique($word_array);
    }

public function linkilo_related_meta_posts($post) {
    $same_title_option = get_option('linkilo_relate_meta_post_same_title'); 
    $this_post_id = $post->id; 
    $get_post_by_id = get_post($this_post_id);
    $get_content_of_post = apply_filters('the_content', $get_post_by_id->post_content);
    $get_curr_post_type = $get_post_by_id->post_type;

    if (post_password_required($get_post_by_id)) {
        $output = __('There is no excerpt because this is a protected post.', 'contextual-related-posts');
        echo $output;
        die();
    }

    // Extract linked post IDs
    $linked_urls = array();
    if (preg_match_all('#\bhttps?://[^\s()<>]+(?:\([\w\d]+\)|([^[:punct:]\s]|/))#', $get_content_of_post, $match)) {
        $linked_urls = $match[0];
    }

    $linked_post_ids = array_map('url_to_postid', $linked_urls);
    $linked_post_ids[] = $this_post_id; // Include current post ID
    $exclude_ids = implode(', ', array_unique($linked_post_ids));

    // Gather content from linked posts for relevance
    $linked_posts_content = array();
    foreach ($linked_post_ids as $linked_post_id) {
        $linked_post = get_post($linked_post_id);
        if ($linked_post) {
            $linked_posts_content[] = $linked_post->post_title . ' ' . wp_strip_all_tags(strip_shortcodes($linked_post->post_content));
        }
    }
    $linked_posts_content = implode(' ', $linked_posts_content);

    // Combine content from current post and linked posts
    $combined_content = $get_content_of_post . ' ' . $linked_posts_content;
    $combined_content = wp_strip_all_tags(strip_shortcodes($combined_content));
    $limited_combined_content = wp_trim_words($combined_content, 300); // Limit words to avoid overly long queries

    // Prepare fulltext search content
    $fulltext_to_match = str_ireplace(' from', '', $limited_combined_content);

    $real_time_date = current_time('mysql');
    $matching_post_types = "";
    $get_post_types = get_option('linkilo_relate_meta_post_types_include', true);
    if (!empty($get_post_types)) {
        $matching_post_types = "'" . implode("', '", $get_post_types) . "'";
    }

    $related_posts = "";
    if (!empty($matching_post_types)) {
        global $wpdb;
        $match_cols = $same_title_option == "show" || empty($get_content_of_post) ? "MATCH ($wpdb->posts.post_title)" : "MATCH ($wpdb->posts.post_title, $wpdb->posts.post_content)";

        $orderby = $this->order == 'date' ? " ORDER BY $wpdb->posts.post_date DESC LIMIT 0, " . $this->limit : " ORDER BY score DESC LIMIT 0, " . $this->limit;

        $related_posts = $wpdb->get_results("SELECT $wpdb->posts.*, $match_cols AGAINST ('$fulltext_to_match') as score FROM $wpdb->posts WHERE 1=1 AND ( $wpdb->posts.post_date <= '$real_time_date' ) AND $wpdb->posts.ID NOT IN ($exclude_ids) AND $wpdb->posts.post_type IN ($matching_post_types) AND (($wpdb->posts.post_status = 'publish' OR $wpdb->posts.post_status = 'inherit')) AND $match_cols AGAINST ('$fulltext_to_match')".$orderby);
    }
    return $related_posts;
}

}
