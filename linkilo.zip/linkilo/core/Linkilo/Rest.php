<?php

class Linkilo_Build_Rest extends WP_REST_Controller
{
    const NAMESPACE = 'linkilo-app-console';

    const ROUTE     = 'code-process';

    public function register()
    {
        $this->register_rest_linkilo();
    }

    public function register_rest_linkilo()
    {
        add_action('rest_api_init', function ( $wp_rest_server )
        {
            /**
             * @var WP_REST_Server $wp_rest_server
             */
            register_rest_route('linkilo-app-console', 'code-process', [
                'methods'             => 'GET',
                'callback'            => [
                    $this,
                    'linkilo_rest_code_process_handle'
                ],
                'permission_callback' => "__return_true",
                'show_in_index'       => true
            ]);
        });
    }

    // New processing function from while the code is retrieved from google search console
    public function linkilo_rest_code_process_handle( WP_REST_Request $request )
    {
        $req_params = $request->get_params();

        if (
            isset($req_params['code']) && 
            !empty($req_params['code'])
        ) {
            // assign code to variable
            $gsc_app_code = $req_params['code'];

            // process the code to retrieve access token from google
            $response = Linkilo_Build_GscAppConsole::linkilo_app_console_retrieve_access_token(trim($gsc_app_code));


            // access token and refresh token are available in response
            if (!is_null($response)) {
                update_option( 'linkilo_app_console_authorized', true );
                update_option( 'linkilo_app_console_tokens_data', $response );

                if (isset($response['access_token']) && !empty($response['access_token'])) {
                    update_option( 'linkilo_app_console_access_token', trim($response['access_token']) );
                }

                if (isset($response['refresh_token']) && !empty($response['refresh_token'])) {
                    update_option( 'linkilo_app_console_refresh_token', trim($response['refresh_token']) );
                }

                if (isset($response['expires_in']) && !empty($response['expires_in'])) {
                    update_option( 'linkilo_app_console_token_expires_in', $response['expires_in'] );

                    $token_expire_time = time() + $response['expires_in'];
                    update_option( 'linkilo_app_console_token_expires_at', $token_expire_time );
                }

                $transient_message = 'Linkilo plugin is now authenticated for retrieving sites.';

                set_transient('linkilo_app_console_notice', $transient_message, MINUTE_IN_SECONDS*30);

                $rest_response = ['status' => 1];
                return new WP_REST_Response( $rest_response, 200 );
            }else{
                update_option('linkilo_app_console_authorized', false);

                $transient_message = 'Linkilo can not retrieve token details from google. Please try to re-authenticate';

                set_transient('linkilo_app_console_notice', $transient_message, MINUTE_IN_SECONDS*30);

                $rest_response = ['status' => 0];
                return new WP_REST_Response( $rest_response, 200 );
            }
        }else{
            $rest_response = ['status' => 2];
            return new WP_REST_Response( $rest_response, 200 );
        }
        return new WP_Error(400, 'Bad request', [ 'status' => 404 ]);
    }
}
