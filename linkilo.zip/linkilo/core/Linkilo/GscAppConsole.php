<?php

/**
 * Class for getting and formatting data from Google Search Console
 *
 * Class Linkilo_Build_GscAppConsole
 */
class Linkilo_Build_GscAppConsole
{
    private $token_data = [];
    function __construct()
    {

        $this->token_data = get_option('linkilo_app_console_tokens_data', []);

        // notice display action
        add_action('admin_notices', [$this, 'linkilo_app_console_notices']);

        // ajax call handler for deactivation
        add_action('wp_ajax_linkilo_app_console_deactivate', [$this, 'linkilo_app_console_deactivate_handle']);

        // ajax call handler for fetching sites
        add_action('wp_ajax_linkilo_app_console_fetch_sites', [$this, 'linkilo_app_console_fetch_sites_handle']);

        // Token refresh call
        add_action('wp_ajax_linkilo_app_console_refresh_token', [$this, 'linkilo_app_console_refresh_token_handle']);

        global $wpdb;
        $linkilo_search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

        $table = $wpdb->get_var("SHOW TABLES LIKE '{$linkilo_search_console_table}'");
        if ($table != $linkilo_search_console_table) {
            $this->linkilo_app_console_setup_database_table();
        }

        // Check if the token is expired when authorized is true
        if ($this->linkilo_app_console_check_authorized()) {
            $this->linkilo_app_console_check_token_expired();
        }

        if (
            isset($_GET['page']) && $_GET['page'] === 'linkilo_settings' &&
            isset($_GET['code']) && !empty($_GET['code'])
        ) {
            $code = $_GET['code'];
            $this->linkilo_app_console_set_process_status($code);
        }
    }

    public function linkilo_app_console_refresh_token_handle()
    {
        $response = [];
        if (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'linkilo-app-console-refresh-auth-token')) {
            self::linkilo_app_console_refresh_auth_token();
        } else {
            $response = ['status' => 0, 'message' => 'Invalid Request.'];
        }
        wp_send_json($response);
        wp_die();
    }
    public static function linkilo_app_console_set_process_status($code = null)
    {
        if (!is_null($code) && !empty($code)) {
            $status = base64_decode($code);
            switch (trim($status)) {
                case 'linkilo-auth-cancelled':
                    $transient_message = 'Auth process cancelled.';
                    break;
                case 'linkilo-auth-failed':
                    $transient_message = 'Auth process failed.';
                    break;
                default:
                    $transient_message = 'Process failed.';
                    break;
            }
            set_transient('linkilo_app_console_notice', $transient_message, MINUTE_IN_SECONDS * 30);
        }
    }

    /**
     * Return authorized status, true is authorized, false not authorized
     * */
    public static function linkilo_app_console_check_authorized()
    {
        $is_linkilo_authorized = get_option('linkilo_app_console_authorized', false);
        $token_data = get_option('linkilo_app_console_tokens_data', []);
        $access_token = get_option('linkilo_app_console_access_token', false);
        $refresh_token = get_option('linkilo_app_console_refresh_token', false);

        // option is available and true
        if (
            !empty($is_linkilo_authorized) &&
            $is_linkilo_authorized &&
            !empty($access_token) &&
            $access_token &&
            !empty($refresh_token) &&
            $refresh_token &&
            sizeof($token_data) > 0 &&
            isset($token_data['access_token']) &&
            !empty($token_data['access_token'])
        ) {
            return true;
        }

        // option is available and false/ option not availble
        return false;
    }

    /**
     * Token expiration time check, refresh token when expired 
     * */
    public static function linkilo_app_console_check_token_expired()
    {
        $token_expires_at = get_option('linkilo_app_console_token_expires_at', false);
        if (
            (false !== $token_expires_at &&
                time() > intval($token_expires_at) || ($token_expires_at == false))
        ) {
            // rather refreshing every time, update from settings->custom settings->refresh token (button)
            self::linkilo_app_console_refresh_auth_token();
        } else {
            return true;
        }
    }

    /**
     * Retrieve new access token from google api while having an old refresh token
     * */
    public static function linkilo_app_console_refresh_auth_token()
    {
        $config = self::linkilo_app_console_configurations();

        $url = "https://www.googleapis.com/oauth2/v4/token";
        $method = "POST";
        $refresh_token = get_option('linkilo_app_console_refresh_token', false);

        if (false !== $refresh_token && !empty($refresh_token)) {
            $args = [
                'client_id' => $config['client_id'],
                'client_secret' => $config['client_secret'],
                'grant_type' => 'refresh_token',
                'refresh_token' => $refresh_token,
            ];
            $retrieved_refresh_token = self::linkilo_app_console_api_call($method, $url, $args, 15);

            if (!is_null($retrieved_refresh_token)) {
                if (isset($retrieved_refresh_token['access_token']) && !empty($retrieved_refresh_token['access_token'])) {
                    $token_data = get_option('linkilo_app_console_tokens_data', []);

                    if (sizeof($token_data) > 0) {
                        $token_data['access_token'] = trim($retrieved_refresh_token['access_token']);
                        update_option('linkilo_app_console_tokens_data', $token_data);
                    }
                    update_option('linkilo_app_console_access_token', trim($retrieved_refresh_token['access_token']));
                }

                if (isset($retrieved_refresh_token['expires_in']) && !empty($retrieved_refresh_token['expires_in'])) {
                    update_option('linkilo_app_console_token_expires_in', $retrieved_refresh_token['expires_in']);

                    $token_expire_time = time() + $retrieved_refresh_token['expires_in'];
                    update_option('linkilo_app_console_token_expires_at', $token_expire_time);
                }

                $transient_message = 'Token refresh complete.';

                set_transient('linkilo_app_console_token_notice', $transient_message, MINUTE_IN_SECONDS * 30);
            } else {
                $transient_message = 'Token expired and could not retrieve refresh token. Please try to Reauthenticate the app.';
                set_transient('linkilo_app_console_token_notice', $transient_message, MINUTE_IN_SECONDS * 30);
            }
        } else {
            $transient_message = 'Token expired and refresh token not availale. Please Reauthenticate the app.';
            set_transient('linkilo_app_console_token_notice', $transient_message, MINUTE_IN_SECONDS * 30);
        }
    }

    /**
     * Populate an table for storing google seach console keywords for the selected website
     * */
    public static function linkilo_app_console_setup_database_table()
    {
        global $wpdb;
        $linkilo_search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

        $table = $wpdb->get_var("SHOW TABLES LIKE '{$linkilo_search_console_table}'");

        if ($table != $linkilo_search_console_table) {
            $linkilo_search_console_table_query = "CREATE TABLE IF NOT EXISTS {$linkilo_search_console_table} (
                gsc_index bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                page_url text,
                keywords text,
                clicks bigint(20) unsigned NOT NULL,
                impressions bigint(20) unsigned NOT NULL,
                ctr float,
                position float,
                scan_date_start datetime,
                scan_date_end datetime,
                page_url_clean text,
                processed tinyint(1) DEFAULT 0,
                PRIMARY KEY (gsc_index),
                INDEX (page_url(255)),
                INDEX (keywords(255))
            ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";
            // create DB table if it doesn't exist
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($linkilo_search_console_table_query);

            if (strpos($wpdb->last_error, 'Index column size too large') !== false) {
                $linkilo_search_console_table_query = str_replace(array('page_url(255)', 'keywords(255)'), array('page_url(191)', 'keywords(191)'), $linkilo_search_console_table_query);
                dbDelta($linkilo_search_console_table_query);
            }
        }

        // Commented this to keep old data to show comparison
        // $wpdb->query("TRUNCATE TABLE {$linkilo_search_console_table}");
    }

    /**
     * Fetch site list from google search console via api 
     * */
    public function linkilo_app_console_fetch_sites_handle()
    {
        $response = [];
        if (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'linkilo-app-console-fetch-sites')) {
            if (
                sizeof($this->token_data) > 0 &&
                isset($this->token_data['access_token']) &&
                !empty($this->token_data['access_token'])
            ) {
                $profiles = array();
                $url = "https://www.googleapis.com/webmasters/v3/sites";
                $method = "GET";
                $args = [];
                $access_token = $this->token_data['access_token'];
                $fetched_sites = self::linkilo_app_console_api_call($method, $url, $args, 15, $access_token);

                if (!is_null($fetched_sites)) {
                    $loop_selected_site = false;
                    $current_site_host = parse_url(get_home_url(), PHP_URL_HOST);
                    foreach ($fetched_sites['siteEntry'] as $fetched_site) {
                        $option_lable = trim($fetched_site['siteUrl']);
                        $list_site = str_replace('sc-domain:', '', $fetched_site['siteUrl']);

                        $fetched_site_host = parse_url($list_site, PHP_URL_HOST);

                        if ($current_site_host === $fetched_site_host) {
                            $hosts[$list_site] = ['site_url' => $list_site, 'site_host' => $fetched_site_host];

                            update_option('linkilo_app_console_matching_hosts', $hosts);
                        }

                        // set the selected site option if the fetched sites list contains current site url
                        if (trailingslashit($list_site) ===  trailingslashit(get_site_url())) {
                            update_option('linkilo_app_console_selected', true);
                            update_option('linkilo_app_console_selected_site', $list_site);

                            $loop_selected_site = true;
                        }

                        $profiles[] = [
                            'option_lable' => $option_lable,
                            'option_value' => $option_lable
                        ];
                    }
                    update_option('linkilo_app_console_fetched_sites_data', $profiles);
                    if ($loop_selected_site) {
                        $transient_message = 'Sites has been selected.';
                        set_transient('linkilo_app_console_site_selection_notice', $transient_message, MINUTE_IN_SECONDS * 30);
                    } else {
                        $transient_message = 'Please select a site from the list.';
                        set_transient('linkilo_app_console_site_selection_notice', $transient_message, MINUTE_IN_SECONDS * 30);
                    }
                    $transient_message = 'Linkilo sites have been fetched.';

                    set_transient('linkilo_app_console_notice', $transient_message, MINUTE_IN_SECONDS * 30);
                    $response = ['status' => 1, 'message' => 'Sites fetched successfully.'];
                } else {
                    $response = ['status' => 0, 'message' => 'Failed to retrieve sites.'];
                }
            } else {
                $response = ['status' => 0, 'message' => 'Access token not available.'];
            }
        } else {
            $response = ['status' => 0, 'message' => 'Invalid Request.'];
        }
        wp_send_json($response);
        wp_die();
    }

    /**
     * Deactivate GSC action handle, remove all the options
     **/
    public static function linkilo_app_console_deactivate_handle()
    {
        if (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'linkilo-app-console-disconnect')) {

            self::linkilo_app_console_revoke_token();

            delete_option('linkilo_app_console_authorized');
            delete_option('linkilo_app_console_tokens_data');
            delete_option('linkilo_app_console_matching_hosts');
            delete_option('linkilo_app_console_selected');
            delete_option('linkilo_app_console_selected_site');
            delete_option('linkilo_app_console_fetched_sites_data');
            delete_option('linkilo_app_console_access_token');
            delete_option('linkilo_app_console_refresh_token');
            delete_option('linkilo_app_console_token_expires_in');
            delete_option('linkilo_app_console_token_expires_at');

            global $wpdb;
            $linkilo_search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

            $wpdb->query("TRUNCATE TABLE $linkilo_search_console_table");

            wp_send_json(true);
            wp_die();
        }
    }
    public static function linkilo_app_console_revoke_token()
    {
        if (self::linkilo_app_console_check_authorized()) {
            $access_token = get_option('linkilo_app_console_access_token', false);
            $refresh_token = get_option('linkilo_app_console_refresh_token', false);

            $token = null;

            if (!empty($access_token) && $access_token) {
                $token = $access_token;
            } elseif (!empty($refresh_token) && $refresh_token) {
                $token = $refresh_token;
            } else {
                $transient_message = 'Can not process revoke request. Token doesn\'t exist.';
                set_transient('linkilo_app_console_revoke_token_notice', $transient_message, MINUTE_IN_SECONDS * 30);
            }

            if (!is_null($token)) {
                $params = array(
                    'timeout' => 60,
                    'method'  => 'POST',
                );
                $params['headers']['Content-Type'] = 'application/x-www-form-urlencoded';

                $req_url = add_query_arg(array('token' => $token), "https://oauth2.googleapis.com/revoke");

                $response = wp_remote_request($req_url, $params);
                $response_body = json_decode(wp_remote_retrieve_body($response), true);
                $response_code = wp_remote_retrieve_response_code($response);

                if ($response_code === 200) {
                    $transient_message = 'Application revoke complete.';
                    set_transient('linkilo_app_console_revoke_token_notice', $transient_message, MINUTE_IN_SECONDS * 30);
                } elseif (is_wp_error($response)) {
                    $transient_message = 'Processed revoke request responded failure.';
                    set_transient('linkilo_app_console_revoke_token_notice', $transient_message, MINUTE_IN_SECONDS * 30);
                }
            }
        }
    }

    /*Show Notices*/
    public function linkilo_app_console_notices()
    {
        $notice_message = get_transient('linkilo_app_console_notice');
        if (false !== $notice_message) {
            self::linkilo_app_console_notice_html($notice_message, 'linkilo_app_console_notice');
        }

        $site_select_notice = get_transient('linkilo_app_console_site_selection_notice');
        if (false != $site_select_notice) {
            self::linkilo_app_console_notice_html($site_select_notice, 'linkilo_app_console_site_selection_notice');
        }

        $token_notice = get_transient('linkilo_app_console_token_notice');
        if (false != $token_notice) {
            self::linkilo_app_console_notice_html($token_notice, 'linkilo_app_console_token_notice');
        }

        $site_data_retreive_notice = get_transient('linkilo_app_console_site_data_retreive_notice');
        if (false != $site_data_retreive_notice) {
            self::linkilo_app_console_notice_html($site_data_retreive_notice, 'linkilo_app_console_site_data_retreive_notice');
        }

        $site_data_null_notice = get_transient('linkilo_app_console_site_data_null_notice');
        if (false != $site_data_null_notice) {
            self::linkilo_app_console_notice_html($site_data_null_notice, 'linkilo_app_console_site_data_null_notice');
        }

        $site_data_fail_notice = get_transient('linkilo_app_console_site_data_fail_notice');
        if (false != $site_data_fail_notice) {
            self::linkilo_app_console_notice_html($site_data_fail_notice, 'linkilo_app_console_site_data_fail_notice');
        }

        $site_data_insert_notice = get_transient('linkilo_app_console_site_data_insert_notice');
        if (false != $site_data_insert_notice) {
            self::linkilo_app_console_notice_html($site_data_insert_notice, 'linkilo_app_console_site_data_insert_notice');
        }

        $revoke_token_notice = get_transient('linkilo_app_console_revoke_token_notice');
        if (false != $revoke_token_notice) {
            self::linkilo_app_console_notice_html($revoke_token_notice, 'linkilo_app_console_revoke_token_notice');
        }

        $settings_save_notice = get_transient('linkilo_settings_save_notice');
        if (false != $settings_save_notice) {
            self::linkilo_app_console_notice_html($settings_save_notice, 'linkilo_settings_save_notice');
        }
    }

    /**
     * Notice display html
     * */
    public static function linkilo_app_console_notice_html($transient_message, $key)
    {
        $html = '<div class="notice notice-info is-dismissible">';
        $html .= '<p>';
        $html .= $transient_message;
        $html .= '</p>';
        $html .= '</div>';
        echo $html;
        delete_transient($key);
    }

    /**
     * Generate redirect url from the configuration
     * */
    public static function linkilo_app_console_user_auth_url($wizard = false)
    {
        // $auth_uri = 'https://accounts.google.com/o/oauth2/v2/auth';
        // $client_id = '773811380543-nuoekm1u45p8fi73og57mbeo4odd70v8.apps.googleusercontent.com';
        // $client_secret = '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';
        // $redirect_uri = 'http://www.localservertwo.com/wp-json/linkilo-auth/authorize';
        // $redirect_uri = 'http://www.localservertwo.com/';
        // $scopes = ['openid', 'https://www.googleapis.com/auth/webmasters.readonly'];
        // $state = base64_encode('google-check-openid');
        // $response_type = 'code';

        // $authenication_url = add_query_arg(
        //     [
        //         'response_type' => $response_type,
        //         'client_id'     => $client_id,
        //         'scope'         => implode(' ', $scopes),
        //         'redirect_uri'  => $redirect_uri,
        //         'state'         => $state,
        //         'nonce'         => $nonce,
        //         'prompt'        => 'consent',
        //         'access_type'   => 'offline',
        //     ], 
        //     $auth_uri
        // );
        // return $authenication_url;

        $config = self::linkilo_app_console_configurations($wizard);

        $nonce = wp_create_nonce('linkilo-app-console-auth-process');
        $auth_api_url = 'https://accounts.google.com/o/oauth2/v2/auth';
        // $auth_api_url = 'https://accounts.google.com/o/oauth2/auth';

        $url = add_query_arg([
            'response_type' => 'code',
            'client_id'     => $config['client_id'],
            'redirect_uri'  => $config['redirect_uri'],
            'scope'         => implode(' ', $config['scopes']),
            'state'         => $config['state'],
            'access_type'   => $config['access_type'],
            'nonce'         => $nonce,
            'prompt'        => 'consent',
        ], $auth_api_url);

        return esc_url_raw($url);
    }

    /**
     * Application configuration for google search console
     * */
    public static function linkilo_app_console_configurations($wizard = false)
    {

        $state = base64_encode(
            json_encode(
                array(
                    // 'url' => get_rest_url(), # current site `wp-json` path
                    'url' => trailingslashit(get_site_url()) . "wp-json/", # current site `wp-json` path
                    'redirect' => admin_url('admin.php'), # current site `wp-admin/admin.php` path
                    'wizard' => $wizard,

                ),
            )
        );

        #Linkilo Main Site
        $redirect_uri = LINKILO_SHOP_URL . '/wp-json/linkilo-auth/authorize';
        $client_id = '980634990097-65pgu6i9kak1r7hrf333kenne21bshqm.apps.googleusercontent.com';
        $client_secret = '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';
        $scopes = ['openid', 'https://www.googleapis.com/auth/webmasters.readonly'];
        $access_type = 'offline';

        // $redirect_uri = 'http://www.localservertwo.com/wp-json/linkilo-auth/authorize';
        // $client_id = '773811380543-nuoekm1u45p8fi73og57mbeo4odd70v8.apps.googleusercontent.com'; 
        // $client_secret = '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';

        $config = [
            'application_name' => 'Linkilo',
            'redirect_uri'     => $redirect_uri,
            'scopes'           => $scopes,
            'access_type'      => $access_type,
            'state'            => $state,
            'client_id'         => $client_id,
            'client_secret'     => $client_secret,
        ];

        return $config;
    }

    /**
     * After retrieving code from the authentication process, call to google api for access token
     * 
     * @param gsc_app_code
     * 
     * @return response from api call
     * */
    public static function linkilo_app_console_retrieve_access_token($gsc_app_code = null)
    {
        if (!is_null($gsc_app_code) && !empty($gsc_app_code)) {

            // configuration
            $config = self::linkilo_app_console_configurations();

            // google api url
            $url = 'https://oauth2.googleapis.com/token';

            // format the array of arguments
            $args = array(
                'client_id'         => $config['client_id'],
                'client_secret' => $config['client_secret'],
                'code' => $gsc_app_code,
                'grant_type' => 'authorization_code',
                'redirect_uri'  => $config['redirect_uri'],
                'state'  => $config['state'],
            );

            $method = "POST";

            $token_call = self::linkilo_app_console_api_call($method, $url, $args, 15, '');

            return $token_call;
        }
    }

    /**
     * Common http api request function
     * @param 
     * */
    private static function linkilo_app_console_api_call($http_method, $req_url, $body_args = [], $req_timeout = 20, $access_token = "")
    {

        $params = array(
            'timeout' => $req_timeout,
            'method'  => $http_method,
        );

        if (!empty($access_token)) {
            $params['headers'] = array('Authorization' => 'Bearer ' . $access_token);
        }

        if ('DELETE' === $http_method || 'PUT' === $http_method) {
            $params['headers']['Content-Length'] = '0';
        } elseif ('POST' === $http_method && !empty($body_args) && is_array($body_args)) {
            if (sizeof($body_args) > 0) {
                $params['body'] = wp_json_encode($body_args);
            }
            $params['headers']['Content-Type'] = 'application/json';
        }

        $response = wp_remote_request($req_url, $params);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        $response_code = wp_remote_retrieve_response_code($response);

        if ($response_code === 200) {
            return $response_body;
        } elseif (is_wp_error($response)) {
            return null;
        } else {
            return null;
        }
    }

    /**
     * Make request to get the selected sites keywords data
     * */
    public static function linkilo_app_console_retireve_site_data($start_date, $end_date, $dimension, $limit = 5000, $start_row = 0)
    {
        if (is_string($dimension) && !empty($dimension)) {
            $dimension = array($dimension);
        } elseif (!is_array($dimension) || empty($dimension)) {
            return false;
        }

        $selected_site = null;
        if (false !== get_option('linkilo_app_console_selected_site', false)) {
            $selected_site = get_option('linkilo_app_console_selected_site');
        }

        if (!is_null($selected_site) && self::linkilo_app_console_check_authorized()) {
            $url = 'https://www.googleapis.com/webmasters/v3/sites/' . urlencode($selected_site) . '/searchAnalytics/query';
            $args = array(
                'startDate'     => $start_date,
                'endDate'       => $end_date,
                'rowLimit'      => $limit,
                'dimensions'    => $dimension,
                'startRow'      => ($start_row * $limit),
                'searchType'    => 'web'
            );
            $method = "POST";

            $access_token = get_option('linkilo_app_console_access_token', false);

            $retrieved_site_data = self::linkilo_app_console_api_call($method, $url, $args, 15, $access_token);

            $rows = false;
            if (
                !is_null($retrieved_site_data) &&
                isset($retrieved_site_data['rows']) &&
                !is_null($retrieved_site_data['rows'])
            ) {
                $transient_message = 'Selected site data retrieved from console api.';
                set_transient('linkilo_app_console_site_data_retreive_notice', $transient_message, MINUTE_IN_SECONDS * 30);
                foreach ($retrieved_site_data['rows'] as &$row) {
                    $row['ctr']      = round($row['ctr'] * 100, 2);
                    $row['position'] = round($row['position'], 2);
                }
                $rows = $retrieved_site_data['rows'];
            } else {
                $transient_message = 'Data queried but no response from console api.';
                set_transient('linkilo_app_console_site_data_null_notice', $transient_message, MINUTE_IN_SECONDS * 30);
            }
            return $rows ? $rows : [];
        } else {
            $transient_message = 'Cannot retrieve selected sites console data.';
            set_transient('linkilo_app_console_site_data_fail_notice', $transient_message, MINUTE_IN_SECONDS * 30);
            return [];
        }
    }

    /**
     * Insert the rerieved data into search console table
     * */
    public static function linkilo_app_console_insert_site_data($rows = array(), $scan_range = array())
    {
        global $wpdb;
        $linkilo_search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

        if (empty($rows)) {
            return false;
        }

        // sort row array in Decending Order
        if (!function_exists('sortByimpressions')) {
            function sortByimpressions($a, $b)
            {
                $a = $a['impressions'];
                $b = $b['impressions'];

                if ($a == $b) return 0;
                return ($a < $b) ? 1 : -1;
            }
            usort($rows, 'sortByimpressions');
        }

        // set up default dates.
        // GSC data is only available when it's around 3 days old.
        // So for a 30 day range, we want to offset the range by 3 days.
        $start_date = date_i18n('Y-m-d', time() - (DAY_IN_SECONDS * 33));
        $end_date   = date_i18n('Y-m-d', time() - (DAY_IN_SECONDS * 3));

        if (isset($scan_range['start_date']) && !empty($scan_range['start_date'])) {
            $start_date = $scan_range['start_date'];
        }

        if (isset($scan_range['end_date']) && !empty($scan_range['end_date'])) {
            $end_date = $scan_range['end_date'];
        }

        // set Limit on Keywords
        $temp_arr = array();
        $distinct_rows = array();
        $distinct_insert_limit =  get_option('linkilo_google_search_console_limit', 10);

        if (sizeof($rows) > 0) {
            foreach ($rows as $k => $v) {
                $key_name = $v['keys'][0];
                if (empty($temp_arr[$key_name])) {
                    $temp_arr[$key_name] = 1;
                } else {
                    $temp_arr[$key_name] = $temp_arr[$key_name] + 1;
                }

                if ($temp_arr[$key_name] <= $distinct_insert_limit) {
                    array_push($distinct_rows, $v);
                }
            }
        }

        $insert_query = "INSERT INTO {$linkilo_search_console_table} (page_url, keywords, clicks, impressions, ctr, position, scan_date_start, scan_date_end, page_url_clean) VALUES ";
        $initial_query = "INSERT INTO {$linkilo_search_console_table} (page_url, keywords, clicks, impressions, ctr, position, scan_date_start, scan_date_end, page_url_clean) VALUES ";

        $insert_data = array();
        $place_holders = array();
        $insert_limit = 800;
        $count = 0;
        $total_rows = count($rows);
        $errors = '';
        $insert_count = 0;
        $inserted_list = array();
        /*foreach($rows as $key => $row){*/
        foreach ($distinct_rows as $key => $row) {
            if (
                !isset($row['keys']) ||
                !isset($row['keys'][0]) ||
                !isset($row['keys'][1])
            ) {

                continue;
            }

            // note the current keyword data so we can aviod duplicates
            $item_id = $row['keys'][1] . $row['keys'][0];
            if (isset($inserted_list[$item_id])) {
                // if the keyword has been saved already, skipp to the next item
                continue;
            } else {
                // if the keyword hasn't been saved yet, note it in the keyword list
                $inserted_list[$item_id] = true;
            }

            $url_to_clean = $row['keys'][1];
            $scheme = parse_url($url_to_clean, PHP_URL_SCHEME);
            $host = parse_url($url_to_clean, PHP_URL_HOST);
            $path = parse_url($url_to_clean, PHP_URL_PATH);

            $page_url_clean =  $scheme . "://" . $host . $path;

            array_push(
                $insert_data,
                esc_url_raw($row['keys'][1]),
                $row['keys'][0],
                $row['clicks'],
                $row['impressions'],
                $row['ctr'],
                $row['position'],
                $start_date,
                $end_date,
                trailingslashit($page_url_clean),
            );



            $place_holders[] = "('%s', '%s', '%d', '%d', '%f', '%f', '%s', '%s', '%s')";


            if (($insert_limit === $count) || ($key + 1) <= $total_rows) {

                $insert_query .= implode(', ', $place_holders);
                $insert_query = $wpdb->prepare($insert_query, $insert_data);
                $inserted = $wpdb->query($insert_query);

                // reset the query data
                $insert_query = $initial_query;
                $place_holders = array();
                $insert_data = array();
                $count = 0;
                if (!empty($wpdb->last_error)) {
                    $errors .= $wpdb->last_error . '<br />';
                } elseif (!empty($inserted)) {
                    $insert_count += $inserted;
                }
            }
            $count++;
        }

        $transient_message = 'Site data insert in progress. Total rows : ' . $total_rows . ', Inserted : ' . $insert_count;
        set_transient('linkilo_app_console_site_data_insert_notice', $transient_message, MINUTE_IN_SECONDS * 30);
        return array('inserted' => $insert_count, 'errors' => $errors);
    }

    /**
     * Obtains all of the unique page urls from the search console table that haven't been processed yet.
     * 
     * @return array $urls Array of unique urls
     **/
    public static function linkilo_app_console_unprocessed_unique_urls()
    {
        global $wpdb;
        $search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

        $urls = $wpdb->get_results("SELECT DISTINCT(`page_url`) FROM {$search_console_table} WHERE `processed` = 0");


        if (!empty($urls)) {
            return $urls;
        } else {
            return array();
        }
    }

    /**
     * Obtains all rows that contain the given url
     **/
    public static function linkilo_app_console_rows_by_url($url = '')
    {
        global $wpdb;
        $search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

        if (empty($url)) {
            return false;
        }

        $data = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$search_console_table} WHERE `page_url` = %s", $url));

        if (!empty($data)) {
            return $data;
        } else {
            return array();
        }
    }

    /**
     * Mark all the rows that have the given url as processed.
     * 
     * @param string $url 
     * 
     * @return bool True on success, False on error
     **/
    public static function linkilo_app_console_mark_row_processed_by_url($url = '')
    {
        global $wpdb;
        $search_console_table = $wpdb->prefix . 'linkilo_search_console_data';

        if (empty($url)) {
            return false;
        }

        $updated = $wpdb->update($search_console_table, array('processed' => 1), array('page_url' => esc_url_raw($url)), array('%d'));

        if (false !== $updated) {
            return true;
        } else {
            return false;
        }
    }
}
