<?php

/**
 * Work with licenses
 */
class Linkilo_Build_ActiveLicense {
    /**
     * Register services
     */
    public function register() {
        add_action('wp_ajax_linkilo_activate_user_license', array(__CLASS__, 'ajax_linkilo_activate_user_license'));
    }

    public static function init() {
        if (!empty($_GET['linkilo_deactivate']))
        {
            update_option(LINKILO_STATUS_OF_LICENSE_OPTION, 'invalid');
            update_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, $message='Deactivated manually');
        }

        include LINKILO_PLUGIN_DIR_PATH . '/templates/linkilo_license.php';
    }

    /**
     * Check if license is valid
     *
     * @return bool
     */
    public static function isValid() {
        if (get_option('linkilo_2_license_status') == 'valid') {
            $prev = get_option('linkilo_2_license_check_time');
            $delta = $prev ? time() - strtotime($prev) : 0;

            if (!$prev || $delta > (60*60*24*3) || !empty($_GET['linkilo_check_license'])) {
                $license = self::getKey();
                self::check($license, $silent = true);
            }

            $status = get_option('linkilo_2_license_status');

            if ($status !== false && $status == 'valid') {
                return true;
            }
        }

        return false;
    }

    /**
     * Get license key
     *
     * @param bool $key
     * @return bool|mixed|void
     */
    public static function getKey($key = false) {
        if (empty($key)) {
            $key = get_option('linkilo_2_license_key');
        }

        if (stristr($key, '-')) {
            $ks = explode('-', $key);
            $key = $ks[1];
        }

        return $key;
    }

    /**
     * Check new license
     *
     * @param $license_key
     * @param bool $silent
     */
    public static function check($license_key, $silent = true) {

        $base_url_path = 'admin.php?page=linkilo_license';
        $item_id = self::getItemId($license_key);
        $license = Linkilo_Build_ActiveLicense::getKey($license_key);
        $code = null;
        if (!empty($item_id) && !empty($license)) {
            // data to send in our API request
            $api_params = array(
                'edd_action' => 'activate_license',
                'license'    => $license,
                'item_id'  => $item_id,
                'url'        => urlencode(home_url())
            );

            $response = wp_remote_post( LINKILO_SHOP_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );
            $code = wp_remote_retrieve_response_code( $response );

            update_option(LINKILO_LICENSE_CHECK_TIME_OPTION, date('c'));

            if ( is_wp_error( $response ) || $code !== 200 ) {
                // error in api call
                if ( is_wp_error( $response ) ) {
                    $message = $response->get_error_message();
                } else {
                    $message = __("$code response code on activation, please try again or check code");
                }
            }else{
                // call sucess response check
                $license_data = json_decode( wp_remote_retrieve_body( $response ) );

                if (!is_null($license_data) && $license_data->success === false) {
                    $message = self::getMessage($license, $license_data);
                }else{
                    // Do when valid
                    if (!is_null($license_data) && $license_data->success && isset($license_data->license) && "valid" === $license_data->license) {

                        // license is valid and make necessary changes now
                        update_option(LINKILO_STATUS_OF_LICENSE_OPTION, $license_data->license);
                        update_option(LINKILO_LICENSE_KEY_OPTION, $license);
                        
                        /*license is valid now update the date when activation is done i.e current date*/
                        $current_date = date('d-m-Y');
                        update_option('linkilo_2_license_activation', $current_date);

                        /*Increase date by a day and store for next timem,so we will check if license is activated valid or not and update status accordingly*/
                        $current_date_to_time = strtotime("1 day", strtotime($current_date));
                        $new_date = date("d-m-Y", $current_date_to_time);
                        update_option('linkilo_2_license_next_check', $new_date);

                        if (!$silent) {
                            // $base_url = admin_url('admin.php?page=linkilo_settings&licensing');
                            $base_url = admin_url('admin.php?page=linkilo&wizard=true');
                            $message = __("License key `%s` was activated", 'linkilo');
                            $message = sprintf($message, $license);
                            $redirect = add_query_arg(array('sl_activation' => 'true', 'message' => urlencode($message)), $base_url);
                            wp_redirect($redirect);
                            exit;
                        } else {
                            return;
                        }
                    }else{
                        return;
                    }
                }
            }

            update_option(LINKILO_STATUS_OF_LICENSE_OPTION, 'invalid');
            update_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, $message);
            /*Upon activation license is not valid store error state*/
            update_option('linkilo_license_error_state', 'state_1');

            if (!$silent) {
                $base_url = admin_url($base_url_path);
                $redirect = add_query_arg(array('sl_activation' => 'false', 'msg' => urlencode($message)), $base_url);
                wp_redirect($redirect);
                exit;
            }
        }else{
            return;
        }
    }

    /**
     * Check if a given site is licensed in the same plan as this site.
     *
     * @param string $site_url The url of the site we want to check.
     * @return bool
     */
    public static function check_site_license($site_url = '', $silent = false) {
        if(empty($site_url)){
            return false;
        }

        // if the site has been recently checked and does have a valid license
        if(self::check_cached_site_licenses($site_url)){
            // return true
            return true;
        }

        $license_key = self::getKey();
        $item_id = self::getItemId($license_key);
        $license = Linkilo_Build_ActiveLicense::getKey($license_key);
        $code = null;

        $api_params = array(
            'edd_action' => 'check_license',
            'license' => $license,
            'item_id'             => $item_id,
            'url' => urlencode($site_url),
        );

        // Call the custom API.
        $response = wp_remote_post( LINKILO_SHOP_URL, array( 'timeout' => 15, 'sslverify' => false, 'body' => $api_params ) );

        $code = wp_remote_retrieve_response_code( $response );

        if ( is_wp_error( $response ) || $code !== 200) {
            return false;
        }else{

            $license_data = json_decode( wp_remote_retrieve_body( $response ) );

            /*Update license status as expired*/
            if(isset($license_data->license) && 'valid' != $license_data->license) {
                update_option(LINKILO_LICENSE_KEY_OPTION, $license);
                update_option(LINKILO_STATUS_OF_LICENSE_OPTION, $license_data->license);
                if ($license_data->license === 'invalid_item_id') {
                    // custom message
                    $message = "Linkilo license is invalid. Please Enter license again or check your subscription on your linkilo.co account.";
                    update_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, $message);
                }else{
                    if (isset($license_data->error)) {
                        // default error message
                        $message = self::getMessage($license, $license_data);
                        update_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, $message);
                    }else{
                        $message = "Linkilo license is invalid. Please Enter license again or check your subscription on your linkilo.co account.";
                        update_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION, $message);
                    }
                }

                if ($silent) {
                    return true;
                } else {
                    return false;
                }
            }else{
                /*Increase date by a day and store for next time,so we will check if license is activated valid or not and update status accordingly*/
                // license if valid until now update next check
                $current_date = date('d-m-Y');
                $next_time = strtotime("1 day", strtotime($current_date));
                $next_date = date("d-m-Y", $next_time);
                update_option('linkilo_2_license_next_check', $next_date);
                return false;
            }
        }
        return false;
    }

    /**
     * Checks a site url against the cached list of known licensed urls.
     * Returns if the site is licensed and has been checked recently
     * 
     * @param string $site_url
     * @return bool
     **/
    public static function check_cached_site_licenses($site_url = ''){
        $site_urls = get_option('linkilo_cached_valid_sites', array());

        if(empty($site_urls) || empty($site_url)) {
            return false;
        }

        $time = time();
        foreach($site_urls as $url_data){
            if($site_url === $url_data['site_url'] && $time < $url_data['expiration']){
                return true;
            }
        }

        return false;
    }

    /**
     * Updates the cached site list with news of licensed sites.
     * 
     **/
    public static function update_cached_site_list($site_url = '') {
        if(empty($site_url)){
            return false;
        }

        $site_cache = get_option('linkilo_cached_valid_sites', array());

        foreach($site_cache as $key => $site_data){
            if($site_data['site_url'] === $site_url){
                unset($site_cache[$key]);
            }
        }

        $site_cache[] = array('site_url' => $site_url, 'expiration' => (time() + (60*60*24*3)) );

        update_option('linkilo_cached_valid_sites', $site_cache);
    }

    /**
     * Get current license ID
     *
     * @param string $license_key
     * @return false|string
     */
    public static function getItemId($license_key = '') {
        if ($license_key && stristr($license_key, '-')) {
            $ks = explode('-', $license_key);
            return $ks[0];
        }

        $item_id = file_get_contents(dirname(__DIR__) . '/../product.txt');

        return $item_id;
    }

    /**
     * Get license message
     *
     * @param $license
     * @param $license_data
     * @return string
     */
    public static function getMessage($license, $license_data) {
        if (isset($license_data->error)) {
            switch ($license_data->error) {
                case 'expired' :
                    $d = date_i18n(get_option('date_format'), strtotime($license_data->expires, current_time('timestamp')));
                    $message = sprintf("Your license key <span class=\"linkilo-license-key-wrap\">%s</span> expired on %s. Please renew your subscription to continue using Linkilo.", $license, $d);
                    $linkilo_pricing_url = esc_url("https://linkilo.co/pricing");
                    $message .=  ' <br><a href='.$linkilo_pricing_url.' target="_blank" class="linkilo_license_pricing_link">Linkilo Pricing &nbsp;<img src="'. LINKILO_PLUGIN_DIR_URL.'images/target.png" style="width: 15px; height: 15px; margin-top: 5px;"></a>';

                    if (empty($license_data->item_name) && $license_data->license === "invalid") {
                        $message = "not a valid license match for this product. please try again later.";
                    }
                    break;

                case 'disabled' :
                case 'revoked' :
                    $message = 'Your License Key <span class="linkilo-license-key-wrap">%s</span> has been disabled';
                    break;

                case 'missing' :
                    $message = 'Missing License <span class="linkilo-license-key-wrap">%s</span>';
                    break;

                case 'invalid' :
                case 'site_inactive' :
                    $message = 'The License Key <span class="linkilo-license-key-wrap">%s</span> is not active for this URL.';
                    break;

                case 'item_name_mismatch' :
                    $message = 'It appears this License Key <span class="linkilo-license-key-wrap">%s</span> is used for a different product. Please log into your linkilo.com user account to find your Linkilo License Key.';
                    break;

                case 'no_activations_left':
                    $message = 'The License Key <span class="linkilo-license-key-wrap">%s</span> has reached its activation limit. Please upgrade your subscription to add more sites.';
                    $linkilo_pricing_url = esc_url("https://linkilo.co/pricing");
                    $message .=  '<br><a href='.$linkilo_pricing_url.' target="_blank" class="linkilo_license_pricing_link">Linkilo Pricing &nbsp;<img src="'. LINKILO_PLUGIN_DIR_URL.'images/target.png" style="width: 15px; height: 15px; margin-top: 5px;"></a>';
                    break;

                case 'invalid_item_id':
                    $message = "The License Key <span class=\"linkilo-license-key-wrap\">%s</span> doesn't go to any known products. Fairly often this is caused by a mistake in entering the License Key or after upgrading your Linkilo subscription. If you've just upgraded your subscription, please delete Linkilo from your site and download a fresh copy from linkilo.com.";
                    break;
        
                default :
                    $message = "your license key <span class=\"linkilo-license-key-wrap\">%s</span> is either expired or not valid. please check the license information on your linkilo.co account page.";
                    break;
            }

            if (stristr($message, '%s')) {
                $message = sprintf($message, $license);
            }

            return $message;
        }else{
            $message = "your license key is either expired or not valid. please check the license information on your linkilo.co account page.";
            return $message;
        }
    }

    /**
     * Activate license
     */
    public static function activate() {
        if (!isset($_POST['hidden_action']) || $_POST['hidden_action'] != 'activate_license' || !check_admin_referer('linkilo_activate_license_nonce', 'linkilo_activate_license_nonce')) {
            return;
        }

        $license = sanitize_text_field(trim($_POST['linkilo_license_key']));

        self::check($license, $silent = false);
    }

    /**
     * Activate license via ajax call
     **/
    public static function ajax_linkilo_activate_user_license(){
        
    }
}
