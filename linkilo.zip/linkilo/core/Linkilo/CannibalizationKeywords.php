<?php

/**
 * Work with Cannibalization Report For Keywords
 */
class Linkilo_Build_CannibalizationKeywords {

    public function __construct() {
        add_filter('screen_settings', array(__CLASS__, 'show_screen_option_keywords'), 11, 2);
        add_filter('set_screen_option_cannibalization_keywords', array(__CLASS__, 'save_options_cannibalization_keywords'), 12, 3);

        add_action('wp_ajax_linkilo_handle_cannibalization_keywords', array($this, 'ajax_linkilo_handle_cannibalization_keywords'));
    }

    public static function init()
    {
        $table = new Linkilo_Build_Table_CannibalizationKeywords();
        $table->prepare_items();
        include LINKILO_PLUGIN_DIR_PATH . '/templates/cannibalization_section_keywords.php';
    }

    public static function show_screen_option_keywords($settings, $screen_obj){

        $screen = get_current_screen();
        $options = get_user_meta(get_current_user_id(), 'cannibalization_keywords', true);

        // exit if we're not on the cannibalization keywords page
        if(!is_object($screen) || $screen->id != 'linkilo_page_keyword_cannibalization') {
            return $settings;
        }

        // Check if the screen options have been saved. If so, use the saved value. Otherwise, use the default values.
        if ( $options ) {
            $per_page = !empty($options['per_page']) ? $options['per_page'] : 20 ;
        } else {
            $per_page = 20;
        }

        if (isset($options['dev_mode']) && intval($options['dev_mode']) === 1) {
            $dev_mode = true;
        }else{
            $dev_mode = false;
        }

        //get apply button
        $button = get_submit_button( __( 'Apply', 'wp-screen-options-framework' ), 'primary large', 'screen-options-apply', false );

        //show HTML form
        ob_start();
        include LINKILO_PLUGIN_DIR_PATH . 'templates/cannibalization_options_keywords.php';
        return ob_get_clean();
    }

    public static function save_options_cannibalization_keywords($status, $option, $value) {

        if(!wp_verify_nonce($_POST['screenoptionnonce'], 'screen-options-nonce')){
            // Not verified
            return;
        }

        if ($option == 'cannibalization_keywords') {
            $value = [];
            if (isset( $_POST['cannibalization_keywords'] ) && is_array( $_POST['cannibalization_keywords'] )) {
                if (!isset($_POST['cannibalization_keywords']['per_page'])) {
                    $_POST['cannibalization_keywords']['per_page'] = 20;
                }

                if (
                    isset($_POST['cannibalization_keywords']['dev_mode']) &&
                    $_POST['cannibalization_keywords']['dev_mode'] === 'on'
                ) {
                    $_POST['cannibalization_keywords']['dev_mode'] = 1;
                }else{
                    $_POST['cannibalization_keywords']['dev_mode'] = 0;
                }

                $value = (array)$_POST['cannibalization_keywords'];
            }
            foreach ($_POST['cannibalization_keywords'] as $ind => $val) {
                intval($val);
            }
            return $value;
        }

        return $status;
    }
    
    public function ajax_linkilo_handle_cannibalization_keywords() {
        $id = intval($_POST['rec_id']);
        
        global $wpdb;
        $console_table = $wpdb->prefix . 'linkilo_search_console_data';

        $query = $wpdb->prepare("DELETE FROM {$console_table} WHERE `gsc_index` = %d", $id);
        $res = $wpdb->query($query);

        // Set messages
        $status_update_s = array('success' => array('title' => __('Request Processed', 'linkilo'), 'text' => __("Entry has been removed.\n", 'linkilo')));

        $status_update_err = array('error' => array('title' => __('Cannot Process Request', 'linkilo'), 'text' => __("There is an error in query processing of the request. \n Please try after some time.", 'linkilo')));

        $status_update_i = array('info' => array('title' => __('Cannot Process Request', 'linkilo'), 'text' => __("No Rows Affected.\n Please try again or later", 'linkilo')));

        if ($res) {
            wp_send_json($status_update_s);
        }elseif($wpdb->last_error !== '') {
            wp_send_json($status_update_err);
        }else{
            wp_send_json($status_update_i);
        }
    }

    /**
     * Get keywords data for cannibalization report data
     *
     * @return array|null
     */
    public static function get_cannibalization_keywords($per_page = null, $page = null, $search = null, $orderby  = null, $order = null, $dev_mode = 0) {

        global $wpdb;
        $console_table = $wpdb->prefix . 'linkilo_search_console_data';

        // if the console_tbl_exists exists
        $console_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}linkilo_search_console_data'");
        if(!empty($console_tbl_exists)){
            // table exists
            //define order columns
            $qu_orderby = "";
            // define order ASC/DESC
            $qu_order = "";

            // check for null value 
            if (!is_null($orderby)) {

                // not null match with case
                switch ($orderby) {
                    case 'q_keyword':
                    $qu_orderby = "ORDER BY `{$console_table}`.`keywords`";
                    break;
                    case 'q_page':
                    $qu_orderby = "ORDER BY `{$console_table}`.`page_url`";
                    break;
                    case 'click':
                    $qu_orderby = "ORDER BY `{$console_table}`.`clicks`";
                    break;
                    case 'impression':
                    $qu_orderby = "ORDER BY `{$console_table}`.`impressions`";
                    break;
                    case 'ctr':
                    $qu_orderby = "ORDER BY `{$console_table}`.`ctr`";
                    break;
                    case 'position':
                    $qu_orderby = "ORDER BY `{$console_table}`.`position`";
                    break;
                    default:
                    $qu_orderby = "ORDER BY `{$console_table}`.`gsc_index`";
                    break;
                }
            }

            // check for null value 
            if (!is_null($order)) {

                // not null match with case
                switch ($order) {
                    case 'asc':
                    $qu_order = "ASC";
                    break;
                    case 'desc':
                    $qu_order = "DESC";
                    break;
                    default:
                    $qu_order = "DESC";
                    break;
                }
            }

            if (!is_null($search) || !empty($search) || $search != "") {
                $report_data= $wpdb->get_results(
                    $wpdb->prepare("
                        SELECT DISTINCT(keywords), gsc_index, page_url, clicks, impressions, ctr, position 
                        FROM {$console_table}
                        WHERE keywords IS NOT NULL
                        AND keywords <> ''
                        AND keywords LIKE '%%%s%%' 
                        GROUP BY keywords HAVING COUNT(keywords) > 0
                        $qu_orderby $qu_order
                        ", 
                        $wpdb->esc_like($search)
                    ),
                    ARRAY_A
                );
            }else{
                $report_data = $wpdb->get_results("
                    SELECT DISTINCT(keywords), gsc_index, page_url, clicks, impressions, ctr, position 
                    FROM {$console_table}
                    WHERE keywords IS NOT NULL
                    AND keywords <> ''
                    GROUP BY keywords HAVING COUNT(keywords) > 0
                    $qu_orderby $qu_order
                    ", 
                    ARRAY_A
                );

                if (intval($dev_mode) === 1) {
                    return [
                        'total' => sizeof($report_data),
                        'report_data' => array_slice($report_data, ($page - 1) * $per_page, $per_page)
                    ];
                }
            }
            
            $counter = 0;
            foreach ($report_data as $row_index => $word) {
                $page_urls = $wpdb->get_results(
                    $wpdb->prepare("
                        SELECT DISTINCT(page_url_clean), gsc_index, keywords, clicks, impressions, ctr, position
                        FROM {$console_table} 
                        WHERE `keywords` = %s
                        GROUP BY page_url_clean HAVING COUNT(page_url_clean) > 0
                        ",
                        $wpdb->esc_like($word['keywords']),
                    ), 
                    ARRAY_A
                );

                if (sizeof($page_urls) > 1) {
                    $counter++;
                    $report_data[$row_index]['matched_q_keyword'] = $page_urls;
                }else{
                    unset($report_data[$row_index]);
                }
            }

            return [
                'total' => sizeof($report_data),
                'report_data' => array_slice($report_data, ($page - 1) * $per_page, $per_page)
            ];
        }else{
            return false;
        }
    } 
}
