<?php


if (!class_exists('WP_List_Table')) {
	require_once ( ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

/**
* Class Linkilo_Build_Table_AnchorAnalysis
*/
class Linkilo_Build_Table_AnchorAnalysis extends WP_List_Table
{
	function get_columns()
	{
		return [
			'anchor_text' => 'Anchor',
			'internal_count' => 'Internal',
			'external_count' => 'External',

		];
	}

	function get_sortable_columns()
	{
		$cols = $this->get_columns();

		$sortable_columns = [];

		foreach ($cols as $col_k => $col_name) {
			$sortable_columns[$col_k] = [$col_k, false];
		}

		return $sortable_columns;
	}

	function prepare_items()
	{
		$options = get_user_meta(get_current_user_id(), 'anar_rep_options', true);

		$per_page = !empty($options['per_page']) ? $options['per_page'] : 20;
		$page = isset($_REQUEST['paged']) ? (int)$_REQUEST['paged'] : 1;
		$search = !empty($_GET['s']) ? $_GET['s'] : null;

		$orderby = (isset($_REQUEST['orderby']) && !empty($_REQUEST['orderby'])) ? sanitize_text_field($_REQUEST['orderby']) : 'main.anchor';
		$order = (!empty($_REQUEST['order'])) ? sanitize_text_field($_REQUEST['order']) : 'ASC';

		$columns = $this->get_columns();

		$hidden = [];
		$sortable = $this->get_sortable_columns();
		$this->_column_headers = [$columns, $hidden, $sortable];
		// Get all Data for anchor section

		$anchor_data = Linkilo_Build_Console::getLinksAnalysisData(null, "anchor", null, $per_page, $page, $search, $orderby, $order);
		$this->items = $anchor_data['anchor_list'];

		$this->set_pagination_args(array(
			'total_items' => $anchor_data['total'],
			'per_page' => $per_page,
			'total_pages' => ceil($anchor_data['total'] / $per_page)
		));
	}

	function column_default($item, $column_name)
	{
		switch($column_name)
		{
			case 'anchor_text':
			if (!is_null($item['anchor']) && 
				!empty($item['anchor']) &&
				strlen(trim($item['anchor'])) > 2
			){
				return _e($item['anchor'], 'linkilo'); 
			}
			case 'internal_count':
			if (!is_null($item['anchor']) && 
				!empty($item['anchor']) &&
				strlen(trim($item['anchor'])) > 2
			){
	    		// get internal count of anchor from the data array
				$internal_count = $item['internal_count'];

				// get anchor details with post id
				$internal_data = Linkilo_Build_Console::getLinksAnalysisData(null, "in_count", $item['anchor']);

				if (sizeof($internal_data) > 0){
				$list = '<ul class="report_links anchor-analysis-page-table">';
				foreach ($internal_data as $key => $value)
				{
					$r_index = intval($value['link_id']);
					$post_id = intval($value['post_id']);
					$post_title = get_the_title($post_id);
					$post_type = 'post';
					$url_edit = esc_url(get_edit_post_link($post_id));
					$url_view = esc_url(get_permalink($post_id));
					$anchor_text =base64_encode(trim($value['anchor']));
					$substring = substr($anchor_text,0,5);
					$anchor_url = base64_encode(trim($value['raw_url']));               
					$counter_wrap_id ='data_anchor_count_' . $substring  ;
					$td_wrap ='data_anchor_count_wrap_' . $substring  ;
					$uniqe_li = 'anchor_url_wrap_'.$r_index;
					$list .= '<li class="'.$uniqe_li.'">';
					$list .= '<div style="margin-bottom:10px;display:flex;flex-direction:row;padding: 0;">
								<div class="links-row-col-left-title anchor-page">
									<span class="dashicons dashicons-admin-page"></span> 
									<span>Post Title : </span> 
								</div>
								<span class="links-row-col-right-text">'.$post_title.'</span> 
							</div>
							<div style="margin-bottom:10px;display:flex;flex-direction:row;padding: 0;">
								<div class="links-row-col-left-title anchor-page">
									<span class="dashicons dashicons-media-text"></span>
									<span>Anchor Text : </span>
								</div>
								<span class="links-row-col-right-text"> '.strip_tags($value['anchor']).'</span> 
							</div>
							<span class="links-row-col-settings-text">
								<span class="dashicons dashicons-admin-generic add-urls-links-table"></span>		
								<span class="links-row-col-settings-anchor">
									<a class="auto-link-table-edit" href="'.$url_edit.'" target="_blank">edit</a> 
									<a class="auto-link-table-edit" href="'.$url_view.'" target="_blank">view</a>
									<a href="javascript:void(0)" class="auto-link-table-edit linkilo_anchor_report_row_delete delete-anchor"
									data-wrap_id="'.$r_index.'"
									data-wrap_class="'.$uniqe_li.'"
									data-td_wrap="'.$td_wrap.'"
									data-counter_wrap_id="'.$counter_wrap_id.'"
									data-post_id="' . $post_id . '" 
									data-post_type="' . $post_type . '" 
									data-anchor="'.$anchor_text . '" 
									data-url="' . $anchor_url . '">
									remove</a>
								</span>
							</span>
					</li>';
				}
				$list .= '</ul>';
				$count = sizeof($internal_data);      

				$warpper_div ='<div id="'.$td_wrap .'" class="linkilo-collapsible-wrapper">
				<div id="'.$counter_wrap_id.'" class="linkilo-anchor-count-wrap_'. $substring.' linkilo-collapsible linkilo-collapsible-static" data-default-count="'.$count.'" title="Internal Count"  >'.$count.' </div>
				<div class="linkilo-content">'.$list.'</div>
				</div>';
				}else{
					$warpper_div = '<div title="Internal Count" style="margin:0px; text-align: center; padding: 5px">'. $internal_count .'</div>';
				}
				return $warpper_div;
			}
			case 'external_count':
			if (!is_null($item['anchor']) && 
			!empty($item['anchor']) &&
			strlen(trim($item['anchor'])) > 2
			){
	    		
				$external_count = $item['external_count']; 

	    		// get anchor details with post id
				$external_data = Linkilo_Build_Console::getLinksAnalysisData(null, "ex_count", $item['anchor']); 
			
				if (sizeof($external_data) > 0) 
				{
				$list = '<ul class="report_links anchor-analysis-page-table">';
				foreach ($external_data as $key => $value){
					$r_index = intval($value['link_id']);
					$post_id = intval($value['post_id']);
					$post_title = get_the_title($post_id);
					$post_type = 'post';
					$url_edit = esc_url(get_edit_post_link($post_id));
					$url_view = esc_url(get_permalink($post_id));
					$anchor_text =base64_encode(trim($value['anchor']));
					$substring = substr($anchor_text,0,8);
					$anchor_url = base64_encode(trim($value['raw_url']));
					$counter_wrap_id ='data_anchor_count_' . $substring  ;
					$td_wrap ='data_anchor_count_wrap_' . $substring  ;
					$uniqe_li = 'anchor_url_wrap_'.$r_index;
					$list .= '<li class="'.$uniqe_li.'">
						<div style="margin-bottom:10px;display:flex;flex-direction:row;padding: 0;">
							<div class="links-row-col-left-title anchor-page">
								<span class="dashicons dashicons-admin-page"></span>
								<span>Post Title : </span>
							</div>
							<span class="links-row-col-right-text">'.$post_title.'</span>
						</div>
						<div style="margin-bottom:10px;display:flex;flex-direction:row;padding: 0;">
							<div class="links-row-col-left-title anchor-page">
							<span class="dashicons dashicons-media-text"></span>
							<span>Anchor Text : </span>
						</div> 
						<span class="links-row-col-right-text">'.strip_tags($value['anchor']).'</span> 
					</div>
		
					<span class="links-row-col-settings-text">
						<span class="dashicons dashicons-admin-generic add-urls-links-table"></span>

						<span class="links-row-col-settings-anchor">
							<a class="auto-link-table-edit" href="'.$url_edit.'" target="_blank">edit</a> 
							<a class="auto-link-table-edit" href="'.$url_view.'" target="_blank">view</a>
							<a href="javascript:void(0)" class="auto-link-table-edit linkilo_anchor_report_row_delete delete-anchor"
							data-wrap_id="'.$r_index.'"  
							data-wrap_class="'.$uniqe_li.'" 
							data-td_wrap="'.$td_wrap.'"
							data-counter_wrap_id="'.$counter_wrap_id.'"
							data-post_id="' . $post_id . '" 
							data-post_type="' . $post_type . '" 
							data-anchor="'.$anchor_text . '" 
							data-url="' . $anchor_url . '">
							remove</a>
						</span>
					</span>
					</li>';
				}
				$list .= '</ul>';  
				$count = sizeof($external_data);  
				$warpper_div = '<div id="'.$td_wrap .'"  class="linkilo-collapsible-wrapper">
				<div id="'.$counter_wrap_id.'" class="linkilo-anchor-count-wrap_'. $substring.' linkilo-collapsible linkilo-collapsible-static" data-default-count="'.$count.'" title="External Count"  >'.$count.' </div>
				<div class="linkilo-content">'.$list.'</div>
				</div>';
				}else{
					$warpper_div = '<div title="External Count" style="margin:0px; text-align: center; padding: 5px">'.$external_count.'</div>';
				}
				return $warpper_div;
			}
			default:
			break;
		}
	}

}
