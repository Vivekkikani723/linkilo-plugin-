<?php

if (!class_exists('WP_List_Table')) {
    require_once ( ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

/**
 * Class Linkilo_Build_Table_CannibalizationLinks
 */
class Linkilo_Build_Table_CannibalizationLinks extends WP_List_Table {
    function get_columns() {
        return [
            'anchor' => 'Query',
            'q_page' => 'Page URL',
            'click' => 'Clicks',
            'impression' => 'Impressions',
            'ctr' => 'CTR',
            'position' => 'Position',
        ];
    }

    function get_sortable_columns() {
        $cols = $this->get_columns();
        $sortable_columns = [];
        foreach ($cols as $col_k => $col_name) {
            if ($col_k === "anchor" || $col_k === "q_page" ) {
                $sortable_columns[$col_k] = [$col_k, false];
            }
        }        
        return $sortable_columns;
    }

    function prepare_items() {
        $options = get_user_meta(get_current_user_id(), 'cannibalization_links', true);
        $per_page = !empty($options['per_page']) ? $options['per_page'] : 20;
        $page = isset($_REQUEST['paged']) ? (int)$_REQUEST['paged'] : 1;
        $search = !empty($_GET['s']) ? $_GET['s'] : null;

        $orderby = (isset($_REQUEST['orderby']) && !empty($_REQUEST['orderby'])) ? sanitize_text_field($_REQUEST['orderby']) : 'link_id';
        $order = (!empty($_REQUEST['order'])) ? sanitize_text_field($_REQUEST['order']) : 'asc';


        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];
        // Get all Data for anchor section

        $query_data = Linkilo_Build_CannibalizationLinks::get_cannibalization_links($per_page, $page, $search, $orderby, $order);

        $this->items = $query_data['report_data'];

        $this->set_pagination_args(array(
            'total_items' => $query_data['total'],
            'per_page' => $per_page,
            'total_pages' => ceil($query_data['total'] / $per_page)
        ));
    }

    function column_default($item, $column_name) {
        if (!empty(trim($item['anchor']))) {
            // $post_content = get_the_content( null, false, intval( $item['post_id'] ) );
            $post_id = intval( $item['post_id'] );
            $post = new Linkilo_Build_Model_Feed($post_id, get_post_type($post_id));
            $post_content = $post->getContent();
            switch($column_name) {
                case 'anchor':
                    if (
                        !is_null($item['anchor']) && 
                        !empty(trim($item['anchor'])) &&
                        $item['anchor'] !== "" &&
                        strlen(trim($item['anchor'])) > 2
                    ) { 
                        return esc_html($item['anchor']); 
                    }
                break;
                case 'q_page':
                    $count = 0;
                    if (isset($item['matched_anchor']) && sizeof($item['matched_anchor']) > 0) {
                        $count = sizeof($item['matched_anchor']);
                    }

                    if ($count > 1) {

                        $r_index = intval($item['link_id']);

                        /*linkilo-collapsible-wrapper starts*/
                        $wrapper_div = '<div class="linkilo-collapsible-wrapper">';

                        $wrapper_div .= '<div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count">';

                        $wrapper_div .= '<span class="cannibalization_links_count_wrap_'.$r_index.'" data-default_count="'.$count.'"> '.$count.'</span>'; 

                        $wrapper_div .= '</div>';

                        $wrapper_div .= '<div class="linkilo-content">';

                        /*Process Loader*/
                        $wrapper_div .= '<div class="cannibalization_links_loader_'.$r_index.' cannibalization_links_loader_wrap" style="display:none;">';
                        $wrapper_div .= '<div class="linkilo_progress_panel_cannib_links loader"></div>';
                        $wrapper_div .='</div>';
                        /*Process Loader ends*/

                        /* u-list starts*/
                        $wrapper_div .= '<ul class="cannibalization_links_list cannibalization_links_wrap_'.$r_index.'" style="display:block">';

                        foreach ($item['matched_anchor'] as $r_in => $r_data) { 
                            $post_id = intval($r_data['post_id']);
                            $raw_url = $r_data['raw_url'];
                            $clean_url = urldecode($r_data['clean_url']);
                            $word = $r_data['anchor'];
                            $post_type = $r_data['post_type'];
                            $loop_r_index = intval($r_data['link_id']);

                            $post_url_of_the_word = get_permalink($post_id);
                            $post_title_of_the_word = get_the_title($post_id);

                            $url_edit = esc_url(get_edit_post_link($post_id));

                            if (isset($r_data['gsc_data']) && sizeof($r_data['gsc_data']) > 0) {
                                $clicks = isset($r_data['gsc_data']['clicks']) ? $r_data['gsc_data']['clicks'] : "N/A";

                                $impressions = isset($r_data['gsc_data']['impressions']) ? $r_data['gsc_data']['impressions'] : "N/A";

                                $ctr = isset($r_data['gsc_data']['ctr']) ? $r_data['gsc_data']['ctr'] : "N/A";

                                $position = isset($r_data['gsc_data']['position']) ? $r_data['gsc_data']['position'] : "N/A";

                            } else {
                                $clicks = "N/A";
                                $impressions = "N/A";
                                $ctr = "N/A";
                                $position = "N/A";
                            }

                            /*Highlight the word in sentence*/
                            preg_match('`(\!|\?|\.|^|)([^.!?\n]*<a\s.*?(?:href=[\'"]' . preg_quote($raw_url, '`') . '[\'"]).*?>' . preg_quote($word, '`') . '<\/a>((?!<a)[^.!?\n])*)`i', $post_content, $string_matches);
                            
                            $matched_sentence = '';
                            if ($string_matches && isset($string_matches[2])) {
                                $matched_sentence = str_ireplace("<br>", '', $string_matches[2]);
                            }elseif ($string_matches && isset($string_matches[1])) {
                                $matched_sentence = str_ireplace("<br>", '', $string_matches[1]);
                            }else{
                                $matched_sentence = null;
                            }
                            $highlighted_sentence = $word;
                            if (!is_null($matched_sentence) && !empty($matched_sentence)) {
                                $positon_before = stripos($matched_sentence, "<a", 0);
                                $positon_after = stripos($matched_sentence, "/a>", 0) + 3;
                                $substr_before = substr($matched_sentence, 0, $positon_before);
                                $substr_after = substr($matched_sentence, $positon_after, 30);

                                $highlight_color_span = '<span style="color: #1078C7;">'.trim($word).'</span>';
                                $highlighted_sentence = trim(strip_tags($substr_before))." ".trim($highlight_color_span). " ".trim(strip_tags($substr_after));
                            }

                            /*Highlight the word in sentence ends*/
                            /* list element starts*/
                            $wrapper_div .= '<li>';

                            $wrapper_div .= '<i class="linkilo_cannibalization_links_remove dashicons dashicons-no-alt"  
                            data-wrap_id="'.$r_index.'" 
                            data-post_id="'.$post_id.'" 
                            data-post_type="'.$post_type.'" 
                            data-anchor="'.base64_encode($word).'" 
                            data-url="'.base64_encode($raw_url).'"
                            ></i>';

                            /*Wrapper data_section starts*/
                            $wrapper_div .= '<div class="data_section" style="display:block;">';

                            $wrapper_div .= '<div class="linkilo_cannib_replace_overlay_'.$loop_r_index.'">';
                            // Word
                            // $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('word').'&nbsp;:&nbsp;&nbsp;</b>'.esc_html($word).'</div>';
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer" class="link_cannibalization_highlight_wrap"><div class="links-row-col-left-title link-cannib-page"><span class="dashicons dashicons-media-text"></span> <span>'.strtoupper('word : ').'</span></div><span class="links-row-col-right-text">'.$highlighted_sentence.'</span></div>';

                            // Link
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer"><div class="links-row-col-left-title link-cannib-page"><span class="dashicons dashicons-admin-links"></span> <span>'.strtoupper('link to : ').'</span></div> 
                            <span class="links-row-col-right-text">
                                <span id="rep_link_wrap_'.$loop_r_index.'">'.$clean_url.'</span> 
                                <input type="hidden" name="rep_link_text_raw_url_'.$loop_r_index.'" id="rep_link_text_raw_url_'.$loop_r_index.'" value="'.base64_encode($raw_url).'">
                            </span>
                            </div>';

                            // Post Edit Link
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer"> 
                                <div class="links-row-col-left-title link-cannib-page">
                                    <span class="dashicons dashicons-edit"></span> 
                                    <span>'.strtoupper('location url : ').'</span>
                                </div>
                                <span class="links-row-col-right-text">
                                    <a href="'.$url_edit.'" target="_blank">'.$post_title_of_the_word.'</a> 
                                </span>
                            </div>';

                            // Clicks data
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer">
                                <div class="links-row-col-left-title link-cannib-page">
                                    <span class="dashicons dashicons-info-outline"></span> 
                                    <span>'.strtoupper('clicks : ').'</span>
                                </div>
                                <span class="links-row-col-right-text">
                                '.$clicks.'
                                </span>
                            </div>';

                            // Impressions data
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer">
                                <div class="links-row-col-left-title link-cannib-page">
                                    <span class="dashicons dashicons-info-outline"></span> 
                                    <span>'.strtoupper('impressions : ').'</span>
                                </div>
                                <span class="links-row-col-right-text">
                                    '.$impressions.'
                                </span>
                            </div>';

                            // CTR data
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer">
                                <div class="links-row-col-left-title link-cannib-page">
                                    <span class="dashicons dashicons-info-outline"></span> 
                                    <span>'.strtoupper('ctr : ').'</span>
                                </div>
                                <span class="links-row-col-right-text">
                                    '.$ctr.'
                                </span>
                            </div>';

                            // Position data
                            $wrapper_div .= '<div class="link-cannib-row-col-wrppaer">
                                <div class="links-row-col-left-title link-cannib-page">
                                    <span class="dashicons dashicons-info-outline"></span> 
                                    <span>'.strtoupper('position : ').'</span>
                                </div>
                                <span class="links-row-col-right-text">
                                    '.$position.'
                                </span>
                            </div>';

                            $wrapper_div .= '</div>'; 

                            $wrapper_div .= '<span class="cannibalization_links_replace link-form-button cannib_hide_button_'.$loop_r_index.'" 
                            data-post_id="'.$post_id.'" 
                            data-wrap_id="'.$r_index.'" 
                            data-post_type="'.$post_type.'"
                            data-loop_r_index="'.$loop_r_index.'"
                            ><a href="javascript:void(0)" class="cst-btn-clr" style="padding: 3px 15px; border-radius: 3px; margin-bottom: 10px;" >'.ucwords('replace url').'</a></span>';
                            $wrapper_div .= '<div class="replace_cannibalization_link_'.$loop_r_index.'"></div>';
                            $wrapper_div .= '</div>';
                            /*Wrapper data_section ends*/

                            $wrapper_div .= '</li>'; 
                            /* list element ends*/
                        }
                        $wrapper_div .= '</ul>';
                        /* u-list ends*/
                        $wrapper_div .= '</div>';
                        /*linkilo-collapsible-wrapper ends*/
                        return $wrapper_div;
                    }
                break;
                case 'click':
                    if (isset($item['gsc_data']) && sizeof($item['gsc_data']) != 0) {
                        return $item['gsc_data']['clicks'];
                    }else{
                        return "N/A";
                    }
                break;
                case 'impression':
                    if (isset($item['gsc_data']) && sizeof($item['gsc_data']) != 0) {
                        return $item['gsc_data']['impressions'];
                    }else{
                        return "N/A";
                    }
                break;
                case 'ctr':
                    if (isset($item['gsc_data']) && sizeof($item['gsc_data']) != 0) {
                        return $item['gsc_data']['ctr'];
                    }else{
                        return "N/A";
                    }
                break;
                case 'position':
                    if (isset($item['gsc_data']) && sizeof($item['gsc_data']) != 0) {
                        return $item['gsc_data']['position'];
                    }else{
                        return "N/A";
                    }
                break;
                default:
                    // do nothing
                break;
            }
        }
    } 
}
