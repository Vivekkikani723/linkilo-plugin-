<?php

if (!class_exists('WP_List_Table')) {
    require_once ( ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

/**
 * Class CannibalizationKeywords
 */
class Linkilo_Build_Table_CannibalizationKeywords extends WP_List_Table
{
    function get_columns()
    {
        return [
            'q_keyword' => 'Query',
            'q_page' => 'Page URL',
            'click' => 'Clicks',
            'impression' => 'Impressions',
            'ctr' => 'CTR',
            'position' => 'Position',
        ];
    }

    function get_sortable_columns()
    {
        $cols = $this->get_columns();

        $sortable_columns = [];

        foreach ($cols as $col_k => $col_name) {
            $sortable_columns[$col_k] = [$col_k, false];
        }

        return $sortable_columns;
    }

    function prepare_items()
    {
        $options = get_user_meta(get_current_user_id(), 'cannibalization_keywords', true);
        $per_page = !empty($options['per_page']) ? $options['per_page'] : 20;
        $page = isset($_REQUEST['paged']) ? (int)$_REQUEST['paged'] : 1;
        $search = !empty($_GET['s']) ? $_GET['s'] : null;

        $orderby = (isset($_REQUEST['orderby']) && !empty($_REQUEST['orderby'])) ? sanitize_text_field($_REQUEST['orderby']) : 'gsc_index';
        $order = (!empty($_REQUEST['order'])) ? sanitize_text_field($_REQUEST['order']) : 'asc';
        $dev_mode = isset($options['dev_mode']) && $options['dev_mode'] === 1 ? 1 : 0;

        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];
        // Get all Data for anchor section

        $query_data = Linkilo_Build_CannibalizationKeywords::get_cannibalization_keywords($per_page, $page, $search, $orderby, $order, $dev_mode);

        if ($query_data) {
            $this->items = $query_data['report_data'];
            $this->set_pagination_args(array(
                'total_items' => $query_data['total'],
                'per_page' => $per_page,
                'total_pages' => ceil($query_data['total'] / $per_page)
            ));
        }else{
            $this->items = array();
        }

    }

    function column_default($item, $column_name) {
        switch($column_name) {
            case 'q_keyword':
            if (!is_null($item['keywords']) && 
                !empty($item['keywords']) &&
                $item['keywords'] !== "" &&
                strlen(trim($item['keywords'])) > 2
            ) { 
                return esc_html($item['keywords']); 
        }

        case 'q_page':

        if (
            isset($item['matched_q_keyword']) && 
            sizeof($item['matched_q_keyword']) > 0
        ) {
            $count = sizeof($item['matched_q_keyword']);
        }else{   
            $count = 0;
        }

        if ($count > 1) {

            $r_index = intval($item['gsc_index']);

            $wrapper_div = '<div class="linkilo-collapsible-wrapper">';

            $wrapper_div .= '<div class="linkilo-collapsible linkilo-collapsible-static linkilo-links-count">';

            $wrapper_div .= '<span class="cannibalization_keywords_count_wrap_'.$r_index.'" data-default_count="'.$count.'"> '.$count.'</span>';

            $wrapper_div .= '</div>';

            $wrapper_div .= '<div class="linkilo-content">';

            /*Process Loader*/
            $wrapper_div .= '<div class="cannibalization_keywords_loader_'.$r_index.' cannibalization_keywords_loader_wrap" style="display:none;">';
            $wrapper_div .= '<div class="linkilo_progress_panel_cannib_keywords loader"></div>';
            $wrapper_div .='</div>';
            /*Process Loader ends*/

            $wrapper_div .= '<ul class="cannibalization_keywords_list cannibalization_keywords_wrap_'.$r_index.'" style="display:block">';

            foreach ($item['matched_q_keyword'] as $r_in => $r_data) {
                $url = $r_data['page_url_clean'];
                $word = $r_data['keywords'];
                $clicks = $r_data['clicks'];
                $impressions = $r_data['impressions'];
                $ctr = $r_data['ctr'];
                $position = $r_data['position'];

                $row_id = $r_data['gsc_index'];
                $wrapper_div .= '<li>';

                $wrapper_div .= '<i class="linkilo_cannibalization_keywords_remove dashicons dashicons-no-alt" data-rec_id="'.$row_id.'" data-wrap_id="'.$r_index.'"></i>';

                $wrapper_div .= '<div class="data_section" style="display:block;">';

                $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('word').'&nbsp;:&nbsp;&nbsp;</b>'.esc_html($word).'</div>';
                $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('link').'&nbsp;:&nbsp;&nbsp;</b>'.$url.'</div>';
                $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('clicks').' &nbsp;:&nbsp;&nbsp;</b>'.$clicks.'</div>';
                $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('impressions').' &nbsp;:&nbsp;&nbsp;</b>'.$impressions.'</div>';
                $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('ctr').' &nbsp;:&nbsp;&nbsp;</b>'.$ctr.'</div>';
                $wrapper_div .= '<div style="margin: 3px 0; padding-bottom: 1px;"><b>'.strtoupper('position').' &nbsp;:&nbsp;&nbsp;</b>'.$position.'</div>';

                $wrapper_div .= '</div>';

                $wrapper_div .= '</li>'; 
            }
            
            $wrapper_div .= '</ul>';
            $wrapper_div .= '</div>';

            return $wrapper_div;
        }

        if (!is_null($item['page_url']) ) {
            return $item['page_url'];
        }
        case 'click':
        if (!is_null($item['clicks']) ) {
            return $item['clicks'];
        }
        case 'impression':
        if (!is_null($item['impressions'])) {
            return $item['impressions']; 
        }
        case 'ctr':
        if (!is_null($item['ctr'])) {
            return $item['ctr']; 
        }
        case 'position':
        if (!is_null($item['position'])) {
            return $item['position']; 
        }
        default:
        break;
    }
}
}
?>