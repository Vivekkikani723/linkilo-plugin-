<?php

/**
 * Work with Linkilo_Build_AnchorAnalysis
 */
class Linkilo_Build_AnchorAnalysis {

    public function __construct() {
        add_filter('screen_settings', array(__CLASS__, 'anar_show_screen_options'), 11, 2);
        add_filter('set_screen_option_anar_rep_options', array(__CLASS__, 'anar_save_options'), 12, 3);
        //add_action( 'wp_ajax_delete_post_anchor_tag', [$this,'delete_post_anchor_tag']);
    }

    public static function init() {
        $table = new Linkilo_Build_Table_AnchorAnalysis();
        $table->prepare_items();
        include LINKILO_PLUGIN_DIR_PATH . '/templates/anchor_analysis_section.php';
    }

    public static function anar_show_screen_options($settings, $screen_obj) {

        $screen = get_current_screen();
        $options = get_user_meta(get_current_user_id(), 'anar_rep_options', true);

        // exit if we're not on the anchor analysis keywords page
        if(!is_object($screen) || $screen->id != 'linkilo_page_anchor_analysis'){
            return $settings;
        }

        // Check if the screen options have been saved. If so, use the saved value. Otherwise, use the default values.
        if ( $options ) {
            $per_page = !empty($options['per_page']) ? $options['per_page'] : 20 ;
        } else {
            $per_page = 20;
        }

        //get apply button
        $button = get_submit_button( __( 'Apply', 'wp-screen-options-framework' ), 'primary large', 'screen-options-apply', false );

        //show HTML form
        ob_start();
        include LINKILO_PLUGIN_DIR_PATH . 'templates/anar_report_options.php';
        return ob_get_clean();
    }

    public static function anar_save_options($status, $option, $value) {

        if(!wp_verify_nonce($_POST['screenoptionnonce'], 'screen-options-nonce')){
            // Not verified
            return;
        }

        if ($option == 'anar_rep_options') {
            $value = [];
            if (isset( $_POST['anar_rep_options'] ) && is_array( $_POST['anar_rep_options'] )) {
                if (!isset($_POST['anar_rep_options']['per_page'])) {
                    $_POST['anar_rep_options']['per_page'] = 20;
                }
                $value = $_POST['anar_rep_options'];
            }
            return $value;
        }

        return $status;
    }
}
