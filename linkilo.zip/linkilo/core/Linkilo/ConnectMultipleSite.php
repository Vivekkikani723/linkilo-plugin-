<?php

/**
 * Handles connecting to other sites that have Linkilo installed and tranferring data.
 **/

class Linkilo_Build_ConnectMultipleSite{

    static $query_limit = 5000; // How many items should we ask for in a batch?

    public function register(){
        add_action('wp_ajax_linkilo_link_selected_site', array(__CLASS__, 'ajax_link_selected_site'));
        add_action('wp_ajax_linkilo_register_selected_site', array(__CLASS__, 'ajax_register_selected_site'));
        add_action('wp_ajax_linkilo_outer_site_suggestion_toggle', array(__CLASS__, 'ajax_outer_site_suggestion_toggle'));
        add_action('wp_ajax_linkilo_remove_registered_site', array(__CLASS__, 'ajax_remove_registered_site'));
        add_action('wp_ajax_linkilo_remove_linked_site', array(__CLASS__, 'ajax_remove_linked_site'));

        // Perform scan operation
        add_action('wp_ajax_linkilo_refresh_site_data', array(__CLASS__, 'ajax_download_all_posts'));

        // Get posts from Settings import or refresh
        add_action('wp_ajax_linkilo_refresh_current_site_data', array(__CLASS__, 'ajax_download_all_posts_of_linked_site'));
        
        // add_action('wp_loaded', array(__CLASS__, 'process_tokens'));
        // add_action('post_updated', array(__CLASS__, 'push_item_update_to_network'), 99, 3);
        // add_action('edited_term_taxonomy', array(__CLASS__, 'push_item_update_to_network'), 99, 2);
        // add_action('delete_post', array(__CLASS__, 'push_item_delete_to_network'), 99, 2);
        // add_action('delete_term_taxonomy', array(__CLASS__, 'push_item_delete_to_network'), 99, 1);

        $linking_option = get_option('linkilo_link_external_sites', false);

        $this->create_connection_req_entry_table();
        $this->auto_populate_option();
        add_action('wp_ajax_linkilo_handle_connection_entry', array(__CLASS__, 'ajax_linkilo_handle_connection_entry'));
    }

    public static function linkilo_generate_unique_params($handle = "",$method = 'e') {
        // Set default output value
        $output = null;

        // Set keys
        $s_key =  get_option(LINKILO_R_A_K_OPTIONS);
        $s_iv = get_option(LINKILO_R_A_I_V_OPTIONS);

        // hash
        $key = hash('sha256',$s_key);
        $iv = substr(hash('sha256',$s_iv),0,16);

        // Check whether encryption or decryption
        if($method == 'e'){
            // We are encrypting
            $output = base64_encode(openssl_encrypt($handle,"AES-256-CBC",$key,0,$iv));
        }else if($method == 'd'){
            // We are decrypting
            $output = openssl_decrypt(base64_decode($handle),"AES-256-CBC",$key,0,$iv);
        }
        // Return the final value
        return $output;
    }

    
    /**
     * Ajax handle connection entries on button click
     * */
    public static function ajax_linkilo_handle_connection_entry() {
        // error message
        $err_msg_arr = array('error' => array('title' => __("Request Cannot be processed." , 'linkilo'), 'text' => __("There is an error in processing the request. \n Please try after some time.", 'linkilo')));

        // approve message
        $status_update_a = array('success' => array('title' => __("Status Updated", 'linkilo'), 'text' => __("The Request Status has been updated. \n Sites are now interlikned.", 'linkilo')));

        // disapprove message
        $status_update_d = array('success' => array('title' => __("Status Updated", 'linkilo'), 'text' => __("Current Request has been disapproved. \n To connect again you need to request again to this site for interlinking.", 'linkilo')));

        // information message for understanding
        $status_update_i = array('info' => array('title' => __("Request processed.", 'linkilo'), 'text' => __("No Rows Affected.", 'linkilo')));

        // assign variables
        $id = (isset($_POST['req_id'])) ? intval($_POST['req_id']) : '';

        // req_status 1: Accept, 0: Decline
        $type = (isset($_POST['req_type'])) ? intval($_POST['req_type']) : '';

        // check for empty variables
        if ( 
            !empty($id) && $id != '' &&
            ($type == 0 || $type == 1)
        ) {

            // respond to the site from which connection request is coming
            $response = self::linkilo_call_site_response($id, $type);

            if ($response['process'] && is_null($response['message'])) {
                // process and updated this status accordingly in current site
                global $wpdb;
                $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

                // check type if 1 the accept
                if ($type == 1) {
                    // set url
                    $url = (isset($_POST['c_url']) && $_POST['c_url'] != "") ? $_POST['c_url'] : '';

                    // check for empty string
                    if ($url !== "" || !empty($url)) {
                        $reg = self::linkilo_register_selected_site_option($url, true);
                    }else{
                        // Url is not available show error
                        wp_send_json($err_msg_arr);
                        wp_die();    
                    }

                    // site is resistered now
                    if ($reg) {
                        // update status
                        // req_type 
                        // 1: incoming
                        $update_query = $wpdb->prepare("
                            UPDATE {$entry_table} 
                            SET {$entry_table}.`req_status` = %d , {$entry_table}.`req_expire_time` = NULL
                            WHERE {$entry_table}.`id` = %d 
                            AND {$entry_table}.`req_type` = %d", 
                            $type, 
                            $id, 
                            1
                        );
                        $q_status = $wpdb->query($update_query);

                        if ($q_status) {
                            // reuest processed and status changed show status message
                            // and site is now registerd
                            wp_send_json($status_update_a);
                            wp_die();    
                        }else{
                            // show info becuase no rows are affected
                            wp_send_json($status_update_i);
                            wp_die();    
                        }
                    }else{
                    // site is not resistered show error
                        wp_send_json($err_msg_arr);
                        wp_die();    
                    }
                }

                // it's now a disapprove
                if ($type == 0) {
                    // req_type 
                    // 1: incoming
                    $update_query = $wpdb->prepare("
                        UPDATE {$entry_table} 
                        SET `req_status` = %d , {$entry_table}.`req_expire_time` = NULL
                        WHERE {$entry_table}.`id` = %d 
                        AND req_type = %d", 
                        $type, 
                        $id, 
                        1
                    );
                    $q_status = $wpdb->query($update_query);

                    if ($q_status) {
                        // reuest processed and status changed show status message
                        wp_send_json($status_update_d);
                        wp_die();    
                    }else{
                        // show info becuase no rows are affected
                        wp_send_json($status_update_i);
                        wp_die();    
                    }
                }
            }else{
                // If process had issues show respective messages in alert
                wp_send_json($response['message']);
                wp_die();    
            }
        }else{
            // show error as conditions are not satified
            wp_send_json($err_msg_arr);
            wp_die();    
        }
    }


    /**
     * Call and respond to site 
     * Request acceptance callback operation perform 
     * */
    public static function linkilo_call_site_response($record = null, $response_type = null){
        $ret_process = false;
        $ret_message = null;

        if (
            is_null($record) || is_null($response_type) || 
            intval($record) == 0 || intval($response_type) > 1 
        ) {
            $a_return = array(
                'process' => $ret_process,
                'message' => $ret_message
            );
            return $a_return;
        }

        global $wpdb;
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

        // req_type 
        // 0: outgoing
        // 1: incoming
        // $resreq_status 1: Accept, 0: Decline

        $id = intval($record);
        $res_type = intval($response_type);
        // other site request type
        $req_type = 0;

        // get record with req_type is incoming i.e. 1
        $entry = $wpdb->get_row("
            SELECT * 
            FROM {$entry_table} 
            WHERE id = $id
            AND site_from_url IS NOT NULL 
            AND site_from_url <> ''
            AND req_status IS NULL
            AND req_type = 1
            ",
            ARRAY_A
        );

        if ($entry) {
            $to = $entry['site_from_url'];
            $from = $entry['site_to_url'];
            $unique_code = $entry['unique_code'];

            $call_site = trailingslashit($to)."wp-json/linkilo/v1/postConnectionResponse";

            /*paramas encode */
            $calling_host = parse_url(site_url(), PHP_URL_HOST);
            $called_host = parse_url($to, PHP_URL_HOST);

            $calling_host_ip = gethostbyname($calling_host);
            $called_host_ip = gethostbyname($called_host);


            $data_set = array(
                $calling_host,
                $calling_host_ip,
                $called_host,
                $called_host_ip
            );
            $a_string = implode("=X=",$data_set);

            $key = self::linkilo_generate_unique_params($a_string,'e');
            /*paramas encode ends*/
            
            /*Post request starts*/        
            $site_url_from = site_url();
            $site_url_to = $to;
            $h = self::linkilo_h_get($to);

            $body = array(
                'code' => $unique_code,
                'from_site' => $from,
                'to_site' => $to,
                'res_type' => $res_type,
                'req_type' => $req_type,
                'h' => $h
            );

            $call_response = wp_remote_post(
                $call_site,
                array(
                    'headers'     => array(
                        'Content-Type' => 'application/json; charset=utf-8',
                        'Authorization' => 'Bearer ' . base64_encode( 'linkilo:site_connection_request_reponse' ),
                        'key' => $key,
                        'cache-control' => 'no-cache',
                        'timeout'     => 60, // added
                        'redirection' => 5,  // added
                        'blocking'    => true, // added
                        'httpversion' => '1.0',
                        'sslverify' => false,
                    ),
                    'body'        => json_encode($body),
                    'method'      => 'POST',
                    'data_format' => 'body',
                )
            );
            /*Post request ends*/

            $reponse_body = json_decode(wp_remote_retrieve_body($call_response), true);
            $response_code = wp_remote_retrieve_response_code($call_response);

            if (
                ($response_code == 401 && $reponse_body['code'] == 'auth_401') ||
                ($response_code == 403 && $reponse_body['code'] == 'forb_403') ||
                ($response_code == 204 && $reponse_body['code'] == 'forb_204') ||
                ($response_code == 400 && $reponse_body['code'] == 'e_ex_400') ||
                ($response_code == 400 && $reponse_body['code'] == 'param_400') ||
                ($response_code == 400 && $reponse_body['code'] == 'up_400')
            ) {
                $ret_process = false;
                $ret_message = array(
                    'error' => array(
                        'title' => __("Process Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to process the current request. \n\n Please try after some time.", 'linkilo')
                    )
                );
            } elseif ($response_code == 404) {
                $ret_process = false;
                $ret_message = array(
                    'error' => array(
                        'title' => __("Process Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to process the current request. \n\n Please try after some time.", 'linkilo')
                    )
                );
            } elseif($response_code == 500) {
                $ret_process = false;
                $ret_message = array(
                    'error' => array(
                        'title' => __("Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to process the current request. \n\n The requested site can not processs the request at the moment. \n\n Please try after some time.", 'linkilo')
                    )
                );
            } elseif ($response_code == 400 && $reponse_body['code'] == 'sl_di_400') {
                $ret_process = false;
                $ret_message = array(
                    'error' => array(
                        'title' => __("Site Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to process the current request. \n\n Please enable \"Linkilo\" \n OR \n \"Add external site for link suggestions\" \n ON \n \"".$to."\" \n From Linkilo Settings and after that try again to process.", 'linkilo')
                    )
                );
            } elseif($response_code == 200 && $reponse_body['code'] == 'up_200') {
                $ret_process = true;
                $ret_message = null;
            }
        }
        $a_return = array(
            'process' => $ret_process,
            'message' => $ret_message
        );
        return $a_return;
    }
    /**
     * Auto create option
     * */
    public function auto_populate_option(){
        $site_code_option = get_option( 'linkilo_link_external_sites_access_code' );

        if ( 
            empty(trim($site_code_option)) ||
            $site_code_option === '' ||
            $site_code_option == false
        ) {
            // option is not available at all crate it now
            // Or option is available but has no value
            $rand = Linkilo_Build_ConnectMultipleSite::generate_random_id_string();
            $code = substr($rand, 0, 150);
            update_option('linkilo_link_external_sites_access_code', $code);
        }
    }

    /**
     * Create Connection reuest entry table for storing site connection data about 
     * reqauest and responses from api calls
     * */
    public static function create_connection_req_entry_table(){
        global $wpdb;
        $connection_req_entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

        $table = $wpdb->get_var("SHOW TABLES LIKE '{$connection_req_entry_table}'");
        
        if ($table != $connection_req_entry_table) {
            $connection_req_entry_table_query = "CREATE TABLE IF NOT EXISTS {$connection_req_entry_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            site_from_url varchar(500),
            site_to_url varchar(500),
            unique_code text,
            req_expire_time DATE DEFAULT NULL,
            req_status tinyint(1) DEFAULT NULL,
            req_type tinyint(1) DEFAULT NULL,
            req_expire_status tinyint(1) DEFAULT NULL,
            PRIMARY KEY (id)
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";
                // create DB table if it doesn't exist
        require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($connection_req_entry_table_query);
    }
}

    /**
     * Clear or truncate the table at time of deleting the plugin
     * */
    public static function clear_connection_req_entry_table(){
        global $wpdb;
        $connection_req_entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';
        $table = $wpdb->get_var("SHOW TABLES LIKE '{$connection_req_entry_table}'");
        if ($table == $connection_req_entry_table) {
            $wpdb->query("TRUNCATE TABLE {$connection_req_entry_table}");
        }
    }

    public static function get_connected_entries_meta($site = null) {
        if (is_null($site)) {
            return false;
        }

        $url = trailingslashit(esc_url_raw($site));
        global $wpdb;
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';
        $entries = $wpdb->get_var("
            SELECT id 
            FROM {$entry_table} 
            WHERE site_from_url IS NOT NULL 
            AND site_to_url IS NOT NULL 
            AND unique_code IS NOT NULL 
            AND site_from_url <> ''
            AND unique_code <> ''
            AND site_to_url <> ''
            AND (site_from_url = '$url' OR site_to_url = '$url') 
            "
        );

        return $entries;
    }

    public static function get_old_connected_site_entry($site = null)
    {   
        if (is_null($site)) {
            return false;
        }
        $url = trailingslashit(esc_url_raw($site));
        global $wpdb;
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';
        $entries = $wpdb->get_row("
            SELECT id, req_status, req_type, req_expire_time
            FROM {$entry_table} 
            WHERE site_from_url IS NOT NULL 
            AND site_to_url IS NOT NULL 
            AND unique_code IS NOT NULL 
            AND site_from_url <> ''
            AND unique_code <> ''
            AND site_to_url <> ''
            AND (site_from_url = '$url' OR site_to_url = '$url') 
            ",
            ARRAY_A
        );

        if (is_null($entries)) {
            return false;
        }

        return $entries;
    }

    public static function create_data_table(){
        global $wpdb;
        $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';
        $table = $wpdb->get_var("SHOW TABLES LIKE '{$linkilo_data_table}'");
        if ($table != $linkilo_data_table) {
            $linkilo_data_table_query = "CREATE TABLE IF NOT EXISTS {$linkilo_data_table} (
            item_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            post_type text,
            type varchar(10),
            site_url text,
            post_url text,
            post_title text,
            stemmed_title text,
            post_modified_gmt DATETIME,
            last_scan DATETIME NOT NULL DEFAULT NOW(),
            PRIMARY KEY  (item_id),
            INDEX (post_id),
            INDEX (site_url(255))
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";
                        // create DB table if it doesn't exist
        require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($linkilo_data_table_query);
    }
}

public static function clear_data_table(){
    global $wpdb;
    $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';
    $table = $wpdb->get_var("SHOW TABLES LIKE '{$linkilo_data_table}'");
    if ($table == $linkilo_data_table) {
        $wpdb->query("TRUNCATE TABLE {$linkilo_data_table}");
    }
}

    /**
     * Erases the data for a given external site
     **/
    public static function clear_external_site_data($url = ''){
        global $wpdb;
        $data_table = $wpdb->prefix . 'linkilo_site_linking_data';
        if(empty($url)){
            return false;
        }

        $url = trailingslashit(esc_url_raw($url));

        // make sure the site exists
        if(!self::check_if_site_added($url)){
            return false;
        }

        // get all the post indexes for the site data to remove
        $indexes = $wpdb->get_col($wpdb->prepare("SELECT `item_id` FROM {$data_table} WHERE `site_url` = %s", $url));

        // if we have post indexes
        if(!empty($indexes)){
            // drop the database indexes for the other cols to speed up deletion
            $wpdb->query("ALTER TABLE {$data_table} DROP INDEX `post_id`");
            $wpdb->query("ALTER TABLE {$data_table} DROP INDEX `site_url`");

            // loop over the ids and remove them from the db
            while(true){
                $ids = array_splice($indexes, 0, 10000);

                // exit if we're out of ids
                if(empty($ids)){
                    break;
                }

                // create the ids list
                $ids = implode(', ', $ids);

                // delete the ids in the list
                $wpdb->query("DELETE FROM {$data_table} WHERE `item_id` IN ({$ids})");
            }

            // now that we're done removing the posts, re-add the database indexes
            $wpdb->query("ALTER TABLE {$data_table} ADD INDEX( `post_id`)");
            $wpdb->query("ALTER TABLE {$data_table} ADD INDEX( `site_url`(255))");
        }

        return true;
    }

    /**
     * Gets a data item from the database.
     **/
    public static function get_data_item($id = 0, $type = 'post', $site_url = ''){
        global $wpdb;
        $data_table = $wpdb->prefix . 'linkilo_site_linking_data';

        if(empty($id) || empty($type) || empty($site_url)){
            return false;
        }

        $query = $wpdb->prepare("SELECT * FROM {$data_table} WHERE `post_id` = %d AND `post_type` = %s AND `site_url` = %s", $id, $type, $site_url);
        $item = $wpdb->get_results($query, ARRAY_A);

        if (sizeof($item) === 0) {
            return false;
        }else{
            return $item;
        }
    }

    /**
     * Updates an item's data in the database.
     * Creates the item if it doesn't exist in the table.
     * 
     * @param object $item_data Item data from the site that pushed the update.
     * @param string $site_url The url of the site that pushed the update.
     **/
    public static function update_data_item($item_data = array(), $site_url = ''){
        if(empty($item_data) || empty($site_url)){
            return false;
        }

        $site_url = trailingslashit(esc_url_raw($site_url));

        // find out if we have the item on hand
        $stored_item = self::get_data_item($item_data->post_id, $item_data->type, $site_url);

        if(empty($stored_item)){
            $results = self::save_data(array($item_data), $site_url); // wrapp the object in an array because the saver expects to deal with an array of items
        }else{
            $results = self::update_data(array($item_data), $site_url); // wrapp the object in an array because the saver expects to deal with an array of items
        }

        return $results;
    }

    /**
     * Deletes an item's data from the database.
     * 
     * @param object $item_data The id and data type of the item that was deleted.
     * @param string $site_url The url that the item was deleted from.
     **/
    public static function delete_data_item($item_data = array(), $site_url = ''){
        global $wpdb;
        $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';

        if(empty($item_data) || empty($site_url)){
            return false;
        }

        $site_url = trailingslashit(esc_url_raw($site_url));

        // find out if we have the item
        $stored_items = self::get_data_item($item_data->post_id, $item_data->type, $site_url);

        // if we do, delete it
        $deleted = false;
        if(!empty($stored_items)){
            foreach($stored_items as $stored_item){
                $deleted = $wpdb->delete($linkilo_data_table, array('item_id' => $stored_item->item_id));
            }
        }

        return $deleted;
    }

    /**
     * Counts how many external site data items we have in the database
     **/
    public static function count_data_items(){
        global $wpdb;
        $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';

        // check if the user has disabled suggestions for an external site
        $no_suggestions = get_option('linkilo_disable_external_site_suggestions', array());
        $ignore_sites = '';
        if(!empty($no_suggestions)){
            $urls = array_keys($no_suggestions);
            $ignore = implode('\', \'', $urls);
            $ignore_sites = "WHERE `site_url` NOT IN ('$ignore')";
        }

        $item_count = $wpdb->get_var("SELECT COUNT(`post_id`) FROM {$linkilo_data_table} {$ignore_sites}");

        if(!empty($item_count)){
            return $item_count;
        }else{
            return 0;
        }
    }

    /**
     * Checks to see if there's data stored for the given url.
     **/
    public static function check_for_stored_data($site_url = ''){
        global $wpdb;
        $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';

        if(empty($site_url)){
            return false;
        }

        $site_url = trailingslashit(esc_url_raw($site_url));

        $item = $wpdb->get_var($wpdb->prepare("SELECT COUNT(`post_id`) FROM {$linkilo_data_table} WHERE `site_url` = %s LIMIT 1", $site_url));

        return (!empty($item)) ? true: false;
    }


    /**
     * Pings the site at the given url to see if it recognizes this site.
     **/
    public static function ping_site($target_url = ''){
        if(empty($target_url)){
            return false;
        }

        $query_data = self::create_initial_request_string($target_url);

        if(empty($query_data)){
            return false;
        }

        // call the other site to see if it recognizes us
        $response = self::call_site($target_url, $query_data, true);

        // if the site has responded to out call, check to make sure it has the second token
        if(!empty($response)){
            if(isset($response->sectok) && !empty($response->sectok)){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    /**
     * Updates all the sites in the network. 
     * Runs through the authentication process for all the passed sites.
     * Specific sites to update can be listed by passing them in the $urls var.
     **/
    public static function update_network_sites($query_args = array(), $urls = array()) {
        if(empty($urls)) {
            $urls = self::get_linked_sites();
        }
        
        $linked_urls = array();
        foreach($urls as $url){
            $linked_urls[] = trailingslashit(wp_http_validate_url($url));
        }

        if(empty($linked_urls)){
            return false;
        }

        $query_data = array();
        foreach($linked_urls as $url){
            $query_data[$url] = self::create_initial_request_string($url);
        }

        if(empty($query_data)){
            return false;
        }

        // call the other sites with the initial round of auths
        $responses = self::call_sites($linked_urls, $query_data);

        // if the site has responded to out call, check to make sure it has the second token
        if(!empty($responses)){

            $verified_urls = array();
            $access_tokens = array();
            foreach($responses as $response){
                if(isset($response->sectok) && !empty($response->sectok)){
                    // check the token
                    $away_site_url = self::process_secondary_request_string($response->sectok, $response->time);

                    // if the token is valid
                    if(!empty($away_site_url)){
                        $time = time();
                        // save the url for calling
                        $verified_urls[] = $away_site_url;

                        // make the request token
                        $access_tokens[$away_site_url] = self::create_access_token($response->sectok, $away_site_url, $time, 0, $query_args);
                    }
                }
            }

            if(!empty($verified_urls)){
                $responses = self::call_sites($verified_urls, $access_tokens, true);

                foreach($responses as $response){
                    if(isset($response->status) && $response->status === 200){
                        // if any site returns 200, return true.
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Call a single site.
     * 
     **/
    public static function call_site($target_url = '', $query_args = array(), $ping = false){
        if(empty($target_url)){
            return false;
        }

        if(!empty($ping)){
            $query_args['ping'] = '1';
        }

        $url = array($target_url);
        $target_args = array($target_url => $query_args);

        $response = self::call_sites($url, $target_args);

        if(!empty($response)){
            $response = $response[$target_url];
        }

        return $response;
    }


    /**
     * Save the posts data in into current sites linkiling data table
     * */
    public static function save_posts_data($data = array(), $site_url = ''){

        global $wpdb;
        $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';

        if(empty($data) || empty($site_url)){
            return false;
        }


        $count = 0;
        $insert_query = "INSERT INTO {$linkilo_data_table} (post_id, post_type, type, site_url, post_url, post_title, stemmed_title, post_modified_gmt) VALUES ";
        $insert_data = array();
        $place_holders = array();
        $limit = 1000;
        $insert_count = 0;
        $site_url = trailingslashit(esc_url_raw($site_url));
        $timezone = new DateTimeZone('UTC');


        $update_data = array();

        foreach($data as $en){
            // find out if we have the item on hand
            $stored_item = self::get_data_item($en['id'], $en['type'], $site_url);
            if (!$stored_item) {
                // item does not exists
                // create new entry
                $type = ($en['type'] === 'post' || $en['type'] === 'page') ? 'post': 'term';
                $timestamp = strtotime($en['gmt'] . ' GMT');

                if(empty($timestamp)){
                    continue;
                }

                if(function_exists('wp_date')){
                    $gmt_time = wp_date('Y-m-d H:i:s', $timestamp, $timezone);
                }else{
                    $gmt_time = date_i18n('Y-m-d H:i:s', $timestamp);
                }
                $title = sanitize_text_field($en['title']);
                $stemmed_title = Linkilo_Build_WordFunctions::getStemmedSentence($title);

                array_push(
                    $insert_data,
                    (int) $en['id'],
                    sanitize_text_field($en['type']),
                    $type,
                    $site_url,
                    esc_url_raw($en['post_url']),
                    $title,
                    $stemmed_title,
                    $gmt_time
                );
                $place_holders [] = "('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s')";

                // if we've hit the limit, save the assembled data
                if($count > $limit){
                    $insert_query .= implode(', ', $place_holders);
                    $insert_query = $wpdb->prepare($insert_query, $insert_data);
                    $insert_count += $wpdb->query($insert_query);

                    // reset the insert data vars for the next run around
                    $insert_query = "INSERT INTO {$linkilo_data_table} (post_id, post_type, type, site_url, post_url, post_title, stemmed_title, post_modified_gmt) VALUES ";
                    $insert_data = array();
                    $place_holders = array();
                    $count = 0;
                }
                $count++;
            }else{
                // item does exists
                // update existing
                array_push($update_data, $en);
            }
        }
        if(!empty($insert_data)){
            $insert_query .= implode(', ', $place_holders);
            $insert_query = $wpdb->prepare($insert_query, $insert_data);
            $insert_count += $wpdb->query($insert_query);
        }

        if (sizeof($update_data) > 0) {
            $update_status = self::update_posts_data($update_data, $site_url);
        }

        if ( 
            (!empty($insert_count) || !empty($update_status)) ||
            (intval($insert_count) === 0 && intval($update_status) === 0) 
        ) {
            return true;
        }else{
            return false;
        }
    }

    public static function update_posts_data($data_items, $site_url){

        global $wpdb;
        $data_table = $wpdb->prefix . 'linkilo_site_linking_data';
        
        if(empty($data_items)){
            return false;
        }

        $timezone = new DateTimeZone('UTC');
        $site_url = trailingslashit(esc_url_raw($site_url));
        $updated = 0;

        foreach($data_items as $item){

            $timestamp = strtotime($item['gmt'] . ' GMT');

            if(empty($timestamp)){
                continue;
            }

            if(function_exists('wp_date')){
                $gmt_time = wp_date('Y-m-d H:i:s', $timestamp, $timezone);
            }else{
                $gmt_time = date_i18n('Y-m-d H:i:s', $timestamp);
            }
            $type = ($item['type'] === 'post' || $item['type'] === 'page') ? 'post': 'term';
            $title = sanitize_text_field($item['title']);
            $stemmed_title = Linkilo_Build_WordFunctions::getStemmedSentence($title);

            $update = array(
                'post_title' => $title,
                'stemmed_title' => $stemmed_title,
                'post_url' => esc_url_raw($item['post_url']),
                'post_modified_gmt' => $gmt_time
            );

            $where = array('site_url' => $site_url, 'post_id' => (int)$item['id'], 'type' => $type);

            $update_status = $wpdb->update($data_table, $update, $where);

            if(!empty($update_status)){
                $updated += $update_status;
            }
        }

        return $updated;
    }
    /**
     * Saves the data from the away site into the database
     * @param string $data
     **/
    public static function save_data($data = array(), $site_url = ''){
        global $wpdb;
        $linkilo_data_table = $wpdb->prefix . 'linkilo_site_linking_data';

        if(empty($data) || empty($site_url)){
            return false;
        }

        $count = 0;
        $insert_query = "INSERT INTO {$linkilo_data_table} (post_id, post_type, type, site_url, post_url, post_title, stemmed_title, post_modified_gmt) VALUES ";
        $insert_data = array();
        $place_holders = array();
        $limit = 1000;
        $insert_count = 0;
        $site_url = trailingslashit(esc_url_raw($site_url));
        $timezone = new DateTimeZone('UTC');

        foreach($data as $dat){

            $type = ($dat->type === 'post') ? 'post': 'term';
            $timestamp = strtotime($dat->post_modified_gmt . ' GMT');

            if(empty($timestamp)){
                continue;
            }

            if(function_exists('wp_date')){
                $gmt_time = wp_date('Y-m-d H:i:s', $timestamp, $timezone);
            }else{
                $gmt_time = date_i18n('Y-m-d H:i:s', $timestamp);
            }
            $title = sanitize_text_field($dat->post_title);
            $stemmed_title = Linkilo_Build_WordFunctions::getStemmedSentence($title);

            array_push(
                $insert_data,
                (int) $dat->post_id,
                sanitize_text_field($dat->post_type),
                $type,
                $site_url,
                esc_url_raw($dat->post_url),
                $title,
                $stemmed_title,
                $gmt_time
            );
            $place_holders [] = "('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s')";

            // if we've hit the limit, save the assembled data
            if($count > $limit){
                $insert_query .= implode(', ', $place_holders);
                $insert_query = $wpdb->prepare($insert_query, $insert_data);
                $insert_count += $wpdb->query($insert_query);

                // reset the insert data vars for the next run around
                $insert_query = "INSERT INTO {$linkilo_data_table} (post_id, post_type, type, site_url, post_url, post_title, stemmed_title, post_modified_gmt) VALUES ";
                $insert_data = array();
                $place_holders = array();
                $count = 0;
            }
            $count++;
        }

        if(!empty($insert_data)){
            $insert_query .= implode(', ', $place_holders);
            $insert_query = $wpdb->prepare($insert_query, $insert_data);
            $insert_count += $wpdb->query($insert_query);
        }

        if(!empty($insert_count)){
            return $insert_count;
        }else{
            return false;
        }
    }

    /**
     * Updates existing data items from extenal sites
     **/
    public static function update_data($data_items, $site_url){
        global $wpdb;
        $data_table = $wpdb->prefix . 'linkilo_site_linking_data';
        
        if(empty($data_items)){
            return false;
        }

        $timezone = new DateTimeZone('UTC');
        $site_url = trailingslashit(esc_url_raw($site_url));
        $updated = 0;

        foreach($data_items as $item){

            $timestamp = strtotime($item->post_modified_gmt . ' GMT');

            if(empty($timestamp)){
                continue;
            }

            if(function_exists('wp_date')){
                $gmt_time = wp_date('Y-m-d H:i:s', $timestamp, $timezone);
            }else{
                $gmt_time = date_i18n('Y-m-d H:i:s', $timestamp);
            }
            $type = ($item->type === 'post') ? 'post': 'term';
            $title = sanitize_text_field($item->post_title);
            $stemmed_title = Linkilo_Build_WordFunctions::getStemmedSentence($title);

            $update = array(
                'post_title' => $title,
                'stemmed_title' => $stemmed_title,
                'post_url' => esc_url_raw($item->post_url),
                'post_modified_gmt' => $gmt_time
            );

            $where = array('site_url' => $site_url, 'post_id' => (int)$item->post_id, 'type' => $type);

            $update_status = $wpdb->update($data_table, $update, $where);

            if(!empty($update_status)){
                $updated += $update_status;
            }
        }

        return $updated;
    }


    /**
     * Get the stored hash for the current url if it exists.
     * 
     * @param string $target_url The site to lookup the hash for. 
     * @return string|bool Returns the hash if stored, false if it's not.
     **/
    public static function get_secondary_request_hash_data($target_url = ''){
        if(empty($target_url)){
            return false;
        }

        $stored_hashes = get_option('linkilo_stored_request_hashes', array());
        $time = time();
        $target_url = trailingslashit(esc_url_raw($target_url));

        // go over all the hashes
        foreach($stored_hashes as $hash_data){
            if($hash_data['target_url'] === $target_url && ($hash_data['expiration'] > $time)){
                // return the stored hash
                return $hash_data;
            }
        }

        return false;
    }

    /**
     * Check site entry
     * */
    public static function check_site_entry_reg_or_link($site_url = ''){
        if(!empty($site_url)){
            $site_url = trailingslashit(esc_url_raw($site_url));

            // regstered sites
            $regsd_sites = self::get_registered_sites();

            // linked sites
            $linkd_sites = self::get_linked_sites();

            $site_exists = false;
            foreach($regsd_sites as $site){
                if($site === $site_url){
                    $site_exists = true;
                    break;
                }
            }

            foreach($linkd_sites as $site){
                if($site === $site_url){
                    $site_exists = true;
                    break;
                }
            }

            if($site_exists){
                // yes site exists
                return true;
            }else{
                // site not exists
                return false;
            }
        }

        // as no matching entry is there
        return null;
    }

    /**
     * Updates the list of linked sites with the supplied site url.
     * Checks to make sure duplicate urls aren't added to the list.
     * 
     * @param string $site_url The url of the site that's been validated and we're saving to the list.
     **/
    public static function update_registered_sites($site_url = ''){
        if(!empty($site_url)){
            $site_url = trailingslashit(esc_url_raw($site_url));
            $sites = self::get_registered_sites();
            $site_exists = false;
            foreach($sites as $site){
                if($site === $site_url){
                    $site_exists = true;
                    break;
                }
            }

            if(!$site_exists){
                $sites[] = $site_url;
                update_option('linkilo_registered_sites', $sites);
                return true;
            }else{
                return false;
            }
        }

        return null;
    }

    /**
     * Updates the list of linked sites with the supplied site url.
     * Checks to make sure duplicate urls aren't added to the list.
     * 
     * @param string $site_url The url of the site that's been validated and we're saving to the list.
     **/
    public static function update_linked_sites($site_url = ''){
        $ret = false;
        if(!empty($site_url)){
            $site_url = trailingslashit(esc_url_raw($site_url));
            $sites = self::get_linked_sites();
            $site_exists = false;
            foreach($sites as $site){
                if($site === $site_url){
                    $site_exists = true;
                    break;
                }
            }

            if(!$site_exists){
                $sites[] = $site_url;
                update_option('linkilo_linked_sites', $sites);
                $ret = true;
            }
        }
        return $ret;
    }

    /**
     * Gets an array of all registered sites.
     * A site can be registered in the site linking settings without being successfully linked.
     * 
     * @return array $linked_sites
     **/
    public static function get_registered_sites(){
        $registered_sites = get_option('linkilo_registered_sites', array());

        return $registered_sites;
    }

    /**
     * Gets an array of all linked sites.
     * 
     * @return array $linked_sites
     **/
    public static function get_linked_sites(){
        $linked_sites = get_option('linkilo_linked_sites', array());

        return $linked_sites;
    }

    /**
     * Remove entry from table once remove is processed by the user
     * */
    public static function remove_connection_entry($id = null) {

        if (is_null($id) || empty($id) || $id === '') {
            return false;
        }

        global $wpdb;
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

        // expire_status 
        // 1: it has been deleted from this site
        // Null:  no action till now
        $update_query = $wpdb->prepare("
            UPDATE {$entry_table} 
            SET {$entry_table}.`req_expire_status` = %d
            WHERE {$entry_table}.`id` = %d",
            1, 
            $id
        );
        $q_status = $wpdb->query($update_query);

        if($wpdb->last_error !== '') :
            return false;
        else:
            return true;
        endif;
    } 
    /**
     * Removes a site from the linked site list and deletes it's stored data
     * 
     * @param string $site_url The home url of the site that we're removing from the site.
     * @return bool $removed Returns True if the site has been removed, and False if it hasn't been.
     **/
    public static function remove_linked_site($site_url = ''){
        $removed = false;
        if(!empty($site_url)){
            $sites = self::get_linked_sites();
            $found_site = false;
            foreach($sites as $key => $site){
                if($site === $site_url){
                    $found_site = true;
                    unset($sites[$key]);
                }
            }

            // if the site has been found
            if($found_site){
                // clear the site data from the db
                $cleared = self::clear_external_site_data($site_url);
            }

            // update the list
            $removed = update_option('linkilo_linked_sites', $sites);

            // and unregister the site
            self::remove_registered_site($site_url);
        }

        return $removed;
    }


    /**
     * Removes a site from the registered site list.
     * 
     * @param string $site_url The home url of the site that we're removing from the registered list.
     * @return bool $removed Returns True if the site has been removed, and False if it hasn't been.
     **/
    public static function remove_registered_site($site_url = ''){
        $unregistered = false;
        if(!empty($site_url)){
            $sites = self::get_registered_sites();
            $found_site = false;
            foreach($sites as $key => $site){
                if($site === $site_url){
                    $found_site = true;
                    unset($sites[$key]);
                }
            }

            if($found_site){
                // update the list
                $unregistered = update_option('linkilo_registered_sites', $sites);
            }
        }

        return $unregistered;
    }

    public static function check_if_site_added($site_url = ''){
        if(!empty($site_url)){
            $sites = self::get_linked_sites();
            foreach($sites as $key => $site){
                if($site === $site_url){
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Gets an array of linked site domains
     * @return array $domains An array of linked site domains
     **/
    public static function get_linked_site_domains(){
        $domains = array();
        $sites = self::get_linked_sites();
        foreach($sites as $key => $site){
            $domain = wp_parse_url($site, PHP_URL_HOST);
            if(!empty($domain)){
                $domains[] = $domain;
            }
        }

        return $domains;
    }

    /**
     * Process request accept and make site visible on settings screen
     * */
    public static function linkilo_register_selected_site_option($url = null, $request = false) {
        // set default return variable
        $reg = false;

        if ($request && !is_null($url)) {
            // if the license is valid, save the site to the registry
            $saved = self::update_registered_sites($url);
            $linked = self::update_linked_sites($url);
            if($saved){
                $reg = true;
            }elseif($saved === false){
                // update $reg as site is saved 
                $reg = true;
            }else{
                $reg = false;
            }
        }

        return $reg;
    }


    /**
     * Handle function for registration ajax
     * */
    public static function ajax_register_selected_site() {
        $sent = false;
        Linkilo_Build_Root::verify_nonce('register-site-nonce');

        if(!isset($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("No Url", 'linkilo'), 
                        'text' => __("The site url field is empty, please add the url of the site you want to link to.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }else{
            $url = wp_http_validate_url($_POST['url']);
            if(empty($url)) {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Url Format Error", 'linkilo'), 
                            'text' => __("The given url was not in the necessary format. Please enter the url as it appears in your browser's address bar, including the protocol (https or http).", 
                                'linkilo')
                        )
                    )
                );
                wp_die();    
            }

            $url = trailingslashit($url);
        }

        if ($url === trailingslashit( esc_url(site_url()) )) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Invalid Request!", 'linkilo'), 
                        'text' => __("Please enter a valid home URL of other site.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }
        $old = self::get_old_connected_site_entry($url);

        $site_exist = self::check_site_entry_reg_or_link($url);

        $call = true;

        if ($old) {
            if (intval($old['req_type']) === 0 && is_null($old['req_status'])) {
                $call = false;
                // this site has already sent a request 
                // show user info about that 
                wp_send_json(
                    array(
                        'info' => array(
                            'title' => __("Request Already Sent", 'linkilo'), 
                            'text' => __("Likilo has already sent a connection request to \n ".$url." \n site, valid till ".$old['req_expire_time'].". \n\n Please check summary dashboard under linkilo on \n ".$url." \n and respond to the request accordingly. \n\n If requests are not visible check the option for showing request entries in linkilo settings custom setting tab.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }

            if (intval($old['req_type']) === 1 && is_null($old['req_status'])) {
                $call = false;
                // this site has been request by the site they are trying to connect to
                // show user info about that 
                wp_send_json(
                    array(
                        'info' => array(
                            'title' => __("Pending Response!", 'linkilo'), 
                            'text' => __("The site \n ".$url." \n has already sent a connection request to this site. \n\n Please check summary dashboard under linkilo on \n ".$url." \n and respond to the request accordingly. \n\n If requests are not visible check the option for showing request entries in linkilo settings custom setting tab.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }

            // req_status 1: Accepted, 0: Declined
            // req_type 0: outgoing, 1: incoming
            // site exist and has an request status accepted either req_type incoming or outgoing
            if (
                $site_exist && 
                (intval($old['req_type']) === 0 || intval($old['req_type']) === 1) &&
                intval($old['req_status']) === 1
            ) {
                $call = false;
                wp_send_json(    
                    array(
                        'info' => array(
                            'title' => __("Already Connected!", 'linkilo'), 
                            'text' => __("The site has already been connected to this site. And sites are interlinked. \n\n You can process posts import.", 'linkilo')
                        )
                    )
                );
                wp_die();
            }
        }

        $unique_code = null;
        if (
            isset($_POST['unique_code']) &&
            !empty(trim($_POST['unique_code']))
        ) {
            $unique_code = $_POST['unique_code'];
            // Try to get the old code
            $site_code_option = get_option( 'linkilo_link_external_sites_access_code' );
        }else{
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Unique Code Error", 'linkilo'), 
                        'text' => __("The generated unique code has some issues. Please try again after doing page reload.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        if (is_null($site_exist)) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Format Error", 'linkilo'), 
                        'text' => __("The given url was not in the necessary format. Please enter the url as it appears in your browser's address bar.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        if ($call && !$old && !$site_exist) {
            $call_site = trailingslashit($url)."wp-json/linkilo/v1/postConnectionRequest";

            /*paramas encode */
            $calling_host = parse_url(site_url(), PHP_URL_HOST);
            $called_host = parse_url($url, PHP_URL_HOST);

            $calling_host_ip = gethostbyname($calling_host);
            $called_host_ip = gethostbyname($called_host);


            $data_set = array(
                $calling_host,
                $calling_host_ip,
                $called_host,
                $called_host_ip
            );
            $a_string = implode("=X=",$data_set);

            $key = self::linkilo_generate_unique_params($a_string,'e');
            /*paramas encode ends*/
            
            /*Post resuest starts*/        
            $site_url_from = site_url();
            $site_url_to = $url;
            $h = self::linkilo_h_get($site_url_to);

            $body = array(
                'code' => $unique_code,
                'from_site' => $site_url_from,
                'to_site' => $site_url_to,
                'req_expiration' => 2,
                'h' => $h
            );

            $call_response = wp_remote_post(
                $call_site,
                array(
                    'headers'     => array(
                        'Content-Type' => 'application/json; charset=utf-8',
                        'Authorization' => 'Bearer ' . base64_encode( 'linkilo:site_connection_request' ),
                        'key' => $key,
                        'cache-control' => 'no-cache',
                        'timeout'     => 60, // added
                        'redirection' => 5,  // added
                        'blocking'    => true, // added
                        'httpversion' => '1.0',
                        'sslverify' => false,
                    ),
                    'body'        => json_encode($body),
                    'method'      => 'POST',
                    'data_format' => 'body',
                )
            );

            $reponse_body = json_decode(wp_remote_retrieve_body($call_response), true);
            $response_code = wp_remote_retrieve_response_code($call_response);

            /*Post resuest ends*/
            if (
                ($response_code == 401 && $reponse_body['code'] == 'auth_401') ||
                ($response_code == 403 && $reponse_body['code'] == 'forb_403') ||
                ($response_code == 204 && $reponse_body['code'] == 'forb_204') ||
                ($response_code == 400 && $reponse_body['code'] == 'en_400')
            ) {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Connection Error!", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            } elseif ($response_code == 404) {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Connection Error!", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please Install/Activate Linkilo on ".$url." and try again after enabling \"Add external site for link suggestions\" from Linkilo->Settings->Custom Settings.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            } elseif($response_code == 500) {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Connection Error!", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n The requested server can not processs the request at the moment. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            } elseif($response_code == 200 && $reponse_body['code'] == 'e_ex_200') {
                wp_send_json(
                    array(
                        'success' => array(
                            'title' => __("Status Updated", 'linkilo'), 
                            'text' => __("Request Status has been updated. \n\n You can respond to the request from linkilo summary dashboard on \n ".$url.".", 'linkilo')
                        )
                    )
                );
                wp_die();    
            } elseif($response_code == 200 && $reponse_body['code'] == 'en_200') {
                $sent = true;
                $data = array(
                    'code' => $unique_code,
                    'from_site' => $site_url_from,
                    'to_site' => $site_url_to,
                    'req_expiration' => 2,
                );
                $entry = self::linkilo_add_connection_entry_row($data);
                if ($entry) {
                    wp_send_json(
                        array(
                            'success' => array(
                                'title' => __("Request Sent", 'linkilo'), 
                                'text' => __("Likilo has sent a connection request to \n ".$url." \n site. \n\n Please check summary dashboard under linkilo on \n ".$url." \n and respond to the request accordingly. \n\n The request will be valid till 2 Days. \n After that you need to request again for connection.", 'linkilo')
                            )
                        )
                    );
                    wp_die();    
                }else{
                    wp_send_json(
                        array(
                            'success' => array(
                                'title' => __("Request Sent, Entry Error!", 'linkilo'), 
                                'text' => __("Cannot make entry. \n\n Likilo has sent a connection request to \n ".$url." \n site. \n\n Please check summary dashboard under linkilo on \n ".$url." \n and respond to the request accordingly. \n\n The request will be valid till 2 Days. \n After that you need to request again for connection.", 'linkilo')
                            )
                        )
                    );
                    wp_die();    
                }
            } elseif ($response_code == 400 && $reponse_body['code'] == 'param_400') {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Parameters Missing", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            } elseif ($response_code == 400 && $reponse_body['code'] == 'sl_di_400') {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Site Connection Error", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please enable \"Add external site for link suggestions\" from Settings and after that try to register your site or connect with support for better solution.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }
        }
    }   

    /**
     * Entry the data row into connection entry table on succesfull request
     * */
    public static function linkilo_add_connection_entry_row($data = array()){

        $ret = false;

        if (sizeof($data) > 5) {
            return $ret;
        }

        global $wpdb;
        $from = trailingslashit(esc_url_raw($data['from_site']));
        $to = trailingslashit(esc_url_raw($data['to_site']));
        $unique_code = $data['code'];

        $exp =intval($data['req_expiration']);
        $exp_date = date('Y:m:d', strtotime(' +'.$exp.' day'));
        // req_type 
        // 0: outgoing
        // 1: incoming
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';
        $wpdb->insert(
            $entry_table,
            array( 
                'site_from_url' => $from,
                'site_to_url' => $to,
                'unique_code' => $unique_code,
                'req_expire_time' => $exp_date,
                'req_type' => 0
            ), 
            array( 
                '%s', 
                '%s', 
                '%s', 
                '%s', 
                '%d', 
            ) 
        );

        $lastid = $wpdb->insert_id;

        if (!empty($lastid)) {
            $ret = true;
        }

        return $ret;
    }
    /**
     * Performs the site link validating and saving on an ajax call.
     **/
    public static function ajax_link_selected_site(){
        Linkilo_Build_Root::verify_nonce('link-site-nonce');

        if(!isset($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("No Url", 'linkilo'), 
                        'text' => __("The site url field is empty, please add the url of the site you want to link to.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }else{
            $url = trailingslashit(wp_http_validate_url($_POST['url']));
            if(empty($url)){
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Url Format Error", 'linkilo'), 
                            'text' => __("The given url was not in the necessary format. Please enter the url as it appears in your browser's address bar, including the protocol (https or http).", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }

            $url = trailingslashit($url);
        }

        // set up the data table if it's not created
        self::create_data_table();

        if(empty($license_active)){
            // ping the other site to see if this one has alrady been added
            $ping_result = self::ping_site($url);
                // create the action buttons
            $import_button = '<a href="#" class="linkilo-refresh-post-data button-primary" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'download-site-data-nonce') . '">' . __('Import Post Data', 'linkilo') . '</a>';
            $suggestions_button = '<a href="#" class="linkilo-external-site-suggestions-toggle button-primary site-linking-button" data-suggestions-enabled="1" data-site-url="' . esc_url($url) . '" data-enable-text="' . __('Enable Suggestions', 'linkilo') . '" data-disable-text="' . __('Disable Suggestions', 'linkilo') . '" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'toggle-external-site-suggestions-nonce') . '">' . __('Disable Suggestions', 'linkilo') . '</a>';
            $unlink_button = '<a href="#" class="linkilo-unlink-site-button button-primary button-purple" data-nonce="' . wp_create_nonce(wp_get_current_user()->ID . 'unlink-site-nonce') . '">' . __('Remove Site', 'linkilo') . '</a>';
                // save the url to the list of sites
            self::update_linked_sites($url);
                // and tell the user the site is linked
            wp_send_json(
                array(
                    'success' => array(
                        'title' => __("Site Linked!", 'linkilo'), 
                        'text' => __("The site has been linked to this one and data can be shared between them!", 'linkilo'), 
                        'unlink_button' => $unlink_button, 
                        'import_button' => $import_button, 
                        'suggestions_button' => $suggestions_button
                    )
                )
            );
            wp_die();    
        }
    }

    public static function linkilo_h_get($url){
        $name = LINKILO_PLUGIN_BASE_NAME; 
        $s_h = parse_url($url, PHP_URL_HOST);
        $data = array(
            $name,
            $s_h
        );
        $bind_key =  get_option(LINKILO_B_K_OPTIONS);

        $hash =  hash_hmac('sha512', http_build_query($data), $bind_key);

        return $hash;
    }

    /**
     * Toggles if suggestions will be made to external sites on ajax call
     **/
    public static function ajax_outer_site_suggestion_toggle(){
        Linkilo_Build_Root::verify_nonce('toggle-external-site-suggestions-nonce');

        if(!isset($_POST['url']) || empty($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Missing", 'linkilo'), 
                        'text' => __("The site url was missing from the unregister attempt. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = wp_http_validate_url($_POST['url']);

        if(empty($url)){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Format Error", 'linkilo'), 
                        'text' => __("The site url was misformatted. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = trailingslashit($url);

        $current_status = isset($_POST['suggestions_enabled']) ? (int)$_POST['suggestions_enabled']: 0;

        $no_suggestions_sites = get_option('linkilo_disable_external_site_suggestions', array());

        // if suggestions are currently enabled, toggle them off
        if($current_status){
            $no_suggestions_sites[$url] = 1;
        }else{
            if(isset($no_suggestions_sites[$url])){
                unset($no_suggestions_sites[$url]);
            }
        }

        $updated = update_option('linkilo_disable_external_site_suggestions', $no_suggestions_sites);

        if($updated){
            if($current_status){
                wp_send_json(
                    array(
                        'success' => array(
                            'title' => __("Site Suggestions Disabled!", 'linkilo'), 
                            'text' => __("Linkilo will not show suggestions to this external site.")
                        )
                    )
                );
                wp_die();    
            }else{
                wp_send_json(
                    array(
                        'success' => array(
                            'title' => __("Site Suggestions Enabled!", 'linkilo'), 
                            'text' => __("Linkilo will now show suggestions to the external site.")
                        )
                    )
                );
                wp_die();    
            }
        }else{
            wp_send_json(
                array(
                    'info' => array(
                        'title' => __("Site Setting Not Saved", 'linkilo'), 
                        'text' => __("There was an error that prevented Linkilo from saving the option. Please reload the page and try again.")
                    )
                )
            );
            wp_die();    
        }
    }


    /**
     * Removes a registered site by ajax call
     * 
     **/
    public static function ajax_remove_registered_site(){
        Linkilo_Build_Root::verify_nonce('unregister-site-nonce');

        if(!isset($_POST['url']) || empty($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Missing", 'linkilo'), 
                        'text' => __("The site url was missing from the unregister attempt. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = wp_http_validate_url($_POST['url']);

        if(empty($url)){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Format Error", 'linkilo'), 
                        'text' => __("The site url was misformatted. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = trailingslashit($url);

        $removed = self::remove_registered_site($url);

        if($removed){
            wp_send_json(
                array(
                    'success' => array(
                        'title' => __("Site Unregistered!", 'linkilo'), 
                        'text' => __("The external site has been removed from this site's list of registered sites.")
                    )
                )
            );
            wp_die();    
        }else{
            wp_send_json(
                array(
                    'info' => array(
                        'title' => __("Site Could Not Be Unregistered", 'linkilo'), 
                        'text' => __("The external site could not be removed from the site list. Please reload the page and try again.")
                    )
                )
            );
            wp_die();    
        }
    }


    /**
     * Removes a linked site by ajax call
     * 
     **/
    public static function ajax_remove_linked_site(){
        Linkilo_Build_Root::verify_nonce('unlink-site-nonce');

        if(!isset($_POST['url']) || empty($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Missing", 'linkilo'), 
                        'text' => __("The site url was missing from the unlink attempt. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = wp_http_validate_url($_POST['url']);

        if(empty($url)){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Format Error", 'linkilo'), 
                        'text' => __("The site url was misformatted. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = trailingslashit($url);
        $rec_id = (int) $_POST['url_id'];

        $remove_entry = self::remove_connection_entry($rec_id);

        if ($remove_entry) {
            $removed = self::remove_linked_site($url);
        }else{
            wp_send_json(
                array(
                    'info' => array(
                        'title' => __("Site Could Not Be Removed", 'linkilo'), 
                        'text' => __("The external site could not be removed from the site list. Please reload the page and try again.")
                    )
                )
            );
            wp_die();    
        }

        if($removed){
            wp_send_json(
                array(
                    'success' => array(
                        'title' => __("Site Removed!", 'linkilo'), 
                        'text' => __("The external site has been removed from this site's list of sites. Just a reminder, the external site may need to have this site removed from its list as well.")
                    )
                )
            );
            wp_die();    
        }else{
            wp_send_json(
                array(
                    'info' => array(
                        'title' => __("Site Could Not Be Removed", 'linkilo'), 
                        'text' => __("The external site could not be removed from the site list. Please reload the page and try again.")
                    )
                )
            );
            wp_die();    
        }
    }


    /**
     * Call to site and get the data
     * (This function works for single site data call operation i.e. from settings tab when import or refresh operation performed)
     * */
    public static function ajax_download_all_posts_of_linked_site(){
        Linkilo_Build_Root::verify_nonce('download-site-data-nonce');

        if(!isset($_POST['url']) || empty($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Missing", 'linkilo'), 
                        'text' => __("The site url was missing from the unlink attempt. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = wp_http_validate_url($_POST['url']);

        if(empty($url)){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Format Error", 'linkilo'), 
                        'text' => __("The site url was misformatted. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        // if the site has been authed and this is the first go round, clear the existing site data
        if(isset($_POST['reset']) && !empty($_POST['reset'])){
            $cleared = self::clear_external_site_data($url);

            if(empty($cleared)){
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Could Not Clear Existing Data", 'linkilo'), 
                            'text' => __("Linkilo could not erase the site's existing post data from the database. Please reload the page and try again.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }
        }
        
        $to = trailingslashit($url);
        $from = trailingslashit(site_url());

        $rec_id = (int) $_POST['url_id'];
        $unique_code = self::get_code_of_site($rec_id);

        $call_site = trailingslashit($to)."wp-json/linkilo/v1/getPostsData";

        /*paramas encode */
        $calling_host = parse_url($from, PHP_URL_HOST);
        $called_host = parse_url($to, PHP_URL_HOST);

        $calling_host_ip = gethostbyname($calling_host);
        $called_host_ip = gethostbyname($called_host);


        $data_set = array(
            $calling_host,
            $calling_host_ip,
            $called_host,
            $called_host_ip
        );
        $a_string = implode("=X=",$data_set);

        $key = self::linkilo_generate_unique_params($a_string,'e');
        /*paramas encode ends*/

        /*Post request starts*/        
        $site_url_from = site_url();
        $site_url_to = $to;
        $h = self::linkilo_h_get($to);

        $body = array(
            'code' => $unique_code,
            'h' => $h,
            'l' => self::$query_limit
        );

        $call_site = add_query_arg($body, esc_url_raw(trailingslashit($call_site)));

        $call_response = wp_remote_get(
            $call_site,
            array(
                'headers'     => array(
                    'Content-Type' => 'application/json; charset=utf-8',
                    'Authorization' => 'Bearer ' . base64_encode( 'linkilo:get_site_posts_limited_cols' ),
                    'key' => $key,
                    'cache-control' => 'no-cache',
                        'timeout'     => 60, // added
                        'redirection' => 5,  // added
                        'blocking'    => true, // added
                        'httpversion' => '1.0',
                        'sslverify' => false,
                    ),
                'body' => null,
            )
        );
        /*Post request ends*/

        $reponse_body = json_decode(wp_remote_retrieve_body($call_response), true);
        $response_code = wp_remote_retrieve_response_code($call_response);

        if (
            ($response_code == 401 && $reponse_body['code'] == 'auth_401') ||
            ($response_code == 403 && $reponse_body['code'] == 'forb_403') ||
            ($response_code == 204 && $reponse_body['code'] == 'forb_204') ||
            ($response_code == 400 && $reponse_body['code'] == 'c_400')
        ) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif ($response_code == 400 && $reponse_body['code'] == 'en_400') {
            // showing this cause the site is not in the list of connected sites and has been removed
            // process removal
            $remove_entry = self::remove_connection_entry($rec_id);
            $removed = null;
            if ($remove_entry) {
                $removed = self::remove_linked_site($url);
            }

            if ($remove_entry && $removed && !is_null($removed)) {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Connection Error!", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please perform the connection process to connect the site and transfer posts after some time or connect with support for better solution.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }else{
                wp_send_json(
                    array(
                        'info' => array(
                            'title' => __("Process error", 'linkilo'), 
                            'text' => __("The external site could not be removed from the site list. Please reload the page and try again.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }
        } elseif ($response_code == 400 && $reponse_body['code'] == 'en_p_400') {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Process Error!", 'linkilo'), 
                        'text' => __("Likilo is unable process entries at the moment. \n\n Please try after some time.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif ($response_code == 404) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please Install/Activate Linkilo on ".$url." and try again after enabling \"Add external site for link suggestions\" from Linkilo->Settings->Custom Settings.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif($response_code == 500) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n The requested server can not processs the request at the moment. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif ($response_code == 400 && $reponse_body['code'] == 'sl_di_400') {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Site Connection Error", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please enable \"Add external site for link suggestions\" from Settings and after that try to register your site or connect with support for better solution.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif($response_code == 200 && $reponse_body['code'] == 'en_200') {
                // if there are items
            if(!empty($reponse_body['posts']) && $reponse_body['size'] > 0){
                    // save them
                $saved = self::save_posts_data($reponse_body['posts'], $url);

                if ($saved) {
                    wp_send_json(
                        array(
                            'success' => array(
                                'title' => __("Download and Update complete!", 'linkilo'), 
                                'text' => __("All of the post data has been downloaded saved and updated.", 'linkilo')
                            )
                        )
                    );
                    wp_die();    
                }else{
                    wp_send_json(
                        array(
                            'error' => array(
                                'title' => __("Data processing error", 'linkilo'), 
                                'text' => __("Cannot Process Some of the Results!", 'linkilo')
                            )
                        )
                    );
                    wp_die();    
                }
            }
        }
    }


    /**
     * Downloads all the post data from a single site by a stepped process.
     * This function works when the process of scan is performed
     **/
    public static function ajax_download_all_posts(){
        /*PRESET STARTS*/
        Linkilo_Build_Root::verify_nonce('download-site-data-nonce');

        if(!isset($_POST['url']) || empty($_POST['url'])){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Missing", 'linkilo'), 
                        'text' => __("The site url was missing from the unlink attempt. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }

        $url = wp_http_validate_url($_POST['url']);

        if(empty($url)){
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Url Format Error", 'linkilo'), 
                        'text' => __("The site url was misformatted. Please reload the page and try again.", 'linkilo')
                    )
                )
            );
            wp_die();    
        }
        /*PRESET ENDS*/

        /*Get post data from site starts*/
        global $wpdb;
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';
        $entry = $wpdb->get_var("
            SELECT id 
            FROM {$entry_table} 
            WHERE ( site_from_url LIKE '%$url%' OR site_to_url LIKE '%$url%')
            AND site_from_url IS NOT NULL 
            AND site_to_url IS NOT NULL 
            AND unique_code IS NOT NULL 
            AND site_from_url <> ''
            AND unique_code <> ''
            AND site_to_url <> ''
            "
        );

        $to = trailingslashit($url);
        $from = trailingslashit(site_url());

        $rec_id = intval($entry);
        $unique_code = self::get_code_of_site($rec_id);

        $call_site = trailingslashit($to)."wp-json/linkilo/v1/getPostsData";

        /*paramas encode */
        $calling_host = parse_url($from, PHP_URL_HOST);
        $called_host = parse_url($to, PHP_URL_HOST);

        $calling_host_ip = gethostbyname($calling_host);
        $called_host_ip = gethostbyname($called_host);


        $data_set = array(
            $calling_host,
            $calling_host_ip,
            $called_host,
            $called_host_ip
        );
        $a_string = implode("=X=",$data_set);

        $key = self::linkilo_generate_unique_params($a_string,'e');
        /*paramas encode ends*/

        /*Post request starts*/        
        $site_url_from = site_url();
        $site_url_to = $to;
        $h = self::linkilo_h_get($to);

        $body = array(
            'code' => $unique_code,
            'h' => $h,
            'l' => self::$query_limit
        );

        $call_site = add_query_arg($body, esc_url_raw(trailingslashit($call_site)));

        $call_response = wp_remote_get(
            $call_site,
            array(
                'headers'     => array(
                    'Content-Type' => 'application/json; charset=utf-8',
                    'Authorization' => 'Bearer ' . base64_encode( 'linkilo:get_site_posts_limited_cols' ),
                    'key' => $key,
                    'cache-control' => 'no-cache',
                        'timeout'     => 60, // added
                        'redirection' => 5,  // added
                        'blocking'    => true, // added
                        'httpversion' => '1.0',
                        'sslverify' => false,
                    ),
                'body' => null,
            )
        );
        /*Post request ends*/

        $reponse_body = json_decode(wp_remote_retrieve_body($call_response), true);
        $response_code = wp_remote_retrieve_response_code($call_response);

        if (
            ($response_code == 401 && $reponse_body['code'] == 'auth_401') ||
            ($response_code == 403 && $reponse_body['code'] == 'forb_403') ||
            ($response_code == 204 && $reponse_body['code'] == 'forb_204') ||
            ($response_code == 400 && $reponse_body['code'] == 'c_400')
        ) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __('Connection Error!', 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif ($response_code == 400 && $reponse_body['code'] == 'en_400') {
            // showing this cause the site is not in the list of connected sites and has been removed
            // process removal
            $remove_entry = self::remove_connection_entry($rec_id);
            $removed = null;
            if ($remove_entry) {
                $removed = self::remove_linked_site($url);
            }

            if ($remove_entry && $removed && !is_null($removed)) {
                wp_send_json(
                    array(
                        'error' => array(
                            'title' => __("Connection Error!", 'linkilo'), 
                            'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please perform the connection process to connect the site and transfer posts after some time or connect with support for better solution.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }else{
                wp_send_json(
                    array(
                        'info' => array(
                            'title' => __("Process error", 'linkilo'), 
                            'text' => __("The external site could not be removed from the site list. Please reload the page and try again.", 'linkilo')
                        )
                    )
                );
                wp_die();    
            }
        } elseif ($response_code == 400 && $reponse_body['code'] == 'en_p_400') {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Process Error!", 'linkilo'), 
                        'text' => __("Likilo is unable process entries at the moment. \n\n Please try after some time.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif ($response_code == 404) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please Install/Activate Linkilo on ".$url." and try again after enabling \"Add external site for link suggestions\" from Linkilo->Settings->Custom Settings.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif($response_code == 500) {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Connection Error!", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n The requested server can not processs the request at the moment. \n\n Please try after some time or connect with support for better solution.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif ($response_code == 400 && $reponse_body['code'] == 'sl_di_400') {
            wp_send_json(
                array(
                    'error' => array(
                        'title' => __("Site Connection Error", 'linkilo'), 
                        'text' => __("Likilo is unable to establish connection with the requested website. \n\n Please enable \"Add external site for link suggestions\" from Settings and after that try to register your site or connect with support for better solution.", 'linkilo')
                    )
                )
            );
            wp_die();    
        } elseif($response_code == 200 && $reponse_body['code'] == 'en_200') {
                // if there are items
            if(!empty($reponse_body['posts']) && $reponse_body['size'] > 0){
                    // save them
                $saved = self::save_posts_data($reponse_body['posts'], $url);

                if ($saved) {
                    wp_send_json(
                        array(
                            'success' => array(
                                'title' => __("Download and Update complete!", 'linkilo'), 
                                'text' => __("All of the post data has been downloaded saved and updated.", 'linkilo')
                            )
                        )
                    );
                    wp_die();    
                }else{
                    wp_send_json(
                        array(
                            'error' => array(
                                'title' => __("Data processing error", 'linkilo'), 
                                'text' => __("Cannot Process Some of the Results!", 'linkilo')
                            )
                        )
                    );
                    wp_die();    
                }
            }
        }
        /*Get post data from site ends*/
    }

    public static function get_code_of_site($id = null){
        if (is_null($id)) {
            return false;
        }

        global $wpdb;
        $entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

        $id = intval($id);
        $entry = $wpdb->get_var("
            SELECT unique_code 
            FROM {$entry_table} 
            WHERE id = $id
            AND site_from_url IS NOT NULL 
            AND site_to_url IS NOT NULL 
            AND unique_code IS NOT NULL 
            AND site_from_url <> ''
            AND unique_code <> ''
            AND site_to_url <> ''
            "
        );

        return $entry;
    }

    public static function generate_random_id_string(){
        $string = 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipiscingvelit sed quia non numquam do eius modi tempora incididunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam quis nostrumd exercitationem ullam corporis suscipit laboriosam nisi ut aliquid ex ea commodi consequatur';
        $string .= '12478157109868713518973513596817351231354610512753798358757893475757895675972857750912390810238192301938901830918039810923810938102936987598783754875857637453587985775';
        $string = str_shuffle($string);
        $string .= time();
        $string .= md5(str_shuffle($string));
        $string = str_shuffle($string);
        $string = str_replace(' ', '', $string);

        return $string;
    }

    /**
     * Creates an hmac hash for verifying data in transit
     **/
    public static function create_hmac($results, $limit, $page, $target_url){
        $secret_string = self::get_access_code_1();
        $secondary_secret_string = self::get_access_code_2();
        $target_url = trailingslashit(esc_url_raw($target_url));
        $secondary_hash_data = self::get_secondary_request_hash_data($target_url);

        if(empty($secondary_hash_data)){
            return false;
        }

        $data = array(
            $results,
            (int)$limit,
            (int)$page,
            $target_url,
            $secondary_hash_data['hash']
        );

        $hash = hash_hmac('sha512', http_build_query($data), $secret_string . $secondary_secret_string);

        return $hash;
    }

    public static function check_hmac($results, $page, $other_site, $data_hash){
        $secret_string = self::get_access_code_1();
        $secondary_secret_string = self::get_access_code_2();
        $other_site = trailingslashit(esc_url_raw($other_site));
        $secondary_hash_data = self::get_secondary_request_hash_data($other_site);

        if(empty($secondary_hash_data)){
            return false;
        }

        $data = array(
            $results,
            self::$query_limit,
            (int)$page,
            trailingslashit(site_url()),
            $secondary_hash_data['hash']
        );

        $hash = hash_hmac('sha512', http_build_query($data), $secret_string . $secondary_secret_string);

        return hash_equals($hash, $data_hash);

    }

    public static function is_json($str) {
        $json = json_decode($str);
        return $json && $str != $json;
    }

    /**
     * Gets the first access code from the front half of the inputted access code.
     * To simplify the interface, we store both access codes in the same input and split it here to get the correct peice for the job. 
     **/
    public static function get_access_code_1() {
        $access_code = get_option('linkilo_link_external_sites_access_code', false);

        if(empty($access_code)){
            return false;
        }

        $access_code = trim($access_code);

        $length = floor((mb_strlen($access_code) / 2));
        $code1 = mb_substr($access_code, 0, $length);

        return $code1;
    }

    /**
     * Gets the second access code from the back half of the inputted access code.
     * To simplify the interface, we store both access codes in the same input and split it here to get the correct peice for the job. 
     **/
    public static function get_access_code_2(){
        $access_code = get_option('linkilo_link_external_sites_access_code', false);

        if(empty($access_code)){
            return false;
        }

        $access_code = trim($access_code);

        $length = floor((mb_strlen($access_code) / 2));
        $code2 = mb_substr($access_code, $length);

        return $code2;
    }
}
?>