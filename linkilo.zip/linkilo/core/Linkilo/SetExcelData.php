<?php

require_once LINKILO_PLUGIN_DIR_PATH . 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer as Writer;

/**
 * Class to work with Excel
 *
 * Class Linkilo_Build_SetExcelData
 */
class Linkilo_Build_SetExcelData
{
    /**
     * Export post data to Excel
     *
     * @param $post Linkilo_Build_Model_Feed
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     */
    public static function exportPost($post)
    {
        //get links data
        $incoming_internal = $post->getIncomingInternalLinks();
        $outgoing_internal = $post->getOutboundInternalLinks();
        $outgoing_external = $post->getOutboundExternalLinks();

        //create spreadsheet
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getProperties()
            ->setCreator('Linkilo')
            ->setTitle(Linkilo_Build_WordFunctions::remove_emoji($post->getTitle()));

        $sheet = $spreadsheet->setActiveSheetIndex(0);

        //set column width
        $sheet->getDefaultColumnDimension()->setWidth(25);
        $sheet->getColumnDimension('C')->setWidth(40);
        $sheet->getColumnDimension('F')->setWidth(40);
        $sheet->getColumnDimension('H')->setWidth(40);

        //merge cells
        $sheet->mergeCells('A5:C5')
            ->mergeCells('D5:F5')
            ->mergeCells('G5:H5');

        //set styles
        foreach (['A5', 'D5', 'G5'] as $cell) {
            $sheet->getStyle($cell)->getAlignment()->setHorizontal('center');
            $sheet->getStyle($cell)->getFill()->setFillType('solid')
                ->getStartColor()->setRGB('4272fd');
            $sheet->getStyle($cell)->getFont()->setBold(true)->getColor()->setRGB('ffffff');
        }

        foreach (['A1', 'A2', 'A3', 'A6', 'B6', 'C6', 'D6', 'E6', 'F6', 'G6', 'H6'] as $cell) {
            $sheet->getStyle($cell)->getFont()->setBold(true);
        }

        $sheet->getStyle('D5')->getFill()->getStartColor()->setRGB('2dc0fd');
        $sheet->getStyle('G5')->getFill()->getStartColor()->setRGB('a81ec1');

        //fill labels
        $sheet->setCellValue('A1', 'Title')
            ->setCellValue('A2', 'Type')
            ->setCellValue('A3', 'URL')
            ->setCellValue('A5', 'Incoming Internal Links' . (!empty($incoming_internal) ? ' (' . count($incoming_internal) . ')' : ''))
            ->setCellValue('D5', 'Outgoing Internal Links' . (!empty($outgoing_internal) ? ' (' . count($outgoing_internal) . ')' : ''))
            ->setCellValue('G5', 'Outgoing External Links' . (!empty($outgoing_external) ? ' (' . count($outgoing_external) . ')' : ''))
            ->setCellValue('A6', 'Anchor')
            ->setCellValue('B6', 'Title')
            ->setCellValue('C6', 'URL')
            ->setCellValue('D6', 'Anchor')
            ->setCellValue('F6', 'Title')
            ->setCellValue('E6', 'URL')
            ->setCellValue('F6', 'Anchor')
            ->setCellValue('G6', 'URL');

        //fill values
        $sheet->setCellValue('B1', Linkilo_Build_WordFunctions::remove_emoji($post->getTitle()))
            ->setCellValue('B2', $post->getType())
            ->setCellValue('B3', $post->getLinks()->view);

        $i = 6;
        foreach ($incoming_internal as $link) {
            $i++;
            $sheet->setCellValue('A' . $i, Linkilo_Build_WordFunctions::remove_emoji(substr($link->anchor, 0, 100)))
                ->setCellValue('B' . $i, Linkilo_Build_WordFunctions::remove_emoji($link->post->getTitle()))
                ->setCellValue('C' . $i, $link->post->getLinks()->view);
        }

        $i = 6;
        foreach ($outgoing_internal as $link) {
            $i++;
            $sheet->setCellValue('D' . $i, Linkilo_Build_WordFunctions::remove_emoji(substr($link->anchor, 0, 100)))
                ->setCellValue('F' . $i, $link->url);

            if (!empty($link->post)) {
                $sheet->setCellValue('E' . $i, Linkilo_Build_WordFunctions::remove_emoji($link->post->getTitle()));
            }
        }

        $i = 6;
        foreach ($outgoing_external as $link) {
            $i++;
            $sheet->setCellValue('G' . $i, Linkilo_Build_WordFunctions::remove_emoji(substr($link->anchor, 0, 100)))
                ->setCellValue('H' . $i, $link->url);
        }

        //download file
        $writer = new Writer\Xls($spreadsheet);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $post->getTitle() . '.xls"');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');

        die;
    }
}
