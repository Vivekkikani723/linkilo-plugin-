<?php

/**
 * Work with Links Cannibalization Report
 */
class Linkilo_Build_CannibalizationLinks {

    public function __construct() {
        add_filter('screen_settings', array(__CLASS__, 'show_screen_options_links'), 11, 2);
        add_filter('set_screen_option_cannibalization_links', array(__CLASS__, 'save_options_cannibalization_links'), 12, 3);
        add_action('wp_ajax_linkilo_cannibalization_links_replace', array($this, 'ajax_linkilo_cannibalization_links_replace'));
        add_action('wp_ajax_linkilo_cannibalization_links_process_replace', array($this, 'linkilo_cannibalization_links_process_replace'));
    }

    public static function init() {
        $table = new Linkilo_Build_Table_CannibalizationLinks();
        $table->prepare_items();
        include LINKILO_PLUGIN_DIR_PATH . '/templates/cannibalization_section_links.php';
    }

    public static function show_screen_options_links($settings, $screen_obj){

        $screen = get_current_screen();
        $options = get_user_meta(get_current_user_id(), 'cannibalization_links', true);

        // exit if we're not on the cannibalization keywords page
        if(!is_object($screen) || $screen->id != 'linkilo_page_link_cannibalization'){
            return $settings;
        }

        // Check if the screen options have been saved. If so, use the saved value. Otherwise, use the default values.
        if ( $options ) {
            $per_page = !empty($options['per_page']) ? $options['per_page'] : 20 ;
        } else {
            $per_page = 20;
        }

        //get apply button
        $button = get_submit_button( __( 'Apply', 'wp-screen-options-framework' ), 'primary large', 'screen-options-apply', false );

        //show HTML form
        ob_start();
        include LINKILO_PLUGIN_DIR_PATH . 'templates/cannibalization_options_links.php';
        return ob_get_clean();
    }

    public static function save_options_cannibalization_links($status, $option, $value) {

        if(!wp_verify_nonce($_POST['screenoptionnonce'], 'screen-options-nonce')){
            // Not verified
            return;
        }

        if ($option == 'cannibalization_links') {
            $value = [];
            if (isset( $_POST['cannibalization_links'] ) && is_array( $_POST['cannibalization_links'] )) {
                if (!isset($_POST['cannibalization_links']['per_page'])) {
                    $_POST['cannibalization_links']['per_page'] = 20;
                }
                $value = $_POST['cannibalization_links'];
            }
            return $value;
        }

        return $status;
    }

    /**
     * Get suggestions from posts and return to display in front-end
     * */
    public function ajax_linkilo_cannibalization_links_replace() {
        $the_query = new WP_Query( 
            array( 
                'posts_per_page' => -1, 
                's' => esc_attr( $_POST['keyword'] ), 
                'post_type' => array(
                    'page',
                    'post'
                ) 
            ) 
        );
        
        $posts_return = array();
        if( $the_query->have_posts() ) :
            while( $the_query->have_posts() ): $the_query->the_post();
                $posts_return[] = array(
                    "ID" => get_the_ID(),
                    "title" => get_the_title(),
                    "permalink" => get_permalink( get_the_ID() ),
                    "info" => get_the_date('Y/m/d')
                );
            endwhile;
            wp_reset_postdata();  
        endif;

        wp_send_json($posts_return);
        exit();
    }

    /**
     * Process the replacement of link and save data
     * */
    public function linkilo_cannibalization_links_process_replace() {
        $response = array();
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : null;

        // current raw link on the sentence or word in list  
        $c_raw_link = isset($_POST['c_raw_link']) ? base64_decode($_POST['c_raw_link']) : null;

        // current input box link raw 
        $raw_url_replace = isset($_POST['rep_link']) ? esc_url_raw($_POST['rep_link']) : null;

        // Table Row index of the entry where links needs to be replaced  
        $row_id = isset($_POST['index']) ? intval($_POST['index']) : null;  

        if (
            !is_null($post_id) && 
            !is_null($c_raw_link) && 
            !is_null($raw_url_replace) &&
            !is_null($row_id) &&
            wp_http_validate_url($raw_url_replace)
        ) {
            $post_type = get_post_type($post_id);
            $post = new Linkilo_Build_Model_Feed($post_id, $post_type);
            $content = $post->getContent();

            // current input box link cleaned
            $clean_url_replace = trailingslashit(strtok($raw_url_replace, '?#'));

            // find the paragraph having the link.
            $phrases = Linkilo_Build_UrlRecommendation::getPhrases($content, true, array(), true, "", 1);

            if ($phrases) {
                foreach ($phrases as $arr_index => $phrase) {
                    $sourcestring = $phrase->sentence_src;
                    preg_match_all('/<a href="(.*?)"/s', $sourcestring, $matches);
                    foreach ($matches as $key => $match) {
                        if (in_array($c_raw_link, $match)) {
                            // replace the link in the phrase itself
                            $new_sourcestring = str_replace($c_raw_link, $raw_url_replace, $sourcestring);

                            // replace the phrase in the content itself
                            $content = str_replace($sourcestring, $new_sourcestring, $content);
                        }
                    }
                }
                $updated = $post->updateContent($content);

                // check content is updated
                if ($updated) {
                    // Link updated in Content

                    global $wpdb;
                    $links_report = $wpdb->prefix . 'linkilo_report_links';

                    // host name of from the url
                    $host = parse_url(urldecode($clean_url_replace), PHP_URL_HOST);
                    $host = str_replace('www.', '', $host);

                    if (Linkilo_Build_PostUrl::isInternal($clean_url_replace)) {
                        // internal : 1
                        $internal = 1;
                    }else{
                        // external : 0
                        $internal = 0;
                    }

                    // update entry
                    $update_query = $wpdb->prepare("
                        UPDATE {$links_report} 
                        SET `clean_url` = %s , `raw_url` = %s, `host` = %s, `internal` = %d 
                        WHERE {$links_report}.`link_id` = %d
                        ",
                        $clean_url_replace, 
                        $raw_url_replace,
                        $host,
                        $internal,
                        $row_id
                    );
                    // run query
                    $query = $wpdb->query($update_query);

                    // If error then respond with error
                    if ($wpdb->last_error !== '') {
                        $response = array(
                            'error' => array(
                                'title' => __('Error in processing query!', 'linkilo'),
                                'text'  => sprint_f(__('There was an error when trying to update the data. The error was: %s', 'linkilo'), $wpdb->last_error),
                            ),
                            'status' => 0
                        );
                    }else{
                        // respond with success
                        $response = array(
                            'success' => array(
                                'title' => __('Success', 'linkilo'),
                                'text'  => __('The link has been successfully updated!', 'linkilo'),
                            ),
                            'status' => 1
                        );
                    }
                }else{
                    // Else show that there was no such link in the content of post
                    $response = array(
                        'error' => array(
                            'title' => __("No link found in content!", 'linkilo'),
                            'text'  => __("There was an error when trying to update the data. \n Please try again!", 'linkilo'),
                        ),
                        'status' => 0
                    );
                }

            }
        }else{
            $response = array(
                'error' => array(
                    'title' => __("Invalid parameters!", 'linkilo'),
                    'text'  => __("There was an error when trying to update the data. \n Please try again!", 'linkilo'),
                ),
                'status' => 0
            );
        }
        wp_send_json($response);
        exit();
    }

    /**
     * Get anchor data for cannibalization report data
     *
     * @return array|null
     */
    public static function get_cannibalization_links($per_page = null, $page = null, $search = null, $orderby  = null, $order = null) {

        global $wpdb;
        $links_report = $wpdb->prefix . 'linkilo_report_links';
        $console_table = $wpdb->prefix . 'linkilo_search_console_data';

        // if the console_tbl_exists exists
        $console_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}linkilo_search_console_data'");

        // if the linkilo_report_links exists
        $report_links_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$wpdb->prefix}linkilo_report_links'");

        if(!empty($report_links_tbl_exists)){

            //define order columns
            $qu_orderby = "";
            // define order ASC/DESC
            $qu_order = "";

            // check for null value 
            if (!is_null($orderby)) {

                // not null match with case
                switch ($orderby) {
                    case 'anchor':
                    $qu_orderby = "ORDER BY `{$links_report}`.`anchor`";
                    break;
                    case 'q_page':
                    $qu_orderby = "ORDER BY `{$links_report}`.`clean_url`";
                    break;
                    case 'click':
                    $qu_orderby = "ORDER BY `{$links_report}`.`clicks`";
                    break;
                    case 'impression':
                    $qu_orderby = "ORDER BY `{$links_report}`.`impressions`";
                    break;
                    case 'ctr':
                    $qu_orderby = "ORDER BY `{$links_report}`.`ctr`";
                    break;
                    case 'position':
                    $qu_orderby = "ORDER BY `{$links_report}`.`position`";
                    break;
                    default:
                    $qu_orderby = "ORDER BY `{$links_report}`.`link_id`";
                    break;
                }
            }

            // check for null value 
            if (!is_null($order)) {
                // not null match with case
                switch ($order) {
                    case 'asc':
                    $qu_order = "ASC";
                    break;
                    case 'desc':
                    $qu_order = "DESC";
                    break;
                    default:
                    $qu_order = "DESC";
                    break;
                }
            }

            if (!is_null($search) || !empty($search) || $search != "") {
                $report_data= $wpdb->get_results(
                    $wpdb->prepare("
                        SELECT DISTINCT(anchor), link_id, post_id, clean_url, raw_url, post_type
                        FROM {$links_report}
                        WHERE anchor IS NOT NULL 
                        AND anchor <> '' 
                        AND anchor LIKE '%%%s%%' 
                        GROUP BY anchor HAVING COUNT(anchor) > 0
                        $qu_orderby $qu_order
                        ", 
                        $wpdb->esc_like($search)
                    ),
                    ARRAY_A
                );
            }else{
                $report_data = $wpdb->get_results("
                    SELECT DISTINCT(anchor), link_id, post_id, clean_url, raw_url, post_type
                    FROM {$links_report}
                    WHERE anchor IS NOT NULL 
                    AND anchor <> '' 
                    GROUP BY anchor HAVING COUNT(anchor) > 0
                    $qu_orderby $qu_order
                    ", 
                    ARRAY_A
                );
            }

            $counter = 0;
            foreach ($report_data as $row_index => $word) {
                if (!empty(trim($word['anchor']))) {
                    $page_urls = $wpdb->get_results(
                        $wpdb->prepare("
                            SELECT DISTINCT(clean_url), anchor, link_id, post_id, clean_url, raw_url, post_type
                            FROM {$links_report} 
                            WHERE `anchor` = %s
                            GROUP BY clean_url HAVING COUNT(clean_url) > 0
                            ",
                            $wpdb->esc_like($word['anchor']),
                        ), 
                        ARRAY_A
                    );

                    if (!empty($console_tbl_exists)) {
                        foreach ($page_urls as $p_row_index => $p_row_value) {
                            $gsc_data = $wpdb->get_results(
                                $wpdb->prepare("
                                    SELECT gsc_index, page_url, keywords, clicks, impressions, ctr, position, page_url_clean
                                    FROM $console_table 
                                    WHERE keywords = %s
                                    AND (
                                        page_url = %s OR page_url_clean = %s
                                        )
                                    ",
                                    $wpdb->esc_like($p_row_value['anchor']),
                                    $p_row_value['clean_url'],
                                    $p_row_value['clean_url'],
                                ), 
                                ARRAY_A
                            );
                            if (sizeof($gsc_data) > 0) {
                            // push only one entry 
                                $report_data[$row_index]['gsc_data'] = $gsc_data[0];
                                $page_urls[$p_row_index]['gsc_data'] = $gsc_data[0];
                            }else{
                                $page_urls[$p_row_index]['gsc_data'] = array();
                                $report_data[$row_index]['gsc_data'] = array();
                            }
                        }
                    }else{
                        $report_data[$row_index]['gsc_data'] = array();
                    }

                    if (sizeof($page_urls) > 1) {
                        $counter++;
                        $report_data[$row_index]['matched_anchor'] = $page_urls;
                    }else{
                        unset($report_data[$row_index]);
                    }
                }
            }
            return [
                'total' => count($report_data),
                'report_data' => array_slice($report_data, ($page - 1) * $per_page, $per_page)
            ];
        }
    }
}
