<?php

/**
* 
* Register routes for the rest api
* 
* */ 
class Linkilo_Build_RegisterRoutes extends WP_REST_Controller{

	/**
	 *	Constructor.
	 **/
	public function __construct() {

		$linking_option = get_option('linkilo_link_external_sites', false);
		
		if (Linkilo_Build_ActiveLicense::isValid() && $linking_option == 1) {
			$this->namespace = 'linkilo/v1';
			$this->rest_base_reqt = 'postConnectionRequest';
			$this->rest_base_resp = 'postConnectionResponse';
			$this->rest_base_post = 'getPostsData';
			add_action( 'admin_notices', array($this, 'linkilo_show_new_req_notice') );
			add_action('admin_init', array($this, 'linkilo_connection_entry_notice_function') );
		}
	}

	/**
	 * Register the component routes.
	 * */
	public function register_routes() {
		register_rest_route( 
			$this->namespace, 
			'/' . $this->rest_base_reqt, 
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'linkilo_push_connection_request' ),
					'permission_callback' => '__return_true',
				)
			) 
		);

		register_rest_route( 
			$this->namespace, 
			'/' . $this->rest_base_resp, 
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'linkilo_push_connection_request_response' ),
					'permission_callback' => '__return_true',
				)
			) 
		);

		register_rest_route( 
			$this->namespace, 
			'/' . $this->rest_base_post, 
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'linkilo_get_posts_data' ),
					'permission_callback' => '__return_true',
				)
			) 
		);
	}

	/**
	 * Handle request from site.
	 */
	public function linkilo_push_connection_request( WP_REST_Request $request) {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {
			$header_a  = $request->get_header('authorization');
			$rep_code = str_replace('Bearer ', '', $header_a);
			$decode = explode(':', base64_decode($rep_code));

			if (!in_array('linkilo', $decode) && !in_array('site_connection_request', $decode)) {
				$response = array(
					'status' => "error",
					'code'	=> 'auth_401',
				);	
				return new WP_REST_Response($response, 401);
			}

			$header = $request->get_header('key');

			if (empty($header) || is_null($header) || $header === "") {
				$response = array(
					'status' => "error",
					'code'	=> 'auth_401',
				);	
				return new WP_REST_Response($response, 401);
			}

			$data = Linkilo_Build_ConnectMultipleSite::linkilo_generate_unique_params($header,'d');

			$rep = str_replace(' ', '', $data);

			if ($data === false || $rep === "") {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_403',
				);	
				return new WP_REST_Response($response, 403);
			}

			$explode = explode('=X=', $data);

			if (sizeof($explode) < 2 || sizeof($explode) > 4) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204',
				);	
				return new WP_REST_Response($response, 204);	
			}

			$host = parse_url(site_url(), PHP_URL_HOST);
			$ip = gethostbyname($host);
			if (!in_array($host, $explode) || !in_array($ip, $explode)) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204',
				);
				return new WP_REST_Response($response, 204);	
			}

			$parameters = $request->get_params();
			$h = $request->get_param('h');
			$h_m = Linkilo_Build_ConnectMultipleSite::linkilo_h_get(site_url());

			if (!hash_equals($h, $h_m)) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204',
				);
				return new WP_REST_Response($response, 204);	
			} 

			if (
				( !isset($parameters['code']) ||  
					empty($parameters['code']) || 
					$parameters['code'] === ""
				) || 
				( !isset($parameters['from_site']) || 
					empty($parameters['from_site']) || 
					$parameters['from_site'] === ""
				) || 
				( !isset($parameters['to_site']) || 
					empty($parameters['to_site']) || 
					$parameters['to_site'] === ""
				) ||
				( !isset($parameters['req_expiration']) || 
					empty($parameters['req_expiration']) || 
					$parameters['req_expiration'] === ""
				) ||
				!hash_equals($h, $h_m)
			) {
				$response = array(
					'status' => "error",
					'code'	=> 'param_400',
				);	
				return new WP_REST_Response($response, 400);
			}

			if (
				isset($parameters['code']) && 
				!empty($parameters['code']) && 
				$parameters['code'] !== "" &&
				hash_equals($h, $h_m)
			) {
				// Check site interlinking enabled
				$linking_option = get_option('linkilo_link_external_sites', false);

				if ($linking_option == 1) {
					global $wpdb;
					$entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

					$from = trailingslashit(esc_url_raw($parameters['from_site']));
					$to = trailingslashit(esc_url_raw($parameters['to_site']));
					$unique_code = $parameters['code'];
					$exp =intval($parameters['req_expiration']);
					$exp_date = date('Y:m:d', strtotime(' +'.$exp.' day')); 

					$entry = $wpdb->get_var("
						SELECT count(*) 
						FROM $entry_table 
						WHERE site_from_url IS NOT NULL 
						AND site_from_url <> '' 
						AND site_from_url = '$from' 
						AND site_to_url = '$to'	
						AND req_type = 1
						AND (req_status IS NULL OR req_status = 0)
						"
					);

					if ($entry == 0) {
						$wpdb->insert(
							$entry_table,
							array( 
								'site_from_url' => $from,
								'site_to_url' => $to,
								'unique_code' => $unique_code,
								'req_expire_time' => $exp_date,
								'req_type' => 1,
							), 
							array( 
								'%s', 
								'%s', 
								'%s', 
								'%s', 
								'%d', 
							)
						);

						$lastid = $wpdb->insert_id;

						if (!empty($lastid)) {
							$response = array(
								'status' => "success",
								'code'	=> 'en_200'
							);
							return new WP_REST_Response($response, 200);
						}else{
							$response = array(
								'status' => "error",
								'code'	=> 'en_400'
							);
							return new WP_REST_Response($response, 400);
						}
					}else{
						$response = array(
							'status' => "success",
							'code'	=> 'e_ex_200'
						);
						return new WP_REST_Response($response, 200);
					}
				}else{
					$response = array(
						'status' => "error",
						'code'	=> 'sl_di_400'
					);
					return new WP_REST_Response($response, 400);
				}
			}else{
				$response = array(
					'status' => "error",
					'code'	=> 'param_400'
				);	
				return new WP_REST_Response($response, 400);	
			}
		}else{
			$response = array(
				'status' => "error",
				'code'	=> 'param_400'
			);	
			return new WP_REST_Response($response, 400);
		}
	}

	/**
	 * Handle request procession from requested site.
	 */
	public function linkilo_push_connection_request_response( WP_REST_Request $request) {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {
			$header_a  = $request->get_header('authorization');
			$rep_code = str_replace('Bearer ', '', $header_a);
			$decode = explode(':', base64_decode($rep_code));

			if (!in_array('linkilo', $decode) && !in_array('site_connection_request_reponse', $decode)) {
				$response = array(
					'status' => "error",
					'code'	=> 'auth_401',
				);	
				return new WP_REST_Response($response, 401);
			}

			$header = $request->get_header('key');

			if (empty($header) || is_null($header) || $header === "") {
				$response = array(
					'status' => "error",
					'code'	=> 'auth_401'
				);	
				return new WP_REST_Response($response, 401);
			}

			$data = Linkilo_Build_ConnectMultipleSite::linkilo_generate_unique_params($header,'d');

			$rep = str_replace(' ', '', $data);

			if ($data === false || $rep === "") {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_403'
				);	
				return new WP_REST_Response($response, 403);
			}

			$explode = explode('=X=', $data);

			if (sizeof($explode) < 2 || sizeof($explode) > 4) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204'
				);	
				return new WP_REST_Response($response, 204);	
			}

			$host = parse_url(site_url(), PHP_URL_HOST);
			$ip = gethostbyname($host);
			if (!in_array($host, $explode) || !in_array($ip, $explode)) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204'
				);
				return new WP_REST_Response($response, 204);	
			}

			$parameters = $request->get_params();
			$h = $request->get_param('h');
			$h_m = Linkilo_Build_ConnectMultipleSite::linkilo_h_get(site_url());

			if (!hash_equals($h, $h_m)) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204'
				);
				return new WP_REST_Response($response, 204);	
			} 

			if (
				( !isset($parameters['code']) ||  
					empty($parameters['code']) || 
					$parameters['code'] === ""
				) || 
				( !isset($parameters['from_site']) || 
					empty($parameters['from_site']) || 
					$parameters['from_site'] === ""
				) || 
				( !isset($parameters['to_site']) || 
					empty($parameters['to_site']) || 
					$parameters['to_site'] === ""
				) ||
				( !isset($parameters['res_type']) || 
					intval($parameters['res_type']) > 1
				) ||
				( !isset($parameters['req_type']) || 
					(
						intval($parameters['req_type']) !== 0 ||
						intval($parameters['req_type']) > 0
					)
				) ||
				!hash_equals($h, $h_m)
			) {
				$response = array(
					'status' => "error",
					'code'	=> 'param_400'
				);	
				return new WP_REST_Response($response, 400);
			}		

			if (
				isset($parameters['code']) && !empty($parameters['code']) && 
				$parameters['code'] !== "" && $parameters['res_type'] !== "" &&
				intval($parameters['res_type']) < 2 && intval($parameters['req_type']) < 1 &&
				intval($parameters['req_type']) === 0 && hash_equals($h, $h_m)
			) {
				$linking_option = get_option('linkilo_link_external_sites', false);

				if ($linking_option == 1) {
					// linking option enabled on this site
					global $wpdb;
					$entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

					$from = $parameters['from_site'];
					$to = $parameters['to_site'];
					$unique_code = $parameters['code'];
					$res_type = intval($parameters['res_type']);
					$req_type = (intval($parameters['req_type']) > 0) ? 0 : intval($parameters['req_type']); 

					$entry = $wpdb->get_row("
						SELECT id, count(*) as count 
						FROM $entry_table 
						WHERE site_from_url IS NOT NULL 
						AND site_from_url <> '' 
						AND unique_code = '$unique_code' 
						AND site_from_url = '$to' 
						AND site_to_url = '$from'	
						AND req_type = $req_type
						AND req_status IS NULL", ARRAY_A
					);

					if (intval($entry['count']) === 1) {
						$record = intval($entry['id']);

						$update_query = $wpdb->prepare("
							UPDATE {$entry_table} 
							SET `req_status` = %d , `req_expire_time` = NULL 
							WHERE {$entry_table}.`id` = %d
							AND {$entry_table}.`unique_code` = %s 
							AND {$entry_table}.`req_type` = %d
							", 
							$res_type, 
							$record, 
							$unique_code, 
							$req_type
						);
						$query = $wpdb->query($update_query);

						if (intval($query) === 1) {
							$reg = Linkilo_Build_ConnectMultipleSite::linkilo_register_selected_site_option($from, true);
							if ($reg) {
								$response = array(
									'status' => "success",
									'code'	=> 'up_200'
								);
								return new WP_REST_Response($response, 200);
							}else{
								$response = array(
									'status' => "error",
									'code'	=> 'up_400'
								);
								return new WP_REST_Response($response, 400);
							}
						}else{
							$response = array(
								'status' => "error",
								'code'	=> 'up_400'
							);
							return new WP_REST_Response($response, 400);
						}
					}else{
						$response = array(
							'status' => "error",
							'code'	=> 'e_ex_400'
						);
						return new WP_REST_Response($response, 400);
					}
				}else{
					$response = array(
						'status' => "error",
						'code'	=> 'sl_di_400'
					);
					return new WP_REST_Response($response, 400);
				}
			}else{
				$response = array(
					'status' => "error",
					'code'	=> 'param_400'
				);	
				return new WP_REST_Response($response, 400);	
			}
		}else{
			$response = array(
				'status' => "error",
				'code'	=> 'param_400'
			);	
			return new WP_REST_Response($response, 400);
		}
	}

	/**
	 * Handle response for giving back requested data of posts 
	 */
	public function linkilo_get_posts_data(WP_REST_Request $request) {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {
			$header_a  = $request->get_header('authorization');
			$rep_code = str_replace('Bearer ', '', $header_a);
			$decode = explode(':', base64_decode($rep_code));

			if (!in_array('linkilo', $decode) && !in_array('get_site_posts_limited_cols', $decode)) {
				$response = array(
					'status' => "error",
					'code'	=> 'auth_401'
				);	
				return new WP_REST_Response($response, 401);
			}

			$header = $request->get_header('key');

			if (empty($header) || is_null($header) || $header === "") {
				$response = array(
					'status' => "error",
					'code'	=> 'auth_401'
				);	
				return new WP_REST_Response($response, 401);
			}

			$data = Linkilo_Build_ConnectMultipleSite::linkilo_generate_unique_params($header,'d');

			$rep = str_replace(' ', '', $data);

			if ($data === false || $rep === "") {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_403'
				);	
				return new WP_REST_Response($response, 403);
			}

			$explode = explode('=X=', $data);

			if (sizeof($explode) < 2 || sizeof($explode) > 4) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204'
				);	
				return new WP_REST_Response($response, 204);	
			}

			$host = parse_url(site_url(), PHP_URL_HOST);
			$ip = gethostbyname($host);
			if (!in_array($host, $explode) || !in_array($ip, $explode)) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204'
				);
				return new WP_REST_Response($response, 204);	
			}

			$parameters = $request->get_params();
			$h = $request->get_param('h');
			$h_m = Linkilo_Build_ConnectMultipleSite::linkilo_h_get(site_url());

			if (!hash_equals($h, $h_m)) {
				$response = array(
					'status' => "error",
					'code'	=> 'forb_204'
				);
				return new WP_REST_Response($response, 204);	
			} 

			if (
				( !isset($parameters['code']) ||  
					empty($parameters['code']) || 
					$parameters['code'] === ""
				) ||
				( !isset($parameters['h']) ||  
					empty($parameters['h']) || 
					$parameters['h'] === ""
				) || 
				!hash_equals($h, $h_m)
			) {
				$response = array(
					'status' => "error",
					'code'	=> 'param_400'
				);	
				return new WP_REST_Response($response, 400);
			}		

			if (
				isset($parameters['code']) && !empty($parameters['code']) && 
				$parameters['code'] !== "" && isset($parameters['h']) && 
				$parameters['h'] !== "" && intval($parameters['l']) === 5000 && 
				hash_equals($h, $h_m)
			) {
				$linking_option = get_option('linkilo_link_external_sites', false);

				if ($linking_option == 1) {
					global $wpdb;
					$entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

					$url = trailingslashit(site_url());
					$unique_code_req_param = $parameters['code'];

					// current site unique code 
					$entry = $wpdb->get_var("
						SELECT unique_code 
						FROM {$entry_table} 
						WHERE site_from_url IS NOT NULL 
						AND site_to_url IS NOT NULL 
						AND unique_code IS NOT NULL 
						AND site_from_url <> ''
						AND unique_code <> ''
						AND site_to_url <> ''
						AND (site_from_url = '$url' OR site_to_url = '$url') 
						AND (unique_code = '$unique_code_req_param') 
						"
					);

					if ($parameters['code'] == $entry) {
						$posts_table = $wpdb->prefix . 'posts';
						$entries = $wpdb->get_results("	
							SELECT ID as id, post_title as title, post_type as type, post_modified_gmt as gmt
							FROM {$posts_table} 
							WHERE post_status = 'publish' 
							AND (post_type = 'post' OR post_type = 'page')
							",
							ARRAY_A
						);

						if (sizeof($entries) === 0) {
							$response = array(
								'status' => "error",
								'code'	=> 'en_400' 
							);	
							return new WP_REST_Response($response, 400);
						}

						$counter = 0;
						foreach ($entries as $i => $en) {
							$entries[$i]['post_url'] = get_permalink($en['id']);
							$counter++;
						}

						if (intval($counter) === sizeof($entries)) {
							$response = array(
								'posts'	=> $entries,
								'code'	=> 'en_200',
								'size'	=> sizeof($entries)
							);
							return new WP_REST_Response($response, 200);
						}else{
							$response = array(
								'status' => "error",
								'code'	=> 'en_p_400'
							);	
							return new WP_REST_Response($response, 400);
						}
					}else{
						$response = array(
							'status' => "error",
							'code'	=> 'en_400'
						);	
						return new WP_REST_Response($response, 400);
					}
				}else{
					$response = array(
						'status' => "error",
						'code'	=> 'sl_di_400'
					);
					return new WP_REST_Response($response, 400);
				}
			}else{
				$response = array(
					'status' => "error",
					'code'	=> 'c_400'
				);	
				return new WP_REST_Response($response, 400);	
			}	
		}else{
			$response = array(
				'status' => "error",
				'code'	=> 'param_400'
			);	
			return new WP_REST_Response($response, 400);
		}
	}
	
	/**
	 * Show admin notice on request from other site 
	 */
	public static function linkilo_show_new_req_notice() {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {

			global $wpdb;
			$entry_table = $wpdb->prefix . 'linkilo_connection_req_entry';

			$entries = $wpdb->get_results("
				SELECT * 
				FROM {$entry_table} 
				WHERE site_from_url IS NOT NULL 
				AND site_to_url IS NOT NULL 
				AND unique_code IS NOT NULL 
				AND site_from_url <> ''
				AND unique_code <> ''
				AND site_to_url <> ''
				",
				ARRAY_A
			);

			if (sizeof($entries) > 0) {
				$content = "";
				$current_date = date('Y-m-d');
				$sr_no_cnt = 1;

				// loop through entries
				foreach ($entries as $i => $entry) {
					$id = intval($entry['id']);

					if (
						$current_date < $entry['req_expire_time'] &&
						intval($entry['req_type']) === 1 &&
						is_null($entry['req_status'])
					) {
						$status = (is_null($entry['req_status'])) ? 'Pending' : 'Approved';
						$url = $entry['site_from_url'];

						$ac = 1;
						$dc = 0;

						$content .= sprintf( __( '<tr>'));
						$content .= sprintf( __( '<td>'.$sr_no_cnt.'</td>'));
						$content .= sprintf( __( '<td> '  )). $url .sprintf( __( '</td> '  ));
						$content .= sprintf( __( '<td> '  )). $status .sprintf( __( '</td> '  ));
						$content .= sprintf( __( '<td>'));
						$content .= sprintf( __( '<button type="button" class="btn_req_accept" data-id="'.$id.'" data-type="'.$ac.'" data-url="'.$url.'">Accept</button>'));
						$content .= sprintf( __( '<button type="button" class="btn_req_decline" data-id="'.$id.'" data-type="'.$dc.'">Decline</button>'));
						$content .= sprintf( __( '</td>'));
						$content .= sprintf( __( '</tr>'));

						$sr_no_cnt++;
					}

					if (
						$current_date > $entry['req_expire_time'] &&
						intval($entry['req_type']) === 1 &&
						is_null($entry['req_status'])
					) {
						$query = $wpdb->prepare("DELETE FROM {$entry_table} WHERE `id` = %d", $id);
						$wpdb->query($query);
					}

					if (
						$current_date > $entry['req_expire_time'] &&
						intval($entry['req_type']) === 0 &&
						is_null($entry['req_status'])
					) {
						$query = $wpdb->prepare("DELETE FROM {$entry_table} WHERE `id` = %d", $id);
						$wpdb->query($query);
					}

					if (
						is_null($entry['req_expire_time']) &&
						(intval($entry['req_type']) === 0 || intval($entry['req_type']) === 1) &&
						intval($entry['req_status']) === 0
					) {
						$query = $wpdb->prepare("DELETE FROM {$entry_table} WHERE `id` = %d", $id);
						$wpdb->query($query);
					}

					if (
						is_null($entry['req_expire_time']) &&
						(intval($entry['req_type']) === 0 || intval($entry['req_type']) === 1) &&
						intval($entry['req_status']) === 1 &&
						!is_null($entry['req_expire_status']) &&  
						intval($entry['req_expire_status']) === 1
					) {
						$query = $wpdb->prepare("DELETE FROM {$entry_table} WHERE `id` = %d", $id);
						$wpdb->query($query);
					}
				}

				$notice = get_option('linkilo_site_connection_entries_notice');
				if (
					isset($_GET['page']) && 
					(
						$_GET['page'] == 'linkilo' || 
						$_GET['page'] == 'linkilo_keywords' || 
						$_GET['page'] == 'linkilo_focus_keywords' || 
						$_GET['page'] == 'linkilo_settings' 
					) &&
					!empty($content) && $content !== "" &&
					$notice && intval($notice) === 1 	
				) {
					echo self::html_header();
					echo $content;
					echo self::html_footer();
				}
			}
		}
	}

	public static function linkilo_connection_entry_notice_function() {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {
		    if (isset($_GET['linkio_dismiss_notice'])) {
		        $redirect = $_SERVER["HTTP_REFERER"];
		        update_option('linkilo_site_connection_entries_notice', "0");
		        wp_safe_redirect($redirect, 302, 'linkilo');
		        exit();
		    }		    
		}
	}

	public static function html_header() {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {
			// Init the html and append data to it accordingly
			$html = sprintf( __('<div class="notice notice-info notice_mt linkilo-admin-notice-sc">'));
			$html .= sprintf( __('<div class="site_connection_entry_table_heading">'));
			$html .= sprintf( __('<div class="notice_dismiss_button"><a href="?linkio_dismiss_notice"></a></div>'));
			$html .= sprintf( __('<span>'));
			$html .= sprintf( __('Linkilo Site Connection Requests'));
			$html .= sprintf( __('</span>'));
			$html .= sprintf( __('</div>'));

			$html .= sprintf( __('<div class="admin_notice_loader" style="display:none;">'));
			$html .= sprintf( __('<div class="linkilo_progress_panel loader">'));
			$html .= sprintf( __('<div class="progress_count" style="width:100%%">'));
			$html .= sprintf( __('</div>'));
			$html .= sprintf( __('</div>'));
			$html .= sprintf( __('<div class="linkilo_progress_panel_center"> Loading </div>'));
			$html .= sprintf( __('</div>'));
			$html .= sprintf( __( '<div class="admin_notice_table" style="display:block;">'  ));

			// init table
			$html .= sprintf( __('<table class="site_connection_entry_table">'));
			$html .= sprintf( __('<thead>'));
			$html .= sprintf( __('<th> No.</th>'));
			$html .= sprintf( __('<th> Site URL</th>'));
			$html .= sprintf( __('<th> Status</th>'));
			$html .= sprintf( __('<th colspan="2"> Actions </th>'));
			$html .= sprintf( __('</thead>'));
			$html .= sprintf( __('<tbody>'));

			return $html;
		}
	}

	public static function html_footer() {
		if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" && Linkilo_Build_ActiveLicense::isValid()) {
			$html = sprintf( __('<tfoot>'));
			$html .= sprintf( __('<th> No.</th>'));
			$html .= sprintf( __('<th> Site URL</th>'));
			$html .= sprintf( __('<th> Status</th>'));
			$html .= sprintf( __('<th colspan="2"> Actions </th>'));
			$html .= sprintf( __('</tfoot></tbody></table>'));
			$html .= sprintf( __('</div>'));
			$html .= sprintf( __('</div>'));

			return $html;
		}
	}
}