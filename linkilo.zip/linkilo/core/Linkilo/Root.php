<?php
/**
 * Base controller
 */
class Linkilo_Build_Root
{
    public static $report_menu;

    /**
     * Register services
     */
    public function register()
    {
        add_action('admin_init', [$this, 'init']);
        add_action('admin_menu', [$this, 'addMenu']);
        add_action('add_meta_boxes', [$this, 'addMetaBoxes']);
        add_action('admin_enqueue_scripts', [$this, 'addScripts']);
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_frontend_scripts'));
        add_action('plugin_action_links_' . LINKILO_PLUGIN_BASE_NAME, [$this, 'showSettingsLink']);
        add_action('upgrader_process_complete', [$this, 'upgrade_complete'], 10, 2);
        add_action('wp_ajax_get_recommended_url', ['Linkilo_Build_UrlRecommendation','ajax_get_recommended_url']);
        add_action('wp_ajax_linkilo_get_outer_site_recommendation', ['Linkilo_Build_UrlRecommendation', 'ajax_get_outer_site_recommendation']);
        add_action('wp_ajax_update_recommendation_display', ['Linkilo_Build_UrlRecommendation','ajax_update_recommendation_display']);
        add_action('wp_ajax_load_more_outgoing_suggestions', ['Linkilo_Build_UrlRecommendation','load_more_outgoing_suggestions_handle']);
        add_action('wp_ajax_linkilo_csv_export', ['Linkilo_Build_CsvExport','ajax_csv']);
        
        add_action('wp_ajax_linkilo_save_wizard_global_settings', [$this, 'linkilo_save_wizard_global_settings_callback']);
        add_action('wp_ajax_linkilo_save_prev_wizard_steps', [$this, 'linkilo_save_prev_wizard_steps_callback']);
        add_action('wp_ajax_linkilo_save_skiped_wizard_steps', [$this, 'linkilo_save_skiped_wizard_steps_callback']);

        add_filter( 
            'the_content', 
            array( 
                __CLASS__, 
                'open_links_in_new_tabs' 
            ) 
        );
        add_filter('the_content', [$this,'add_external_link_icon']);
        add_filter( 'the_content', [ $this, 'add_internal_link_content' ] );
        register_activation_hook( __FILE__, [ $this, 'include_licensing_file_on_activation']);

        if (
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'linkilo') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'linkilo_keywords') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'linkilo_focus_keywords') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'linkilo_settings') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'linkilo_license') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'link_cannibalization') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'keyword_cannibalization') ||
            (isset($_GET['page']) && !empty($_GET['page']) && $_GET['page'] == 'anchor_analysis')
        ) {
            // Admin footer modification
            add_filter(
                'admin_footer_text',
                [ $this, 'linkilo_change_admin_footer' ]
            );
        }

        foreach(Linkilo_Build_AdminSettings::getPostTypes() as $post_type){

            add_filter("get_user_option_meta-box-order_{$post_type}", [$this, 'group_metaboxes'], 1000, 1 );

            add_filter($post_type . '_row_actions', array(__CLASS__, 'modify_list_row_actions'), 10, 2);
            //add_filter( "manage_{$post_type}_posts_columns", array(__CLASS__, 'add_columns'), 11 );
            add_action( "manage_{$post_type}_posts_custom_column", array(__CLASS__, 'columns_contents'), 11, 2);
        }

        foreach(Linkilo_Build_AdminSettings::getTermTypes() as $term_type){
            add_filter($term_type . '_row_actions', array(__CLASS__, 'modify_list_row_actions'), 10, 2); // we can only add the row actions. There's no modifying of the columns...
        }

        $linking_option = get_option('linkilo_link_external_sites', false);
        if (Linkilo_Build_ActiveLicense::isValid() && $linking_option == 1) {
            // Initialize rest
            add_action( 'rest_api_init', function () {
                $controller = new Linkilo_Build_RegisterRoutes();
                $controller->register_routes();
            });
        }

        // handle follow/unfollow toggle
        add_action('wp_ajax_linkilo_toggle_follow_link', [$this,'linkilo_handle_follow_unfollow_operation']);

        // handle checked for gsc focus keywords toggle
        add_action('wp_ajax_linkilo_checked_rows', [$this,'linkilo_handle_checked_rows']);
        add_action('wp_ajax_linkilo_save_external_settings_extra_fields', [$this,'linkilo_save_external_settings_extra_fields_callback']);

        add_action('wp_ajax_link_preview', [$this,'linkilo_link_preview_handle']);
        add_action('wp_ajax_nopriv_link_preview', [$this,'linkilo_link_preview_handle']);

        add_filter('script_loader_tag', [$this, 'linkilo_add_type_attribute'] , 20, 3);

        /*Show Notice on link whisper detection*/
        add_action(
            'admin_notices',
            [ $this, 'linkilo_notice_for_non_dependent_plugins' ]
        );

       
    }


    /*Runs when deactivation of plugin is made through action button on admin notice*/
    public function linkilo_handle_non_dependent_plugin_deactivation() {

        if (
            current_user_can('administrator') &&
            isset( $_GET['_delw'] ) &&
            isset( $_GET['ret_url'] ) &&
            wp_verify_nonce( $_GET['_delw'], 'linkilo-deactivate-link-whisper' )
        ) {
            if ( is_plugin_active( 'link-whisper-premium/link-whisper.php' ) ) {
                deactivate_plugins( 'link-whisper-premium/link-whisper.php' );
            }

            $redirect_to = urldecode($_GET['ret_url']);
            wp_redirect( $redirect_to );
            exit;
        }
    }
    
     /**
     * Display link whisper notice
     * */
     public function linkilo_notice_for_non_dependent_plugins() {
        if (current_user_can('administrator') && is_plugin_active( 'link-whisper-premium/link-whisper.php' ) ) {
            $page_url = site_url( $_SERVER['REQUEST_URI'] );
            $nonce_url = wp_nonce_url( $page_url, 'linkilo-deactivate-link-whisper', '_delw' );
            $deactivate_url = add_query_arg( 'ret_url', urlencode($page_url), $nonce_url );
            ?>
            <div class="<?php echo esc_attr( 'error notice-warning is-dismissible' ); ?>">
                <p>
                    <span><b>Linkilo:</b></span>
                    <?php esc_html_e( "The following plugin are not compatible with our plugin and may cause unexpected and slow down your server:", 'linkilo' ); ?>
                    <ul style="display:flex;flex-wrap:wrap;list-style: unset;padding-left: 20px;justify-content:space-between;">
                        <li style="width:70%">
                            <span>
                                <b>Link Whisper:</b>
                                <?php esc_html_e("This plugin will crawl your site for link suggestion and we also do the same task. Having two plugins trying to do the same task will not provide you the most optimal result. Deactivate and use Linkilo instead.", 'linkilo'); ?>
                            </span>
                        </li>
                        <li style="min-width:fit-content;list-style: none;">
                            <a href="<?php echo $deactivate_url; ?>" class="button">
                                <?php esc_html_e( 'Deactivate', 'linkilo' ); ?>
                            </a>
                        </li>
                    </ul>                   
                </p>
            </div>
            <?php
        }
    }

    public function linkilo_add_type_attribute($tag, $handle, $src) {
        // if not your script, do nothing and return original $tag
        if ( 'preview-hyperlink-call' === $handle || 'preview-hyperlink-js' === $handle) {
            $tag = '<script type="module" src="' . esc_url( $src ) . '" id="'.$handle.'" defer></script>';
            return $tag;
        }
        // change the script tag by adding type="module" and return it.
        return $tag;
    }

    /**
     * Initial function
     */
    function init() {
        $post = self::getPost();

        if (!empty($_GET['csv_export'])) {
            Linkilo_Build_CsvExport::csv();
        }
        
        if (!empty($_GET['type'])) {
            // if the current page has a "type" value
            $type = $_GET['type'];

            switch ($type) {
                case 'delete_link':               
                Linkilo_Build_PostUrl::delete();
                break;
                case 'incoming_suggestions_page_container':
                include LINKILO_PLUGIN_DIR_PATH . '/templates/incoming_recommendation_page_container.php';
                exit;
                break;
            }
        }

        if (!empty($_GET['area'])) {
            switch ($_GET['area']) {
                case 'linkilo_export':
                Linkilo_Build_CsvExport::getInstance()->export($post);
                break;
                case 'linkilo_excel_export':
                $post = self::getPost();
                if (!empty($post)) {
                    Linkilo_Build_SetExcelData::exportPost($post);
                }
                break;
            }
        }

        if (!empty($_POST['hidden_action'])) {
            switch ($_POST['hidden_action']) {
                case 'linkilo_save_settings':
                Linkilo_Build_AdminSettings::save();
                break;
                case 'activate_license':
                Linkilo_Build_ActiveLicense::activate();
                break;
            }
        }
    }

    /**
     * This function is used for add Icons before or after external Links
     *
     *
     * @return  void
     */
    public function add_external_link_icon( $content ) {
    
        $linkilo_ext_opt_external_set       = get_option( 'linkilo_external_setting_ext_field' );
       
        $linkilo_icon_type                  = isset( $linkilo_ext_opt_external_set['linkilo_icon_type'] ) ? $linkilo_ext_opt_external_set['linkilo_icon_type'] : '';
    
        $linkilo_icon_position              = isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) ? $linkilo_ext_opt_external_set['linkilo_icon_position'] : '';
    
        $linkilo_selectedClass              = isset( $linkilo_ext_opt_external_set['linkilo_selectedClass'] ) ? $linkilo_ext_opt_external_set['linkilo_selectedClass'] : '';

    
        $linkilo_skip_check                 = isset( $linkilo_ext_opt_external_set['linkilo_skip_isChecked'] ) ? $linkilo_ext_opt_external_set['linkilo_skip_isChecked'] : '';
    
        $linkilo_exclude_iconfordmn_name    = isset( $linkilo_ext_opt_external_set['linkilo_exclude_iconfordmn_name'] ) ? $linkilo_ext_opt_external_set['linkilo_exclude_iconfordmn_name'] : '';
    
        $spc_dmn_name_and_cls_arr           = isset( $linkilo_ext_opt_external_set['spc_dmn_name_and_cls_arr'] ) ? $linkilo_ext_opt_external_set['spc_dmn_name_and_cls_arr'] : '';
       
        $exclude_domain_name                = trim( $linkilo_exclude_iconfordmn_name );
        $deomain_name_with_remove_spaces    = preg_replace( '/\s*,\s*/', ',', $exclude_domain_name );
       
        $linkilo_exclude_dmnfrm_icon_arr    = explode( ",",$deomain_name_with_remove_spaces );
    
        $pattern                            = '/<a(.*?)href=["\'](.*?)["\'](.*?)>(.*?)<\/a>/i';
    
        // Match all links in the content
        $matches                            = array();
        $linkili_excl_doamin_arr            = array();
        $linkilo_specfi_domain_arr          = array();
        $linkilo_icon_spec_dmn              = array();
        preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER );
    
        foreach ( $linkilo_exclude_dmnfrm_icon_arr as $url ) {
            $url_without_protocol           = str_replace( array( 'http://', 'https://' ), '', $url );
            // $url_without_protocol        = rtrim($url_without_proto, '/\\');
    
            array_push( $linkili_excl_doamin_arr,$url_without_protocol );
        }
    
        if( !empty( $spc_dmn_name_and_cls_arr ) )
        {
            foreach ( $spc_dmn_name_and_cls_arr as $urll ) {
                $url_without_protocol2 = str_replace( array( 'http://', 'https://' ), '', $urll['domain_name'] );
                // $url_without_protocol2 = rtrim($url_without_proto2, '/\\');
                array_push( $linkilo_icon_spec_dmn,$urll['icon_class'] );
    
                array_push( $linkilo_specfi_domain_arr,$url_without_protocol2 );
            }
        }

        // Loop through the matches
        foreach ( $matches as $match ) {
    
            $link       = isset( $match[2] ) ? $match[2] : '';
            $ext_attr   = isset( $match[3] ) ? $match[3] : '';
            $match4     = isset( $match[4] ) ? $match[4] : '';
            $match1     = isset( $match[1] ) ? $match[1] : '';
    
            // Check if the link is external
            if ( $this->is_external_link( $link ) ) {
                // Output the link with the icon
                $value_without_proto    = str_replace( array( 'http://', 'https://' ), '', $link ); 
                $value_without_protocol = rtrim( $value_without_proto, '/\\' );
    
                if( is_array( $linkilo_exclude_dmnfrm_icon_arr ) && !empty( $linkilo_exclude_dmnfrm_icon_arr ) )
                {
                   if( in_array( $value_without_protocol, $linkili_excl_doamin_arr ) )
                   {
                        $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                   }
                   else
                   {
                        $matchingKey = array_search( $value_without_protocol, $linkilo_specfi_domain_arr );
                        
                        if( $matchingKey !== false )
                        {
                            if( isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left' )
                            {
                                $replacement = ' <i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                            }
                            else
                            {
                                $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                            }
                        }
                        else
                        {
                            if( isset( $linkilo_ext_opt_external_set['linkilo_icon_type'] ) && $linkilo_ext_opt_external_set['linkilo_icon_type'] == 'linkilo_external_icon' || $linkilo_ext_opt_external_set['linkilo_icon_type'] == 'linkilo_verified_icon' )
                            {
                                if( $linkilo_skip_check == 'true' )
                                {
                                    $linkilo_htm ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                
                                    $dom = new DOMDocument();
                                    $dom->loadHTML( $linkilo_htm );
                                    $imgTags = $dom->getElementsByTagName( 'img' );
                                    if ($imgTags->length > 0) {
                
                                        $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                    }
                                    else
                                    {
                                        if( isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left')
                                        {
                                            $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                        }
                                        else
                                        {
                                            $replacement = '<a' . $match1 . 'href="' . esc_url( $link ) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                        }
                
                                    }
                                }
                                else
                                {
                                    if( isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left' )
                                    {
                                        $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                    }
                                    else
                                    {
                                        $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                    }
                                }
                            }
                            else
                            {
                                $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
    
                            }
                        }
                    }
                    // $content = str_replace($match[0], $replacement, $content);
                   
                }
                elseif( is_array( $spc_dmn_name_and_cls_arr ) && !empty( $spc_dmn_name_and_cls_arr ) )
                {
                    $matchingKey = array_search( $value_without_protocol, $linkilo_specfi_domain_arr );
    
                    if($matchingKey !== false)
                    {
                        if(isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left')
                        {
                            $replacement = ' <i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url( $link ) . '" '.$ext_attr .' >'.$match4.'</a>';
                        }
                        else
                        {
                            $replacement = '<a' . $match1 . 'href="' . esc_url( $link ) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                        }
                    }
                    else
                    {
                        if( isset( $linkilo_ext_opt_external_set['linkilo_icon_type'] ) && $linkilo_ext_opt_external_set['linkilo_icon_type'] == 'linkilo_external_icon' || $linkilo_ext_opt_external_set['linkilo_icon_type'] == 'linkilo_verified_icon' )
                        {
                            if( $linkilo_skip_check == 'true' )
                            {
                                $linkilo_htm ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
            
                                $dom = new DOMDocument();
                                $dom->loadHTML($linkilo_htm);
                                $imgTags = $dom->getElementsByTagName('img');
                                if ($imgTags->length > 0) {
            
                                    $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                }
                                else
                                {
                                    if(isset($linkilo_ext_opt_external_set['linkilo_icon_position']) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left')
                                    {
                                        $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                    }
                                    else
                                    {
                                        $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                    }
            
                                }
                            }
                            else
                            {
                                if(isset($linkilo_ext_opt_external_set['linkilo_icon_position']) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left')
                                {
                                    $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                }
                                else
                                {
            
                                    $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                }
                            }
                        }
                        else{
                                $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
    
                        }
                    }
                    // $content = str_replace($match[0], $replacement, $content);
                }
                elseif( isset($linkilo_ext_opt_external_set['linkilo_icon_type'] ) && $linkilo_ext_opt_external_set['linkilo_icon_type'] == 'linkilo_external_icon' || $linkilo_ext_opt_external_set['linkilo_icon_type'] == 'linkilo_verified_icon' )
                {
                    if($linkilo_skip_check == 'true')
                    {
                        $linkilo_htm ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
    
                        $dom = new DOMDocument();
                        $dom->loadHTML($linkilo_htm);
                        $imgTags = $dom->getElementsByTagName('img');
                        if ($imgTags->length > 0) {
    
                            $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                        }
                        else
                        {
                            if(isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left' )
                            {
                                $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                            }
                            else
                            {
                                $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                            }
    
                        }
                    }
                    else
                    {
                        if( isset( $linkilo_ext_opt_external_set['linkilo_icon_position'] ) && $linkilo_ext_opt_external_set['linkilo_icon_position'] == 'left')
                        {
                            $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                        }
                        else
                        {
    
                            $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                        }
                    }
                }
                else
                {
                    $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                }
                $content = str_replace( $match[0], $replacement, $content );
            }
        }
        return $content; 
    }
    
    /**
     * This function is used for checking external Links
     *
     *
     * @return  void
     */
    public function is_external_link( $url ) {
        $site_url = get_site_url();
    
        if ( strpos( $url, $site_url ) !== 0 ) {
            return true; // External link
        }
    
        return false; // Internal link
    }

    /**
     * This function is used for add icons before or after nnternal links
     *
     *
     * @return  void
     */
    public function add_internal_link_content($content)
    {
        $linkilo_selectedClass           = '';
        $linkilo_internal_icon_type         = get_option('linkilo_internal_icon_type',true);
        $linkilo_internal_icon         = get_option('linkilo_internal_icon',true);
        $linkilo_internal_verified_icon = get_option('linkilo_internal_verified_icon',true); 
        
        $linkilo_interlanl_icon_position    = get_option('linkilo_interlanl_icon_position',true);
        $linkilo_internal_skip_icon         = get_option('linkilo_internal_skip_icon',true);
        $linkilo_intl_excl_domain_from_icon = get_option('linkilo_internal_exclude_domain_from_icon',true);
        $linkilo_internal_specific_domain   = get_option('linkilo_internal_specific_domain',true);
        $linkilo_internal_spc_dmn_icon      = get_option('linkilo_internal_spc_dmn_icon',true);
        $linkilo_spc_dmnname_and_icon_arr= array();
        if(!empty($linkilo_internal_specific_domain)){
            if(is_array($linkilo_internal_specific_domain))
            {
                foreach ($linkilo_internal_specific_domain as $key => $linki_dmn_name) {
                    if (isset($linkilo_internal_spc_dmn_icon[$key])) {
                        $linkilo_icon_class = $linkilo_internal_spc_dmn_icon[$key];
                        $linkilo_spc_dmnname_and_icon_arr[$linki_dmn_name] = $linkilo_icon_class;
                    }
                }
            }
        }

        if(!empty($linkilo_internal_icon_type) && $linkilo_internal_icon_type == 'linkilo_internal_icon')
        {
            if( $linkilo_internal_icon ){

                $linkilo_selectedClass = $linkilo_internal_icon;
            }else{

                $linkilo_selectedClass = '';
            }
        }
        elseif(!empty($linkilo_internal_icon_type) && $linkilo_internal_icon_type == 'linkilo_internal_verified_icon')
        {
            $linkilo_selectedClass = $linkilo_internal_verified_icon;
        }
        else
        {
            $linkilo_selectedClass = '';
        }

        $exclude_domain_name_internal_links                = trim( $linkilo_intl_excl_domain_from_icon );
    
        $deomain_name_with_remove_spaces    = preg_replace( '/\s*,\s*/', ',', $exclude_domain_name_internal_links );
       
        $linkilo_exclude_dmnfrm_icon_arr    = explode( ",",$deomain_name_with_remove_spaces );

        
        $pattern = '/<a(.*?)href=["\'](.*?)["\'](.*?)>(.*?)<\/a>/i';

        // Match all links in the content
        $matches                            = array();
        $linkili_excl_doamin_arr   = array();
        $linkilo_specfi_domain_arr          = array();
        $linkilo_icon_spec_dmn              = array();
        preg_match_all( $pattern, $content, $matches, PREG_SET_ORDER );
    
        foreach ( $linkilo_exclude_dmnfrm_icon_arr as $url ) {
            $url_without_proto           = str_replace( array( 'http://', 'https://' ), '', $url );
            $url_without_protocol = rtrim( $url_without_proto, '/\\' );
            array_push( $linkili_excl_doamin_arr,$url_without_protocol );
        }

        if( !empty( $linkilo_spc_dmnname_and_icon_arr ) )
        {
            foreach ( $linkilo_spc_dmnname_and_icon_arr as $spc_domain_name => $specfic_dmn_clss) {
                $url_without_proto2 = str_replace( array( 'http://', 'https://' ), '', $spc_domain_name );
                $url_without_protocol2 = rtrim( $url_without_proto2, '/\\' );

                array_push( $linkilo_icon_spec_dmn,$specfic_dmn_clss );
                array_push( $linkilo_specfi_domain_arr,$url_without_protocol2 );
            }
        }

        // Loop through the matches
        foreach ( $matches as $match ) {
            $link = isset( $match[2] ) ? $match[2] : '';
            $ext_attr   = isset( $match[3] ) ? $match[3] : '';
            $match4     = isset( $match[4] ) ? $match[4] : '';
            $match1     = isset( $match[1] ) ? $match[1] : '';

            if ( $this->is_internal_link( $link ) ) {
                
                // Modify internal link content here
                // For example, you can add something before or after the link
                $value_without_proto    = str_replace( array( 'http://', 'https://' ), '', $link ); 
                $value_without_protocol = rtrim( $value_without_proto, '/\\' );

                if( is_array( $linkilo_exclude_dmnfrm_icon_arr ) && !empty( $linkilo_exclude_dmnfrm_icon_arr ) )
                {

                   if( in_array( $value_without_protocol, $linkili_excl_doamin_arr ) )
                   {
                        $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                   }
                   else
                   {
                        $matchingKey = array_search( $value_without_protocol, $linkilo_specfi_domain_arr );
                        
                        if( $matchingKey !== false )
                        {
                            if( !empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left' )
                            {
                                $replacement = ' <i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                            }
                            else
                            {
                                $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                            }
                        }
                        else
                        {
                            if( !empty( $linkilo_internal_icon_type) && $linkilo_internal_icon_type == 'linkilo_internal_icon' || $linkilo_internal_icon_type == 'linkilo_internal_verified_icon' )
                            {
                                if( $linkilo_internal_skip_icon == 'on' )
                                {
                                    $linkilo_htm ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                
                                    $dom = new DOMDocument();
                                    $dom->loadHTML( $linkilo_htm );
                                    $imgTags = $dom->getElementsByTagName( 'img' );
                                    if ($imgTags->length > 0) {
                
                                        $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                    }
                                    else
                                    {
                                        if(  !empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left')
                                        {
                                            $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                        }
                                        else
                                        {
                                            $replacement = '<a' . $match1 . 'href="' . esc_url( $link ) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                        }
                
                                    }
                                }
                                else
                                {
                                    if(  !empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left' )
                                    {
                                        $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                    }
                                    else
                                    {
                                        $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                    }
                                }
                            }
                            else
                            {
                                $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
    
                            }
                        }
                    }
                    // $content = str_replace($match[0], $replacement, $content);
                   
                }
                elseif( is_array( $linkilo_spc_dmnname_and_icon_arr ) && !empty( $linkilo_spc_dmnname_and_icon_arr ) )
                {
                    $matchingKey = array_search( $value_without_protocol, $linkilo_specfi_domain_arr );
    
                    if($matchingKey !== false)
                    {
                        if(!empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left')
                        {
                            $replacement = ' <i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url( $link ) . '" '.$ext_attr .' >'.$match4.'</a>';
                        }
                        else
                        {
                            $replacement = '<a' . $match1 . 'href="' . esc_url( $link ) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_icon_spec_dmn[$matchingKey].'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                        }
                    }
                    else
                    {
                        if(!empty( $linkilo_internal_icon_type) && $linkilo_internal_icon_type == 'linkilo_internal_icon' || $linkilo_internal_icon_type == 'linkilo_internal_verified_icon')
                        {
                            if( $linkilo_internal_skip_icon == 'on')
                            {
                                $linkilo_htm ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
            
                                $dom = new DOMDocument();
                                $dom->loadHTML($linkilo_htm);
                                $imgTags = $dom->getElementsByTagName('img');
                                if ($imgTags->length > 0) {
            
                                    $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                }
                                else
                                {
                                    if(!empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left')
                                    {
                                        $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                    }
                                    else
                                    {
                                        $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                    }
            
                                }
                            }
                            else
                            {
                                if(!empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left')
                                {
                                    $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                                }
                                else
                                {
            
                                    $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                                }
                            }
                        }
                        else{
                                $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
    
                        }
                    }
                    // $content = str_replace($match[0], $replacement, $content);
                }
                elseif( !empty( $linkilo_internal_icon_type) && $linkilo_internal_icon_type == 'linkilo_internal_icon' || $linkilo_internal_icon_type == 'linkilo_internal_verified_icon')
                {
                    if($linkilo_internal_skip_icon == 'on')
                    {
                        $linkilo_htm ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
    
                        $dom = new DOMDocument();
                        $dom->loadHTML($linkilo_htm);
                        $imgTags = $dom->getElementsByTagName('img');
                        if ($imgTags->length > 0) {
    
                            $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                        }
                        else
                        {
                            if(!empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left' )
                            {
                                $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                            }
                            else
                            {
                                $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                            }
    
                        }
                    }
                    else
                    {
                        if( !empty( $linkilo_interlanl_icon_position ) && $linkilo_interlanl_icon_position == 'left')
                        {
                            $replacement = ' <i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i><a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                        }
                        else
                        {
    
                            $replacement = '<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a><i class="'.$linkilo_selectedClass.'" style="height:14px;width:14px;padding:0 6px !important;display: inline-block !important;"></i>';
                        }
                    }
                }
                else
                {
                    $replacement ='<a' . $match1 . 'href="' . esc_url($link) . '" '.$ext_attr .' >'.$match4.'</a>';
                }
                $content = str_replace( $match[0], $replacement, $content );
            }
        }
        return $content;
    }

      /**
     * This function is used for checking internal Links
     *
     *
     * @return  void
     */
    public function is_internal_link( $url ) {
        $site_url = get_site_url();
    
        if ( strpos( $url, $site_url ) === 0 ) {
            return true; // Internal link
        }
    
        return false; // External link
    }

    /**
     * This function is used for changing wordpress deafault footer message
     *
     *
     * @return  void
     */
    public function linkilo_change_admin_footer () {
        echo '<span id="footer-thankyou">Thank you for using <a href="https://linkilo.co/" target="_blank">Linkilo</a></span>';
    }

    /**
     * This function is used for adding menu and submenus
     *
     *
     * @return  void
     */
    public function addMenu() {
        if (!Linkilo_Build_ActiveLicense::isValid()) {
            add_menu_page(
                __('Linkilo', 'linkilo'),
                __('Linkilo', 'linkilo'),
                'publish_posts',
                'linkilo_license',
                [Linkilo_Build_ActiveLicense::class, 'init'],
                'dashicons-privacy'
            );

            self::check_redirect();
            return;
        }

        if (!Linkilo_Build_ActiveLicense::isValid() || Linkilo_Build_ActiveLicense::isValid()) {
            self::check_redirect();
        }

        $check = get_option('linkilo_2_license_next_check');
        $date = date('d-m-Y');

        // On linkilo plugin pages
        if (
            get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" &&
            (
                $check === $date ||
                $date > $check ||
                $check < $date
            ) &&
            isset($_GET['page']) &&
            (
                trim($_GET['page']) === "linkilo" ||
                trim($_GET['page']) === "linkilo_keywords" ||
                trim($_GET['page']) === "linkilo_focus_keywords" ||
                trim($_GET['page']) === "anchor_analysis" ||
                trim($_GET['page']) === "link_cannibalization" ||
                trim($_GET['page']) === "keyword_cannibalization" ||
                trim($_GET['page']) === "linkilo_settings" ||
                trim($_GET['page']) === "linkilo_license"
            )
        ) {
            $site_url = trailingslashit(home_url());
            if (Linkilo_Build_ActiveLicense::check_site_license($site_url, true)) {
                wp_redirect(admin_url('admin.php?page=linkilo_license'));
                exit();
            }
        }elseif(
            get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" &&
            (
                $check === $date ||
                $date > $check ||
                $check < $date
            )
        ){
            $site_url = trailingslashit(home_url());
            if (Linkilo_Build_ActiveLicense::check_site_license($site_url, true)) {
                delete_option(LINKILO_LICENSE_CHECK_TIME_OPTION);
                delete_option(LINKILO_STATUS_OF_LICENSE_OPTION);
                delete_option(LINKILO_LAST_ERROR_FOR_LICENSE_OPTION);
                delete_option('linkilo_license_error_state');
                delete_option(LINKILO_LICENSE_KEY_OPTION);
                delete_option(LINKILO_CURRENT_LICENSE_DATA_OPTION);
                delete_option('linkilo_2_license_activation');
                delete_option('linkilo_2_license_next_check');
            }
        }

        add_menu_page(
            __('Linkilo', 'linkilo'), #page_title
            __(ucwords('Linkilo'), 'linkilo'), #menu_title
            'publish_posts', #capability
            'linkilo', #menu_slug
            [Linkilo_Build_UrlRecord::class, 'init'], #callable $function
            'dashicons-admin-links' #icon_url next is postion which is null
        );

        if(LINKILO_STATUS_HAS_RUN_SCAN){
            $page_title = __('Linkilo', 'linkilo');
            $menu_title = __('Summary', 'linkilo');
        }else{
            $page_title = __('Linkilo', 'linkilo');
            $menu_title = __('Complete Install', 'linkilo');
        }

        self::$report_menu = add_submenu_page(
            'linkilo',
            $page_title,
            ucwords($menu_title),
            'publish_posts',
            'linkilo',
            [Linkilo_Build_UrlRecord::class, 'init']
        );

        // add the advanced functionality if the first scan has been run
        if(!empty(LINKILO_STATUS_HAS_RUN_SCAN)){
                // __('Add URLs', 'linkilo'), #$page_title
            add_submenu_page(
                'linkilo', #$parent_slug
                __('Add URLs', 'linkilo'), #$page_title
                __(ucwords('Add URLs'), 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'admin.php?page=linkilo&type=links' #$menu_slug /next $function / next $position
            );

            $autolinks = add_submenu_page(
                'linkilo', #$parent_slug
                __('Add New Auto Links', 'linkilo'), #$page_title
                __(ucwords('Add New Auto Links'), 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'linkilo_keywords', #$menu_slug
                [Linkilo_Build_RelateUrlKeyword::class, 'init'] #$function
            );

            //add autolink screen options
            add_action("load-" . $autolinks, function () {
                add_screen_option( 'linkilo_keyword_options', array( // todo possibly update 'keywords' to 'autolink' to avoid confusion
                    'option' => 'linkilo_keyword_options',
                ) );
            });



            $urlchanger = add_submenu_page(
                'linkilo', #$parent_slug
                __('Update URL', 'linkilo'), #$page_title
                __('Update URL', 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'urlchanger', #$menu_slug
                [Linkilo_Build_UrlReplace::class, 'init'] #$function
            );

            //add autolink screen options
            add_action("load-" . $urlchanger, function () {
                add_screen_option( 'UrlReplace', array( // todo possibly update 'keywords' to 'autolink' to avoid confusion
                    'option' => 'url_replace_option',
                ) );
            });


            $focus_keywords = add_submenu_page(
                'linkilo', #$parent_slug
                __('Linkilo', 'linkilo'), #$page_title
                __(ucwords('Focus Keyword'), 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'linkilo_focus_keywords', #$menu_slug
                [Linkilo_Build_FocusKeyword::class, 'init'] #$function
            );

            //add focus keyword screen options
            add_action("load-" . $focus_keywords, function () {
                add_screen_option( 'focus_keyword_options', array(
                    'option' => 'focus_keyword_options',
                ) );
            });

            /*Sub menu page for anchor report*/
            $anchor_analysis_report = add_submenu_page(
                'linkilo', #$parent_slug
                __('Linkilo', 'linkilo'), #$page_title
                __(ucwords('Anchor Report'), 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'anchor_analysis', #$menu_slug
                [Linkilo_Build_AnchorAnalysis::class, 'init'] #$function
            );
            //add anchor_analysis_report screen options
            add_action("load-" . $anchor_analysis_report, function () {
                add_screen_option( 'anar_rep_options', array(
                    'option' => 'anar_rep_options',
                ) );
            });
            /*Sub menu page for anchor report ends*/

            /*Sub menu page for cannibalization report for Keywords*/
            $cannibalization_keywords = add_submenu_page(
                'linkilo',#$parent_slug
                __('Linkilo', 'linkilo'), #$page_title
                __(ucwords('Keyword Cannibalization Report'), 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'keyword_cannibalization', #$menu_slug
                [Linkilo_Build_CannibalizationKeywords::class, 'init'] #$function
            );

            //add cannibalization_keywords screen options
            add_action("load-" . $cannibalization_keywords, function () {
                add_screen_option( 'cannibalization_keywords', array(
                    'option' => 'cannibalization_keywords',
                ) );
            });
            /*Sub menu page for cannibalization report for Keywords ends*/

            /*Sub menu page for cannibalization report for Links*/
            $cannibalization_links = add_submenu_page(
                'linkilo',#$parent_slug
                __('Linkilo', 'linkilo'), #$page_title
                __(ucwords('Link Cannibalization Report'), 'linkilo'), #$menu_title
                'publish_posts', #$capability
                'link_cannibalization', #$menu_slug
                [Linkilo_Build_CannibalizationLinks::class, 'init'] #$function
            );

            //add cannibalization_links screen options
            add_action("load-" . $cannibalization_links, function () {
                add_screen_option( 'cannibalization_links', array(
                    'option' => 'cannibalization_links',
                ) );
            });
            /*Sub menu page for cannibalization report for Links ends*/
        }
        add_submenu_page(
            'linkilo', #$parent_slug
            __('Linkilo', 'linkilo'), #$page_title
            __(ucwords('Settings'), 'linkilo'), #$menu_title
            'publish_posts', #$capability
            'linkilo_settings', #$menu_slug
            [Linkilo_Build_AdminSettings::class, 'init'] #$function
        );

    }

    // function wporg_simple_role() {
    //     add_role(
    //         'simple_role',
    //         'Simple Role',
    //         array(
    //             'read'         => true,
    //             'edit_posts'   => true,
    //             'upload_files' => true,
    //         ),
    //     );
    // }

    // Add the simple_role.






    
     /* Check redirecta based on license activation and validation
     * */
     public static function check_redirect() {
        // Valid and page check
        if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid") {
            if (isset($_GET['page']) && trim($_GET['page']) === "linkilo_license") {
                wp_redirect(admin_url('admin.php?page=linkilo'));
                exit();
            };

            if (
                !LINKILO_STATUS_HAS_RUN_SCAN &&
                isset($_GET['page']) &&
                (
                    trim($_GET['page']) === "linkilo_keywords" ||
                    trim($_GET['page']) === "linkilo_focus_keywords" ||
                    trim($_GET['page']) === "anchor_analysis" ||
                    trim($_GET['page']) === "link_cannibalization" ||
                    trim($_GET['page']) === "keyword_cannibalization"
                )
            ) {
                wp_redirect(admin_url('admin.php?page=linkilo'));
                exit();
            }
        }

        if (get_option(LINKILO_STATUS_OF_LICENSE_OPTION) != "valid") {
            if (
                isset($_GET['page']) &&
                (
                    trim($_GET['page']) === "linkilo" ||
                    trim($_GET['page']) === "linkilo_keywords" ||
                    trim($_GET['page']) === "linkilo_focus_keywords" ||
                    trim($_GET['page']) === "anchor_analysis" ||
                    trim($_GET['page']) === "link_cannibalization" ||
                    trim($_GET['page']) === "keyword_cannibalization" ||
                    trim($_GET['page']) === "linkilo_settings"
                )
            ) {
                wp_redirect(admin_url('admin.php?page=linkilo_license'));
                exit();
            };

            $last_state = get_option('linkilo_license_error_state', '');
            if (
                (
                    empty($last_state) || !empty($last_state)
                ) &&
                isset($_GET['sl_activation']) && $_GET['sl_activation'] === "false" &&
                isset($_GET['msg'])
            ) {
                wp_redirect(admin_url('admin.php?page=linkilo_license'));
                exit();
            }
        }
    }
    /**
     * Get post or term by ID from GET or POST request
     *
     * @return Linkilo_Build_Model_Feed|null
     */
    public static function getPost() {
        if (!empty($_REQUEST['term_id'])) {
            $post = new Linkilo_Build_Model_Feed((int)$_REQUEST['term_id'], 'term');


        } elseif (!empty($_REQUEST['post_id'])){
            $post = new Linkilo_Build_Model_Feed((int)$_REQUEST['post_id']);

        } else {
            $post = null;
        }

        return $post;

    }

    /**
     * Show plugin version
     *
     * @return string
     */
    public static function showVersion() {
        return "<div class='version-main' style='float: right'><span>Version <b>".LINKILO_PLUGIN_VERSION."</b></span></div>";
    }

    /**
     * Show extended error message
     *
     * @param $errno
     * @param $errstr
     * @param $error_file
     * @param $error_line
     */
    public static function handleError($errno, $errstr, $error_file, $error_line) {
        if (stristr($errstr, "WordPress could not establish a secure connection to WordPress.org")) {
            return;
        }

        $file = 'n/a';
        $func = 'n/a';
        $line = 'n/a';
        $debugTrace = debug_backtrace();
        if (isset($debugTrace[1])) {
            $file = isset($debugTrace[1]['file']) ? $debugTrace[1]['file'] : 'n/a';
            $line = isset($debugTrace[1]['line']) ? $debugTrace[1]['line'] : 'n/a';
        }
        if (isset($debugTrace[2])) {
            $func = $debugTrace[2]['function'] ? $debugTrace[2]['function'] : 'n/a';
        }

        $out = "call from <b>$file</b>, $func, $line";

        $trace = '';
        $bt = debug_backtrace();
        $sp = 0;
        foreach($bt as $k=>$v) {
            extract($v);

            $args = '';
            if (isset($v['args'])) {
                $args2 = array();
                foreach($v['args'] as $k => $v) {
                    if (!is_scalar($v)) {
                        $args2[$k] = "Array";
                    }
                    else {
                        $args2[$k] = $v;
                    }
                }
                $args = implode(", ", $args2);
            }

            $file = substr($file,1+strrpos($file,"/"));
            $trace .= str_repeat("&nbsp;",++$sp);
            $trace .= "file=<b>$file</b>, line=$line,
            function=$function(".
            var_export($args, true).")<br>";
        }

        $out .= $trace;

        echo "<b>Error:</b> [$errno] $errstr - $error_file:$error_line<br><br><hr><br><br>$out";
    }

    /**
     * Add meta box to the post edit page
     */
    public static function addMetaBoxes() {
        if (Linkilo_Build_ActiveLicense::isValid()) {
            global $pagenow,$typenow;
            $allowed_pages = array('post.php',);
            $allowed_types = array('post', 'page' , 'link');

            // if (in_array($pagenow, $allowed_pages) && in_array($typenow, $allowed_types) ) {
            if (in_array($pagenow, $allowed_pages)) {

                /*Settings meta box*/
                add_meta_box(
                    'linkilo_focus-keywords', #id
                    __( 'LINKILO - Settings', 'linkilo' ),#title
                    [Linkilo_Build_Root::class, 'showTargetKeywordsBox'], #callback
                    Linkilo_Build_AdminSettings::getPostTypes(), #screen
                    'normal', #context
                    'default', #priority
                );

                /*Outbound Links suggestions*/
                add_meta_box(
                    'linkilo_link-articles', #id
                    __( 'LINKILO - Outbound Link Suggestions', 'linkilo' ),#title
                    [Linkilo_Build_Root::class, 'showSuggestionsBox'], #callback
                    Linkilo_Build_AdminSettings::getPostTypes(), #screen
                    'normal', #context
                    'default', #priority
                );

                if (get_option('linkilo_2_show_inbound_metabox_in_post_edit') == 1) {
                    /*Inbound Links suggestions*/
                    add_meta_box(
                        'linkilo_link-internal-inbound', #id
                        __( 'LINKILO - Inbound Link Suggestions', 'linkilo' ),#title
                        [Linkilo_Build_Root::class, 'showInboundSuggestionsBox'],  #callback
                        Linkilo_Build_AdminSettings::getPostTypes(), #screen
                        'normal', #context
                        'default', #priority
                    );
                }

                /*Current post content links and analysis*/
                add_meta_box(
                    'linkilo_link_analysis_dashboard', #id
                    __( 'LINKILO - Link Analysis Dashboard', 'linkilo' ),#title
                    [Linkilo_Build_Root::class, 'showLinkAnalysisDashboard'], #callback
                    Linkilo_Build_AdminSettings::getPostTypes(), #screen
                    'normal', #context
                    'default', #priority
                );
            }
        }
    }

    /**
     * Show meta box on the post edit page
     */
    public static function showSuggestionsBox()
    {
        $post_id = isset($_REQUEST['post']) ? (int)$_REQUEST['post'] : '';
        $user = wp_get_current_user();
        $manually_trigger_suggestions = !empty(get_option('linkilo_manually_trigger_suggestions', false));
        if ($post_id) {
            include LINKILO_PLUGIN_DIR_PATH . '/templates/url_recommend_list.php';
        }
    }

    /**
     * Show meta box on the post edit page
     */
    public static function showInboundSuggestionsBox() {
        //prepage variables for template
        ?>
        <?php //_e( 'Inbound Link Suggestions Box', 'linkilo' ); ?>
        <?php
        $page = "linkilo";
        $manually_trigger_suggestions = !empty(get_option('linkilo_manually_trigger_suggestions', false));

        $post_id = isset($_GET['post']) ? (int)$_GET['post'] : '';
        $post = new Linkilo_Build_Model_Feed((int)$post_id);

        include LINKILO_PLUGIN_DIR_PATH . '/templates/metabox_incoming_recommendation_page.php';
    }

    /**
     * Show the focus keyword metabox on the post edit screen
     */
    public static function showTargetKeywordsBox()
    {
        ?>
        <?php //_e( 'Focus Keywords Box', 'linkilo' ); ?>
        <?php
        $post_id = isset($_REQUEST['post']) ? (int)$_REQUEST['post'] : '';
        $user = wp_get_current_user();
        if ($post_id) {
            $keyword_sources = Linkilo_Build_FocusKeyword::get_active_keyword_sources();
            $keywords = Linkilo_Build_FocusKeyword::get_keywords_by_post_ids($post_id);
            $negative_keyword_sources = Linkilo_Build_FocusKeyword::get_negative_keyword_sources();
            $negative_keywords = Linkilo_Build_FocusKeyword::get_negative_keywords_by_post_ids($post_id);
            $post = new Linkilo_Build_Model_Feed($post_id, 'post');
            $is_metabox = true;

            include LINKILO_PLUGIN_DIR_PATH . '/templates/focus_keyword_list.php';
        }
    }

    /**
     * Show meta box of showLinkAnalysisDashboard post edit page
     */
    public static function showLinkAnalysisDashboard(){
        $post_id = isset($_REQUEST['post']) ? (int)$_REQUEST['post'] : '';
        $user = wp_get_current_user();

        if ($post_id) {
            $current_post_links_analysis = Linkilo_Build_Console::getLinksAnalysisData($post_id);

            $external_rows = [];
            $internal_rows = [];
            
            if (sizeof($current_post_links_analysis) > 0){   
                $key_external = 'internal';
                $externals = 0;
                $external_rows = array_filter($current_post_links_analysis, function ($element) use ($key_external, $externals) {
                    return isset($element[$key_external]) && $element[$key_external] == $externals;
                });

                $key_internal = 'internal';
                $internals = 1;
                $internal_rows = array_filter($current_post_links_analysis, function ($element) use ($key_internal, $internals) {
                    return isset($element[$key_internal]) && $element[$key_internal] == $internals;
                });
            }

            $posts_internal_links_count = Linkilo_Build_Console::getInternalLinksCount($post_id, 'in');
            $posts_external_links_count = Linkilo_Build_Console::getLinksCountDashboardExternal($post_id);
            $posts_total_links_count = $posts_internal_links_count + $posts_external_links_count;
            
            $posts_nofollow_links_count = Linkilo_Build_Console::getLinksCountDashboardNofollow($post_id);

            $posts_sponsered_links_count = Linkilo_Build_Console::getInternalLinksCount($post_id, 'sp');

            // 1 = _blank and 0 = same_tab
            $posts_new_tab_links_count = Linkilo_Build_Console::getLinksCountTargetBlank($post_id, 1);
            $posts_same_tab_links_count = Linkilo_Build_Console::getLinksCountTargetBlank($post_id, 0);

            include LINKILO_PLUGIN_DIR_PATH . '/templates/link_analysis_dashboard.php';
        }

    }

    // Fetch link preview data from the target URL
    public static function linkilo_fetch_link_preview($url) {
        $response = wp_remote_get($url);
        $html = wp_remote_retrieve_body($response);

        if (!empty(trim($html))) {
            $dom = new DOMDocument();
            @$dom->loadHTML($html);

            $title = $dom->getElementsByTagName('title')->item(0)->nodeValue;
            $description = '';
            $image = '';

            foreach ($dom->getElementsByTagName('meta') as $meta) {
                if ($meta->getAttribute('name') === 'description') {
                    $description = $meta->getAttribute('content');
                }
                if ($meta->getAttribute('property') === 'og:image') {
                    $image = $meta->getAttribute('content');
                }
            }

            
            return [
                'title' => $title,
                'description' => $description,
                'image' => $image
            ];
        }else{
            return [
                'title' => "",
                'description' => "",
                'image' => ""
            ];
        }
    }

    public function linkilo_link_preview_handle() {
        // if (
        //     !isset($_POST['url']) || empty($_POST['url']) ||
        //     !isset($_POST['post_id']) || empty($_POST['post_id']) ||
        //     !isset($_POST['nonce']) || empty($_POST['nonce']) || 
        //     !wp_verify_nonce( $_POST['nonce'], 'linkilo-get-previews' )
        // ) {
        //     $response = array(
        //         'status' => 0
        //     );
        //     wp_send_json($response);
        //     wp_die();
        //     exit;
        // }

        $url = $_POST['url'];
        // $post_id = $_POST['post_id'];

        // if ( get_post_status ($post_id ) === 'publish' ) {
        //     $content = get_the_content( null, false, $post_id);

        //     if (stripos($content,$url)) {
        //         $preview_data = self::linkilo_fetch_link_preview($url);

        //         if(!is_null($preview_data)){
        //             $response = array(
        //                 'status' => 1,
        //                 'data' => $preview_data,
        //                 'message' => 'url is on content and preview call has made'
        //             );
        //         }else{
        //             $response = array(
        //                 'status' => 0,
        //                 'data' => null,
        //                 'message' => 'url is in content and preview call has made = but preview variable is null'
        //             );
        //         }
        //     }else{
        //         $preview_data = null;
        //         $response = array(
        //             'status' => 0,
        //             'data' => null,
        //             'message' => 'url not found in content'
        //         );
        //     }
        // }else{
        //     $preview_data = null;
        //     $response = array(
        //         'status' => 0,
        //         'message' => 'current post is not published'
        //     );
        // }

        // wp_send_json($response);
        // wp_die();

        $preview_data = self::linkilo_fetch_link_preview($url);
        echo json_encode($preview_data);
        wp_die();
    }

    public static function linkilo_handle_checked_rows(){
        $response = array();
        // check for keywords existance
        $row_count = Linkilo_Build_Console::getGscFocusCount();

        // return if not available
        if (intval($row_count) === 0) {
            $response = array( 'status' =>  0);
            wp_send_json($response);
            wp_die();
            exit;
        }

        // process and validate post data
        if (
            !isset($_POST['state']) ||
            ! isset($_POST['nonce']) ||
            ! wp_verify_nonce( $_POST['nonce'], 'linkilo-modify-the-focus-table-checked-rows' )
        ) {
            $response = array('status' => 0);
            wp_send_json($response);
            wp_die();
            exit;
        }

        // set variable
        $checkbox_state = sanitize_text_field($_POST['state']);

        // set column value
        if ($checkbox_state == 'true') {
            $check_column = 1;
        }

        if ($checkbox_state == 'false') {
            $check_column = 0;
        }

        global $wpdb;
        $focus_table = $wpdb->prefix . 'linkilo_focus_keyword_data';
        $keyword_type = 'gsc-keyword';
        // fire update
        $update_rows = $wpdb->update(
            $focus_table, # update table
            array('checked' => $check_column), # set column value
            array('keyword_type' => $keyword_type), # where column value is
            array('%d'), # format for set
            array('%s') # format for where
        );

        if(false !== $update_rows){
            # updated
            $response = array('status' => 1);
        }else{
            # not updated
            $response = array('status' => 0);
        }

        // respond
        wp_send_json($response);
        wp_die();
        exit;
    }

    public function linkilo_save_external_settings_extra_fields_callback()
    {
        $linkilo_icon_type = isset($_POST['linkilo_icon_type']) ? $_POST['linkilo_icon_type'] : '';
        $linkilo_icon_position = isset($_POST['linkilo_icon_position']) ? $_POST['linkilo_icon_position'] : '';
        if(empty($linkilo_icon_type))
        {
            $linkilo_selectedClass ='';
        }
        else{
            $linkilo_selectedClass = isset($_POST['linkilo_selectedClass']) ? $_POST['linkilo_selectedClass'] : '';
        }
        
        $linkilo_isChecked = isset($_POST['linkilo_isChecked']) ? $_POST['linkilo_isChecked'] : '';
        $linkilo_exclude_iconfordmn_name = isset($_POST['linkilo_exclude_iconfordmn']) ? $_POST['linkilo_exclude_iconfordmn'] : '';
        $linkilo_dmn_fileds_arr = isset($_POST['fieldvalues_arr']) ? $_POST['fieldvalues_arr'] : '';

        $linkilio_arr = array(
            'linkilo_icon_type' => $linkilo_icon_type,
            'linkilo_selectedClass' => $linkilo_selectedClass,
            'linkilo_skip_isChecked' =>$linkilo_isChecked,
            'linkilo_icon_position'  => $linkilo_icon_position,
            'linkilo_exclude_iconfordmn_name' => $linkilo_exclude_iconfordmn_name,
            'spc_dmn_name_and_cls_arr' =>$linkilo_dmn_fileds_arr

        );
        update_option('linkilo_external_setting_ext_field', $linkilio_arr);
        wp_die();
        exit;
    }

    /**
     * Handle follow unfollow toggle checkbox operation made on post edit screen under linkilo link anylysis section
     */
    public static function linkilo_handle_follow_unfollow_operation(){
        $response = array();

        $total = isset($_POST['total']) ? intval($_POST['total']) : null;
        $array_size = isset($_POST['checked_array']) ? sizeof($_POST['checked_array']) : null;
        $toggle_post = isset($_POST['post']) ? intval($_POST['post']) : null;

        if ($total > 0 && !is_null($total) && !is_null($array_size) && !is_null($toggle_post)) {
            $checkboxes = $_POST['checked_array'];
            $process_count = 0;

            // search in content and add the relative attribute
            $post_type = get_post_type($toggle_post);
            $post = new Linkilo_Build_Model_Feed($toggle_post, $post_type);
            $content = $post->getContent();

            // Loop through array
            foreach ($checkboxes as $checkbox) {
                // $toggle_val = nofollow = 1
                // $toggle_val = follow = 0

                // set variables
                $toggle_val = intval($checkbox['checked_val']);
                $toggle_id = intval($checkbox['id']);
                $toggle_url = base64_decode($checkbox['url']);
                $toggle_anchor = base64_decode($checkbox['anchor']);

                // $matches an array of exact matched strings with anchor open and close tag
                preg_match_all('|<a\s[^>]*href=["\']' . $toggle_url . '[\'"][^>]*>.*?'.$toggle_anchor.'.*?</a>|', $content, $matches);

                $updated = false;
                if (sizeof($matches) > 0) {
                    $matches_u = array_unique($matches[0]);
                }

                if (sizeof($matches_u) > 0) {
                    foreach ($matches_u as $anchor_tag) {
                        // set replacement variable, it will be overwritten after below process
                        $replacement_anchor = null;

                        if ($toggle_val === 1 ) {
                            // $toggle_val = nofollow = 1
                            // operation 1 - Add nofollow

                            // sub operation 1 - add nofollow if there is rel attribute in the tag and nofollow is not there
                            // ex. rel="noreferrer noopener"

                            // check for rel attribute
                            if (strpos($anchor_tag, "rel=") !== false) {

                                // there is rel attribute in the anchor tag string

                                // check if nofollow is there
                                if (stripos($anchor_tag, "nofollow") == false) {

                                    // nofollow is not in the string

                                    // check if dofollow is there
                                    if (stripos($anchor_tag, "dofollow") !== false) {
                                        // dofollow is there
                                        $replacement_anchor = str_ireplace("dofollow", "nofollow", $anchor_tag);
                                    }else{
                                        // place nofollow inside the attribute
                                        $replacement_anchor = str_ireplace("rel=\"", "rel=\"nofollow ", $anchor_tag);
                                    }
                                }
                            }else{
                                // sub operation 2 - add nofollow if there is no rel attribute in the anchor tag
                                // for ex. - <a href="#">link</a>
                                // for ex. add - rel="nofollow"

                                $replacement_anchor = str_ireplace("<a", "<a rel=\"nofollow\"", $anchor_tag);
                            }
                        }elseif ($toggle_val === 0 ) {
                            // $toggle_val = follow = 0
                            // operation 2 - Remove nofollow

                            // sub operation 1 - remove nofollow if there is rel attribute in tag and nofollow is there
                            // ex. rel="noreferrer noopener nofollow"

                            // check for rel attribute
                            if (strpos($anchor_tag, "rel=") !== false) {

                                // there is rel attribute in the anchor tag string

                                // check if nofollow is there
                                if (stripos($anchor_tag, "nofollow") !== false) {

                                    // nofollow is in the string

                                    // replace nofollow with dofollow from the anchor tag
                                    $replacement_anchor = str_ireplace("nofollow", "dofollow", $anchor_tag);

                                    if (!is_null($replacement_anchor) && stripos($replacement_anchor, "rel=\" \"") !== false) {
                                        // there is rel attribute and it has no values inside
                                        // ex. rel="", it's like this
                                        // remove rel attribute
                                        $removed_rel_attribute = str_ireplace("rel=\" \"", "", $replacement_anchor);
                                        $replacement_anchor = $removed_rel_attribute;
                                    }
                                }
                            }else{
                                // sub operation 2 - add nofollow if there is no rel attribute in the anchor tag
                                // for ex. - <a href="#">link</a>
                                // for ex. add - rel="nofollow"

                                $replacement_anchor = str_ireplace("<a", "<a rel=\"dofollow\"", $anchor_tag);
                            }
                        }


                        if (is_null($replacement_anchor)) {
                            $replacement_anchor = $anchor_tag;
                            $updated = true;
                        }else{
                            // replace the phrase in the content itself
                            $content = str_ireplace($anchor_tag, $replacement_anchor, $content);
                            $updated = $post->updateContent($content);
                        }

                    }
                }

                if ($updated) {
                        // perform updation in table
                    global $wpdb;
                    $links_table = $wpdb->prefix . 'linkilo_report_links';

                    $update_row = $wpdb->update($links_table, array('nofollow' => $toggle_val), array('link_id' => $toggle_id, 'post_id' => $toggle_post, ), array('%d'), array('%d', '%d'));

                    if(false !== $update_row){
                        $process_count++;
                    }
                }
            }

            if (!is_null($process_count) && $process_count === $array_size) {
                $response['status'] = 1;
                $response['title'] = 'Done';
                $response['msg'] = "All Changes has been made successfully.\n Total links: ".$array_size."\n Processed: ".$process_count;
                $response['icon'] = "success";
            }else{
                $response['status'] = 0;
                $response['title'] = 'Process Completed!';
                $response['msg'] = "Some links are remained to be processed.\n Total links: ".$array_size."\n Processed: ".$process_count;
                $response['icon'] = "info";
            }
        }else{
            $response['status'] = 0;
            $response['title'] = 'Process Error';
            $response['msg'] = "Invaild parameters!";
            $response['icon'] = "error";
        }

        wp_send_json($response);
        exit();
    }


    /**
     * Makes sure the link suggestions and the focus keyword metaboxes are in the same general grouping
     **/
    public static function group_metaboxes($option){
        if(empty($option)){
            return $option;
        }

        if (!empty($option['normal'])) {
            $normal_array = explode(',', $option['normal']);

            if (($key = array_search('linkilo_focus-keywords', $normal_array)) !== false) {
                unset($normal_array[$key]);
            }
            if (($key = array_search('linkilo_link-internal-inbound', $normal_array)) !== false) {
                unset($normal_array[$key]);
            }
            if (($key = array_search('linkilo_link-articles', $normal_array)) !== false) {
                unset($normal_array[$key]);
            }
            if (($key = array_search('linkilo_link-analysis', $normal_array)) !== false) {
                unset($normal_array[$key]);
            }
            if (($key = array_search('linkilo_link_analysis_dashboard', $normal_array)) !== false) {
                unset($normal_array[$key]);
            }

            if (sizeof($normal_array) > 0) {
                $option['normal'] = implode(',', $normal_array);
            }else{
                $option['normal'] = '';
            }
        }

        if (!empty($option['advanced'])) {
            $advanced_array = explode(',', $option['advanced']);

            if (($key = array_search('linkilo_focus-keywords', $advanced_array)) !== false) {
                unset($advanced_array[$key]);
            }
            if (($key = array_search('linkilo_link-internal-inbound', $advanced_array)) !== false) {
                unset($advanced_array[$key]);
            }
            if (($key = array_search('linkilo_link-articles', $advanced_array)) !== false) {
                unset($advanced_array[$key]);
            }
            if (($key = array_search('linkilo_link-analysis', $advanced_array)) !== false) {
                unset($advanced_array[$key]);
            }
            if (($key = array_search('linkilo_link_analysis_dashboard', $advanced_array)) !== false) {
                unset($advanced_array[$key]);
            }

            if (sizeof($advanced_array) > 0) {
                $option['advanced'] = implode(',', $advanced_array);
            }else{
                $option['advanced'] = '';
            }
        }

        if (!empty($option['side'])) {
            $side_array = explode(',', $option['side']);

            if (($key = array_search('linkilo_focus-keywords', $side_array)) !== false) {
                unset($side_array[$key]);
            }
            if (($key = array_search('linkilo_link-internal-inbound', $side_array)) !== false) {
                unset($side_array[$key]);
            }
            if (($key = array_search('linkilo_link-articles', $side_array)) !== false) {
                unset($side_array[$key]);
            }
            if (($key = array_search('linkilo_link-analysis', $side_array)) !== false) {
                unset($side_array[$key]);
            }
            if (($key = array_search('linkilo_link_analysis_dashboard', $side_array)) !== false) {
                unset($side_array[$key]);
            }

            if (sizeof($side_array) > 0) {
                $option['side'] = implode(',', $side_array);
            }else{
                $option['side'] = '';
            }
        }

        return $option;
    }

    /**
     * Add scripts to the admin panel
     *
     * @param $hook
     */
    public static function addScripts($hook) {
        // ****** css ******//
        $style_path1 = 'css/admin_load.css';
        $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path1;
        $ver = filemtime($f_path);
        
        wp_register_style('admin_load_style', LINKILO_PLUGIN_DIR_URL.$style_path1, $deps=[], $ver);
        wp_enqueue_style('admin_load_style');

        if (strpos($_SERVER['REQUEST_URI'], '/post.php') !== false || strpos($_SERVER['REQUEST_URI'], '/term.php') !== false || (!empty($_GET['page']) && $_GET['page'] == 'linkilo')) {
            wp_enqueue_editor();
            /*============================================================*/
            $js_path = 'js/sweetalert2.all.min.js';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
            $ver = filemtime($f_path);
            wp_register_script('swal2_all_min', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery'), $ver, $in_footer=true);
            wp_enqueue_script('swal2_all_min');
            /*============================================================*/
        }

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && count($_GET) === 1) {
            if(LINKILO_STATUS_HAS_RUN_SCAN )
            {
                $style_path1 = 'css/dashboard_welcome.css';
                $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path1;
                $ver = filemtime($f_path);
                
                wp_register_style('dashboard_welcome', LINKILO_PLUGIN_DIR_URL.$style_path1, $deps=[], $ver);
                wp_enqueue_style('dashboard_welcome');
            }
        }

        /* enqueue wizard css */

        if(!LINKILO_STATUS_HAS_RUN_SCAN )
        {
            $style_path1 = 'css/dashboard_wizard.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path1;
            $ver = filemtime($f_path);
            
            wp_register_style('dashboard_wizard', LINKILO_PLUGIN_DIR_URL.$style_path1, $deps=[], $ver);
            wp_enqueue_style('dashboard_wizard');
            wp_register_script('block-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js');
            wp_enqueue_script('block-ui');
            wp_register_style('fontaww',LINKILO_PLUGIN_DIR_URL.'fontawesome/css/all.min.css');
                wp_enqueue_style('fontaww');
                wp_register_script('fontaww-script', LINKILO_PLUGIN_DIR_URL.'fontawesome/js/all.min.js');
                wp_enqueue_script('fontaww-script');
        }

        /* enqueue wizard css */
        /* enqueue wizard css */

        if(!LINKILO_STATUS_HAS_RUN_SCAN )
        {
            $style_path1 = 'js/dashboard_wizard.js';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path1;
            $ver = filemtime($f_path);
            
            wp_register_script('dashboard_wizard_js', LINKILO_PLUGIN_DIR_URL.$style_path1, $deps=[], $ver);
            wp_enqueue_script('dashboard_wizard_js');
           
        }

        /* enqueue wizard css */

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && isset($_GET['type']) && ($_GET['type'] == 'incoming_suggestions_page')) {
            /*============================================================*/
            $js_path = 'js/sweetalert2.all.min.js';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
            $ver = filemtime($f_path);
            wp_register_script('swal2_all_min', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery'), $ver, $in_footer=true);
            wp_enqueue_script('swal2_all_min');
            /*============================================================*/

            /*============================================================*/
            $js_path = 'js/sweetalert2.min.js';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
            $ver = filemtime($f_path);
            wp_register_script('swal2_min_js', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery'), $ver, $in_footer=true);
            wp_enqueue_script('swal2_min_js');
            /*============================================================*/

            /*============================================================*/
            $style_path = 'css/sweetalert2.min.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path;
            $ver = filemtime($f_path);
            wp_register_style('swal2_min_css', LINKILO_PLUGIN_DIR_URL.$style_path, $deps=[], $ver);
            wp_enqueue_style('swal2_min_css');
            /*============================================================*/

        }

        wp_register_script('linkilo_sweetalert_script_min', LINKILO_PLUGIN_DIR_URL . 'js/sweetalert.min.js', array('jquery'), $ver=false, $in_footer=true);
        wp_enqueue_script('linkilo_sweetalert_script_min');
       
        $js_path = 'js/linkilo_admin.js';
        $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
        $ver = filemtime($f_path);
        $current_screen = get_current_screen();

        wp_register_script('linkilo_admin_script', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery','jquery-ui-autocomplete'), $ver, $in_footer=true);
        wp_enqueue_script('linkilo_admin_script');
        
        // Individual URL Update Scripts
        if  (isset($_GET['page'] ) && $_GET['page'] === 'urlchanger' ){
            wp_enqueue_script('linkilo-url-changer', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_individual_urlchanger.js', array( 'jquery' ), $ver, $in_footer = true );
            

            wp_localize_script('linkilo-url-changer', 'linkilo_url_changer_object', array( 
                'ajax_url' => admin_url('admin-ajax.php'),
                'u_nonce' => wp_create_nonce('linkilo-url-changer-undo-nonce'),
                'r_nonce' => wp_create_nonce('linkilo-url-changer-replace-nonce'),
            ));

        }

        // URL replace js
        $js_path_url = 'js/linkilo_url_changer.js';
        $f_path_url = LINKILO_PLUGIN_DIR_PATH.$js_path_url;
        $ver_url = filemtime($f_path_url);
        $current_screen_url = get_current_screen();

        wp_register_script('linkilo_url_replace_script', LINKILO_PLUGIN_DIR_URL.$js_path_url, array('jquery','jquery-ui-autocomplete'), $ver_url, $in_footer=true);
        wp_enqueue_script('linkilo_url_replace_script');

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && isset($_GET['type']) && ($_GET['type'] == 'incoming_suggestions_page' || $_GET['type'] == 'click_details_page') ||
            (!empty($current_screen_url) && ('post' === $current_screen_url->base || 'page' === $current_screen_url->base)))
        {
            wp_register_style('linkilo_daterange_picker_css', LINKILO_PLUGIN_DIR_URL . 'css/daterangepicker.css');
            wp_enqueue_style('linkilo_daterange_picker_css');
            wp_register_script('linkilo_moment', LINKILO_PLUGIN_DIR_URL . 'js/moment.js', array('jquery'), $ver, $in_footer = true);
            wp_enqueue_script('linkilo_moment');
            wp_register_script('linkilo_daterange_picker', LINKILO_PLUGIN_DIR_URL . 'js/daterangepicker.js', array('jquery', 'linkilo_moment'), $ver, $in_footer = true);
            wp_enqueue_script('linkilo_daterange_picker');
        }

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && isset($_GET['type']) && $_GET['type'] == 'links') {
            wp_register_script('linkilo_url_record', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_url_record.js', array('jquery'), $ver, $in_footer = true);
            wp_enqueue_script('linkilo_url_record');
        }

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && isset($_GET['type']) && $_GET['type'] == 'error') {
            wp_register_script('linkilo_broken_url_error', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_broken_url_error.js', array('jquery'), $ver, $in_footer = true);
            wp_enqueue_script('linkilo_broken_url_error');
        }

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && isset($_GET['type']) && $_GET['type'] == 'domains') {
            wp_register_script('linkilo_domains', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_domains.js', array('jquery'), $ver, $in_footer = true);
            wp_enqueue_script('linkilo_domains');
        }

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo' && isset($_GET['type']) && ( $_GET['type'] == 'click_details_page' || $_GET['type'] == 'clicks')) {
            wp_register_script('linkilo_url_click', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_url_click.js', array('jquery'), $ver, $in_footer = true);
            wp_enqueue_script('linkilo_url_click');
        }

        if (isset($_GET['page']) && $_GET['page'] == 'linkilo_keywords') {
            wp_register_script('linkilo_relate_keyword', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_relate_keyword.js', array('jquery', 'jquery-ui-autocomplete'), $ver, $in_footer=true);
            wp_enqueue_script('linkilo_relate_keyword');
        }

        if (
            isset($_GET['page']) &&
            $_GET['page'] == 'linkilo' &&
            !isset($_GET['type']) &&
            !isset($_GET['post_type'])
        ){
            /*==============================================================================*/
            $style_path = 'css/concept.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path;
            $ver = filemtime($f_path);
            wp_register_style('linkilo_concept_style', LINKILO_PLUGIN_DIR_URL.$style_path, $deps=[], $ver);
            wp_enqueue_style('linkilo_concept_style');

            $style_path = 'css/admin_load.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path;
            $ver = filemtime($f_path);
            wp_register_style('linkilo_admin_load', LINKILO_PLUGIN_DIR_URL.$style_path, $deps=[], $ver);
            wp_enqueue_style('linkilo_admin_load');
            /*==============================================================================*/

            /*==============================================================================*/
            $style_path = 'plugins/bootstrap/css/bootstrap.min.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path;
            $ver = filemtime($f_path);
            wp_register_style('linkilo_bootstrap_style', LINKILO_PLUGIN_DIR_URL.$style_path, $deps=[], $ver);
            wp_enqueue_style('linkilo_bootstrap_style');
            /*==============================================================================*/


            /*==============================================================================*/
            $js_path = 'plugins/bootstrap/js/bootstrap.min.js';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
            $ver = filemtime($f_path);
            wp_register_script('linkilo_bootstrapmin_script', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery'), $ver, $in_footer=true);
            wp_enqueue_script('linkilo_bootstramin_script');
            /*==============================================================================*/

            /*==============================================================================*/
            $js_path = 'plugins/chartjs/chart.min.js';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
            $ver = filemtime($f_path);

            wp_register_script('linkilo_charts_script', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery'), $ver, $in_footer=true);
            wp_enqueue_script('linkilo_charts_script');
            /*==============================================================================*/
        }
        /*New enqueue for new dashboard ends*/

        if (isset($_GET['page']) && ($_GET['page'] == 'linkilo_focus_keywords' || $_GET['page'] == 'linkilo' && isset($_GET['type']) && $_GET['type'] === 'incoming_suggestions_page') || ('post' === $current_screen->base || 'term' === $current_screen->base) ) {
            wp_register_script('linkilo_focus_keyword', LINKILO_PLUGIN_DIR_URL . 'js/linkilo_focus_keyword.js', array('jquery'), $ver, $in_footer=true);
            wp_enqueue_script('linkilo_focus_keyword');
        }

        $js_path = 'js/linkilo_admin_settings.js';
        $f_path = LINKILO_PLUGIN_DIR_PATH.$js_path;
        $ver = filemtime($f_path);

        wp_register_script('linkilo_admin_settings_script', LINKILO_PLUGIN_DIR_URL.$js_path, array('jquery'), $ver, $in_footer=true);
        wp_enqueue_script('linkilo_admin_settings_script');

        $linkilo_fontwesome_classes = array(
            'option1' => 'fas fa-external-link-square-alt',
            'option2' => 'fa-solid fa-arrow-up-right-from-square',
            'option3' => 'fas fa-external-link-alt',
            'option4' => 'fa-solid fa-square-arrow-up-right',
            'option5' => 'fa-solid fa-check',
            'option6' => 'fa-solid fa-check-to-slot',
            'option7' => 'fa-solid fa-check-double',
            'option8' => 'fa-solid fa-square-check',
            'option9' => 'fa-regular fa-square-check',
            'option10' => 'fa-solid fa-circle-check',
            'option11' => 'fa-regular fa-circle-check',
            'option12' => 'fa-solid fa-user-check'
        );

        if (isset($_GET['section']) && !empty($_GET['section']) &&
        $_GET['section'] === "linkilo-internal-url") {
        $tab_row = "five";
        }elseif (isset($_GET['section']) && !empty($_GET['section']) &&
            $_GET['section'] === "linkilo-external-url") {
            $tab_row = "six";
        }
        else{
            $tab_row = null;

        }
        
        wp_localize_script(
            'linkilo_admin_settings_script',
            'admin_setting',
            array(
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'options' => $linkilo_fontwesome_classes,
                'tab_row' => $tab_row,
                'checked_nonce' => wp_create_nonce( 'linkilo-modify-the-focus-table-checked-rows' ),
            )
        );

        $style_path = 'css/linkilo_admin.css';
        $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path;
        $ver = filemtime($f_path);


        if (
            isset($_GET['page']) && !empty($_GET['page']) &&
            (
                $_GET['page'] == 'linkilo' ||
                $_GET['page'] == 'linkilo_keywords' ||
                $_GET['page'] == 'linkilo_focus_keywords' ||
                $_GET['page'] == 'link_cannibalization' ||
                $_GET['page'] == 'keyword_cannibalization' ||
                $_GET['page'] == 'anchor_analysis' ||
                $_GET['page'] == 'linkilo_license' ||
                $_GET['page'] == 'linkilo_settings' ||
                $_GET['page'] == 'urlchanger'
            ) ||
            strpos($_SERVER['REQUEST_URI'], '/post.php') !== false
        ){
            // load styles on specific pages
            wp_register_style('dashboard_wizard', LINKILO_PLUGIN_DIR_URL.$style_path1, $deps=[], $ver);
            wp_enqueue_style('dashboard_wizard');
            wp_register_script('block-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js');
            wp_enqueue_script('block-ui');
            wp_register_style('fontaww',LINKILO_PLUGIN_DIR_URL.'fontawesome/css/all.min.css');
                wp_enqueue_style('fontaww');
                wp_register_script('fontaww-script', LINKILO_PLUGIN_DIR_URL.'fontawesome/js/all.min.js');

            wp_register_style('linkilo_admin_style', LINKILO_PLUGIN_DIR_URL.$style_path, $deps=[], $ver);
            wp_enqueue_style('linkilo_admin_style');
            $style_path1 = 'css/dashboard_wizard.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path1;
            $ver = filemtime($f_path);
            
            

            

            $disable_fonts = apply_filters('linkilo_disable_fonts', false); // we've only got one font ATM
            
            if(empty($disable_fonts)){
                $style_path = 'css/linkilo_fonts.css';
                $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path;
                $ver = filemtime($f_path);

                wp_register_style('linkilo_admin_fonts', LINKILO_PLUGIN_DIR_URL.$style_path, $deps=[], $ver);
                wp_enqueue_style('linkilo_admin_fonts');
            }
        }
        if (
            isset($_GET['page']) && !empty($_GET['page']) &&
            ($_GET['page'] == 'linkilo_settings'))
            {
                wp_register_style('fontaww',LINKILO_PLUGIN_DIR_URL.'fontawesome/css/all.min.css');
                wp_enqueue_style('fontaww');
                wp_register_script('fontaww-script', LINKILO_PLUGIN_DIR_URL.'fontawesome/js/all.min.js');
                wp_enqueue_script('fontaww-script');
                wp_register_style('select2_css','https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css');
                wp_enqueue_style('select2_css');
                wp_register_script('select2_js','https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js');
                wp_enqueue_script('select2_js');
            }
       
        $ajax_url = admin_url('admin-ajax.php');
        $linkilo_completed_steps_wizard = get_option('completed_steps');

        if( empty( $linkilo_completed_steps_wizard ) && $linkilo_completed_steps_wizard !== '0')
        {
            $linkilo_completed_steps_wizard = 1;
        }
        else{
            $linkilo_completed_steps_wizard = $linkilo_completed_steps_wizard;
        }
       
        $script_params = [];
        $script_params['ajax_url'] = $ajax_url;
        $script_params['completed_steps'] = $linkilo_completed_steps_wizard;
        $script_params['completed'] = __('completed', 'linkilo');
        $script_params['site_linking_enabled'] = (!empty(get_option('linkilo_link_external_sites', false))) ? 1: 0;

        $script_params["LINKILO_PREVIOUS_REPORT_RESET_DATE_TIME_OPTIONS"] = get_option(LINKILO_PREVIOUS_REPORT_RESET_DATE_TIME_OPTIONS);

        wp_localize_script('linkilo_admin_script', 'linkilo_ajax', $script_params);
        
    }

    /**
     * Enqueues the scripts to use on the frontend.
     **/
    public static function enqueue_frontend_scripts(){
        global $post;

        // Add an option to disable the frontend scripts.
        if(empty($post)){
            return;
        }

        // get if the links are to be opened in new tabs
        $open_with_js = ( !empty( get_option( 'linkilo_js_open_new_tabs', false ) ) ) ? 1 : 0;
        $open_all_intrnl = ( !empty( get_option( 'linkilo_internal_att_blank', false ) ) ) ? 1 : 0;
        $open_all_extrnl = ( !empty( get_option( 'linkilo_external_att_blank', false ) ) ) ? 1 : 0;

        // and if the user has disabled click tracking
        $dont_track_clicks = (!empty(get_option('linkilo_disable_click_tracking', false))) ? 1: 0;

        // if none of them are, exist
        if( ($open_with_js == 0 || $open_all_intrnl == 0 && $open_all_extrnl == 0) && $dont_track_clicks == 1){
            return;
        }

        // put together the ajax variables
        $ajax_url = admin_url('admin-ajax.php');
        $script_params = [];
        $script_params['ajaxUrl'] = $ajax_url;
        $script_params['postId'] = $post->ID;
        $script_params['postType'] = (is_a($post, 'WP_Term')) ? 'term': 'post'; // todo find out if the post can be a term, or if it's always a post. // I need to know for link tracking on term pages...
        $script_params['openInternalInNewTab'] = $open_all_intrnl;
        $script_params['openExternalInNewTab'] = $open_all_extrnl;
        $script_params['disableClicks'] = $dont_track_clicks;
        $script_params['openLinksWithJS'] = $open_with_js;

        // output some actual localizations
        $script_params['clicksI18n'] = array(
            'imageNoText'   => __('Image in link: No Text', 'linkilo'),
            'imageText'     => __('Image Title: ', 'linkilo'),
            'noText'        => __('No Anchor Text Found', 'linkilo'),
        );

        // enqueue the frontend scripts
        // $file_path = LINKILO_PLUGIN_DIR_PATH . 'js/frontend.js';
        // $url_path  = LINKILO_PLUGIN_DIR_URL . 'js/frontend.js';

        // wp_enqueue_script('linkilo-frontend-script', $url_path, array('jquery'), filemtime($file_path), false);
        wp_register_style('fontaww',LINKILO_PLUGIN_DIR_URL.'fontawesome/css/all.min.css');
        wp_enqueue_style('fontaww');
        wp_register_script('fontaww-script', LINKILO_PLUGIN_DIR_URL.'fontawesome/js/all.min.js');
        wp_enqueue_script('fontaww-script');
        // output the ajax variables
        wp_localize_script('linkilo-frontend-script', 'linkiloFrontend', $script_params);

        // enqueue the frontend scripts
        if (intval(get_option('linkilo_links_preview', 0)) === 1) {

            $file_path = LINKILO_PLUGIN_DIR_PATH . 'js/link-preview.js';
            $url_path  = LINKILO_PLUGIN_DIR_URL . 'js/link-preview.js';
            wp_enqueue_script('link-preview-js', $url_path, array('jquery'), filemtime($file_path), true);


            $style_link_preview_tooltip = 'css/link-preview.css';
            $tooltip_link_preview_path = LINKILO_PLUGIN_DIR_PATH.$style_link_preview_tooltip;
            $tooltip_link_preview = filemtime($tooltip_link_preview_path);
            wp_register_style('link-preview-css', LINKILO_PLUGIN_DIR_URL.$style_link_preview_tooltip, $deps=[], $tooltip_link_preview);
            wp_enqueue_style('link-preview-css');

            $excluded_links_array = [];
            $excluded_links = get_option('linkilo_preivew_exclude_list', null);
            if (!is_null($excluded_links) && !empty(trim($excluded_links))) {
                $explode = explode("\n", $excluded_links);
                $excluded_links_array = array_map('trim', $explode);
            }

            $internal_preview_enable = get_option('linkilo_preview_internal_enable_disable',0);
            $external_preview_enable = get_option('linkilo_preview_external_enable_disable',0);

            wp_localize_script(
                'link-preview-js',
                'LinkPreview',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'excludedDomains' => $excluded_links_array,
                    'enableInternalLinks' => intval($internal_preview_enable),
                    'enableExternalLinks' => intval($external_preview_enable),
                    // 'preview_logo'=> LINKILO_PLUGIN_DIR_URL."images/preview-logo.webp"
                    // 'post' => get_the_id(),
                    // 'nonce' => wp_create_nonce('linkilo-get-previews'),
                )
            );

            $style_path1 = 'css/admin_load.css';
            $f_path = LINKILO_PLUGIN_DIR_PATH.$style_path1;
            $ver = filemtime($f_path);
            wp_register_style('admin_load_style', LINKILO_PLUGIN_DIR_URL.$style_path1, $deps=[], $ver);
            wp_enqueue_style('admin_load_style');

            /*custom popup script*/
            wp_enqueue_script( 'my-theme', 'https://code.jquery.com/ui/1.10.4/jquery-ui.js', array( 'jquery', 'jquery-ui-accordion' ) );
            wp_enqueue_style('preview-hyperlink-style', 'https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css', array(), '', false);
        }
    }

    /**
     * Show settings link on the plugins page
     *
     * @param $links
     * @return array
     */
    public static function showSettingsLink($links)
    {
        $links[] = '<a href="admin.php?page=linkilo_settings">Settings</a>';
        $links[] = '<a href="admin.php?page=linkilo">Dashboard</a>';

        return $links;
    }

    /**
     * Loads default Linkilo settings in to database on plugin activation.
     */
    public static function activate() {
        // only set default option values if the options are empty
        if('' === get_option(LINKILO_STATUS_OF_LICENSE_OPTION, '')){
            update_option(LINKILO_STATUS_OF_LICENSE_OPTION, '');
        }
        if('' === get_option(LINKILO_LICENSE_KEY_OPTION, '')){
            update_option(LINKILO_LICENSE_KEY_OPTION, '');
        }
        if('' === get_option(LINKILO_NUMBERS_TO_IGNORE_OPTIONS, '')){
            update_option(LINKILO_NUMBERS_TO_IGNORE_OPTIONS, '1');
        }
        if('' === get_option(LINKILO_SELECTED_POST_TYPES_OPTIONS, '')){
            update_option(LINKILO_SELECTED_POST_TYPES_OPTIONS, ['post', 'page']);
        }
        if('' === get_option(LINKILO_RELATE_META_POST_TYPES_OPTIONS, '')){
            update_option(LINKILO_RELATE_META_POST_TYPES_OPTIONS, ['post', 'page']);
        }
        if('' === get_option(LINKILO_RELATE_META_POST_DISPLAY_LIMIT_OPTIONS, '')){
            update_option(LINKILO_RELATE_META_POST_DISPLAY_LIMIT_OPTIONS, 10);
        }
        if('' === get_option(LINKILO_RELATE_META_POST_DISPLAY_ORDER_OPTIONS, '')){
            update_option(LINKILO_RELATE_META_POST_DISPLAY_ORDER_OPTIONS, '');
        }
        if('' === get_option(LINKILO_RELATE_META_POST_ENABLE_DISABLE_OPTIONS, '')){
            update_option(LINKILO_RELATE_META_POST_ENABLE_DISABLE_OPTIONS, '0');
        }
        if('' === get_option(LINKILO_RELATE_META_POST_TYPES_INCLUDE_OPTIONS, '')){
            update_option(LINKILO_RELATE_META_POST_TYPES_INCLUDE_OPTIONS, ['post', 'page']);
        }
        if('' === get_option(LINKILO_SITE_CONNECTION_ENTRIES_NOTICE_OPTIONS, '')){
            update_option(LINKILO_SITE_CONNECTION_ENTRIES_NOTICE_OPTIONS, '0');
        }

        /*if('' === get_option(LINKILO_GSC_POST_KEYWORDS_CHECKED_OPTIONS, '')){
            update_option(LINKILO_GSC_POST_KEYWORDS_CHECKED_OPTIONS, '0');
        }*/

        if('' === get_option(LINKILO_R_A_K_OPTIONS, '')){
            update_option(LINKILO_R_A_K_OPTIONS, "3ioqpan91aiicac67mb879u1tii5oelcareis36em3ngrarqris1e2uleianiii57o9lvutmq9i7ta1lierduvtetde3av2ruoet");
        }
        if('' === get_option(LINKILO_R_A_I_V_OPTIONS, '')){
            update_option(LINKILO_R_A_I_V_OPTIONS, "etlql9tnvntepoudlcodorit6nst8aimsn8eahai6eie1mi0qi7uxpnos9tera8uoe08ieasur5tttreuo5t8e1araitsuot5iii");
        }
        if('' === get_option(LINKILO_B_K_OPTIONS, '')){
            update_option(LINKILO_B_K_OPTIONS, "pri72m8o7vi1eiteupau8m9brdueae4n9tpis63o1g2icmoae7marut1aoeu5ai4muunatmpmuqttmnua5ani8cou52suui850ro16immesi0tpr0rit39etacge2ioa5asddiitie5sarmee99tie");
        }
        if('' === get_option('linkilo_link_external_sites_access_code', '')){
            $rand = Linkilo_Build_ConnectMultipleSite::generate_random_id_string();
            $code = substr($rand, 0, 150);
            update_option('linkilo_link_external_sites_access_code', $code);
        }
        /*if('' === get_option(LINKILO_OPEN_LINKS_IN_NEW_TAB_OPTION, '')){
            update_option(LINKILO_OPEN_LINKS_IN_NEW_TAB_OPTION, '0');
        }*/
        if('' === get_option(LINKILO_CHECK_DEBUG_MODE_OPTION, '')){
            update_option(LINKILO_CHECK_DEBUG_MODE_OPTION, '0');
        }
        if('' === get_option(LINKILO_UPDATE_REPORT_AT_SAVE_OPTIONS, '')){
            update_option(LINKILO_UPDATE_REPORT_AT_SAVE_OPTIONS, '0');
        }
        if('' === get_option(LINKILO_WORDS_LIST_TO_IGNORE_OPTIONS, '')){
            $ignore = "-\r\n" . implode("\r\n", Linkilo_Build_AdminSettings::getIgnoreWords()) . "\r\n-";
            update_option(LINKILO_WORDS_LIST_TO_IGNORE_OPTIONS, $ignore);
        }
        if('' === get_option(LINKILO_IS_LINKS_TABLE_CREATED, '')){
            Linkilo_Build_UrlRecord::setupLinkiloLinkTable(true);
            // if the plugin is activating and the link table isn't set up, assume this is a fresh install
            update_option('linkilo_fresh_install', true); // the link table was created with ver 0.8.3 and was the first major table event, so it should be a safe test for new installs
        }
        if('' === get_option('linkilo_install_date', '')){
            // set the install date since it may come in handy
            update_option('linkilo_install_date', current_time('mysql', true));
        }

        Linkilo_Build_PostUrl::removeLinkClass();

        self::createDatabaseTables();
        self::updateTables();
    }

    /**
     * Runs any update routines after the plugin has been updated.
     */
    public static function upgrade_complete($upgrader_object, $options){
        // If an update has taken place and the updated type is plugins and the plugins element exists
        if( $options['action'] == 'update' && $options['type'] == 'plugin' && isset( $options['plugins'] ) ) {
            // Go through each plugin to see if Linkilo was updated
            foreach( $options['plugins'] as $plugin ) {
                if( $plugin == LINKILO_PLUGIN_BASE_NAME ) {
                    // create any tables that need creating
                    self::createDatabaseTables();
                    // and make sure the existing tables are up to date
                    self::updateTables();
                }
            }
        }
    }

    /**
     * Updates the existing Linkilo data tables with changes as we add them.
     * Does a version check to see if any DB tables have been updated since the last time this was run.
     */
    public static function updateTables(){
        global $wpdb;

        $fresh_install = get_option('linkilo_fresh_install', false);

        $url_changer_tbl = $wpdb->prefix . 'linkilo_urls';
        $url_links_tbl = $wpdb->prefix . 'linkilo_url_links';
        $report_links_tbl = $wpdb->prefix . 'linkilo_report_links';
        $focus_keyword_data_tbl = $wpdb->prefix . 'linkilo_focus_keyword_data';

        // if the DB is up to date, exit
        if(LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_SITE === LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_PLUGIN){
            return;
        }

        // if this is a fresh install of the plugin
        if($fresh_install && empty(LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_SITE)){
            // set the DB version as the latest since all the created tables will be up to date
            update_option('linkilo_site_db_version', LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_PLUGIN);
            update_option('linkilo_fresh_install', false);
            // and exit
            return;
        }


        if( LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_SITE !== LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_PLUGIN ) {

            // Add `wildcard_match` column after `new` column in `linkilo_urls` table
            $url_changer_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$url_changer_tbl}'");
            if(!empty($url_changer_tbl_exists)) {
                $col = $wpdb->query("SHOW COLUMNS FROM {$url_changer_tbl} LIKE 'wildcard_match'");
                if (empty($col)) {
                    $update_table = "ALTER TABLE {$url_changer_tbl} ADD COLUMN wildcard_match tinyint(1) DEFAULT 0 AFTER `new`";
                    $wpdb->query($update_table);
                }
            }

            // Add `original_url` column after `anchor` column in `linkilo_url_links` table
            $url_links_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$url_links_tbl}'");
            if(!empty($url_links_tbl_exists)) {
                $col = $wpdb->query("SHOW COLUMNS FROM {$url_links_tbl} LIKE 'original_url'");
                if (empty($col)) {
                    $update_table = "ALTER TABLE {$url_links_tbl} ADD COLUMN original_url text NOT NULL AFTER `anchor`";
                    $wpdb->query($update_table);
                }
            }

            // Add `relative_link` column after `original_url` column in `linkilo_url_links` table
            $url_links_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$url_links_tbl}'");
            if(!empty($url_links_tbl_exists)) {
                $col = $wpdb->query("SHOW COLUMNS FROM {$url_links_tbl} LIKE 'relative_link'");
                if (empty($col)) {
                    $update_table = "ALTER TABLE {$url_links_tbl} ADD COLUMN relative_link tinyint(1) DEFAULT 0 AFTER `original_url`";
                    $wpdb->query($update_table);
                }
            }

            // Add `status` column after `relative_link` column in `linkilo_url_links` table
            $url_links_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$url_links_tbl}'");
            if(!empty($url_links_tbl_exists)) {
                $col = $wpdb->query("SHOW COLUMNS FROM {$url_links_tbl} LIKE 'status'");
                if (empty($col)) {
                    $update_table = "ALTER TABLE {$url_links_tbl} ADD COLUMN status tinyint(1) DEFAULT 0 AFTER `relative_link`";
                    $wpdb->query($update_table);
                }
            }

            // Add `ssl_status` column after `rel_ugc` column in `linkilo_report_links` table
            $report_links_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$report_links_tbl}'");
            if(!empty($report_links_tbl_exists)) {
                $col = $wpdb->query("SHOW COLUMNS FROM {$report_links_tbl} LIKE 'ssl_status'");
                if (empty($col)) {
                    $update_table = "ALTER TABLE {$report_links_tbl} ADD COLUMN ssl_status tinyint(1) DEFAULT 0 AFTER `rel_ugc`";
                    $wpdb->query($update_table);
                }
            }

            // Add `scan_date_start` and `scan_date_end` column after `save_date` column in `linkilo_focus_keyword_data` table
            $focus_keyword_data_tbl_exists = $wpdb->query("SHOW TABLES LIKE '{$focus_keyword_data_tbl}'");
            if(!empty($focus_keyword_data_tbl_exists)) {
                $col = $wpdb->query("SHOW COLUMNS FROM {$focus_keyword_data_tbl} LIKE 'scan_date_start'");
                if (empty($col)) {
                    $update_table = "ALTER TABLE {$focus_keyword_data_tbl} ADD COLUMN scan_date_start datetime DEFAULT NULL AFTER `save_date`";
                    $wpdb->query($update_table);
                }

                $col2 = $wpdb->query("SHOW COLUMNS FROM {$focus_keyword_data_tbl} LIKE 'scan_date_end'");
                if (empty($col2)) {
                    $update_table2 = "ALTER TABLE {$focus_keyword_data_tbl} ADD COLUMN scan_date_end datetime DEFAULT NULL AFTER `scan_date_start`";
                    $wpdb->query($update_table2);
                }
            }
            
            update_option('linkilo_site_db_version', LINKILO_CHECK_STATUS_OF_DATABASE_VERSION_OF_PLUGIN);
        }
    }


    /**
     * Modifies the post's row actions to add an "Add Incoming Links" button to the row actions.
     * Only adds the link to post types that we create links for.
     *
     * @param $actions
     * @param $object
     * @return $actions
     **/
    public static function modify_list_row_actions( $actions, $object ) {
        $type = is_a($object, 'WP_Post') ? $object->post_type: $object->taxonomy;

        if(!in_array($type, Linkilo_Build_AdminSettings::getAllTypes())){
            return $actions;
        }

        $page = (isset($_GET['paged']) && !empty($_GET['paged'])) ? '&paged=' . (int)$_GET['paged']: '';

        if(is_a($object, 'WP_Post')){
            $actions['linkilo-add-incoming-links'] = '<a target=_blank href="' . admin_url("admin.php?post_id={$object->ID}&page=linkilo&type=incoming_suggestions_page&ret_url=" . base64_encode(admin_url("edit.php?post_type={$type}{$page}&direct_return=1"))) . '">Add Incoming Links</a>';
        }else{
            global $wp_taxonomies;
            $post_type = $wp_taxonomies[$type]->object_type[0];
            $actions['linkilo-add-incoming-links'] = '<a target=_blank href="' . admin_url("admin.php?term_id={$object->term_id}&page=linkilo&type=incoming_suggestions_page&ret_url=" . base64_encode(admin_url("edit-tags.php?taxonomy={$type}{$page}&post_type={$post_type}&direct_return=1"))) . '">Add Incoming Links</a>';
        }

        return $actions;
    }

    /**
     * Add new columns for SEO title, description and focus keywords.
     *
     * @param array $columns Array of column names.
     *
     * @return array
     */
    public static function add_columns($columns){
        global $post_type;

        if(!in_array($post_type, Linkilo_Build_AdminSettings::getPostTypes())){
            return $columns;
        }

        $columns['linkilo-link-stats'] = esc_html__('Link Stats', 'linkilo');

        return $columns;
    }

    /**
     * Add content for custom column.
     *
     * @param string $column_name The name of the column to display.
     * @param int    $post_id     The current post ID.
     */
    public static function columns_contents($column_name, $post_id){
        if('linkilo-link-stats' === $column_name){
            $incoming_internal = (int)get_post_meta($post_id, 'linkilo_links_incoming_internal_count', true);
            $outgoing_internal = (int)get_post_meta($post_id, 'linkilo_links_outgoing_internal_count', true);
            $outgoing_external = (int)get_post_meta($post_id, 'linkilo_links_outgoing_external_count', true);
            $broken_links = Linkilo_Build_BrokenUrlError::getBrokenLinkCountByPostId($post_id);

            $post_type = get_post_type($post_id);
            $page = (isset($_GET['paged']) && !empty($_GET['paged'])) ? '&paged=' . (int)$_GET['paged']: '';
            ?>
            <span class="linkilo-link-stats-column-display linkilo-link-stats-content">
                <strong><?php _e('Links: ', 'linkilo'); ?></strong>
                <span title="<?php _e('Incoming Internal Links', 'linkilo'); ?>"><a target=_blank href="<?php echo admin_url("admin.php?post_id={$post_id}&page=linkilo&type=incoming_suggestions_page&ret_url=" . base64_encode(admin_url("admin.php/edit.php?post_type={$post_type}{$page}"))); ?>"><span class="dashicons dashicons-arrow-down-alt"></span><span><?php echo $incoming_internal; ?></span></a></span>
                <span class="divider"></span>
                <span title="<?php _e('Outgoing Internal Links', 'linkilo'); ?>"><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>"><span class="dashicons dashicons-external  <?php echo (!empty($outgoing_internal)) ? 'linkilo-has-outgoing': ''; ?>"></span> <span><?php echo $outgoing_internal; ?></span></a></span>
                <span class="divider"></span>
                <span title="<?php _e('Outgoing External Links', 'linkilo'); ?>"><span class="dashicons dashicons-admin-site-alt3 <?php echo (!empty($outgoing_external)) ? 'linkilo-has-outgoing': ''; ?>"></span> <span><?php echo $outgoing_external; ?></span></span>
                <span class="divider"></span>
                <?php if(!empty($broken_links)){ ?>
                    <span title="<?php _e('Broken Links', 'linkilo'); ?>"><a target=_blank href="<?php echo admin_url("admin.php?page=linkilo&type=error&post_id={$post_id}"); ?>"><span class="dashicons dashicons-editor-unlink broken-links"></span> <span><?php echo $broken_links; ?></span></a></span>
                <?php }else{ ?>
                    <span title="<?php _e('Broken Links', 'linkilo'); ?>">
                        <span class="dashicons dashicons-editor-unlink"></span>
                        <span>0</span>
                    </span>
                <?php } ?>
            </span>
            <?php
        }
    }

    /**
     * Filters the post content to make links open in new tabs if they don't already.
     * Differentiates between internal and external links.
     * @param string $content
     * @return string $content
     **/
    public static function open_links_in_new_tabs($content = ''){

        $open_all_intrnl = !empty(get_option('linkilo_internal_att_blank', false));
        $open_all_extrnl = !empty(get_option('linkilo_external_att_blank', false));

        if($open_all_intrnl || $open_all_extrnl){
            preg_match_all( '/<(a\s[^>]*?href=[\'"]([^\'"]*?)[\'"][^>]*?)>/', $content, $matches );

            foreach($matches[0] as $key => $link){
                // if the link already opens in a new tab, skip to the next link
                if(false !== strpos($link, 'target="_blank"')){
                    continue;
                }

                $internal = Linkilo_Build_PostUrl::isInternal($matches[2][$key]);

                if($internal && $open_all_intrnl){
                    $new_link = str_replace($matches[1][$key], $matches[1][$key] . ' target="_blank"', $link);
                    $content = mb_ereg_replace(preg_quote($link), $new_link, $content);
                }elseif(!$internal && $open_all_extrnl){
                    $new_link = str_replace($matches[1][$key], $matches[1][$key] . ' target="_blank"', $link);
                    $content = mb_ereg_replace(preg_quote($link), $new_link, $content);
                }
            }
        }

        return $content;
    }

    public static function fixCollation($table)
    {
        global $wpdb;
        $table_status = $wpdb->get_results("SHOW TABLE STATUS where name like '$table'");
        if (empty($table_status[0]->Collation) || $table_status[0]->Collation != 'utf8mb4_unicode_ci') {
            $wpdb->query("alter table $table convert to character set utf8mb4 collate utf8mb4_unicode_ci");
        }
    }

    public static function verify_nonce($key)
    {
        $user = wp_get_current_user();
        if(!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], $user->ID . $key)){
            wp_send_json(array(
                'error' => array(
                    'title' => __('Data Error', 'linkilo'),
                    'text'  => __('There was an error in processing the data, please reload the page and try again.', 'linkilo'),
                )
            ));
        }
    }

    /**
     * Removes a hooked function from the wp hook or filter.
     * We have to flip through the hooked functions because a lot of the methods use instantiated objects
     *
     * @param string $tag The hook/filter name that the function is hooked to
     * @param string $object The object who's method we're removing from the hook/filter
     * @param string $function The object method that we're removing from the hook/filter
     * @param int $priority The priority of the function that we're removing
     **/
    public static function remove_hooked_function($tag, $object, $function, $priority){
        global $wp_filter;
        $priority = intval($priority);

        // if the hook that we're looking for does exist and at the priority we're looking for
        if( isset($wp_filter[$tag]) &&
            isset($wp_filter[$tag]->callbacks) &&
            !empty($wp_filter[$tag]->callbacks) &&
            isset($wp_filter[$tag]->callbacks[$priority]) &&
            !empty($wp_filter[$tag]->callbacks[$priority]))
        {
            // look over all the callbacks in the priority we're looking in
            foreach($wp_filter[$tag]->callbacks[$priority] as $key => $data)
            {
                // if the current item is the callback we're looking for
                if(isset($data['function']) && is_a($data['function'][0], $object) && $data['function'][1] === $function){
                    // remove the callback
                    unset($wp_filter[$tag]->callbacks[$priority][$key]);

                    // if there aren't any more callbacks, remove the priority setting too
                    if(empty($wp_filter[$tag]->callbacks[$priority])){
                        unset($wp_filter[$tag]->callbacks[$priority]);
                    }
                }
            }
        }
    }

    /**
     * Updates the WP option cache indepenently of the update_options functionality.
     * I've found that for some users the cache won't update and that keeps some option based processing from working.
     * The code is mostly pulled from the update_option function
     *
     * @param string $option The name of the option that we're saving.
     * @param mixed $value The option value that we're saving.
     **/
    public static function update_option_cache($option = '', $value = ''){
        $option = trim( $option );
        if ( empty( $option ) ) {
            return false;
        }

        $serialized_value = maybe_serialize( $value );

        $alloptions = wp_load_alloptions( true );
        if ( isset( $alloptions[ $option ] ) ) {
            $alloptions[ $option ] = $serialized_value;
            wp_cache_set( 'alloptions', $alloptions, 'options' );
        } else {
            wp_cache_set( $option, $serialized_value, 'options' );
        }
    }

    /**
     * Deletes all Linkilo related data on plugin deletion
     **/
    public static function delete_linkilo_data(){
        global $wpdb;

        $delete = null;
        // license valid but scan has not run and user is deleting plugin
        if (
            get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" &&
            !LINKILO_STATUS_HAS_RUN_SCAN
        ) {
            $delete = true;
        }

        // license not valid and scan has not run and user is deleting plugin
        if (
            get_option(LINKILO_STATUS_OF_LICENSE_OPTION) !== "valid" &&
            !LINKILO_STATUS_HAS_RUN_SCAN
        ) {
            $delete = true;
        }

        // license valid and scan has been run and user is deleting plugin
        // OR
        // license valid and scan has not been run and user is deleting plugin
        if (
            get_option(LINKILO_STATUS_OF_LICENSE_OPTION) === "valid" &&
            (LINKILO_STATUS_HAS_RUN_SCAN || !LINKILO_STATUS_HAS_RUN_SCAN)
        ) {
            // if we're not really sure that the user wants to delete all data, exit
            if('1' !== get_option('linkilo_delete_all_data', false)) {
                return;
            }else{
                $delete = true;
            }
        }

        // license is expired and scan has ran before and user is deleting plugin
        if (!get_option(LINKILO_STATUS_OF_LICENSE_OPTION) && LINKILO_STATUS_HAS_RUN_SCAN) {
            // check if we're not really sure that the user wants to delete all data, exit
            if('1' !== get_option('linkilo_delete_all_data', false)) {
                return;
            }else{
                $delete = true;
            }

        }

        // license is not used till now and scan has not ran untill now and user is deleting plugin
        if (!get_option(LINKILO_STATUS_OF_LICENSE_OPTION) && !LINKILO_STATUS_HAS_RUN_SCAN) {
            $delete = true;
        }

        if ($delete && !is_null($delete)) {
            // create a list of all possible tables
            $tables = array(
                "{$wpdb->prefix}linkilo_broken_links",
                "{$wpdb->prefix}linkilo_ignore_links",
                "{$wpdb->prefix}linkilo_url_click_data",
                "{$wpdb->prefix}linkilo_keywords",
                "{$wpdb->prefix}linkilo_keyword_links",
                "{$wpdb->prefix}linkilo_keyword_select_links",
                "{$wpdb->prefix}linkilo_report_links",
                "{$wpdb->prefix}linkilo_search_console_data",
                "{$wpdb->prefix}linkilo_site_linking_data",
                "{$wpdb->prefix}linkilo_connection_req_entry",
                "{$wpdb->prefix}linkilo_focus_keyword_data",
                "{$wpdb->prefix}linkilo_urls",
                "{$wpdb->prefix}linkilo_url_links",
            );

            // go over the list of tables and delete all tables that exist
            foreach($tables as $table){
                $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
                if($table_exists === $table){
                    $wpdb->query("DROP TABLE {$table}");
                }
            }

            // get the settings
            $settings = array(
                'linkilo_2_ignore_numbers',
                'linkilo_2_post_types',
                'linkilo_relate_meta_post_types',
                'linkilo_relate_meta_post_display_limit',
                'linkilo_relate_meta_post_display_order',
                'linkilo_relate_meta_post_enable_disable',
                'linkilo_site_connection_entries_notice',
                // 'linkilo_gsc_post_keywords_checked',
                'linkilo_relate_meta_post_types_include',
                'linkilo_2_term_types',
                'linkilo_2_post_statuses',
                'linkilo_2_show_inbound_metabox_in_post_edit',
                'linkilo_2_load_more_inbound_suggestions',
                'linkilo_2_load_more_outbound_suggestions',
                'linkilo_2_ll_use_h123',
                'linkilo_2_ll_pairs_mode',
                'linkilo_2_ll_pairs_rank_pc',
                'linkilo_2_debug_mode',
                'linkilo_option_update_reporting_data_on_save',
                'linkilo_skip_sentences',
                'linkilo_selected_language',
                'linkilo_ignore_links',
                'linkilo_ignore_categories',
                'linkilo_show_all_links',
                'linkilo_manually_trigger_suggestions',
                'linkilo_disable_outgoing_suggestions',
                'linkilo_full_html_suggestions',
                'linkilo_ignore_keywords_posts',
                'linkilo_ignore_stray_feeds',
                'linkilo_preivew_exclude_list',
                'linkilo_marked_as_external',
                'linkilo_disable_acf',
                'linkilo_link_external_sites',
                'linkilo_link_external_sites_access_code',
                'linkilo_2_show_all_post_types',
                'linkilo_disable_search_update',
                'linkilo_domains_marked_as_internal',
                'linkilo_link_to_yoast_cornerstone',
                'linkilo_suggest_to_outgoing_posts',
                'linkilo_only_match_focus_keywords',
                'linkilo_external_rel_noopener',
                'linkilo_external_rel_noreferrer',
                'linkilo_external_rel_sponsored',
                'linkilo_internal_rel_noopener',
                'linkilo_internal_rel_noreferrer',
                'linkilo_external_rel_ugc',
                'linkilo_external_rel_nofollow',
                'linkilo_internal_rel_nofollow',
                'linkilo_delete_all_data',
                'linkilo_insert_links_as_relative',
                'linkilo_ignore_image_urls',
                'linkilo_include_post_meta_in_support_export',
                'linkilo_ignore_acf_fields',
                'linkilo_internal_att_blank',
                'linkilo_external_att_blank',
                'linkilo_preview_internal_enable_disable',
                'linkilo_preview_external_enable_disable',
                // 'linkilo_js_open_new_tabs',
                'linkilo_add_destination_title',
                'linkilo_disable_broken_link_cron_check',
                'linkilo_disable_click_tracking',
                'linkilo_delete_old_click_data',
                'linkilo_delete_old_gsc_data',
                'linkilo_max_links_per_post',
                'linkilo_max_words_match_per_suggest',
                'linkilo_2_license_status',
                'linkilo_2_license_key',
                'linkilo_2_license_data',
                'linkilo_2_ignore_words',
                'linkilo_has_run_initial_scan',
                'linkilo_site_db_version',
                'linkilo_link_table_is_created',
                'linkilo_fresh_install',
                'linkilo_install_date',
                'linkilo_2_license_check_time',
                'linkilo_2_license_last_error',
                'linkilo_post_procession',
                'linkilo_error_reset_run',
                'linkilo_error_check_links_cron',
                'linkilo_keywords_add_same_link',
                'linkilo_keywords_link_once',
                'linkilo_keywords_select_links',
                'linkilo_keywords_set_priority',
                'linkilo_keywords_restrict_to_cats',
                'linkilo_search_console_data',
                'linkilo_gsc_app_authorized',
                'linkilo_2_report_last_updated',
                'linkilo_cached_valid_sites',
                'linkilo_registered_sites',
                'linkilo_linked_sites',
                'linkilo_url_changer_reset',
                'linkilo_keywords_reset',
                'linkilo_r_a_k_store_version',
                'linkilo_r_a_i_v_store_version',
                'linkilo_b_k_store_version',
            );

            // delete each one from the option table
foreach($settings as $setting){
    delete_option($setting);
}

            // Delete any if remained
$options_table = $wpdb->prefix."options";
            // delete linkilo options
$wpdb->query("DELETE FROM {$options_table} WHERE `option_name` LIKE '%linkilo%'");
            // delete edd options
$wpdb->query("DELETE FROM {$options_table} WHERE `option_name` LIKE '%edd%'");
}
}

    /**
     * Checks to see if we're over the time limit.
     *
     * @param int $time_pad The amount of time in advance of the PHP time limit that is considered over the time limit
     * @param int $max_time The absolute time limit that we'll wait for the current process to complete
     * @return bool
     **/
    public static function overTimeLimit($time_pad = 0, $max_time = null){
        $limit = ini_get( 'max_execution_time' );

        // if there is no limit
        if(empty($limit) || $limit === '-1'){
            // create a self imposed limit so the user know Linkilo is still working on looped actions
            $limit = 90;
        }

        // if the exit time pad is less than the limit
        if($limit < $time_pad){
            // default to a 5 second pad
            $time_pad = 5;
        }

        // get the current time
        $current_time = microtime(true);

        // if we've been running for longer than the PHP time limit minus the time pad, OR
        // a max time has been set and we've passed it
        if( ($current_time - LINKILO_STATUS_PROCESSING_START) > ($limit - $time_pad) ||
            $max_time !== null && ($current_time - LINKILO_STATUS_PROCESSING_START) > $max_time)
        {
            // signal that we're over the time limit
            return true;
        }else{
            return false;
        }
    }

    /**
     * Creates the database tables so we're sure that they're all set.
     **/
    public static function createDatabaseTables(){
        Linkilo_Build_UrlClickChecker::prepare_table();
        Linkilo_Build_BrokenUrlError::prepareTable(false);
        Linkilo_Build_BrokenUrlError::prepareIgnoreTable();
        Linkilo_Build_RelateUrlKeyword::prepareTable(); // also prepares the possible links table
        Linkilo_Build_FocusKeyword::prepareTable();
        Linkilo_Build_UrlReplace::prepareTable();
    }


    /*****
     *    $focus_keywords = add_submenu_page(
                'linkilo', #$parent_slug
                __('Linkilo', 'linkilo'), #$page_title
                __(ucwords('Focus Keyword'), 'linkilo'), #$menu_title
                'manage_categories', #$capability
                'linkilo_focus_keywords', #$menu_slug
                [Linkilo_Build_FocusKeyword::class, 'init'] #$function
            );
     */

     /**
     * saving wizard global settings data.
     **/
    public function linkilo_save_wizard_global_settings_callback(){

        $linkilo_wizard_step = (int)isset( $_POST['linkilo_wizard_step'] ) ? $_POST['linkilo_wizard_step'] : '';
        $expiration_time = time() + (60 * 60 * 24 * 365);
        if($linkilo_wizard_step === '1')
        {
            $completedSteps = $linkilo_wizard_step;
            update_option('completed_steps',$completedSteps);
            $msg = array( 'status' => true);
            echo json_encode( $msg );
            wp_die();
        }
        elseif( $linkilo_wizard_step === '2' )
        {
            $opt_keys = [
                'linkilo_2_post_types',
                'linkilo_2_show_all_post_types',
                'linkilo_skip_sentences',
                'linkilo_max_links_per_post',
                'linkilo_max_words_match_per_suggest'
            ];
            
            foreach($opt_keys as $opt_key) {
                    
                if (array_key_exists($opt_key, $_POST)) {
                    if( empty( $_POST['linkilo_2_post_types'] ) )
                    {
                        $msg = array( 'status' => false,'error_msg' => 'Please Select Find Suggested URLs Option');
                        echo json_encode( $msg );
                        wp_die();
                    }
                    update_option($opt_key, $_POST[$opt_key]);

                    $completedSteps = $linkilo_wizard_step;
    
                    update_option('completed_steps',$completedSteps);
                    
                }
            }
            $msg = array( 'status' => true);
            echo json_encode( $msg );
            wp_die();
        }
        elseif( $linkilo_wizard_step === '3' )
        {
            $linkilo_google_search_console_limit = isset( $_POST['linkilo_google_search_console_limit'] ) ? $_POST['linkilo_google_search_console_limit'] : '';
            update_option('linkilo_google_search_console_limit',$linkilo_google_search_console_limit);
            
            $completedSteps = $linkilo_wizard_step;
            update_option('completed_steps',$completedSteps);
            $msg = array( 'status' => true);
            echo json_encode( $msg );
            wp_die();
        }
        elseif( $linkilo_wizard_step === '4' )
        {
            $opt_keys = [
                'linkilo_yoastseo_keyword_enable',
                'linkilo_rankmath_keyword_enable'
            ];
            
            foreach($opt_keys as $opt_key) {
                    
                if (array_key_exists($opt_key, $_POST)) {
                    update_option($opt_key, $_POST[$opt_key]);
                    
                }
            }
            
            $completedSteps = $linkilo_wizard_step;
            update_option('completed_steps',$completedSteps);

            $msg = array( 'status' => true);
            echo json_encode( $msg );
            wp_die();
        }
        elseif( $linkilo_wizard_step === '5' )
        {
            $completedSteps = $linkilo_wizard_step;
            update_option('completed_steps',$completedSteps);

            $linkilo_external_settings = get_option('linkilo_external_setting_ext_field');
            $linkilo_icon_type         = isset( $_POST['linkilo_icon_type'] ) ? $_POST['linkilo_icon_type'] : '';
            $linkilo_icon_position         = isset( $_POST['linkilo_icon_position'] ) ? $_POST['linkilo_icon_position'] : '';
            $linkilo_internal_icon_type         = isset( $_POST['linkilo_internal_icon_type'] ) ? $_POST['linkilo_internal_icon_type'] : '';
            $linkilo_interlanl_icon_position         = isset( $_POST['linkilo_interlanl_icon_position'] ) ? $_POST['linkilo_interlanl_icon_position'] : '';
            $linkilo_chk_internl_opt         = isset( $_POST['linkilo_chk_internl_opt'] ) ? $_POST['linkilo_chk_internl_opt'] : '';
            $linkilo_links_preview         = isset( $_POST['linkilo_links_preview'] ) ? $_POST['linkilo_links_preview'] : '';
            $linkilo_preview_internal_enable_disable         = isset( $_POST['linkilo_preview_internal_enable_disable'] ) ? $_POST['linkilo_preview_internal_enable_disable'] : '';
            $linkilo_preview_external_enable_disable         = isset( $_POST['linkilo_preview_external_enable_disable'] ) ? $_POST['linkilo_preview_external_enable_disable'] : '';

            if(empty($linkilo_icon_type))
            {
                $linkilo_selectedClass ='';
            }
            else{
                $linkilo_selectedClass = isset($_POST['linkilo_selectedClass']) ? $_POST['linkilo_selectedClass'] : '';
            }

            if(empty($linkilo_internal_icon_type))
            {
                $linkilo_internal_selectedClass ='';
            }
            else{
                $linkilo_internal_selectedClass = isset($_POST['linkilo_internal_selectedClass']) ? $_POST['linkilo_internal_selectedClass'] : '';
            }
            if($linkilo_chk_internl_opt === '1')
            {
                update_option('linkilo_internal_icon',$linkilo_internal_selectedClass);
            }
            elseif($linkilo_chk_internl_opt === '2')
            {
                update_option('linkilo_internal_verified_icon',$linkilo_internal_selectedClass);
            }
            else{
                update_option('linkilo_internal_icon','');
                update_option('linkilo_internal_verified_icon','');
            }

            update_option('linkilo_internal_icon_type',$linkilo_internal_icon_type);
            update_option('linkilo_interlanl_icon_position',$linkilo_interlanl_icon_position);
            update_option('linkilo_links_preview',$linkilo_links_preview);
            update_option('linkilo_preview_internal_enable_disable',$linkilo_preview_internal_enable_disable);
            update_option('linkilo_preview_external_enable_disable',$linkilo_preview_external_enable_disable);

            if(!empty($linkilo_external_settings))
            {
                $linkilo_external_settings['linkilo_icon_type'] = $linkilo_icon_type;
                $linkilo_external_settings['linkilo_selectedClass'] = $linkilo_selectedClass;
                $linkilo_external_settings['linkilo_icon_position'] = $linkilo_icon_position;
                update_option('linkilo_external_setting_ext_field', $linkilo_external_settings);
                $msg = array( 'status' => true);
                echo json_encode( $msg );
                wp_die();
            }
            else{
                $linkilo_external_settings = array(
                    'linkilo_icon_type' =>$linkilo_icon_type,
                    'linkilo_selectedClass' => $linkilo_selectedClass,
                    'linkilo_skip_isChecked' => '',
                    'linkilo_icon_position'  => $linkilo_icon_position,
                    'linkilo_exclude_iconfordmn_name' => '',
                    'spc_dmn_name_and_cls_arr' => array(),

                );
                update_option('linkilo_external_setting_ext_field',$linkilo_external_settings);
                
            }
           
            $msg = array( 'status' => true);
            echo json_encode( $msg );
            wp_die();
        }
        elseif( $linkilo_wizard_step === '6' )
        {
            $opt_keys = [
                'linkilo_aloseo_keyword_enable',
                'linkilo_squirrly_seo_keyword_enable'
            ];
            
            foreach($opt_keys as $opt_key) {
                    
                if (array_key_exists($opt_key, $_POST)) {
                    update_option($opt_key, $_POST[$opt_key]);
                    
                }
            }

            $completedSteps = $linkilo_wizard_step;
            update_option('completed_steps',$completedSteps);
            $msg = array( 'status' => true);
            echo json_encode( $msg );
            wp_die();
        }
       
        wp_die();
    }

    public function linkilo_save_prev_wizard_steps_callback()
    {
        $linkilo_wizard_step = (int)isset( $_POST['linkilo_wizard_step'] ) ? $_POST['linkilo_wizard_step'] : '';
        
        $completedSteps = $linkilo_wizard_step;
        update_option('completed_steps',$completedSteps);
        $msg = array( 'status' => true);
        echo json_encode( $msg );
        wp_die();
    }

    public function linkilo_save_skiped_wizard_steps_callback()
    {
        $linkilo_wizard_step = (int)isset( $_POST['linkilo_wizard_step'] ) ? $_POST['linkilo_wizard_step'] : '';
        
        $completedSteps = $linkilo_wizard_step;
        update_option('completed_steps',$completedSteps);
        $msg = array( 'status' => true);
        echo json_encode( $msg );
        wp_die();
    }
}