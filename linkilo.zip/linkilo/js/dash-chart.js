(function ($) {
	$(document).ready(function(){
		Highcharts.chart('chart_container', {

			chart: {
				type: 'solidgauge',
				height: '110%',
			},

			title: {
				text: 'Activity',
				style: {
					fontSize: '24px'
				}
			},

			tooltip: {
				borderWidth: 0,
				backgroundColor: 'none',
				shadow: false,
				style: {
					fontSize: '16px'
				},
				valueSuffix: '%',
				pointFormat: '{series.name}<br><span style="font-size:2em; color: {point.color}; font-weight: bold">{point.y}</span>',
				positioner: function (labelWidth) {
					return {
						x: (this.chart.chartWidth - labelWidth) / 2,
						y: (this.chart.plotHeight / 2) + 15
					};
				}
			},

			pane: {
				startAngle: 0,
				endAngle: 360,
				background: [{ 
					/* Track for Move */
					outerRadius: '112%',
					innerRadius: '88%',
					backgroundColor: Highcharts.color(Highcharts.getOptions().colors[0])
					.setOpacity(0.3)
					.get(),
					borderWidth: 0
				}, { 
					/* Track for Exercise */
					outerRadius: '87%',
					innerRadius: '63%',
					backgroundColor: Highcharts.color(Highcharts.getOptions().colors[1])
					.setOpacity(0.3)
					.get(),
					borderWidth: 0
				}, { 
					/* Track for Stand */
					outerRadius: '62%',
					innerRadius: '38%',
					backgroundColor: Highcharts.color(Highcharts.getOptions().colors[2])
					.setOpacity(0.3)
					.get(),
					borderWidth: 0
				}, { 
					/* Track for Move */
					outerRadius: '37%',
					innerRadius: '30%',
					backgroundColor: Highcharts.color(Highcharts.getOptions().colors[3])
					.setOpacity(0.3)
					.get(),
					borderWidth: 0
				}, { 
					/* Track for Exercise */
					outerRadius: '29%',
					innerRadius: '22%',
					backgroundColor: Highcharts.color(Highcharts.getOptions().colors[4])
					.setOpacity(0.3)
					.get(),
					borderWidth: 0
				}]
			},

			yAxis: {
				min: 0,
				max: 100,
				lineWidth: 0,
				tickPositions: []
			},

			plotOptions: {
				solidgauge: {
					dataLabels: {
						enabled: false
					},
					linecap: 'round',
					stickyTracking: false,
					rounded: true
				}
			},

			series: [{
				name: 'External',
				data: [{
					color: Highcharts.getOptions().colors[0],
					radius: '112%',
					innerRadius: '88%',
					y: 80
				}]
			}, {
				name: 'Internal',
				data: [{
					color: Highcharts.getOptions().colors[1],
					radius: '87%',
					innerRadius: '63%',
					y: 65
				}]
			}, {
				name: 'External Links',
				data: [{
					color: Highcharts.getOptions().colors[2],
					radius: '62%',
					innerRadius: '38%',
					y: 50
				}]
			},{
				name: 'Sponsored',
				data: [{
					color: Highcharts.getOptions().colors[3],
					radius: '37%',
					innerRadius: '30%',
					y: 37
				}]
			}, {
				name: 'User Generated content links',
				data: [{
					color: Highcharts.getOptions().colors[4],
					radius: '29%',
					innerRadius: '22%',
					y: 29
				}]
			}]
		});
	});
})(jQuery);