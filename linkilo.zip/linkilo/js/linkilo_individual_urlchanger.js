"use strict";

( function ($) {
    // individual undo replace
    $(document).on('click', '#linkilo_url_changer_table .undo', function() {
        if ( confirm( "Are you sure you want to undo changes for this URL?" ) ) {
            var el = $(this);
            let li_element_id = $(this).data('li_element');

            let loader = '<div id="loader_'+li_element_id+'" class="linkilo-url-replace-loader"></div>';

            $("li#"+li_element_id+" .linkilo-url-update-table-col-item").hide();
            $("li#"+li_element_id).append(loader);

            var id = el.data('id');
            var word_id = el.data('word_id');
            var target_anchor = el.data('anchor');
            var post_id = el.data('post-id');

            let request_data = {
                action: 'linkilo_single_url_replace_undo',
                nonce : linkilo_url_changer_object.u_nonce,
                linkilo_urls_row_id: id,
                linkilo_url_links_row_id:word_id,
                inkilo_url_links_anchor:target_anchor,
                linkilo_url_links_post_id:post_id,
            };

            $.post(linkilo_url_changer_object.ajax_url, request_data, function( response ){
                $("#loader_" + li_element_id).remove();
                $("li#"  + li_element_id + " .linkilo-url-update-table-col-item").show();

                if ( response.status ) {
                    linkilo_swal('Success!', response.message, 'success');
                }else{
                    linkilo_swal('Error!', response.message, 'error');  
                }
                location.reload();
            });
        }
    });

    // individual replace
    $( document ).on( 'click', '.linkilo_individual_replace_url', function(){
        let post_id = $(this).attr('data-post-id');
        let word_id = $(this).attr('data-word_id');
        let url_id = $(this).attr('data-url_id');
        let target_anchor = $(this).attr('data-anchor');
        let new_url = $(this).attr('data-new-url');
        let old_url = $(this).attr('data-old_url');

        let li_element_id = $(this).data('li_element');

        let loader = '<div id="loader_'+li_element_id+'" class="linkilo-url-replace-loader"></div>';

        $("li#"+li_element_id+" .linkilo-url-update-table-col-item").hide();
        $("li#"+li_element_id).append(loader);

        let ajax_data = {
            action: 'linkilo_single_url_replace',
            nonce: linkilo_url_changer_object.r_nonce,
            post_id: post_id,
            word_id: word_id,
            url_id: url_id,
            target_anchor: target_anchor,
            new_url: new_url,
            old_url: old_url,
        };

        $.ajax({
            type: "POST",
            url: linkilo_url_changer_object.ajax_url,
            data: ajax_data,

            success: function(response){
                $("#loader_" + li_element_id).remove();
                $("li#"  + li_element_id + " .linkilo-url-update-table-col-item").show();

                if ( response.status ) {
                    linkilo_swal('Success!', response.message, 'success');
                }else{
                    linkilo_swal('Error!', response.message, 'error');  
                }
                location.reload();
            }
        });
    });
})( jQuery );