"use strict";
(function ($){
	var reloadGutenberg = false;

	/*preloading*/
	function getSuggestions(manualActivate = false){
		$('[data-linkilo-ajax-container]').each(function(k, el){
			var $el = $(el);
			var url = $el.attr('data-linkilo-ajax-container-url');
			var count = 0;
			var urlParams = parseURLParams(url);

			/*don't load the suggestions automatically if the user has selected manual activation*/
			if($el.data('linkilo-manual-suggestions') == 1 && !manualActivate){
				return
			}

			$el.css({'display': 'block'});
			$('.linkilo-get-manual-suggestions-container').css({'display': 'none'});
			if(urlParams.type && 'outgoing_suggestions_ajax' === urlParams.type[0]){
				ajaxGetSuggestionsOutbound($el, url, count);
			}else if(urlParams.type && 'incoming_suggestions_page_container' === urlParams.type[0]){
				ajaxGetSuggestionsIncoming($el, url, count);
			}else if(urlParams.type && 'meta_incoming_suggestions_page_container' === urlParams.type[0]){
				ajaxGetSuggestionsIncomingMeta($el, url, count);
			}
		});
	}

	getSuggestions();

	$(document).on('click', '#linkilo-get-manual-suggestions', function(e){ 
		e.preventDefault(); 
		getSuggestions(true);
	});

	// Comparison toggle
	$(document).on('change', '#linkilo_comparison_table_filter select[name="keyword_comparison"]', function(e){

		var comparison = $(this).val();

		$('.report_links [data-comparison]').css('display', 'none');
		$('.report_links [data-comparison="'+ comparison +'"]').css('display', 'inline-block');
	});

	function ajaxGetSuggestionsIncoming($el, url, count, lastPost = 0, processedPostCount = 0, key = null){
		var urlParams = parseURLParams(url);
		var post_id = (urlParams.post_id) ? urlParams.post_id[0] : null;
		var term_id = (urlParams.term_id) ? urlParams.term_id[0] : null;
		var keywords = (urlParams.keywords) ? urlParams.keywords[0] : '';
		var sameCategory = (urlParams.same_category) ? urlParams.same_category[0] : '';
		var selectedCategory = (urlParams.selected_category) ? urlParams.selected_category[0] : '';
		var sameTag = (urlParams.same_tag) ? urlParams.same_tag[0] : '';
		var selectedTag = (urlParams.selected_tag) ? urlParams.selected_tag[0] : '';
		var nonce = (urlParams.nonce) ? urlParams.nonce[0]: '';


		// same title checkbox value
		var sameTitle = "";
		var sameTitleTxt = "";
		if (urlParams.same_title_chk) {
			sameTitle = (urlParams.same_title_chk) ? urlParams.same_title_chk[0] : '';
			sameTitleTxt = (urlParams.same_title_text_chk) ? urlParams.same_title_text_chk[0] : '';
		}

		// exact match keyword
		var exactMatchChecked = (urlParams.exact_match_checked) ? urlParams.exact_match_checked[0] : '';

		// Match Url Inbound
		var matchUrl = (urlParams.exact_match_url_slug) ? urlParams.exact_match_url_slug[0] : '';


		if(!nonce){
			return;
		}

        // if there isn't a key set, make one
		if(!key){
			while(true){
				key = Math.round(Math.random() * 1000000000);
				if(key > 999999){break;}
			}
		}

		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'get_recommended_url',
				nonce: nonce,
				count: count,
				post_id: post_id,
				term_id: term_id,
				type: 'incoming_suggestions',
				keywords: keywords,
				same_category: sameCategory,
				selected_category: selectedCategory,
				same_tag: sameTag,
				selected_tag: selectedTag,
				same_title_opt : sameTitle,
				same_title_txt : sameTitleTxt,
				exact_match_keyword: exactMatchChecked,
				match_url: matchUrl,
				last_post: lastPost,
				completed_processing_count: processedPostCount,
				key: key,
			},
			success: function(response){
                // if there was an error
				if(response.error){
                    // output the error message
					linkilo_swal(response.error.title, response.error.text, 'error');
                    // and exit
					return;
				}

				count = parseInt(count) + 1;
				var progress = Math.floor(response.completed_processing_count / (response.post_count + 0.1) * 100);
				if (progress > 100) {
					progress = 100;
				}

				for (var i = 0; i <= progress; i++) {
					$(".progress_count").css({'width': i + '%'});
				}

				if(!response.completed){
					ajaxGetSuggestionsIncoming($el, url, count, response.last_post, response.completed_processing_count, key);
				}else{
					return updateSuggestionDisplay(post_id, term_id, nonce, $el, 'incoming_suggestions', sameCategory, key, selectedCategory, sameTag, selectedTag, matchUrl, sameTitle);
				}
			}
		});
	}

	function ajaxGetSuggestionsIncomingMeta($el, url, count, lastPost = 0, processedPostCount = 0, key = null, post_loader_in = null, btn_attr = null, loader_id = null, btn_loader = null){
		var urlParams = parseURLParams(url);
		var post_id = (urlParams.post_id) ? urlParams.post_id[0] : null;
		var term_id = (urlParams.term_id) ? urlParams.term_id[0] : null;
		var keywords = (urlParams.keywords) ? urlParams.keywords[0] : '';
		var sameCategory = (urlParams.same_category) ? urlParams.same_category[0] : '';
		var selectedCategory = (urlParams.selected_category) ? urlParams.selected_category[0] : '';
		var sameTag = (urlParams.same_tag) ? urlParams.same_tag[0] : '';
		var selectedTag = (urlParams.selected_tag) ? urlParams.selected_tag[0] : '';
		var nonce = (urlParams.nonce) ? urlParams.nonce[0]: '';


    	/*same title in meta checkbox value*/
		var sameTitleInMeta = "";
		var sameTitleTxtInMeta = "";

		if (urlParams.same_title_chk_in_meta) {
			sameTitleInMeta = (urlParams.same_title_chk_in_meta) ? urlParams.same_title_chk_in_meta[0] : '';
			sameTitleTxtInMeta = (urlParams.same_title_text_chk_in_meta) ? urlParams.same_title_text_chk_in_meta[0] : '';
		}

    	/*exact match keyword*/
		var exactMatchCheckedInMeta = (urlParams.exact_match_in_meta_checked) ? urlParams.exact_match_in_meta_checked[0] : '';

    	/*Match Url Inbound Meta Box*/
		var matchUrlInMeta = (urlParams.exact_match_url_slug_in_meta) ? urlParams.exact_match_url_slug_in_meta[0] : '';

		if(!nonce){
			return;
		}

    	/*if there isn't a key set, make one*/
		if(!key){
			while(true){
				key = Math.round(Math.random() * 1000000000);
				if(key > 999999){break;}
			}
		}

		var new_limit = 0;
		if (post_loader_in) {
			var btn_name = 'button[name="'+ btn_attr +'"]';
			new_limit = $(btn_name).attr('data-loop');
		}

		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'get_recommended_url',
				nonce: nonce,
				count: count,
				post_id: post_id,
				term_id: term_id,
				type: 'meta_incoming_suggestions',
				keywords: keywords,
				same_category: sameCategory,
				selected_category: selectedCategory,
				same_tag: sameTag,
				selected_tag: selectedTag,
				same_title_opt_in_meta : sameTitleInMeta,
				same_title_txt_in_meta : sameTitleTxtInMeta,
				exact_match_keyword_in_meta: exactMatchCheckedInMeta,
				match_url_in_meta: matchUrlInMeta,
				last_post: lastPost,
				completed_processing_count: processedPostCount,
				key: key,
				new_limit: new_limit,
			},
			success: function(response){
    			/*if there was an error*/
				if(response.error){

					linkilo_swal(response.error.title, response.error.text, 'error');
					return;
				}

				count = parseInt(count) + 1;
				var progress = Math.floor(response.completed_processing_count / (response.post_count + 0.1) * 100);
				if (progress > 100) {
					progress = 100;
				}

    			/*$('.progress_count').html(progress + '%');*/

				for (var i = 0; i <= progress; i++) {
					$(".progress_count").css({'width': i + '%'});
				}

				if(!response.completed){
					ajaxGetSuggestionsIncomingMeta($el, url, count, response.last_post, response.completed_processing_count, key, post_loader_in, btn_attr, loader_id, btn_loader);
				}else{
					if (post_loader_in) {
						return loadSuggestions(post_id, term_id, nonce, $el, 'loadmore_incoming_suggestions', key, btn_attr, loader_id, btn_loader);
					}
					return updateSuggestionDisplay(post_id, term_id, nonce, $el, 'meta_incoming_suggestions', sameCategory, key, selectedCategory, sameTag, selectedTag, matchUrlInMeta, sameTitleInMeta);
				}
			}
		});
	}

	function ajaxGetSuggestionsOutbound($el, url, count, post_count = 0, key = null, selectedCategories = null, selectedTags = null, post_loader_out = null, btn_attr = null, loader_id = null, btn_loader = null){
    	/*if there isn't a key set, make one*/
		if(!key){
			while(true){
				key = Math.round(Math.random() * 1000000000);
				if(key > 999999){break;}
			}
		}

		var urlParams = parseURLParams(url);
		var post_id = (urlParams.post_id) ? urlParams.post_id[0] : null;
		var term_id = (urlParams.term_id) ? urlParams.term_id[0] : null;
		var sameCategory = (urlParams.same_category) ? urlParams.same_category[0] : '';
		var selectedCategory = (urlParams.selected_category) ? urlParams.selected_category[0] : '';
		var sameTag = (urlParams.same_tag) ? urlParams.same_tag[0] : '';
		var selectedTag = (urlParams.selected_tag) ? urlParams.selected_tag[0] : '';

    	/*same title checkbox value*/
		var sameTitle = "";
		var sameTitleTxt = "";
		if (urlParams.same_title_chk) {
			sameTitle = (urlParams.same_title_chk) ? urlParams.same_title_chk[0] : '';
			sameTitleTxt = (urlParams.same_title_text_chk) ? urlParams.same_title_text_chk[0] : '';
		}

    	/*exact match keyword*/
		var exactMatchChecked = (urlParams.exact_match_checked) ? urlParams.exact_match_checked[0] : '';

    	/*Match url Outboubd*/
		var matchUrl = (urlParams.exact_match_url_slug) ? urlParams.exact_match_url_slug[0] : '';

		var matchArticle = (urlParams.match_related_articles) ? urlParams.match_related_articles[0] : '';

		var matchSubHeading = (urlParams.match_sub_headings) ? urlParams.match_sub_headings[0] : '';

		var nonce = (urlParams.nonce) ? urlParams.nonce[0]: '';

		var selectedCategoriesArr = selectedCategories;
		var selectedTagsArr = selectedTags;

		if(!nonce){
			return;
		}

		var new_limit = 0;
		if (post_loader_out) {
			var btn_name = 'button[name="'+ btn_attr +'"]';
			new_limit = $(btn_name).attr('data-loop');
		}

		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'get_recommended_url',
				nonce: nonce,
				count: count,
				post_count: (post_count) ? parseInt(post_count): 0,
				post_id: post_id,
				term_id: term_id,
				same_category: sameCategory,
				selected_category: selectedCategory,
				same_tag: sameTag,
				selected_tag: selectedTag,
				same_title_opt : sameTitle,
				same_title_txt : sameTitleTxt,
				exact_match_keyword: exactMatchChecked,
				match_url: matchUrl,
				match_article: matchArticle,
				match_sub_heading: matchSubHeading,
				type: 'outgoing_suggestions',
				key: key,
				selectedCategoriesArr: selectedCategoriesArr,
				selectedTagsArr: selectedTagsArr,
				new_limit: new_limit,
			},
			success: function(response){
    			/*if there was an error*/
				if(response.error){
    				/*output the error message*/
					linkilo_swal(response.error.title, response.error.text, 'error');
    				/*and exit*/
					return;
				}

    			/*if there was a notice*/
				if(response.info){
    				/*output the notice message*/
					linkilo_swal(response.info.title, response.info.text, 'info');
    				/*and exit*/
					return;
				}

    			/*$el.find('.progress_count').html(response.message);*/
				if((count * response.batch_size) < response.post_count){
					if (response.multi_cats == 0 || response.multi_tags == 0) {
    					/*no selected category*/
    					/*go with default*/
						ajaxGetSuggestionsOutbound($el, url, response.count, response.post_count, key, response.multi_cats, response.multi_tags, post_loader_out, btn_attr, loader_id, btn_loader);
					}else{
    					/*selected multiple category*/
    					/*go with updated*/
						ajaxGetSuggestionsOutbound($el, url, response.count, response.post_count, key, response.multi_cats, response.multi_tags, post_loader_out, btn_attr, loader_id, btn_loader);
					}
				}else if( (sameCategory || sameTag) || (0 == linkilo_ajax.site_linking_enabled) ){
    				/*if we're doing same tag or cat matching, skip the external sites.*/
					if (post_loader_out) {
						return loadSuggestions(post_id, term_id, nonce, $el, 'loadmore_outgoing_suggestions', key, btn_attr, loader_id, btn_loader);
					}
					return updateSuggestionDisplay(post_id, term_id, nonce, $el, 'outgoing_suggestions', sameCategory, key, selectedCategory, sameTag, selectedTag, matchUrl, sameTitle, response.multi_cats, response.multi_tags);
				}else{
					ajaxGetExternalSiteSuggestions($el, url, 0, 0, key);
				}
			},
			error: function(jqXHR, textStatus, errorThrown){
				console.log({jqXHR, textStatus, errorThrown});
			}
		});
	}


	function ajaxGetExternalSiteSuggestions($el, url, count, post_count = 0, key = null){
        // if there isn't a key set, make one
		if(!key){
			while(true){
				key = Math.round(Math.random() * 1000000000);
				if(key > 999999){break;}
			}
		}

		var urlParams = parseURLParams(url);
		var post_id = (urlParams.post_id) ? urlParams.post_id[0] : null;
		var term_id = (urlParams.term_id) ? urlParams.term_id[0] : null;
		var sameCategory = (urlParams.same_category) ? urlParams.same_category[0] : '';
		var selectedCategory = (urlParams.selected_category) ? urlParams.selected_category[0] : '';
		var sameTag = (urlParams.same_tag) ? urlParams.same_tag[0] : '';
		var selectedTag = (urlParams.selected_tag) ? urlParams.selected_tag[0] : '';
		var nonce = (urlParams.nonce) ? urlParams.nonce[0]: '';

		if(!nonce){
			return;
		}

		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'linkilo_get_outer_site_recommendation',
				nonce: nonce,
				count: count,
				post_count: (post_count) ? parseInt(post_count): 0,
				post_id: post_id,
				term_id: term_id,
				same_category: sameCategory,
				selected_category: selectedCategory,
				same_tag: sameTag,
				selected_tag: selectedTag,
				type: 'outgoing_suggestions',
				key: key,
			},
			success: function(response){
                // if there was an error
				if(response.error){
                    // output the error message
					linkilo_swal(response.error.title, response.error.text, 'error');
                    // and exit
					return;
				}

				// $el.find('.progress_count').html(response.message);

				if((count * response.batch_size) < response.post_count){
					ajaxGetExternalSiteSuggestions($el, url, response.count, response.post_count, key);
				}else{
					return updateSuggestionDisplay(post_id, term_id, nonce, $el, 'outgoing_suggestions', sameCategory, key, selectedCategory, sameTag, selectedTag);
				}
			},
			error: function(jqXHR, textStatus, errorThrown){
				console.log({jqXHR, textStatus, errorThrown});
			}
		});
	}

	function loadSuggestions(postId, termId, nonce, $el, type = 'loadmore_outgoing_suggestions', key, btn_attr, loader_id, btn_loader){
		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'load_more_outgoing_suggestions',
				nonce: nonce,
				post_id: postId,
				term_id: termId,
				key: key,
				type: type
			},
			success: function(response){
				var btn_name = 'button[name="'+btn_attr+'"]';
				$("#"+loader_id).remove();
                // if there was an error
				if(response.error){
                    // output the error message
					linkilo_swal(response.error.title, response.error.text, 'error');
                    // and exit
					return;
				}

				if(response.info){
                    // output the info message
                    // and exit
					linkilo_swal(response.info.title, response.info.text, 'info');
					$( btn_name ).replaceWith( "<button class='button-primary cst-btn-clr no-load-more' disabled='disabled'>LOAD MORE <span class='dashicons dashicons-arrow-down-alt2' style='margin-top: 2px;font-size: 23px;'></span></button>" );
					return;
				}
                // update the suggestion report
				var newLimit = parseInt($(btn_name).attr('data-loop')) + 20;
				$(btn_name).closest('tr').before(response);
				$(btn_name).prop('disabled', false);
				$(btn_name).attr('data-loop', newLimit);

				if ((btn_loader === 1 || btn_loader === 2) && typeof $(btn_name).data('empty') !== 'undefined') {
					let row =  $(btn_name).data('row');
					let btn =  $(btn_name).data('btn');

					$('.'+row).remove();
					$('#'+btn).css("display", "block");;
				}
				// style the sentences
				styleSentences();
			}
		});
	}

	function updateSuggestionDisplay(postId, termId, nonce, $el, type = 'outgoing_suggestions', sameCategory = '', key = null, selectedCategory, sameTag, selectedTag, matchUrl, sameTitle, selectedCategories, selectedTags){
		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'update_recommendation_display',
				nonce: nonce,
				post_id: postId,
				term_id: termId,
				key: key,
				type: type,
				same_category: sameCategory,
				selected_category: selectedCategory,
				same_tag: sameTag,
				selected_tag: selectedTag,
				match_url: matchUrl,
				same_title: sameTitle,
				selectedCategories: selectedCategories,
				selectedTags: selectedTags,
			},
			success: function(response){
                // if there was an error
				if(response.error){
                    // output the error message
					linkilo_swal(response.error.title, response.error.text, 'error');
                    // and exit
					return;
				}

                // update the suggestion report
				$el.html(response);
				// style the sentences
				styleSentences();
			}
		});
	}

    // Helper function that parses urls to get their query vars.
	function parseURLParams(url) {
		var queryStart = url.indexOf("?") + 1,
		queryEnd   = url.indexOf("#") + 1 || url.length + 1,
		query = url.slice(queryStart, queryEnd - 1),
		pairs = query.replace(/\+/g, " ").split("&"),
		parms = {}, i, n, v, nv;

		if (query === url || query === "") return;

		for (i = 0; i < pairs.length; i++) {
			nv = pairs[i].split("=", 2);
			n = decodeURIComponent(nv[0]);
			v = decodeURIComponent(nv[1]);

			if (!parms.hasOwnProperty(n)) parms[n] = [];
			parms[n].push(nv.length === 2 ? v : null);
		}
		return parms;
	}

	function linkiloImplodeEls(sep, els) {
		var res = [];
		$(els).each(function(k, el) {
			res.push(el.outerHTML);
		});

		return res.join(sep);
	}

	function linkiloImplodeText(sep, els) {
		var res = [];
		$(els).each(function(k, el) {
			var $el = $(el);
			res.push($el.text());
		});

		return res.join(sep);
	}

	function linkiloPushFix($ex) {
		var $div = $("<div/>");
		$div.append($ex);
		return $div.html();
	}

	$(document).on('click', '.linkilo_sentence a', function (e) {
		e.preventDefault();
	});

	var wordClicked = false;
	var wordClickedWait;
	var doubleClickWait;
	var clickedWordId = false;
	var clickedSentenceId = false;
	var notDirectlyStyled = true;

	$(document).on('click', '[class*=linkilo_word]', function (e) {
		e.preventDefault();

		var clickedWord = $(this);
		var sentence = clickedWord.closest('.linkilo_sentence');
		var incomingSelectedId = sentence.closest('.linkilo-incoming-sentence-data-container').data('container-id');

		if(wordClicked && false === clickedWordId) {
			return;
		} else if (	clickedWordId === clickedWord.data('linkilo-word-id') &&
			clickedSentenceId === clickedWord.closest('tr').data('linkilo-sentence-id') &&
			notDirectlyStyled ) {
			processDoubleClick(clickedSentenceId, clickedWordId, incomingSelectedId);
			return;
		} else if ( wordClicked ) {
			return;
		}

		wordClicked = true;
		notDirectlyStyled = true;

		/*set up a timeout on the word clicked check so if processing fails the user doesn't have to reload the page to use the suggestion panel.*/
		clearTimeout(wordClickedWait);
		wordClickedWait = setTimeout(function(){
			wordClicked = false;
			notDirectlyStyled = true;
		}, 250);

		// set up a double click timeout to clear the double click watcher
		clearTimeout(doubleClickWait);
		doubleClickWait = setTimeout(function(){
			clickedWordId = false;
			clickedSentenceId = false;
		}, 200);


		// find the words in the current sentence
		var $words = sentence.find('.linkilo_word');

		// tag all the words in the sentence with ids
		var word_id = 0;
		var word_id_attr = 'linkilo-word-id';
		$words.each(function(i, el) {
			word_id++;
			var $el = $(el);
			$el.data(word_id_attr, word_id);
			$el.attr('data-' + word_id_attr, word_id);
		});

		// get the id of the clicked word and the current sentece
		clickedWordId = clickedWord.data('linkilo-word-id');
		clickedSentenceId = clickedWord.closest('tr').data('linkilo-sentence-id');

		if(clickedWordId > 1){
			var previousTag = sentence.find('[data-linkilo-word-id="' + (clickedWordId - 1) + '"]');
			var nextTag = sentence.find('[data-linkilo-word-id="' + (clickedWordId + 1) + '"]');
			if(nextTag.length && previousTag.hasClass('open-tag') && nextTag.hasClass('close-tag')){
				notDirectlyStyled = false;
			}
		}

		// find all the words in the anchor and get the start and end words of the anchor
		var anchorWords = sentence.find('a span');
		var start = anchorWords.first().data('linkilo-word-id');
		var end = anchorWords.last().data('linkilo-word-id');
		var middleWord = findMiddleWord(start, end, anchorWords);
		var clickedPos = clickedWord.data('linkilo-word-id');

		// get the link minus contents
		var anchorClone = sentence.clone().find('a').html('');

		// if the link start and end is undefinded, insert a link at the click location
		if(undefined === end && undefined === start){

			// set the clicked word as the link's only word
			var linkWords = sentence.find('[data-linkilo-word-id="' + clickedPos + '"]');

			// clone the word
			var clonedWords = linkWords.clone();

			// create a new link if we didn't find one
			if(anchorClone.length < 1){
				anchorClone = $('<a href="%view_link%" target="_blank"></a>');
			}

			// insert the cloned words into the cloned anchor
			anchorClone = anchorClone.html(clonedWords);

			// replace the anchor with just the words
			sentence.find('a').replaceWith(sentence.find('a').html());

			// now remove all the new anchor words from the sentence
			sentence.find('[data-linkilo-word-id="' + clickedPos + '"]').remove();

			if((clickedPos - 1) > 0){
				// insert the anchor before the clicked word in the sentence
				anchorClone.insertAfter(sentence.find('[data-linkilo-word-id="' + (clickedPos - 1) + '"]'));
			}else{
				// insert the anchor at the start of the sentence
				sentence.prepend(anchorClone);
			}

			custom_sentence_refresh(sentence);

			if (sentence.closest('.wp-list-table').hasClass('incoming')) {
				sentence.closest('li').find('input[type="radio"]').click();
			}

			wordClicked = false;
			return;
		}

		// find out where the clicked word lands relative to the anchor
		if((clickedPos > end || clickedPos >= middleWord)){
			// if it's past the end of the anchor or middle of the sentence

			// if the user clicked on the last word in the link,
			// reduce the clicked pos by 1 to remove the word from the link
			if(end == clickedPos && start < end){
				clickedPos -= 1;
			}

			var wordIds = numberRange(start, clickedPos);

			// find all the words that will be in the link
			var wordString = '[data-linkilo-word-id="' + wordIds.join('"], [data-linkilo-word-id="') + '"]';
			var linkWords = sentence.find(wordString);

			// clone the words
			var clonedWords = linkWords.clone();

			// insert the cloned words into the cloned anchor
			anchorClone = anchorClone.html(clonedWords);

			// replace the anchor with just the words
			sentence.find('a').replaceWith(sentence.find('a').html());

			// now remove all the new anchor words from the sentence
			sentence.find(wordString).remove();

			if((start - 1) > 0){
				// insert the anchor before the clicked word in the sentence
				anchorClone.insertAfter(sentence.find('[data-linkilo-word-id="' + (start - 1) + '"]'));
			}else{
				// insert the anchor at the start of the sentence
				sentence.prepend(anchorClone);
			}
		}else if(clickedPos < start || clickedPos < middleWord){
			// if it's past the end of the anchor or middle of the sentence

			// if the user clicked on the last word in the link,
			// increase the clicked pos by 1 to remove the word from the link
			if(start == clickedPos && start < end){
				clickedPos += 1;
			}

			var wordIds = numberRange(clickedPos, end);

			// find all the words that will be in the link
			var wordString = '[data-linkilo-word-id="' + wordIds.join('"], [data-linkilo-word-id="') + '"]';
			var linkWords = sentence.find(wordString);

			// clone the words
			var clonedWords = linkWords.clone();

			// insert the cloned words into the cloned anchor
			anchorClone = anchorClone.html(clonedWords);

			// replace the anchor with just the words
			sentence.find('a').replaceWith(sentence.find('a').html());

			// now remove all the new anchor words from the sentence
			sentence.find(wordString).remove();

			if((clickedPos - 1) > 0){
				// insert the anchor before the clicked word in the sentence
				anchorClone.insertAfter(sentence.find('[data-linkilo-word-id="' + (clickedPos - 1) + '"]'));
			}else{
				// insert the anchor at the start of the sentence
				sentence.prepend(anchorClone);
			}
		}

		spaceSentenceWords(sentence);

		// check for html style tags inside the link
		var tags = $(anchorClone).find('.linkilo_suggestion_tag');

		// if there are some
		if(tags.length){
			// process the tags
			processSentenceTags(sentence, anchorClone);
		}

		styleSentenceWords(sentence);

		custom_sentence_refresh(sentence);

		if (sentence.closest('.wp-list-table').hasClass('incoming')) {
			sentence.closest('li').find('input[type="radio"]').click();
		}

		wordClicked = false;
	});

function processDoubleClick(sentenceId, wordId, dataId = false) {
		// if this is
	if(false !== dataId){
			// get the current sentence
		var sentence = $('tr[data-linkilo-sentence-id="' + sentenceId + '"] .linkilo-incoming-sentence-data-container[data-container-id="' + dataId + '"] [data-linkilo-word-id="' + wordId + '"]').closest('.linkilo_sentence');
	}else{
				// get the current sentence
		var sentence = $('tr[data-linkilo-sentence-id="' + sentenceId + '"] .top-level-sentence [data-linkilo-word-id="' + wordId + '"]').closest('.linkilo_sentence');
	}

		// get the link minus contents
	var anchorClone = sentence.clone().find('a').html('');

		// set the clicked word as the link's only word
	var linkWords = sentence.find('[data-linkilo-word-id="' + wordId + '"]');

		// clone the word
	var clonedWords = linkWords.clone();

		// create a new link if we didn't find one
	if(anchorClone.length < 1){
		anchorClone = $('<a href="%view_link%" target="_blank"></a>');
	}

		// insert the cloned words into the cloned anchor
	anchorClone = anchorClone.html(clonedWords);

		// replace the anchor with just the words
	sentence.find('a').replaceWith(sentence.find('a').html());

		// now remove all the new anchor words from the sentence
	sentence.find('[data-linkilo-word-id="' + wordId + '"]').remove();

	if((wordId - 1) > 0){
			// insert the anchor before the clicked word in the sentence
		anchorClone.insertAfter(sentence.find('[data-linkilo-word-id="' + (wordId - 1) + '"]'));
	}else{
			// insert the anchor at the start of the sentence
		sentence.prepend(anchorClone);
	}

	spaceSentenceWords(sentence);

		// check for html style tags inside the link
	var tags = $(anchorClone).find('.linkilo_suggestion_tag');

		// if there are some
	if(tags.length){
			// process the tags
		processSentenceTags(sentence, anchorClone);
	}

	styleSentenceWords(sentence);
	custom_sentence_refresh(sentence);

	if (sentence.closest('.wp-list-table').hasClass('incoming')) {
		sentence.closest('li').find('input[type="radio"]').click();
	}

	wordClicked = false;
	clickedWordId = false;
	clickedSentenceId = false;

		// clear any selections so the user doesn't wind up selecting the full sentence
	clearSelection();
}

function clearSelection(){
	if(window.getSelection){
		window.getSelection().removeAllRanges();
	}else if(document.selection){
		document.selection.empty();
	}
}

function findMiddleWord(start = 0, end = 0, words = []){
	start = parseInt(start);
	end = parseInt(end);

	if(start === end){
		return start;
	}

	var letterRange = [];
	var totalLetters = 0;
	words.each(function(index, word){
		word = $(word);
		if(!word.hasClass('linkilo_suggestion_tag')){
			var length = word.text().length;
			totalLetters += length;
			letterRange[word.data('linkilo-word-id')] = length;
		}
	});

	var middleLetter = Math.round(totalLetters/2);
	var currentCount = 0;
	var middle = 0;
	for(var i in letterRange){
		currentCount += letterRange[i];

		if(currentCount >= middleLetter){
			middle = i;
			break;
		}
	}

	return middle;
}

function numberRange(start = 0, end = 0){
	var result = [];
	for(var i = start; i <= end; i++){
		result.push(i);
	}

	return result;
}

	/**
	 * Sets the correct word spacing on words in the clicked sentence.
	 * @param {object} sentence
	 */
function spaceSentenceWords(sentence) {

	var words = sentence.find('.linkilo_word');
	 	/*find all the existing spaces in the sentence*/
	var spaces = [];
	sentence.contents().filter(function(){
		if(this.nodeType === Node.TEXT_NODE){
			spaces.push(this);
		}
	});

	 	/*and remove them*/
	$(spaces).remove();

	 	/*now add new spaces to the sentence*/
	sentence.find('span').map(function(index, element) {
		var $el = $(this);
		var data = [];

		if(0 === index){
			if(undefined !== words[index + 1] && $(words[index + 1]).hasClass('no-space-left')){
				data = [this];
			}else if($el.hasClass('no-space-right')){
				data = [document.createTextNode(' '), this];
			}else{
				data = [this, document.createTextNode(' ')];
			}
		}else{
			if(undefined !== words[index + 1] && $(words[index + 1]).hasClass('no-space-left')){
				data = [this];
			}else if(undefined !== words[index + 1] && $(words[index + 1]).hasClass('no-space-right')){
				data = [document.createTextNode(' '), this];
			}else if($el.hasClass('no-space-right')){
				data = [this];
			}else{
				data = [this, document.createTextNode(' ')];
			}
		}

		$(data).insertAfter(element);
	});
}

	/**
	 * Moves the html style tags based on the user's link selection so we don't get half a style tag in the link with the other half outside it.
	 * @param sentence
	 * @param anchor
	 */
function processSentenceTags(sentence, anchor){
	var tagTypes = ['linkilo-bold', 'linkilo-ital', 'linkilo-under', 'linkilo-strong', 'linkilo-em'];

		// find all the tags in the anchor and add them to a list
	var anchorTagData = {};
	anchor.find('.linkilo_suggestion_tag').map(function(){
		var $el = $(this);
		for(var i in tagTypes){
			if($el.hasClass(tagTypes[i])){
				if(undefined === anchorTagData[tagTypes[i]]){
					anchorTagData[tagTypes[i]] = [];
				}

				anchorTagData[tagTypes[i]].push($el);
			}
		}
	});

		// look over all the found tags
	var keys = Object.keys(anchorTagData);
	$(keys).each(function(index, key){
			// if the anchor doesn't contain the opening and closing tags,
			// move the tag to the correct location
		if(anchorTagData[key].length === 1){
				// if the tag is an opening one
			if(anchorTagData[key][0].hasClass('open-tag')){
					// move it right until it's outside the anchor
				var tag = sentence.find(anchorTagData[key][0]).detach();
				tag.insertAfter(sentence.find('a'));
			}else{
					// if the tag is an opening one, move it left until it's outside the anchor
				var tag = sentence.find(anchorTagData[key][0]).detach();
				tag.insertBefore(sentence.find('a'));
			}

		}else if(anchorTagData[key].length > 2){
				// todo handle cases where there's 3 of the same type of tag in the link...
		}
	});

		// now remove any tags that are right next to each other
	var words = sentence.find('span');
	words.map(function(index, element){
		var current = $(element);
			// if this is a style tag and the word after this one is a style tag
		if(current.hasClass('linkilo_suggestion_tag') && undefined !== words[index + 1] && $(words[index + 1]).hasClass('linkilo_suggestion_tag')){
			var next = $(words[index + 1]);

				// see if they're both the same kind of tag
			var tagType = '';
			for(var i in tagTypes){
				if(current.hasClass(tagTypes[i])){
					tagType = tagTypes[i];
					break;
				}
			}

				// if it does
			if(next.hasClass(tagType)){
					// remove both tags
				sentence.find(current).remove();
				sentence.find(next).remove();
			}
		}
	});
}

	/**
	 * Styles the words in the sentence based on the HTML style tags found in the text.
	 * Mostly this is to give the user some idea of what we're doing with his style tags.
	 * @param sentence
	 */
function styleSentenceWords(sentence){
	var tagTypes = ['linkilo-bold', 'linkilo-ital', 'linkilo-under', 'linkilo-strong', 'linkilo-em'];
	var styleSettings = {'linkilo-bold': {'font-weight': 600}, 'linkilo-ital': {'font-style': 'italic'},  'linkilo-under': {'text-decoration': 'underline'}, 'linkilo-strong': {'font-weight': 600}, 'linkilo-em': {'font-style': 'italic'}};
	var styles = {};

	var words = sentence.find('span');
	words.map(function(index, element){
		var current = $(element);
			// if this is a style tag
		if(current.hasClass('linkilo_suggestion_tag')){
				// find out what kind it is
			var tagType = '';
			for(var i in tagTypes){
				if(current.hasClass(tagTypes[i])){
					tagType = tagTypes[i];
					break;
				}
			}

				// if it's an opening tag
			if(current.hasClass('open-tag')){
					// add the correct styles to the styling array to mimic the html tag effect
				for(var key in styleSettings[tagType]){
					styles[key] = styleSettings[tagType][key];
				}
			}else{
					// if it's a closing tag, remove the style
				for(var key in styleSettings[tagType]){
					delete styles[key];
				}
			}
		}else{
			current.removeAttr("style").css(styles);
		}
	});
}

	/**
	 * Styles all of the page's sentences.
	 */
function styleSentences(){
	$('#the-list .sentence .linkilo_sentence, #the-list .linkilo-content .linkilo_sentence').each(function(index, sentence){
		styleSentenceWords($(sentence));
	});
}

// $("input[name='linkilo_check_all_toggle']").click(function (e) {
$("input[class='linkilo-check-all-toggle']").click(function (e) {

	let tbl_checkbox_name = $(this).attr('name');
	let row_checkbox_class = $(this).data('row');
	let tbl_save_btn = $(this).data('save-btn');
	// var $checkboxes = $("input[type=checkbox][name=linkilo_check_all_toggle]");
	var $checkboxes = $("input[type=checkbox][name="+tbl_checkbox_name+"]");

	var checkedState = this.checked;
	$checkboxes.each(function() {
		this.checked = checkedState;
	});

	// $('.linkilo_toggle_follow_post_link:checkbox').not(this).prop('checked', this.checked);
	$('.'+row_checkbox_class+':checkbox').not(this).prop('checked', this.checked);

	var checked_boxes = $("."+row_checkbox_class+":checked").length;	

	if (checked_boxes > 0) {
		$("button[name='"+tbl_save_btn+"']").prop('disabled', false);
	}else{
		$("button[name='"+tbl_save_btn+"']").prop('disabled', true);
	}
});



// $(document).on('change', '.linkilo_toggle_follow_post_link', function(e) {
$(document).on('change', '.linkilo_toggle_follow_post_link_internal, .linkilo_toggle_follow_post_link_external', function(e) {

	let row_class = $(this).attr('class');
	let tbl_chk_box = $(this).data('tbl-checkbox');
	let tbl_save_btn = $(this).data('tbl-save-btn');

	// let checked_boxes = $(".linkilo_toggle_follow_post_link:checked").length;
	let checked_boxes = $("."+row_class+":checked").length;

	// var total_checkboxes_available = $('.linkilo_toggle_follow_post_link').length;
	let total_checkboxes_available = $('.'+row_class+'').length;


	if (checked_boxes == total_checkboxes_available){
		// $("input[name='linkilo_check_all_toggle']").prop('checked',true);		
		$("input[name='"+tbl_chk_box+"']").prop('checked',true);		
	}
	else {
		// $("input[name='linkilo_check_all_toggle']").prop('checked',false);		
		$("input[name='"+tbl_chk_box+"']").prop('checked',false);			
	}

	if (checked_boxes > 0) {
		// $("button[name='linkilo_save_attribute_changes']").prop('disabled', false);
		$("button[name='"+tbl_save_btn+"']").prop('disabled', false);
	}else{
		// $("button[name='linkilo_save_attribute_changes']").prop('disabled', true);
		$("button[name='"+tbl_save_btn+"']").prop('disabled', true);
	}
});

// $(document).on('click', "button[name='linkilo_save_attribute_changes']", function(e){
$(document).on('click', "button[name='linkilo_save_attribute_changes_internal'], button[name='linkilo_save_attribute_changes_external'] ", function(e){
	var checked_boxes = [];

	let row_checkbox_class = $(this).data('row');
	let tbl_id = $(this).data('tbl');
	let tbl_loader = $(this).data('tbl-loader');

	// var checked_boxes_length = $(".linkilo_toggle_follow_post_link:checked").length;
	var checked_boxes_length = $("."+row_checkbox_class+":checked").length;

	var loader = '<div class="'+tbl_loader+'"><div class="linkilo_progress_panel loader"></div><div class="linkilo_progress_panel_center">Loading</div></div>';
	var post = $("#linkilo_current_post").val();

	if (checked_boxes_length > 0) {
		$.each($('.'+row_checkbox_class+':checked'), function() {
			checked_boxes.push({
				checked_val : $(this).val(),
				id : $(this).data('id'),
				url : $(this).data('url'),
				anchor : $(this).data('anchor'),
			});
		});
		$("#"+tbl_id).after(loader);
		$("#"+tbl_id).hide();
	}else{
		$("#"+tbl_id).after(loader);
		$("#"+tbl_id).hide();

		linkilo_swal("Can't Process!", "Please select any of the checkboxes and then process.", 'error').then((match) => {
			if (match) {
				$("."+tbl_loader).remove();
				$("#"+tbl_id).show();
			}else{
				$("."+tbl_loader).remove();
				$("#"+tbl_id).show();
			}
		});
		return false;
	}

	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			action: 'linkilo_toggle_follow_link',
			checked_array: checked_boxes,
			total: checked_boxes_length,
			post: post,
		},
		success: function(response){
			if (response.status == 1) {
				$("."+tbl_loader).remove();
				$("#"+tbl_id).show();
			}else{
				setTimeout(function(){
					$("."+tbl_loader).remove();
					$("#"+tbl_id).show();
				}, 10000);
			}

			linkilo_swal(response.title, response.msg, response.icon).then(
				(value) => {
					// reload on ok click
					if (value) {
						location.reload();
					}else{
						// reload on click outside popup window and popup hides
						setTimeout(function(){ location.reload(); }, 100);
					}
				});
		},
		error: function(jqXHR, textStatus, errorThrown){
			console.log({jqXHR, textStatus, errorThrown});
		}
	});
});

$(document).on('change', '#field_same_title', function(e){

	if ($(this).prop('checked')) {
		var sameTitle = 'show';
	}else{
		var sameTitle = 'hide';
	}
	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			action: 'update_related_posts_same_title',
			same_title_option: sameTitle,
		},
		success: function(response){
			console.log(response.flag);
			if (response.flag == 'success') {
				location.reload();
			}else{
				console.log(response.flag + ' : ' + response.msg);
			}
		},
		error: function(jqXHR, textStatus, errorThrown){
			console.log({jqXHR, textStatus, errorThrown});
		}
	});
});

var same_category_loading = false;

var multicat_array = [];
var multitag_array = [];

function linkilo_handle_multi_cats_tags(element, operation = "") {

	var process_cats_tags = false;
	var container = $(element).closest('[data-linkilo-ajax-container]');

	var sameCategory = container.find('#multi_field_same_category').prop('checked');
	var sameTag = container.find('#multi_field_same_tag').prop('checked');

	if (!isNaN($('#linkilo_selected_category_multi').val()) || typeof $('#linkilo_selected_category_multi').val() !== "undefined") {
		var selectedcatval = parseInt($('#linkilo_selected_category_multi').val());
	}else{
		var selectedcatval = parseInt(0);
	}

	if (!isNaN($('#linkilo_selected_tag_multi').val()) || $('#linkilo_selected_tag_multi').val() !== undefined) {
		var selectedtagval = parseInt($('#linkilo_selected_tag_multi').val());
	}else{
		var selectedtagval = parseInt(0);
	}

		/*check operation*/
	if (operation == "op_remove_category" && sameCategory) {
		var elm = '#cat_remove_btn_'+parseInt($(element).data("id"));
		var cat_btn_id = parseInt($(element).data("id"));

			/*remove the element from container*/
		$(elm).remove();

			/*remove the element from array*/
		if (multicat_array.length !== 0) {
			multicat_array = $.grep(multicat_array, function(value) {
				return value != cat_btn_id;
			});
			var last_element = multicat_array[multicat_array.length-1];

				/*reset the value of select box*/
			$('#linkilo_selected_category_multi').val(last_element);

				/*set process_cats_tags to true to process multiple cats*/
			process_cats_tags = true;
		}

		if (multicat_array.length === 0) {
			$( ".linkilo_multi_wrap" ).empty();
			$(".linkilo_multi_wrap").hide();
			multicat_array = [];

				/*reset the value of select box to default*/
			$('#linkilo_selected_category_multi').val("0");

				/*set process_cats_tags to true to process multiple cats*/
			process_cats_tags = true;
		}
	} else if (operation == "op_add_category" && sameCategory) {
		if (selectedcatval == 0) {
				/*i.e user selected ALL CATEGORIES*/

				/*Check the array length to identify that it's empty or not*/
			if (multicat_array.length !== 0) {
					/*empty the array*/
				multicat_array = [];
				process_cats_tags = true;
			}
		}else{
				/*check if value in array*/
			if($.inArray(selectedcatval, multicat_array) == -1){
					/*Not in array add it to array*/
				multicat_array.push(selectedcatval);
				process_cats_tags = true;
			}
		}
	}else if (operation == "op_add_tag" && sameTag) {
		if (selectedtagval == 0) {
				/*i.e user selected ALL TAGS*/
				/*Check the array length to identify that it's empty or not*/
			if (multitag_array.length !== 0) {
					/*empty the array*/
				multitag_array = [];
				process_cats_tags = true;
			}
		}else{
				/*check if value in array*/
			if($.inArray(selectedtagval, multitag_array) == -1){
					/*Not in array add it to array*/
				multitag_array.push(selectedtagval);
				process_cats_tags = true;
			}
		}
	} else if (operation == "op_remove_tag" && sameTag) {
		var elm = '#tag_remove_btn_'+parseInt($(element).data("id"));
		var tag_btn_id = parseInt($(element).data("id"));

			/*remove the element from container*/
		$(elm).remove();

			/*remove the element from array*/
		if (multitag_array.length !== 0) {
			multitag_array = $.grep(multitag_array, function(value) {
				return value != tag_btn_id;
			});
			var last_element = multitag_array[multitag_array.length-1];

				/*reset the value of select box*/
			$('#linkilo_selected_tag_multi').val(last_element);

				/*set process_cats_tags to true to process multiple cats*/
			process_cats_tags = true;
		}

		if (multitag_array.length === 0) {
			$( ".linkilo_multi_wrap" ).empty();
			$(".linkilo_multi_wrap").hide();
			multitag_array = [];

				/*reset the value of select box to default*/
			$('#linkilo_selected_tag_multi').val("0");

				/*set process_cats_tags to true to process multiple cats*/
			process_cats_tags = true;
		}
	}

	if (!same_category_loading) {

		same_category_loading = true;

		var url = container.attr('data-linkilo-ajax-container-url');
		var urlParams = parseURLParams(url);
		var post_id = (urlParams.post_id) ? urlParams.post_id[0] : 0;
		var category_checked = '';
		var tag_checked = '';

			/*remove any active same category settings*/
		url = url.replace('&same_category=true', '');

			/*category*/
		if (sameCategory) {
			url += "&same_category=true";
			category_checked = 'checked="checked"';
		}

		if (container.find('select[name="multi_linkilo_selected_category"]').length) {
			url += "&selected_category=" + container.find('select[name="multi_linkilo_selected_category"]').val();
		}

			/*tag*/
		if (sameTag) {
			url += "&same_tag=true";
			tag_checked = 'checked="checked"';
		}
		if (container.find('select[name="multi_linkilo_selected_tag"]').length) {
			url += "&selected_tag=" + container.find('select[name="multi_linkilo_selected_tag"]').val();
		}

		if(!urlParams.linkilo_no_preload){
			container.html('<div class="linkilo_progress_panel loader"><div class="progress_count" style="width: 100%"></div></div><div class="linkilo_progress_panel_center" > Loading </div>');
		}

		if(urlParams.type && 'outgoing_suggestions_ajax' === urlParams.type[0]){
				/*outgoing suggestion in post content*/
			var selectedCategories = (multicat_array.length === 0) ? 0 : multicat_array;
			var selectedTags = (multitag_array.length === 0) ? 0 : multitag_array;

			ajaxGetSuggestionsOutbound(container, url, 0, 0, null, selectedCategories, selectedTags);
		}
		same_category_loading = false;
	}
}

	/*Remove selected category or tag to process suggestions*/
$(document).on('click', ".remove_option_value", function(event){
	if ($(this).data('checked') == 'cats') {
		linkilo_handle_multi_cats_tags(this, "op_remove_category");
	}else if ($(this).data('checked') == 'tags') {
		linkilo_handle_multi_cats_tags(this, "op_remove_tag");
	}
});

	/*Call Handle action multiple categories and tags starts*/
$(document).on('change', '#multi_field_same_category, select[name="multi_linkilo_selected_category"]', function(event){
	linkilo_handle_multi_cats_tags(this, "op_add_category");
});

	/*Call Handle action multiple categories and tags starts*/
$(document).on('change', '#multi_field_same_tag, select[name="multi_linkilo_selected_tag"]', function(event){
	linkilo_handle_multi_cats_tags(this, "op_add_tag");
});

$(document).on('click', 'button[name="linkilo-outgoing-load-more"], button[name="linkilo-incoming-load-more"]', function(event) {
	var btn_attr = $(this).attr('name');
	var btn_loader = $(this).data('loader');
	var btn_name = 'button[name="'+btn_attr+'"]';
	var colspan = btn_loader === 2 ? '3' : '2';

	var loader_id = 'tr_load_more_'+btn_attr;
	var loader = '<tr id="'+loader_id+'"><td colspan="'+colspan+'"><div class="linkilo_progress_panel loader"><div class="progress_count" style="width: 100%"></div></div><div class="linkilo_progress_panel_center">Loading</div></tr></td>';

	$(btn_name).prop('disabled', true);
	$(btn_name).closest('tr').before(loader);

	var container = $(btn_name).closest('[data-linkilo-ajax-container]');
	var url = container.attr('data-linkilo-ajax-container-url');
	var urlParams = parseURLParams(url);
	var post_id = (urlParams.post_id) ? urlParams.post_id[0] : 0;
	url = url.replace('&same_category=true', '');

	$(btn_name).html('LOAD MORE <span class="dashicons dashicons-arrow-down-alt2" style="margin-top: 2px;font-size: 23px;"></span>');
	if(urlParams.type && 'outgoing_suggestions_ajax' === urlParams.type[0]){
			// outgoing suggestion in post content
		ajaxGetSuggestionsOutbound(container, url, 0, 0, null, null, null, 1, btn_attr, loader_id, btn_loader);
	}else if(urlParams.type && 'meta_incoming_suggestions_page_container' === urlParams.type[0]){
		ajaxGetSuggestionsIncomingMeta(container, url, 0, 0, 0, null, 1, btn_attr, loader_id, btn_loader);
	}
	return false;
});

$(document).on('change', '#field_same_category, #field_same_tag, #field_same_title_chk, #field_same_title_chk_in_metabox, #exact_match_keyword_post, #exact_match_keyword_post_in_metabox, #exact_match_url_slug, #exact_match_url_slug_in_metabox, #links_based_on_related_posts, #links_based_on_sub_headings,select[name="linkilo_selected_category"], select[name="linkilo_selected_tag"]', function(event){

	if (!same_category_loading) {
		same_category_loading = true;
		var container = $(this).closest('[data-linkilo-ajax-container]');
		var url = container.attr('data-linkilo-ajax-container-url');
		var urlParams = parseURLParams(url);
		var sameCategory = container.find('#field_same_category').prop('checked');
		var sameTag = container.find('#field_same_tag').prop('checked');
		var category_checked = '';
		var tag_checked = '';
		var post_id = (urlParams.post_id) ? urlParams.post_id[0] : 0;

			// same title option
		var sameTitle = container.find('#field_same_title_chk').prop('checked');
		var title_checked = '';
		var sameTitleTxtChk = '';

			// field_same_title_chk_in_metabox
		var sameTitleMeta = container.find('#field_same_title_chk_in_metabox').prop('checked');
		var title_checked_meta = '';
		var sameTitleTxtChkMeta = '';

			// exactmatch keyword inbound page and outbound metabox
		var exactMatchKeyword = container.find('#exact_match_keyword_post').prop('checked');
		var exact_match_checked = '';

			// exactmatch keyword inbound metabox
		var exactMatchKeywordInMeta = container.find('#exact_match_keyword_post_in_metabox').prop('checked');
		var exact_match_in_meta_checked = '';

			// match with url slug
		var exactMatchUrlSlug = container.find("#exact_match_url_slug").prop('checked');
		var exact_match_url_slug = '';

			// match with url slug meta
		var exactMatchUrlSlugInMeta = container.find("#exact_match_url_slug_in_metabox").prop('checked');
		var exact_match_url_slug_in_meta = '';

			// related posts
		var matchLinksByRelatedArticle = container.find("#links_based_on_related_posts").prop('checked');
		var match_links_related_checked = '';

		var matchLinksBySubHeading = container.find("#links_based_on_sub_headings").prop('checked');
		var match_links_sub_heading_checked = '';

			// remove any active same category settings
		url = url.replace('&same_category=true', '');

			//category
		if (sameCategory) {
			url += "&same_category=true";
			category_checked = 'checked="checked"';
		}
		if (container.find('select[name="linkilo_selected_category"]').length) {
			url += "&selected_category=" + container.find('select[name="linkilo_selected_category"]').val();
		}

			//tag
		if (sameTag) {
			url += "&same_tag=true";
			tag_checked = 'checked="checked"';
		}
		if (container.find('select[name="linkilo_selected_tag"]').length) {
			url += "&selected_tag=" + container.find('select[name="linkilo_selected_tag"]').val();
		}

			// title
		if (sameTitle) {
			sameTitleTxtChk = $("#field_same_title_chk").data('post_title_chk');

			url += "&same_title_chk=true&same_title_text_chk=" + sameTitleTxtChk;
			title_checked = 'checked="checked"';
		}

			// title Meta box
		if (sameTitleMeta) {
			sameTitleTxtChkMeta = $("#field_same_title_chk_in_metabox").data('post_title_chk_in_meta');

			url += "&same_title_chk_in_meta=true&same_title_text_chk_in_meta=" + sameTitleTxtChkMeta;
			title_checked_meta = 'checked="checked"';
		}

			// Exact Match Keyword for page and outbound
		if (exactMatchKeyword) {
			url += "&exact_match_checked=true";
			exact_match_checked = 'checked="checked"';
		}else{
			exact_match_checked = '';
		}

			// Exact Match Keyword for page and outbound
		if (exactMatchKeywordInMeta) {
			url += "&exact_match_in_meta_checked=true";
			exact_match_in_meta_checked = 'checked="checked"';
		}else{
			exact_match_in_meta_checked = '';
		}

			// Match Url
		if (exactMatchUrlSlug) {
			url += "&exact_match_url_slug=true";
			exact_match_url_slug = 'checked="checked"';
		}else{
			exact_match_url_slug = '';
		}

			// Match Url
		if (exactMatchUrlSlugInMeta) {
			url += "&exact_match_url_slug_in_meta=true";
			exact_match_url_slug_in_meta = 'checked="checked"';
		}else{
			exact_match_url_slug_in_meta = '';
		}

		if (matchLinksByRelatedArticle) {
			url += "&match_related_articles=true";
			match_links_related_checked = 'checked="checked"';
		}

		if (matchLinksBySubHeading) {
			url += "&match_sub_headings=true";
			match_links_sub_heading_checked = 'checked="checked"';
		}

		if(urlParams.linkilo_no_preload && '1' === urlParams.linkilo_no_preload[0]){
			var checkAndButton = '<div style="margin-bottom: 15px;">' +
			'<input style="margin-bottom: -5px;" type="checkbox" name="same_category" id="field_same_category_page" ' + category_checked + '>' +
			'<label for="field_same_category_page">Show Links Based on Category</label> <br>' +
			'<input style="margin-bottom: -5px;" type="checkbox" name="same_tag" id="field_same_tag_page" ' + tag_checked + '>' +
			'<label for="field_same_tag_page">Show Links Based on Tags</label> <br>' +

			'<input style="margin-bottom: -5px;" type="checkbox" name="same_title_chk" id="field_same_title_chk" ' + title_checked + 'js>' +
			'<label for="field_same_title_chk">Show Links Based on Title Tags</label> <br>' +

			'<input style="margin-bottom: -5px;" type="checkbox" name="exact_match_keyword" id="exact_match_keyword_post" ' + exact_match_checked + '>' +
			'<label for="exact_match_keyword_post">Show Links Based on Exact Match Keywords js</label> <br>' +
			'<input style="margin-bottom: -5px;" type="checkbox" name="exact_match_url" id="exact_match_url_slug" ' + exact_match_url_slug + '>' +
			'<label for="exact_match_url_slug">Show Links Based on URL</label> <br>' +
			'<input style="margin-bottom: -5px;" type="checkbox" name="links_based_on_related_posts" id="links_based_on_related_posts" ' + match_links_related_checked + '>' +
			'<label for="links_based_on_related_posts">Show Links Based on Contextual Related Articles</label> <br>' +

			'<input style="margin-bottom: -5px;" type="checkbox" name="links_based_on_sub_headings" id="links_based_on_sub_headings" ' + match_links_sub_heading_checked + '>' +
			'<label for="links_based_on_sub_headings">Show Links Based on Contextual Related Articles</label> <br>' +

			'</div>' +
			'<button id="incoming_suggestions_button" class="sync_linking_keywords_list button-primary" data-id="' + post_id + '" data-type="incoming_suggestions_page_container" data-page="incoming">Custom links</button>';
			container.html(checkAndButton);
		}else{
			container.html('<div class="linkilo_progress_panel loader"><div class="progress_count" style="width: 100%"></div></div><div class="linkilo_progress_panel_center" > Loading </div>');
		}

		if(urlParams.type && 'outgoing_suggestions_ajax' === urlParams.type[0]){
				// outgoing suggestion in post content
			ajaxGetSuggestionsOutbound(container, url, 0);
		}else if(urlParams.type && 'incoming_suggestions_page_container' === urlParams.type[0]){
				// Incoming suggestion to current post from other post content
			ajaxGetSuggestionsIncoming(container, url, 0);
		}else if(urlParams.type && 'meta_incoming_suggestions_page_container' === urlParams.type[0]){
			ajaxGetSuggestionsIncomingMeta(container, url, 0);
		}
		same_category_loading = false;
	}
});

$(document).on('change', '#field_same_category_page', function(){
	var url = document.URL;
	if ($(this).prop('checked')) {
		url += "&same_category=true";
	} else {
		url = url.replace('/&same_category=true/g', '');
	}

	location.href = url;
});

$(document).on('click', '.sync_linking_keywords_list', function (e) {
	e.preventDefault();
	var container = $(this).closest('[data-linkilo-ajax-container]');
	container.hide();
	$('<div class="linkilo_progress_panel_on_meta_box" ><div class="linkilo_progress_panel loader"><div class="progress_count" style="width: 100%"></div></div><div class="linkilo_progress_panel_center" > Loading </div></div>').insertAfter(container);
	var page = $(this).data('page');
	var links = [];
	var data = [];
	var button = $(this);
	let div_class = '';
	if (page == 'incoming') {
		div_class = '.tbl_post_edit_inbound input:checked';
	}else{
		div_class = '.tbl_post_edit_outbound input:checked';
	}

	$(".chk-keywords").change(function() {
		if($(".chk-keywords").is(':checked')) 
			$(".chk-keywords").addClass('selected'); 
		else 
		$(".chk-keywords").removeClass('selected');
	});

	$(div_class).each(function() {
		if (page == 'incoming') {
			if ($(".chk-keywords").is(":checked"))  {
				var ch_box=$(".chk-keywords").val();
				var item = {};
				item.id = $(this).closest('tr').find('.sentence').data('id');
				item.type = $(this).closest('tr').find('.sentence').data('type');
				item.links = [{
					'sentence': $(this).closest('tr').find('.sentence').find('[name="sentence"]').val(),
					'sentence_with_anchor': $(this).closest('tr').find('.linkilo_sentence_with_anchor').html(),
					'custom_sentence': $(this).closest('tr').find('input[name="custom_sentence"]').val()
				}];

				data.push(item);
			}
		} else {
			if ($(this).closest('tr').find('input[type="radio"]:checked').length) {
				var id =  $(this).closest('tr').find('input[type="radio"]:checked').data('id');
				var type = $(this).closest('tr').find('input[type="radio"]:checked').data('type');
				var custom_link = $(this).closest('tr').find('input[type="radio"]:checked').data('custom');
				var post_origin = $(this).closest('tr').find('input[type="radio"]:checked').data('post-origin');
				var site_url = $(this).closest('tr').find('input[type="radio"]:checked').data('site-url');
			} else {
				var id =  $(this).closest('tr').find('.suggestion').data('id');
				var type =  $(this).closest('tr').find('.suggestion').data('type');
				var custom_link =  $(this).closest('tr').find('.suggestion').data('custom');
				var post_origin = $(this).closest('tr').find('.suggestion').data('post-origin');
				var site_url = $(this).closest('tr').find('.suggestion').data('site-url');
			}


			if (
				typeof($(this).closest('div').find('[name="sentence"]').val()) != "undefined" &&
				typeof($(this).closest('div').find('.linkilo_sentence_with_anchor').html()) != "undefined" &&
				typeof($(this).closest('.sentence').find('input[name="custom_sentence"]').val()) != "undefined"
				)
			{
				links.push({
					id: id,
					type: type,
					custom_link: custom_link,
					post_origin: post_origin,
					site_url: site_url,
					sentence: $(this).closest('div').find('[name="sentence"]').val(),
					sentence_with_anchor: $(this).closest('div').find('.linkilo_sentence_with_anchor').html(),
					custom_sentence: $(this).closest('.sentence').find('input[name="custom_sentence"]').val()
				});
			}
		}
	});

	if (page == 'outgoing') {
		data.push({'links': links});
	}else{
		button.addClass('linkilo_button_is_active');
	}

	$('.linkilo_keywords_list, .tbl-link-reports .wp-list-table, #tbl_keywords').addClass('ajax_loader');

	var data_post = {
		"id": $(this).data('id'),
		"type": $(this).data('type'),
		"page": $(this).data('page'),
		"action": 'linkilo_save_feed_url_references',
		'data': data,
		'gutenberg' : $('.block-editor-page').length ? true : false
	};

	$.ajax({
		url: linkilo_ajax.ajax_url,
		dataType: 'json',
		data: data_post,
		method: 'post',
		error: function (jqXHR, textStatus, errorThrown) {
			var wrapper = document.createElement('div');
			$(wrapper).append('<strong>' + textStatus + '</strong><br>');
			$(wrapper).append(jqXHR.responseText);
			linkilo_swal({"title": "Error", "content": wrapper, "icon": "error"});

			$('.linkilo_keywords_list, .tbl-link-reports .wp-list-table, #tbl_keywords').removeClass('ajax_loader');
			$( ".linkilo_progress_panel_on_meta_box" ).remove();
			container.show();
		},
		success: function (data) {
			if (data.err_msg) {
				linkilo_swal('Error', data.err_msg, 'error').then((match) => {
					if (match) {
						$('.linkilo_keywords_list, .tbl-link-reports .wp-list-table, #tbl_keywords').removeClass('ajax_loader');
						$( ".linkilo_progress_panel_on_meta_box" ).remove();
						container.show();
					}else{
						$('.linkilo_keywords_list, .tbl-link-reports .wp-list-table, #tbl_keywords').removeClass('ajax_loader');
						$( ".linkilo_progress_panel_on_meta_box" ).remove();
						container.show();
					}
				});
			} else {
				if (page == 'outgoing') {
					if ($('.editor-post-save-draft').length) {
						$('.editor-post-save-draft').click();
					} else if ($('#save-post').length) {
						$('#save-post').click();
					} else if ($('.editor-post-publish-button').length) {
						$('.editor-post-publish-button').click();
					} else if ($('#publish').length) {
						$('#publish').click();
					} else if ($('.edit-tag-actions').length) {
						$('.edit-tag-actions input[type="submit"]').click();
					}

					// set the flag so we know that the editor needs to be reloaded
					reloadGutenberg = true;
				} else {
					location.reload();
				}
			}
		},
		complete: function(){
			button.removeClass('linkilo_button_is_active');
			$('.linkilo_keywords_list').removeClass('ajax_loader');
		}
	})
});

function stristr(haystack, needle, bool){
		// http://jsphp.co/jsphp/fn/view/stristr
		// +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
		// +   bugfxied by: Onno Marsman
		// *     example 1: stristr('Kevin van Zonneveld', 'Van');
		// *     returns 1: 'van Zonneveld'
		// *     example 2: stristr('Kevin van Zonneveld', 'VAN', true);
		// *     returns 2: 'Kevin '
	var pos = 0;

	haystack += '';
	pos = haystack.toLowerCase().indexOf((needle + '').toLowerCase());

	if (pos == -1) {
		return false;
	} else {
		if (bool) {
			return haystack.substr(0, pos);
		} else {
			return haystack.slice(pos);
		}
	}
}

function linkilo_handle_errors(resp)
{
	if (stristr(resp, "520") && stristr(resp, "unknown error") && stristr(resp, "Cloudflare")) {
		linkilo_swal('Error', "It seems you are using CloudFlare and CloudFlare is hiding some error message. Please temporary disable CloudFlare, open reporting page again, look if it has any new errors and send it to us", 'error')
		.then(linkilo_report_next_step);
		return true;
	}

	if (stristr(resp, "504") && stristr(resp, "gateway")) {
		linkilo_swal('Error', "504 error: Gateway timeout - please ask your hosting support about this error", 'error')
		.then(linkilo_report_next_step);
		return true;
	}

	return false;
}

function linkilo_report_next_step()
{
	location.reload();
}

    /**
     * Makes the call to reset the report data when the user clicks on the "Reset Data" button.
     **/
function resetReportData(e){
	e.preventDefault();
	
	var form = $(this);
	var nonce = form.find('[name="reset_data_nonce"]').val();
	var wizard_run_scan = form.find('[name="wizard_run_scan"]');
	if (wizard_run_scan.length) {
        wizard_run_scan = wizard_run_scan.val();
        // Use anotherFieldValue as needed
    }
	else{
		var wizard_run_scan = '';
	}
	

	if(!nonce || form.attr('disabled')){
		return;
	}

        // disable the reset button
	form.attr('disabled', true);
        // add a color change to the button indicate it's disabled
	form.find('button.button-primary').addClass('linkilo_button_is_active');
	processReportReset(nonce, 0, true,wizard_run_scan);
}


var timeList = [];
function processReportReset(nonce = null, loopCount = 0, clearData = false,wizard_run_scan = null){
	if(!nonce){
		return;
	}

	var static_loader_content = '<div class="wrap linkilo-loading-screen"><h1 class="wp-heading-inline">Summary</h1><hr class="wp-header-end"><div id="poststuff"><div id="post-body" class="metabox-holder"><div id="post-body-content" style="position: relative;"><div><h3></h3><h3>Crawling your site...</h3><span class="linkilo-loading-status-message">This should only take a few moments.</span></div><div class="syns_div linkilo_report_need_prepare"><h4 class="linkilo_progress_panel_msg hide">Synchronizing your data..</h4><div class="linkilo_progress_panel"><div class="progress_count" style="width:100%"><span class="linkilo-loading-status"></span></div></div><div class="linkilo_progress_panel_center"> Loading </div></div></div></div></div></div>';

	$('#wpbody-content').html(static_loader_content);
	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			action: 'refresh_record_data',
			nonce: nonce,
			loop_count: loopCount,
			clear_data: clearData,
			wizard_run_scan: wizard_run_scan
		},
		error: function (jqXHR, textStatus) {
			var resp = jqXHR.responseText;

			if (linkilo_handle_errors(resp)) {
				linkilo_report_next_step();
				return;
			}

			var wrapper = document.createElement('div');
			$(wrapper).append('<strong>' + textStatus + '</strong><br>');
			$(wrapper).append(jqXHR.responseText);
			linkilo_swal({"title": "Error", "content": wrapper, "icon": "error"}).then(linkilo_report_next_step());
		},
		success: function(response){

			if(response.error){
				linkilo_swal(response.error.title, response.error.text, 'error');
				return;
			}

                // if we've been around a couple times without processing links, there must have been an error
			if(!response.links_to_process_count && response.loop_count > 5){
				linkilo_swal('Data Reset Error', 'Linkilo has tried a number of times to reset the report data, and it hasn\'t been able to complete the action.', 'error');
				return;
			}

                // if the data has been successfully reset
			if(response.data_setup_complete){
                    // set the loading screen now that the data setup is complete
				if(response.loading_screen){
					$('#wpbody-content').html(response.loading_screen);
				}
                    // set the time
				timeList.push(response.time);
                    // and call the data processing function to handle the data
				processReportData(response.nonce, 0, 0, 0);
			}else{
                    // if we're not done processing links, go around again
				processReportReset(response.nonce, (response.loop_count + 1), true,response.wizard_run_scan= null);
			}
		}
	});
}

    // listen for clicks on the "Reset Data" button
$('#linkilo_report_reset_data_form').on('submit', resetReportData);

/* for wizard perform Scan */
	$("#linkilo_report_reset_data_form_wizard").on('submit', resetReportData);
/* for wizard perform Scan */

    /**
     * Process runner that handles the report data generation process.
     * Loops around until all the site's links are inserted into the Linkilo link table
     **/
function processReportData(nonce = null, loopCount = 0, linkPostsToProcessCount = 0, linkPostsProcessed = 0, metaFilled = false, linksFilled = false){
	if(!nonce){
		return;
	}

        // initialize the stage clock. // The clock is useful for debugging
	if(loopCount < 1){
		if(timeList.length > 0){
			var lastTime = timeList.pop();
			timeList = [lastTime];
		}else{
			timeList = [];
		}
	}

	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			action: 'process_record_data',
			nonce: nonce,
			loop_count: loopCount,
			link_posts_to_process_count: linkPostsToProcessCount,
			link_posts_processed: linkPostsProcessed,
			meta_filled: metaFilled,
			links_filled: linksFilled
		},
		error: function (jqXHR, textStatus, errorThrown) {
			var resp = jqXHR.responseText;

			if (linkilo_handle_errors(resp)) {
				linkilo_report_next_step();
				return;
			}

			var wrapper = document.createElement('div');
			$(wrapper).append('<strong>' + textStatus + '</strong><br>');
			$(wrapper).append(jqXHR.responseText);
			linkilo_swal({"title": "Error", "content": wrapper, "icon": "error"}).then(linkilo_report_next_step());

		},
		success: function(response){
                // if there was an error
			if(response.error){
                    // output the error message
				linkilo_swal(response.error.title, response.error.text, 'error');
                    // and exit
				return;
			}

                // log the time
			timeList.push(response.time);

                // if the meta has been successfully processed
				if(response.loop_again)
				{
					processReportData(  response.nonce,
						(response.loop_count + 1),
						response.link_posts_to_process_count,
						response.link_posts_processed,
						response.meta_filled,
						response.links_filled);
				}
			if(response.processing_complete){
					// if the processing is complete
					// console.log the time if available
				if(timeList > 1){
					console.log('The post processing took: ' + (timeList[(timeList.length - 1)] - timeList[0]) + ' seconds.');
				}

				// update the loading bar one more time
				animateTheReportLoadingBar(response);

					// if there are linked sites, show the external site processing loading page
				if(response.loading_screen){
					$('#wpbody-content').html(response.loading_screen);
				}

					// find out if there's external sites we need to get data from
				var externalSites = $('.linkilo_report_need_prepare.processing');

					// if there are no linked sites or the site linking is disabled
				if(externalSites.length < 1 || (0 == linkilo_ajax.site_linking_enabled)){
						// show the user the success message!
					linkilo_swal('Success!', 'Synchronization has been completed.', 'success').then(linkilo_report_next_step);
				}else{
						// call the site updator if there are sites to update
					processExternalSites();
				}

					// and exit since in either case we're done here
				return;
			} else if(response.link_processing_complete){
					// if we've finished loading links into the link table
					// show the post processing loading page
				if(response.loading_screen){
					$('#wpbody-content').html(response.loading_screen);
				}

					// console.log the time if available
				if(timeList > 1) {
					console.log('The link processing took: ' + (timeList[(timeList.length - 1)] - timeList[0]) + ' seconds.');
				}

					// re-call the function for the final round of processing
				processReportData(  response.nonce,
					0,
					response.link_posts_to_process_count,
					0,
					response.meta_filled,
					response.links_filled);

			} else if(response.meta_filled){
					// show the link processing loading screen
				if(response.loading_screen){
					$('#wpbody-content').html(response.loading_screen);
				}
					// console.log the time if available
				if(timeList > 1){
					console.log('The meta processing took: ' + (timeList[(timeList.length - 1)] - timeList[0]) + ' seconds.');
				}

					// update the loading bar
				animateTheReportLoadingBar(response);

					// and recall the function to begin the link processing (loading the site's links into the link table)
				processReportData(  
						response.nonce,                         // nonce
						0,                                      // loop count
						response.link_posts_to_process_count,   // posts/cats to process count
						0,                                      // how many have been processed so far
						response.meta_filled,                   // if the meta processing is complete
						response.links_filled
						);
					// if the link processing is complete
			} else{
                    // if we're not done processing, go around again
				processReportData(  response.nonce,
					(response.loop_count + 1),
					response.link_posts_to_process_count,
					response.link_posts_processed,
					response.meta_filled,
					response.links_filled);

                    // if the meta has been processed
				if(response.meta_filled){
                        // update the loading bar
					animateTheReportLoadingBar(response);
				}
			}
		}
	});
}

	/**
	 * Processes the external sites by ajax calls
	 **/
function processExternalSites(){
	var externalSites = $('.linkilo_report_need_prepare.processing').first();

	if(externalSites.length < 1){
			// show the user the success message!
		linkilo_swal('Success!', 'Synchronization has been completed.', 'success').then(linkilo_report_next_step);
		return;
	}

	var site = $(externalSites),
	url = site.data('linked-url'),
	page = site.data('page'),
	saved = site.data('saved'),
	total = site.data('total'),
	nonce = site.data('nonce');


	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			action: 'linkilo_refresh_site_data',
			url: url,
			nonce: nonce,
			page: page,
			saved: saved,
			total: total
		},
		success: function(response){
				// if there was an error
			if(response.error){
					// remove the processing class
				site.removeClass('processing');
					// make the background of the loading bar red to indicate an error
				site.find('.progress_panel').css({'background': '#c7584d'});
				site.find('.progress_count').css({'background': '#fd2d2d'});
					// and add an error text
				site.find('.linkilo-loading-status').text('Processing Error');

					// and go on to the next site
				processExternalSites();

				return;
			}else if(response.success){
					// if the site is processed, update the display

					// remove the processing class
				site.removeClass('processing');
					// and go on to the next site
				processExternalSites();
				return;
			}else if(response){
					// if there's still posts to process in the current site

					// update the page relavent data
				site.data('page', response.page),
				site.data('saved', response.saved),
				site.data('total', response.total),

					// update the display
				animateLinkedSiteLoadingBar(site, response);

					// and go around again
				processExternalSites();
				return;
			}
		}
	});
}


    /**
     * Updates the loading bar length and the displayed completion status.
     *
     * A possible improvement might be to progressively update the loading bar so its more interesting.
     * As it is now, the bar jumps every 60s, so it might be a bit dull and the user might wonder if it's working.
     **/
function animateTheReportLoadingBar(response){
        // get the loading display
	var loadingDisplay = $('#wpbody-content .linkilo-loading-screen');
        // create some variable to update the display with
	var percentCompleted = Math.floor((response.link_posts_processed/response.link_posts_to_process_count) * 100);
	var displayedStatus = percentCompleted + '%' + ((response.links_filled) ? (', ' + response.link_posts_processed + '/' + response.link_posts_to_process_count) : '') + ' ' + linkilo_ajax.completed;
}

    /**
     * Updates the loading bars for linked sites during the link scan.
     * Increases the length of the loading bars and the text content contained in the bar as the data is downloaded.
	 *
	 **/
function animateLinkedSiteLoadingBar(site, response){
        // create some variables to update the display with
	var percentCompleted = Math.floor((response.saved/response.total) * 100);
	var displayedStatus = percentCompleted + '%' + ((response.saved) ? (', ' + response.saved + '/' + response.total) : '');

}

$(document).on('click', '.linkilo-collapsible', function (e) {
	if ($(this).hasClass('linkilo-no-action') ||
		$(e.target).hasClass('linkilo_word') ||
		$(e.target).hasClass('add-internal-links') ||
		$(e.target).hasClass('add_custom_link_button') ||
		$(e.target).hasClass('add_custom_link') ||
		$(e.target).parents('.add_custom_link').length ||
		$(this).find('.custom-link-wrapper').length > 0 ||
		$(this).find('.wp-editor-wrap').length > 0
		)
	{
		return;
	}

		// exit if the user clicked the "Add" button in the link report
	if($(e.srcElement).hasClass('add-internal-links')){
		return;
	}
	e.preventDefault();

	var $el = $(this);
	var $content = $el.closest('.linkilo-collapsible-wrapper').find('.linkilo-content');
	var cl_active = 'linkilo-active';
	var wrapper = $el.parents('.linkilo-collapsible-wrapper');

	if ($el.hasClass(cl_active)) {
		$el.removeClass(cl_active);
		wrapper.removeClass(cl_active);
		$content.hide();
	} else {
			// if this is the link report or focus keyword report or autolink table or the domains table
		if($('.tbl-link-reports').length || $('#linkilo_focus_keyword_table').length || $('#linkilo_keywords_table').length || $('#report_domains').length){
				// hide any open dropdowns in the same row
			$(this).closest('tr').find('td .linkilo-collapsible').removeClass('linkilo-active');
			$(this).closest('tr').find('td .linkilo-collapsible-wrapper').removeClass('linkilo-active');
			$(this).closest('tr').find('td .linkilo-collapsible-wrapper').find('.linkilo-content').hide();
		}
		$el.addClass(cl_active);
		wrapper.addClass(cl_active);
			// $content.show();
		$content.css('display', 'inline-block');
	}
});

$(document).on('click', '#select_all', function () {
	if ($(this).prop('checked')) {
		if ($('.best_keywords').hasClass('outgoing')) {
			$(this).closest('table').find('.sentence:visible input[type="checkbox"].chk-keywords:visible').prop('checked', true);
		} else {
			$(this).closest('table').find('input[type="checkbox"].chk-keywords:visible').prop('checked', true);
		}

		$('.suggestion-select-all').prop('checked', true);
	} else {
		$(this).closest('table').find('input[type="checkbox"].chk-keywords').prop('checked', false);
		$('.suggestion-select-all').prop('checked', false);
	}
});

$(document).on('click', '.best_keywords.outgoing .linkilo-collapsible-wrapper input[type="radio"]', function () {
	var data = $(this).closest('li').find('.data').html();
	var id = $(this).data('id');
	var type = $(this).data('type');
	var suggestion = $(this).data('suggestion');
	var origin = $(this).data('post-origin');
	var siteUrl = $(this).data('site-url');

	$(this).closest('ul').find('input').prop('checked', false);

	$(this).prop('checked', true);
	$(this).closest('.linkilo-collapsible-wrapper').find('.linkilo-collapsible-static').html('<div data-id="' + id + '" data-type="' + type + '" data-post-origin="' + origin + '" data-site-url="' + siteUrl + '">' + data + '<span class="add_custom_link_button link-form-button"> | <a href="javascript:void(0)">Custom Link</a></span><span class="linkilo_add_feed_url_to_ignore link-form-button"> | <a href="javascript:void(0)">Ignore Link</a></span></div>');
	$(this).closest('tr').find('input[type="checkbox"]').prop('checked', false);
	$(this).closest('tr').find('input[type="checkbox"]').val(suggestion + ',' + id);

	if (!$(this).closest('tr').find('input[data-linkilo-custom-anchor]').length && $(this).closest('tr').find('.sentence[data-id="'+id+'"][data-type="'+type+'"]').length) {
		$(this).closest('tr').find('.sentences > div').hide();
		$(this).closest('tr').find('.sentence[data-id="'+id+'"][data-type="'+type+'"]').show();
	}
});

$(document).on('click', '.best_keywords.incoming .linkilo-collapsible-wrapper input[type="radio"]', function () {
	var id = $(this).data('id');
	var data = $(this).closest('li').find('.data').html();
	$(this).closest('ul').find('input').prop('checked', false);
	$(this).prop('checked', true);
	$(this).closest('.linkilo-collapsible-wrapper').find('.sentence').html(data + '<span class="linkilo_edit_sentence">| <a href="javascript:void(0)">Edit</a></span>');
	$(this).closest('tr').find('input[type="checkbox"]').prop('checked', false);
	$(this).closest('tr').find('.raw_html').hide();
	$(this).closest('tr').find('.raw_html[data-id="' + id + '"]').show();
});

$(document).on('click', '.best_keywords input[type="checkbox"]', function () {
	if ($(this).prop('checked')) {
		if ($('.best_keywords').hasClass('outgoing')) {
			var checked = $('.best_keywords .sentence:visible input[type="checkbox"].chk-keywords:checked');
		} else {
			var checked = $('.best_keywords input[type="checkbox"].chk-keywords:checked');
		}
		if (checked.length > 50) {
			checked = checked.slice(50);
			console.log(checked);
			checked.each(function(){
				$(this).prop('checked', false);
			});
			linkilo_swal('Warning', 'You can choose only 50 links', 'warning');
		}
	}

});

    // remove entry from console table
$(document).on('click', '.linkilo_cannibalization_keywords_remove', function () {
	if (confirm("Are you sure you want to remove this entry from table?")) {
		var el = $(this);
		var r_id = parseInt(el.data('rec_id'));
		var w_id = parseInt(el.data('wrap_id'));

		var loader_class = '.cannibalization_keywords_loader_'+w_id;
		var data_class = '.cannibalization_keywords_wrap_'+w_id;

    		// show loader
		$(loader_class).show();

    		// hide data
		$(data_class).hide();

		$.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'linkilo_handle_cannibalization_keywords',
				rec_id: r_id
			},
			success: function (response) {
				if(response.success){
					var count_class = '.cannibalization_keywords_count_wrap_'+w_id;

					var default_count = $('span'+count_class).data('default_count');
					var new_count = default_count-1;

					if (new_count > 2 || new_count == 2) {
							// show data
						$(data_class).show();
							// hide loader
						$(loader_class).hide();

						$('span'+count_class).data('default_count', new_count);
						$('span'+count_class).text(new_count);

				    		// remove li
						el.closest('li').fadeOut(300);
					}else{
			    			// remove row
						el.closest('tr').fadeOut(300);
					}
				}else if(response.error){
					console.log(response.error.title, response.error.text, 'error');
				}else if(response.info){
					console.log(response.info.title, response.info.text, 'info');
				}
			},
			error: function (jqXHR, textStatus, errorThrown) {
				console.log(jqXHR, textStatus, errorThrown);
			}
		});
	}
});

// for wizard js
$(document).ready(function () {
    // hidden things
    $(".form-business").hide();
    $("#successMessage").hide();
	var linkilo_links_preview_chk 	= $(document).find("input[name='linkilo_links_preview']").prop("checked") ? 1 : 0;
	if(linkilo_links_preview_chk === 0)
	{
		$('#linkilo_external_link_preview').hide();
		$('#linkilo_internal_link_preview').hide();
	}
	var completedSteps = linkilo_ajax.completed_steps;
// console.log(completedSteps);
    if (completedSteps) {
        // for (var i = 0; i < completedStepList.length; i++) {
        //     var completedStep = completedStepList[i];
            $(".linkilo_next_wizard[data-step='" + completedSteps + "']").addClass("completed");
        // }
    }
	var completed_class = $('.linkilo_next_wizard').hasClass("completed");
	if(completed_class)
	{
		var nextRow = $('.linkilo_next_wizard').parents(".linkilo_wizard_all_tab_common_class_step"+completedSteps).next(".linkilo_wizard_all_tab_common_class_step"+completedSteps);
		
		// console.log(nextRow.length);
		if (nextRow.length === 0) {
		if(completedSteps > 0)
		{
			var i =1;
			while( i !== completedSteps)
			{
				// console.log($i);
				$(".text-center[data-step='" + i + "']").addClass("active");
				
				if(i == completedSteps)
				{
				$(".text-center[data-step='" + i + "']").next().addClass("active");

					break;
				}
				i++;
			}
		}
			// $(".text-center").data("step",completedSteps).addClass("active");
			// linkilo_wizard_all_tab_common_class_step1
			$('.linkilo_wizard_all_tab_common_class_step1').hide();
			$('.linkilo_next_wizard').parents(".linkilo_wizard_all_tab_common_class_step"+completedSteps).next().show();
			
		}
	}

    // next button
    $(".linkilo_next_wizard").on({
        click: function () {
			var clickedButton = $(this);
			var linkilo_wizard_step = clickedButton.data("step");
			var skip = clickedButton.data("skip");
			if(linkilo_wizard_step == 1)
			{
				var data = {
					action: 'linkilo_save_wizard_global_settings',
					linkilo_wizard_step				: linkilo_wizard_step,
				}
			}
			else if(linkilo_wizard_step == 2)
			{
				var linkilo_selectedValues = [];

    			// Loop through each checked checkbox
				$("input[name='linkilo_2_post_types[]']:checked").each(function() {
					linkilo_selectedValues.push($(this).val());
				});
				var linkilo_2_show_all_post_types 	= $("input[name='linkilo_2_show_all_post_types']").prop("checked") ? 1 : 0;
				var linkilo_skip_sentences 			= $("select[name='linkilo_skip_sentences']").val();
				var linkilo_max_links_per_post = $("select[name='linkilo_max_links_per_post']").val();
				var linkilo_max_words_match_per_suggest = $("select[name='linkilo_max_words_match_per_suggest']").val();
				var data = {
						action: 'linkilo_save_wizard_global_settings',
						linkilo_2_post_types			: linkilo_selectedValues,
						linkilo_2_show_all_post_types 	: linkilo_2_show_all_post_types,
						linkilo_skip_sentences 			: linkilo_skip_sentences,
						linkilo_max_links_per_post      : linkilo_max_links_per_post,
						linkilo_max_words_match_per_suggest : linkilo_max_words_match_per_suggest,
						linkilo_wizard_step				: linkilo_wizard_step
					}

			}
			else if(linkilo_wizard_step == 3)
			{
				var linkilo_google_search_console_limit = $("select[name='linkilo_google_search_console_limit']").val();

				var data = {
					action: 'linkilo_save_wizard_global_settings',
					linkilo_wizard_step				: linkilo_wizard_step,
					linkilo_google_search_console_limit : linkilo_google_search_console_limit
				}
			}
			else if(linkilo_wizard_step == 4)
			{
				var linkilo_rankmath_keyword_enable = '';
				var linkilo_yoastseo_keyword_enable = '';
				var rankmath_exists = $("input[name='linkilo_rankmath_keyword_enable']").length > 0;
				var yoast_exists = $("input[name='linkilo_yoastseo_keyword_enable']").length > 0;
				
				if(rankmath_exists)
				{
					linkilo_rankmath_keyword_enable =  $("input[name='linkilo_rankmath_keyword_enable']").prop("checked") ? 1 : 0;
				}
				else
				{
					linkilo_rankmath_keyword_enable = 0;
				}
				if(yoast_exists)
				{
					linkilo_yoastseo_keyword_enable =  $("input[name='linkilo_yoastseo_keyword_enable']").prop("checked") ? 1 : 0;
				}
				else
				{
					linkilo_yoastseo_keyword_enable = 0;
				}
				var data = {
					action: 'linkilo_save_wizard_global_settings',
					linkilo_wizard_step				: linkilo_wizard_step,
					linkilo_yoastseo_keyword_enable : linkilo_yoastseo_keyword_enable,
					linkilo_rankmath_keyword_enable : linkilo_rankmath_keyword_enable

				}
			}
			else if(linkilo_wizard_step == 5)
			{
				var linkilo_icon_type = $("select[name='linkilo_icon_type']").val();
				var linkilo_icon_position = $("select[name='linkilo_icon_position']").val();
				var linkilo_internal_icon_type = $("select[name='linkilo_internal_icon_type']").val();
				var linkilo_interlanl_icon_position = $("select[name='linkilo_interlanl_icon_position']").val();

				if(linkilo_icon_type == 'linkilo_external_icon')
				{
					var linkilo_selectedClass = $('input[name="linkilo_external_icon"]:checked').val();
				}
				else if(linkilo_icon_type == 'linkilo_verified_icon')
				{
					var linkilo_selectedClass = $('input[name="linkilo_verified_icon"]:checked').val();
				}
				else
				{
					var linkilo_selectedClass ='';
				}

				var linkilo_chk_internl_opt = '';
				if(linkilo_internal_icon_type == 'linkilo_internal_icon')
				{
					var linkilo_internal_selectedClass = $('input[name="linkilo_internal_icon"]:checked').val();
					linkilo_chk_internl_opt = '1';
				}
				else if(linkilo_internal_icon_type == 'linkilo_internal_verified_icon')
				{
					var linkilo_internal_selectedClass = $('input[name="linkilo_internal_verified_icon"]:checked').val();
					linkilo_chk_internl_opt = '2';
				}
				else
				{
					var linkilo_internal_selectedClass ='';
					linkilo_chk_internl_opt = '0';
				}
				var linkilo_preview_internal_enable_disable = '';
				var linkilo_preview_external_enable_disable = '';
				var linkilo_links_preview 	= $("input[name='linkilo_links_preview']").prop("checked") ? 1 : 0;
				var linkilo_internl_link_preview = $("input[name='linkilo_preview_internal_enable_disable']").length > 0;
				var linkilo_external_link_preview = $("input[name='linkilo_preview_external_enable_disable']").length > 0;

				if(linkilo_internl_link_preview)
				{
					linkilo_preview_internal_enable_disable =  $("input[name='linkilo_preview_internal_enable_disable']").prop("checked") ? 1 : 0;
				}
				else
				{
					linkilo_preview_internal_enable_disable = 0;
				}

				if(linkilo_external_link_preview)
				{
					linkilo_preview_external_enable_disable =  $("input[name='linkilo_preview_external_enable_disable']").prop("checked") ? 1 : 0;
				}
				else
				{
					linkilo_preview_external_enable_disable = 0;
				}

				var data = {
					action: 'linkilo_save_wizard_global_settings',
					linkilo_wizard_step				: linkilo_wizard_step,
					linkilo_icon_type               : linkilo_icon_type,
					linkilo_selectedClass           : linkilo_selectedClass,
					linkilo_icon_position           : linkilo_icon_position,
					linkilo_internal_icon_type      : linkilo_internal_icon_type,
					linkilo_chk_internl_opt         : linkilo_chk_internl_opt,
					linkilo_internal_selectedClass   : linkilo_internal_selectedClass,
					linkilo_interlanl_icon_position  : linkilo_interlanl_icon_position,
					linkilo_links_preview            : linkilo_links_preview,
					linkilo_preview_internal_enable_disable : linkilo_preview_internal_enable_disable,
					linkilo_preview_external_enable_disable : linkilo_preview_external_enable_disable
				}
			}
			else if(linkilo_wizard_step == 6)
			{
				var linkilo_aloseo_keyword_enable = '';
				var linkilo_squirrly_seo_keyword_enable = '';
				var aioseo_exists = $("input[name='linkilo_aloseo_keyword_enable']").length > 0;
				var squirrly_exists = $("input[name='linkilo_squirrly_seo_keyword_enable']").length > 0;
				
				if(aioseo_exists)
				{
					linkilo_aloseo_keyword_enable =  $("input[name='linkilo_aloseo_keyword_enable']").prop("checked") ? 1 : 0;
				}
				else
				{
					linkilo_aloseo_keyword_enable = 0;
				}
				if(squirrly_exists)
				{
					linkilo_squirrly_seo_keyword_enable =  $("input[name='linkilo_squirrly_seo_keyword_enable']").prop("checked") ? 1 : 0;
				}
				else
				{
					linkilo_squirrly_seo_keyword_enable = 0;
				}

				
				var data = {
					action: 'linkilo_save_wizard_global_settings',
					linkilo_wizard_step				: linkilo_wizard_step,
					linkilo_aloseo_keyword_enable   : linkilo_aloseo_keyword_enable,
					linkilo_squirrly_seo_keyword_enable : linkilo_squirrly_seo_keyword_enable

				}
			}
			
			$.blockUI({ message: '<div class="loader"></div>' });
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: data,
				success: function (response) {
					$.unblockUI();
					var parsedResponse = JSON.parse(response);
					if(parsedResponse.status === true)
					{
						
						// $(".step[data-step='" + linkilo_wizard_step + "']").addClass("completed");
						// clickedButton.data("step",linkilo_wizard_step).addClass("completed");
						
		
						var nextRow = clickedButton.parents(".linkilo_wizard_all_tab_common_class").next(".linkilo_wizard_all_tab_common_class");
						if (nextRow.length) {
						
							$("#progressBar").find(".active").next().addClass("active");
			
							$("#alertBox").addClass("d-none");
							clickedButton.parents(".linkilo_wizard_all_tab_common_class").fadeOut("fast", function () {
								nextRow.fadeIn('fast');
							});
						}
					}
					else
					{
						$(".linkilo_wizard_err_message").text(parsedResponse.error_msg);
					}
					
				}
			});
			
        }
    });

	$(".linkilo_skip_wizard").on({
        click: function () {
			var clickedButton = $(this);
			var linkilo_wizard_step = clickedButton.data("step");
			var data = {
				action: 'linkilo_save_skiped_wizard_steps',
				linkilo_wizard_step				: linkilo_wizard_step,
			}
			$.blockUI({ message: '<div class="loader"></div>' });
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: data,
				success: function (response) {
					$.unblockUI();
					var parsedResponse = JSON.parse(response);
					if(parsedResponse.status === true)
					{
						
						$(".step[data-step='" + linkilo_wizard_step + "']").addClass("completed");
						clickedButton.data("step",linkilo_wizard_step).addClass("completed");
						
						var nextRow = clickedButton.parents(".linkilo_wizard_all_tab_common_class").next(".linkilo_wizard_all_tab_common_class");
						if (nextRow.length) {
						
							$("#progressBar").find(".active").next().addClass("active");
			
							$("#alertBox").addClass("d-none");
							clickedButton.parents(".linkilo_wizard_all_tab_common_class").fadeOut("fast", function () {
								nextRow.fadeIn('fast');
							});
						}
					}
					
				}
			});
            //    $("#progressBar").find(".active").next().addClass("active");
			  
            //     $("#alertBox").addClass("d-none");
			// 	var nextRow = $(this).parents(".linkilo_wizard_all_tab_common_class").next(".linkilo_wizard_all_tab_common_class");
			// if (nextRow.length) {
			// 	$(this).parents(".linkilo_wizard_all_tab_common_class").fadeOut("fast", function () {
			// 		nextRow.fadeIn('fast');
			// 	});
			// }
        }
    });
    // back button
    $(".linkilo_wizard_back").on({
        click: function () {
			var clickedButton = $(this);
			var linkilo_wizard_step = clickedButton.data("step");
			var data = {
				action: 'linkilo_save_prev_wizard_steps',
				linkilo_wizard_step				: linkilo_wizard_step,
			}
			console.log(linkilo_wizard_step);
			$.blockUI({ message: '<div class="loader"></div>' });
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: data,
				success: function (response) {
					$.unblockUI();
					var parsedResponse = JSON.parse(response);
					if(parsedResponse.status === true)
					{
						
						$(".step[data-step='" + linkilo_wizard_step + "']").addClass("completed");
						clickedButton.data("step",linkilo_wizard_step).addClass("completed");
						
		
						// var nextRow = clickedButton.parents(".linkilo_wizard_all_tab_common_class").next(".linkilo_wizard_all_tab_common_class");
						// if (nextRow.length) {
						
						// 	$("#progressBar").find(".active").next().addClass("active");
			
						// 	$("#alertBox").addClass("d-none");
						// 	clickedButton.parents(".linkilo_wizard_all_tab_common_class").fadeOut("fast", function () {
						// 		nextRow.fadeIn('fast');
						// 	});
						// }
						$("#progressBar").last().removeClass("active");
						clickedButton.parents(".linkilo_wizard_all_tab_common_class").fadeOut("fast", function () {
							clickedButton.prev(".linkilo_wizard_all_tab_common_class").fadeIn("fast");
						});
					}
					
				}
			});
            $("#progressBar .active").last().removeClass("active");
            $(this).parents(".linkilo_wizard_all_tab_common_class").fadeOut("fast", function () {
                $(this).prev(".linkilo_wizard_all_tab_common_class").fadeIn("fast");
            });
        }
    });

    $('#label_linkilo_links_preview').change(function() {
		// If the checkbox is checked, show the fields; otherwise, hide them
		if ($(this).is(':checked')) {
			$('#linkilo_external_link_preview').show();
			$('#linkilo_internal_link_preview').show();
		} else {
			
			$('#label_linkilo_preview_internal_enable_disable').prop('checked', false);
			$('#label_linkilo_preview_external_enable_disable').prop('checked', false);
			$('#linkilo_external_link_preview').hide();
			$('#linkilo_internal_link_preview').hide();
		}
	});
    //back to wizard
    $(".back-to-wizard").on({
        click: function () {
            location.reload(true);
        }
    });
});

//////

function showHideWizardSteps(lastCompletedStep, skippedSteps) {
    $(".linkilo_wizard_all_tab_common_class").each(function () {
        // var stepNumber = $(this).data("step");
		var clickedButton = $(this);
            var stepNumber = clickedButton.data("step");


        if (stepNumber <= lastCompletedStep && skippedSteps.indexOf(stepNumber) === -1) {
            $(this).fadeIn("fast");
        } else {
            $(this).hide();
        }
    });

    $("#progressBar").find(".step").removeClass("active");
    for (var i = 1; i <= lastCompletedStep; i++) {
        $("#progressBar").find(".step[data-step='" + i + "']").addClass("active");
    }
}

function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}
	//delete link from post content
$(document).on('click', '.linkilo_link_delete, .linkilo_cannibalization_links_remove, .linkilo_anchor_report_row_delete', function () {
	var anchor_wraper_class = $(this).data("counter_wrap_id");
	if (confirm("Are you sure you want to delete this link? This will delete the link from the page that it\'s on.")) {

		var el = $(this);
		var w_id = parseInt(el.data('wrap_id'));

		if(el.hasClass('delete-anchor')){
				var wrap_class_li =  '.'+el.data("wrap_class"); //single li wrapper class
				var wrap_class_li_loader =  el.data("wrap_class")+'_loader'; //loader class for li
				var td_wrap =  el.data("td_wrap"); //column td class
				
				$(wrap_class_li).after('<div id="anchor_report_loader" class="'+wrap_class_li_loader+' cannibalization_links_loader_wrap"><div class="linkilo_progress_panel_cannib_links loader"></div></div>');        //add loader to current li

				$(wrap_class_li).hide();  //li hide
			}

			if (typeof el.data('wrap_id') !== 'undefined' && !isNaN(w_id)) {
				var loader_class = '.cannibalization_links_loader_'+w_id;
				var data_class = '.cannibalization_links_wrap_'+w_id;
	    		// show loader
				$(loader_class).show();
	    		// hide data
				$(data_class).hide();
			}

			var data = {
				url: el.data('url'),		
				anchor: el.data('anchor'),
				post_id: el.data('post_id'),
				post_type: el.data('post_type'),
				link_id: typeof el.data('link_id') !== 'undefined' ? el.data('link_id') : ''
			};
			$.post('admin.php?page=linkilo&type=delete_link', data, function(response)
			{ 
				if (el.hasClass('broken_link')) {
					if (typeof el.data('wrap_id') !== 'undefined' && !isNaN(w_id)){
						var count_class = '.cannibalization_links_count_wrap_'+w_id;
						var default_count = $('span'+count_class).data('default_count');
						var new_count = default_count-1;
						if (new_count > 2 || new_count == 2) {
							$(data_class).show();
							$(loader_class).hide();
							$('span'+count_class).data('default_count', new_count);
							$('span'+count_class).text(new_count);
							el.closest('tr').fadeOut(300);
						}else{
							el.closest('tr').fadeOut(300);
						}
					}else{
						el.closest('tr').fadeOut(300);
					}
				}
				else if(el.hasClass('delete-anchor'))
				{
					var w_id = parseInt(el.data('wrap_id'));
					if (typeof el.data('wrap_id') !== 'undefined' && !isNaN(w_id))
					{
						if (response.success) {
							var default_count = $("#" + anchor_wraper_class).html(); 						
							var new_count = default_count-1;
							$("#" + anchor_wraper_class).data("default-count", new_count);
							$("#" + anchor_wraper_class).text(new_count);						
							$('.'+wrap_class_li_loader).remove();					
							if(new_count == 0){
								$('#'+td_wrap).html('<div title="Internal Count" style="margin:0px; text-align: center; padding: 5px">0</div>');							
								$('#'+td_wrap).removeClass('linkilo-active');
								el.closest('tr').fadeOut(300);
							}
							else{
								$(wrap_class_li).remove();
							}
							linkilo_swal(response.success.title, response.success.text, 'success');
						}

						if (response.error) {
							$('.'+wrap_class_li_loader).remove();
							$(wrap_class_li).show();
							linkilo_swal(response.error.title, response.error.text, 'error');
						}
					}				
				}
				else{					
					var w_id = parseInt(el.data('wrap_id'));
					if (typeof el.data('wrap_id') !== 'undefined' && !isNaN(w_id))
					{

						var count_class = '.cannibalization_links_count_wrap_'+w_id;
						var default_count = $('span'+count_class).data('default_count');
						var new_count = default_count-1;
						if (new_count > 2 || new_count == 2) {
							$(data_class).show();
							$(loader_class).hide();
							$('span'+count_class).data('default_count', new_count);
							$('span'+count_class).text(new_count);
							el.closest('li').fadeOut(300);
						}else{
							el.closest('tr').fadeOut(300);
						}
					}else{
						el.closest('li').fadeOut(300);
					}
				}

			});
		}
	});



	// ignore an orphaned post from the link report
$(document).on('click', '.linkilo-ignore-orphaned-post', function (e) {
	e.preventDefault();
	var el = $(this);

	if (confirm("Are you sure you want to ignore this post on the Orphaned Posts view? It will still be visible on the Summarys and you can re-add the post to the Orphan URLs from the settings.")) {
		var el = $(this);
		var data = {
			action: 'linkilo_ignore_stray_feed',
			post_id: el.data('post-id'),
			type: el.data('type'),
			nonce: el.data('nonce')
		};
		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			dataType: 'json',
			data: data,
			error: function (jqXHR, textStatus, errorThrown) {
				var wrapper = document.createElement('div');
				$(wrapper).append('<strong>' + textStatus + '</strong><br>');
				$(wrapper).append(jqXHR.responseText);
				linkilo_swal({"title": "Error", "content": wrapper, "icon": "error"});
			},
			success: function(response){
				if(response.success){
					if (el.hasClass('linkilo-ignore-orphaned-post')) {
						el.closest('tr').fadeOut(300);
					} else {
						el.closest('li').fadeOut(300);
					}
				}else if(response.error){
					linkilo_swal(response.error.title, response.error.text, 'error');
				}
			}
		});
	}
});

$(document).ready(function(){
	var saving = false;

	if (typeof wp.data != 'undefined' && typeof wp.data.select('core/editor') != 'undefined') {
		wp.data.subscribe(function () {
			if (document.body.classList.contains( 'block-editor-page' ) && !saving && reloadGutenberg) {
				saving = true;
				setTimeout(function(){
					$.post( ajaxurl, {action: 'linkilo_editor_reload', post_id: $('#post_ID').val()}, function(data) {
						if (data == 'reload') {
							location.reload();
						}

						saving = false;
						reloadGutenberg = false;
					});
				}, 3000);
			}
		});
	}

	if ($('#post_ID').length) {
		$.post( ajaxurl, {action: 'linkilo_is_outgoing_urls_added', id: $('#post_ID').val(), type: 'post'}, function(data) {
			if (data == 'success') {
				linkilo_swal('Success', 'Links have been added successfully', 'success');
			}
		});
	}

	if ($('#incoming_suggestions_page').length) {
		var id  = $('#incoming_suggestions_page').data('id');
		var type  = $('#incoming_suggestions_page').data('type');
		var page_type  = $('#incoming_suggestions_page').data('page');

		$.post( ajaxurl, {action: 'linkilo_is_incoming_urls_added', id: id, type: type}, function(data) {
			if (data == 'success') {
				if (page_type === 'edit') {
					linkilo_swal('Done', 'Your Links have been added', 'success');
				}else{
					Swal.fire({
						title: 'OK \n\n\n Great Job! \n\n',
						text: "Your Links have been added",
						showCancelButton: true,
						confirmButtonColor: '#1078C7',
						cancelButtonColor: '#1078C7',
						confirmButtonText: 'Add New URLs',
						cancelButtonText: 'OK'
					}).then((result) => {
						if (result.isConfirmed) {
							window.location.href = "admin.php?page=linkilo&type=links";
						}
					});
				}
			}
		});
	}

		//show links chart in dashboard
	if ($('#linkilo_links_chart').length) {

		var internal = $('input[name="internal_links_count"]').val();
		var external = $('input[name="total_links_count"]').val();

		new Chart($("#linkilo_links_chart"), {
			"type": "doughnut",
			"data": {
				"labels": ["Internal", "External"],
				"datasets": [{
					"label": "My First Dataset",
					"data": [internal, external],
					"backgroundColor": ["#FE6383", "#FF9F40"]
				}]
			},
			options: {
				legend: {
					display: true
				}
			}
		});
	}


		//show links click chart in detailed click report
	if ($('#link-click-detail-chart').length) {

		var clickData	= JSON.parse($('input#link-click-detail-data').val());
		var range		= JSON.parse($('input#link-click-detail-data-range').val());
		var clickCount = 0;
		var dateRange = getAllDays(range.start, range.end);
		var displayData = [];

		if(clickData !== ''){
			for(var i in dateRange){
				var date = dateRange[i];
				if(clickData[date] !== undefined){
					displayData.push([date, clickData[date]]);
					clickCount += clickData[date];
				}else{
					displayData.push([date, 0]);
				}
			}
		}

		$('#link-click-detail-chart').jqChart({
			title: { text: 'Clicks per day' },
			legend: {
				title: '',
				font: '15px sans-serif',
				location: 'top',
				border: {visible: false},
				visible: false
			},
			border: { visible: false },
			animation: { duration: 1 },
			shadows: {
				enabled: true
			},
			axes: [
			{
				type: 'linear',
				location: 'left',
				minimum: 0,
			},
			{
				location: 'bottom',
				labels: {
					resolveOverlappingMode: 'hide'
				},
				majorTickMarks: {
				},
				minorTickMarks: {
				}
			},
			{
				location: 'bottom',
				title: {
					text: 'Total Clicks for Selected Range: ' + clickCount,
					font: '16px sans-serif',
					fillStyle: '#282828',
				},
				strokeStyle: '#ffffff	',
				labels: {
					resolveOverlappingMode: 'hide'
				},
				majorTickMarks: {
				},
				minorTickMarks: {
				}
			},
			],
			series: [
			{
				type: 'area',
				title: '',
				shadows: {
					enabled: true
				},
				lineWidth : 2,
				fillStyle: '#2dc0fd',
				strokeStyle:'#6b3da7',
				markers: {
					size: 8,
					type: 'rounded',
					strokeStyle: 'black',
					fillStyle : '#6b3da7',
					lineWidth: 1
				},
				labels: {
					visible: false,
					stringFormat: '%d',
					valueType: 'dataValue',
					font: 'bold 15px sans-serif',
					fillStyle: 'transparent',
					fontWeight: 'bold'
				},
				data: displayData,
				leaderLineWidth: 1,
				leaderLineStrokeStyle: 'black'
			}
			]
		});
	}

	function getAllDays(start, end) {
		var s = new Date(start);
		var e = new Date(end);
		var a = [];

		while(s < e) {
			a.push(moment(s).format("MMMM DD, YYYY"));
			s = new Date(s.setDate(
				s.getDate() + 1
				))
		}

			// add an extra day because the date range counter cuts the last day off.
		a.push(moment(s).format("MMMM DD, YYYY"));

		return a;
	};

});

/*Cannibalization links replace*/
	// replace btn and add input field
$('.cannibalization_links_replace').click(function(e){
	var post_id = $(this).data('post_id');
	var loop_r_index = $(this).data('loop_r_index');

	$('.cannib_hide_button_'+loop_r_index).hide();

	$(this).next('.replace_cannibalization_link_'+loop_r_index).append(
		'<div class="custom-link-wrapper">' +
		'<div class="add_custom_links_cannib">' +
		'<input id="cannib_replace_input_'+loop_r_index+'" type="text" placeholder="Paste URL or type any word to search..." style="width: 60%;border: 1px solid #9ea1c9; border-radius: 5px;" class="cannibalization_links_replace_input" data-loop_id="'+loop_r_index+'" autocomplete="off">' +
		'<button type="button" class="cannib_links_replace_btn_yes y_btn_en_'+loop_r_index+'" data-input="'+loop_r_index+'" data-current_post_id="'+post_id+'"><span class="dashicons dashicons-yes"></span></button>	'+
		'<button type="button" id="cannib_close_inpupt" class="cannib_links_replace_btn_no n_btn_en_'+loop_r_index+'" data-wrap='+loop_r_index+'><span class="dashicons dashicons-no"></span></button>'+

		'<div id="cannib_replace_loader_'+loop_r_index+'" class="linkilo_cannib_replace_loader loader"></div>'+

		'<span class="rep_process_loader"></span>'+
		'<span id="cannib_ajax_loader_'+loop_r_index+'"></span>'+
		'<span id="val_err_'+loop_r_index+'" class="clr_err_span"></span>'+
		'<span id="val_suc_'+loop_r_index+'" class="clr_suc_span"></span>'+
		'<div class="cannib_links_list"></div>' +
		'</div>' +
		'</div>'
		);
});

$(document).on('keyup', '.add_custom_links_cannib input[type="text"]', linkilo_cannib_links_autocomplete);

$(document).on('click', '.add_custom_links_cannib .cannib_links_list .item', linkilo_cannib_links_choose);

function linkilo_cannib_links_choose() {
	var url = $(this).data('url');
	$(this).closest('.add_custom_links_cannib').find('input[type="text"]').val(url);
	$(this).closest('.cannib_links_list').html('').hide();
}

var linkilo_cannib_links_autocomplete_timeout = null;
var linkilo_cannib_links_number = 0;
function linkilo_cannib_links_autocomplete(e) {
	$(document).click(function() {
		$('.cannib_links_list').html('').hide();
	});
	$(this).removeClass("clr_validation");
	$(this).attr('placeholder', 'Paste URL or type any word to search...');
	var input_id = parseInt($(this).data('loop_id'));
	var err_span = $('#val_err_'+input_id);
	err_span.hide();
	err_span.empty();

	var list = $(this).closest('div').find('.cannib_links_list');
		//choose variant with keyboard
	if ((e.which == 38 || e.which == 40 || e.which == 13) && list.css('display') !== 'none') {
		switch (e.which) {
		case 38:
			linkilo_cannib_links_number--;
			if (linkilo_cannib_links_number > 0) {
				list.find('.item').removeClass('active');
				list.find('.item:nth-child(' + linkilo_cannib_links_number + ')').addClass('active')
			}
			break;
		case 40:
			linkilo_cannib_links_number++;
			if (linkilo_cannib_links_number <= list.find('.item').length) {
				list.find('.item').removeClass('active');
				list.find('.item:nth-child(' + linkilo_cannib_links_number + ')').addClass('active')
			}
			break;
		case 13:
			if (list.find('.item.active').length) {
				var url = list.find('.item.active').data('url');
				list.closest('.add_custom_link').find('input[type="text"]').val(url);
				list.html('').hide();
				linkilo_cannib_links_number = 0;
			}
			break;
		}
	} else {
			//search posts
		var search = $(this).val();
		if (search.length > 2) {
			clearTimeout(linkilo_cannib_links_autocomplete_timeout);
			linkilo_cannib_links_autocomplete_timeout = setTimeout(function(event){
				$.ajax({
					type: 'post',
					url: ajaxurl,
					data: {
						action: 'linkilo_cannibalization_links_replace',
						keyword: search
					},
					success: function(response) {
						if (response.length > 2) {
							list.html('');
							for (var item of response) {
								list.append('<div class="item" data-url="' + item.permalink + '"><div class="title">' + item.title + '</div><div class="date">' + item.info + '</div></div>');
							}
							list.show();
							linkilo_cannib_links_number = 0;
						}else{
							if (search && response.length < 2) {
								list.html('');
								list.append('<div class="cannib_links_list_no_posts"><p>No Post found.</p></div>');
								list.show();
							}
						}
					}
				});
			}, 500);
		}

		if (search.length == 0 || search.length <= 2) {
			list.empty();
			list.hide();
		}
	}
}

	// if the user cancels the custom link
$(document).on('click', 'button#cannib_close_inpupt', function(e){
	var loop_r_index = $(this).data('wrap');
	$('.cannib_hide_button_'+loop_r_index).show();
	$('.replace_cannibalization_link_'+loop_r_index).empty();
});

$(document).on('click', 'button.cannib_links_replace_btn_yes', function(event) {
	var input_id = $(this).data('input');
	var c_post_id = $(this).data('current_post_id');
	var replace_input = $('#cannib_replace_input_'+input_id);
	var err_span = $('#val_err_'+input_id);
	var suc_span = $('#val_suc_'+input_id);
	var link_text = $('#rep_link_wrap_'+input_id);
	var link = $('#cannib_replace_input_'+input_id).val();
	var link_text_raw = $('#rep_link_text_raw_url_'+input_id).val();

	if (!link) {
    		// empty
		replace_input.addClass('clr_validation');
		replace_input.attr('placeholder', 'Start typing to search...');
		err_span.text('Invalid URL!');
		err_span.show();
		return false;
	}else if(!/^(http|https):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i.test(link)) {
    		// check if not a url
			// invaild url
		replace_input.addClass('clr_validation');
		err_span.text('Invalid URL!');
		err_span.show();
		return false;
	}else if (link === link_text.text()) {

		replace_input.prop("disabled", true);
		if(replace_input.hasClass('clr_validation')){
			replace_input.removeClass('clr_validation');
		}

		suc_span.text('Already Changed!');
		suc_span.show();

		setTimeout(function() {
			suc_span.hide();
			suc_span.empty();
			replace_input.prop("disabled", false);
		}, 3000);
		return false;
	}else{
    		// not empty process now
		replace_input.prop("disabled", true);
		$(".y_btn_en_"+input_id).prop("disabled", true);
		$(".n_btn_en_"+input_id).prop("disabled", true);

		$(".linkilo_cannib_replace_overlay_"+input_id).addClass('linkilo_cannib_replace_overlay_wrap');
		$("#cannib_replace_loader_"+input_id).show();
		if(replace_input.hasClass('clr_validation')){
			replace_input.removeClass('clr_validation');
		}

		$.ajax({
			type: 'post',
			url: ajaxurl,
			data: {
				action: 'linkilo_cannibalization_links_process_replace',
				rep_link: link,
				index: input_id,
				post_id: c_post_id,
				c_raw_link: link_text_raw
			},
			success: function(response) {
    				// debugger
				if (response.status == 1) {
					replace_input.prop("disabled", false);
					replace_input.val('');
					link_text.text(decodeURIComponent(link));
					$(".y_btn_en_"+input_id).prop("disabled", false);
					$(".n_btn_en_"+input_id).prop("disabled", false);

					$(".linkilo_cannib_replace_overlay_"+input_id).removeClass('linkilo_cannib_replace_overlay_wrap');
					$("#cannib_replace_loader_"+input_id).hide();
					suc_span.text('Success');
					suc_span.show();

					setTimeout(function() {
						suc_span.hide();
						suc_span.empty();
					}, 3000);
				}

				if (response.status == 0) {
					replace_input.prop("disabled", false);
					replace_input.addClass('clr_validation');
					$(".y_btn_en_"+input_id).prop("disabled", false);
					$(".n_btn_en_"+input_id).prop("disabled", false);

					$(".linkilo_cannib_replace_overlay_"+input_id).removeClass('linkilo_cannib_replace_overlay_wrap');
					$("#cannib_replace_loader_"+input_id).hide();

					err_span.text('Error!');
					err_span.show();

					setTimeout(function() {
						replace_input.removeClass('clr_validation');
						err_span.hide();
						err_span.empty();
					}, 3000);
				}
			}
		});
	}
});
	/*Cannibalization links replace ends*/

$(document).on('click', '.add_custom_link_button', function(e){
	$(this).closest('div').append('<div class="custom-link-wrapper">' +
		'<div class="add_custom_link">' +
		'<input type="text" placeholder="Paste URL or type to search">' +
		'<div class="links_list"></div>' +
		'<span class="button-primary cst-btn-clr">' +
		'<i class="mce-ico mce-i-dashicon dashicons-editor-break"></i>' +
		'</span>' +
		'</div>' +
		'<div class="cancel_custom_link">' +
		'<span class="button-primary cst-btn-clr">' +
		'<i class="mce-ico mce-i-dashicon dashicons-no"></i>' +
		'</span>' +
		'</div>' +
		'</div>');
	$(this).closest('.suggestion').find('.link-form-button').hide();
	$(this).closest('.linkilo-collapsible-wrapper').find('.link-form-button').hide();
});

$(document).on('keyup', '.add_custom_link input[type="text"]', linkilo_link_autocomplete);
$(document).on('click', '.add_custom_link .links_list .item', linkilo_link_choose);

var linkilo_link_autocomplete_timeout = null;
var linkilo_link_number = 0;

function linkilo_link_autocomplete(e) {
	var list = $(this).closest('div').find('.links_list');
		//choose variant with keyboard
	if ((e.which == 38 || e.which == 40 || e.which == 13) && list.css('display') !== 'none') {
		switch (e.which) {
		case 38:
			linkilo_link_number--;
			if (linkilo_link_number > 0) {
				list.find('.item').removeClass('active');
				list.find('.item:nth-child(' + linkilo_link_number + ')').addClass('active')
			}
			break;
		case 40:
			linkilo_link_number++;
			if (linkilo_link_number <= list.find('.item').length) {
				list.find('.item').removeClass('active');
				list.find('.item:nth-child(' + linkilo_link_number + ')').addClass('active')
			}
			break;
		case 13:
			if (list.find('.item.active').length) {
				var url = list.find('.item.active').data('url');
				list.closest('.add_custom_link').find('input[type="text"]').val(url);
				list.html('').hide();
				linkilo_link_number = 0;
			}
			break;
		}
	} else {
			//search posts
		var search = $(this).val();
		if ($('#_ajax_linking_nonce').length && search.length) {
			var nonce = $('#_ajax_linking_nonce').val();
			clearTimeout(linkilo_link_autocomplete_timeout);
			linkilo_link_autocomplete_timeout = setTimeout(function(){
				$.post(ajaxurl, {
					page: 1,
					search: search,
					action: 'wp-link-ajax',
					_ajax_linking_nonce: nonce,
					'linkilo_custom_link_search': 1
				}, function (response) {
					list.html('');
					response = jQuery.parseJSON(response);
					for (var item of response) {
						list.append('<div class="item" data-url="' + item.permalink + '"><div class="title">' + item.title + '</div><div class="date">' + item.info + '</div></div>');
					}
					list.show();
					linkilo_link_number = 0;
				});
			}, 500);
		}
	}
}

function linkilo_link_choose() {
	var url = $(this).data('url');
	$(this).closest('.add_custom_link').find('input[type="text"]').val(url);
	$(this).closest('.links_list').html('').hide();
}

$(document).on('click', '.add_custom_link span', function(){
	var el = $(this);
	var link = el.parent().find('input').val();
	if (link) {
		$.post(ajaxurl, {link: link, action: 'linkilo_get_feed_url_title'}, function (response) {
			response = $.parseJSON(response);
			if (!el.parents('.linkilo-collapsible-wrapper').length) {
				var suggestion = el.closest('.suggestion');
				suggestion.html(response.title + '<br><a class="post-slug" target="_blank" href="'+link+'">'+response.link+'</a>' +
					'<span class="add_custom_link_button link-form-button"> | <a href="javascript:void(0)">Custom Link</a></span>');
				suggestion.data('id', response.id);
				suggestion.data('type', response.type);
				suggestion.data('custom', response.link);
			} else {
				var wrapper = el.closest('.linkilo-collapsible-wrapper');
				wrapper.find('input[type="radio"]').prop('checked', false);
				wrapper.find('.linkilo-content ul').prepend('<li>' +
					'<div>' +
					'<input type="radio" checked="" data-id="'+response.id+'" data-type="'+response.type+'" data-suggestion="-1" data-custom="'+link+'" data-post-origin="internal" data-site-url="">' +
					'<span class="data">' +
					'<span style="opacity:1">'+response.title+'</span><br>' +
					'<a class="post-slug" target="_blank" href="'+link+'">'+response.link+'</a>\n' +
					'</span>' +
					'</div>' +
					'</li>');
				wrapper.find('input[type="radio"]')[0].click();
				wrapper.find('.linkilo-collapsible').addClass('linkilo-active');
				wrapper.find('.linkilo-content').show();
			}
		});
	} else {
		alert("The link is empty!");
	}
});

    // if the user cancels the custom link
$(document).on('click', '.cancel_custom_link span', function(){
	$(this).closest('.suggestion').find('.link-form-button').show();
	$(this).closest('.linkilo-collapsible-wrapper').find('.link-form-button').show();
	$(this).closest('.custom-link-wrapper').remove();
});

	//show edit sentence form
$(document).on('click', '.linkilo_edit_sentence', function(){
	var block = $(this).closest('.sentence');
	var form = block.find('.linkilo_edit_sentence_form');
	var id = 'linkilo_editor' + block.data('id');
	var sentence = form.find('.linkilo_content').html();

	if (typeof incoming_internal_link !== 'undefined') {
		var link = incoming_internal_link;
	} else {
		var link = $(this).closest('tr').find('.post-slug:first').attr('href');
	}

	sentence = sentence.replace('%view_link%', link);
	form.find('.linkilo_content').attr('id', id).html(sentence).show();
	form.show();
	var textarea_height = form.find('.linkilo_content').height() + 100;
	form.find('.linkilo_content').height(textarea_height);
	if(undefined === wp.blockEditor){
		wp.editor.initialize(id, {
			tinymce: true,
			quicktags: true,
		});
	}else{
		wp.oldEditor.initialize(id, {
			tinymce: true,
			quicktags: true,
		});
	}

	block.find('input[type="checkbox"], .linkilo_sentence_with_anchor, .linkilo_edit_sentence').hide();
	setTimeout(function(){ block.find('.mce-tinymce').show(); }, 500);
	form.find('.linkilo_content').hide();
	form.show();
});

	//Cancel button pressed
$(document).on('click', '.linkilo_edit_sentence_form .button-secondary', function(){
	var block = $(this).closest('.sentence');
	linkilo_editor_remove(block);
});

	//Save edited sentence
$(document).on('click', '.linkilo_edit_sentence_form .button-primary', function(){
	var block = $(this).closest('.sentence');
	var id = 'linkilo_editor' + block.data('id');

		//get content from the editor
	var sentence;
	if ($('#' + id).css('display') == 'none') {
		var editor = tinyMCE.get(id);
		sentence = editor.getContent();
	} else {
		sentence = $('#' + id).val();
	}

		//remove multiple whitespaces and outer P tag
	if (sentence.substr(0,3) == '<p>') {
		sentence = sentence.substr(3);
	}
	if (sentence.substr(-4) == '</p>') {
		sentence = sentence.substr(0, sentence.length - 4);
	}
	var sentence_clear = sentence;

		//put each word to span
	var link = sentence.match(/<a[^>]+>/);
	if (link[0] != null) {
		sentence = sentence.replace(/<a[^>]+\s*>/, ' %link_start% ');
		sentence = sentence.replace(/\s*<\/a>/, ' %link_end% ');
	}

		// check for a second link
	var secondLink = sentence.match(/<a[^>]+>/);
	if (secondLink != null && secondLink[0] != null) {
			// if there are more links, remove them
		sentence = sentence.replace(/<a[^>]+\s*>/g, '');
		sentence = sentence.replace(/\s*<\/a>/g, '');
			// and update the clear sentence so the additional links aren't present
		sentence_clear = sentence.replace(/%link_start%/g, link[0]);
		sentence_clear = sentence_clear.replace(/%link_end%/g, '</a>');
	}

	sentence = sentence.replace(/\s+/g, ' ');
	sentence = sentence.replace(/ /g, '</span> <span class="linkilo_word">');
	sentence = '<span class="linkilo_word">' + sentence + '</span>';
	if (link[0] != null) {
		sentence = sentence.replace(/<span class="linkilo_word">%link_start%<\/span>/g, link[0]);
		sentence = sentence.replace(/<span class="linkilo_word">%link_end%<\/span>/g, '</a>');
	}

	block.find('.linkilo_sentence').html(sentence);
	block.find('input[name="custom_sentence"]').val(btoa(unescape(encodeURIComponent(sentence_clear))));

	if (block.closest('tr').find('.raw_html').length) {
		sentence_clear = sentence_clear.replace(/</g, '&lt;');
		sentence_clear = sentence_clear.replace(/>/g, '&gt;');
		block.closest('tr').find('.raw_html').hide();
		block.closest('tr').find('.raw_html.custom-text').html(sentence_clear).show();
	}

	linkilo_editor_remove(block)
});

	//Remove WP Editor after sentence editing
function linkilo_editor_remove(block) {
	var form = block.find('.linkilo_edit_sentence_form');
	var textarea_height = form.find('.linkilo_content').height() - 100;
	form.find('.linkilo_content').height(textarea_height);
	form.hide();
	form.find('.linkilo_content').attr('id', '').prependTo(form);
	if(undefined === wp.blockEditor){
		wp.editor.remove('linkilo_editor' + block.data('id'));
	}else{
		wp.oldEditor.remove('linkilo_editor' + block.data('id'));
	}
	form.find('.wp-editor-wrap').remove();
	block.find('input[type="checkbox"], .linkilo_sentence_with_anchor, .linkilo_edit_sentence').show();
}

function custom_sentence_refresh(el) {
	var input = el.closest('.sentence').find('input[name="custom_sentence"]');
	var sentence = el.closest('.linkilo_sentence').html();
	sentence = sentence.replace(/<span[^>]+linkilo_suggestion_tag[^>]+>([a-zA-Z0-9=+]+)<\/span>/g, function (x) {
		x = x.replace(/<span[^>]+>/g, '');
		x = x.replace(/<\/span>/g, '');
		return atob(x);
	});
	sentence = sentence.replace(/<\/span> <\/a>/g, '<\/span><\/a> ');
	sentence = sentence.replace(/<span[^>]+>/g, '');
	sentence = sentence.replace(/<\/span>/g, '');
	el.closest('.sentence').find('.linkilo_content').html(sentence);

	if (input.val() !== '') {
		input.val(btoa(unescape(encodeURIComponent(sentence))));
	}
}

$(document).on('click', '.linkilo_add_feed_url_to_ignore', function(){
	if (confirm('You are about to add this link to your ignore list and it will never be suggested as a link in the future. However, you can reverse this decision on the settings page.')) {
		var block = $(this).closest('div');
		var id = block.data('id');
		var type = block.data('type');
		var postOrigin = block.data('post-origin');
		var siteUrl = block.data('site-url');

		$.post(ajaxurl, {
			id: id,
			type: type,
			post_origin: postOrigin,
			site_url: siteUrl,
			action: 'linkilo_add_feed_url_to_ignore'
		}, function (response) {
			response = $.parseJSON(response);
			if (response.error) {
				linkilo_swal('Error', response.error, 'error');
			} else {
				if (block.closest('.suggestion').length) {
					block.closest('tr').fadeOut(300, function(){
						$(this).remove();
					});
				} else {
					var id = block.data('id');
					var type = block.data('type');
					var wrapper = block.closest('.linkilo-collapsible-wrapper');

					wrapper.find('input[data-id="' +  id + '"][data-type="' +  type + '"]').closest('li').remove();
					wrapper.find('li:first input').prop('checked', true).click();
				}
				linkilo_swal('Success', 'Link was added to the ignored list successfully!', 'success');
			}
		});
	}
});

var mouseExit;
$(document).on('mouseover', '.linkilo_help i, .linkilo_help div', function(){
	clearTimeout(mouseExit);
	$('.linkilo_help div').hide();
	$(this).parent().children('div').show();
});

$(document).on('mouseout', '.linkilo_help i, .linkilo_help div', function(){
	var element = this;
	mouseExit = setTimeout(function(){
		$(element).parent().children('div').hide();
	}, 250);

});

$(document).on('click', '.csv_button', function(){
	$(this).addClass('linkilo_button_is_active');
	var type = $(this).data('type');
	linkilo_csv_request(type, 1);
});

function linkilo_csv_request(type, count) {
	$.post(ajaxurl, {
		count: count,
		type: type,
		action: 'linkilo_csv_export'
	}, function (response) {
		if (response.error) {
			linkilo_swal('Error', response.error, 'error');
		} else {
			if (response.filename) {
				$('.csv_button').removeClass('linkilo_button_is_active');
				var link = document.createElement('a');
				link.href = response.filename;
				switch (type) {
				case 'link_cannibalization':
					link.download = 'link_cannibalization.csv';
					break;
				case 'keyword_cannibalization':
					link.download = 'keyword_cannibalization.csv';
					break;
				case 'anchor_analysis':
					link.download = 'anchor_analysis.csv';
					break;
				default:
					link.download = 'links_export.csv';
					break;
				}
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			} else {
				linkilo_csv_request(response.type, ++response.count);
			}
		}
	});
}

$(document).on('click', '.return_to_report', function(e){
	e.preventDefault();
		// if a link is specified
	if(undefined !== this.href){
			// parse the url
		var params = parseURLParams(this.href);

			// if the url is back to an edit page
		if(	undefined !== typeof params &&
			( (undefined !== params.action && undefined !== params.post && 'edit' === params.action[0]) || params.direct_return)
			){
			if(params.ret_url && params.ret_url[0]){
				var link = atob(params.ret_url[0]);
			}else{
				var link = this.href;
			}

				// redirect back to the page
			location.href = link;
			return;
		}
	}

	$.post(
		ajaxurl,
		{
			action: 'linkilo_back_to_record',
		}, function(){
			window.close();
		}
		);
	window.location.href = this.href;
});

$(document).on('click', '.linkilo_gsc_switch_app', function(){
	if($(this).hasClass('enter-custom')){
		$('.linkilo_gsc_app_inputs').hide();
		$('.linkilo_gsc_custom_app_inputs').show();
	}else{
		$('.linkilo_gsc_app_inputs').show();
		$('.linkilo_gsc_custom_app_inputs').hide();
	}
});

	/*New GSC Deactivate Flow*/
$(document).on('click', '.linkilo-app-console-deactivate', function(){
	$('.settings_screen_loader').show();
	$('.settings_content_section').hide();
	$.post(ajaxurl, {
		action: 'linkilo_app_console_deactivate',
		nonce: $(this).data('nonce')
	}, function (response) {
		location.reload();
	});
});

$(document).on('click', '.linkilo-app-console-refresh-auth-token', function(){
	$('.settings_screen_loader').show();
	$('.settings_content_section').hide();
	$.post(ajaxurl, {
		action: 'linkilo_app_console_refresh_token',
		nonce: $(this).data('nonce')
	}, function (response) {
		//location.reload();
	});
});

$(document).on('click', '.linkilo-app-console-get-sites', function(){
	var status_span = $('#site_fetching_status');
	$('.linkilo-app-console-deactivate').css('cursor', 'not-allowed');
	status_span.text('Fetching sites...');
	$.post(ajaxurl, {
		action: 'linkilo_app_console_fetch_sites',
		nonce: $(this).data('nonce')
	}, function (response) {
		$('.linkilo-app-console-deactivate').css('cursor', 'default');
		status_span.text(response.message);
		if (response.status == 1) {
			location.reload();
		}
	});
});
	/*New GSC Deactivate Flow ends*/

	/** Sticky Header **/
	// Makes the thead sticky to the top of the screen when scrolled down far enough
if($('.wp-list-table').length){
	var theadTop = $('.wp-list-table').offset().top;
	var adminBarHeight = parseInt(document.getElementById('wpadminbar').offsetHeight);
	var scrollLine = (theadTop - adminBarHeight);
	var sticky = false;

		// duplicate the footer and insert in the table head
	$('.wp-list-table tfoot tr').clone().addClass('linkilo-sticky-header').css({'display': 'none', 'top': adminBarHeight + 'px'}).appendTo('.wp-list-table thead');

		// resizes the header elements
	function sizeHeaderElements(){
			// adjust for any change in the admin bar
		adminBarHeight = parseInt(document.getElementById('wpadminbar').offsetHeight);
		$('.linkilo-sticky-header').css({'top': adminBarHeight + 'px'});

			// adjust the size of the header columns
		var elements = $('.linkilo-sticky-header').find('th');
		$('.wp-list-table thead tr').not('.linkilo-sticky-header').find('th').each(function(index, element){
			var width = getComputedStyle(element).width;

			$(elements[index]).css({'width': width});
		});
	}
	sizeHeaderElements();

	function resetScrollLinePositions(){
		theadTop = $('.wp-list-table').offset().top;
		adminBarHeight = parseInt(document.getElementById('wpadminbar').offsetHeight);
		scrollLine = (theadTop - adminBarHeight);
	}

	$(window).on('scroll', function(e){
		var scroll = parseInt(document.documentElement.scrollTop);

			// if we've passed the scroll line and the head is not sticky
		if(scroll > scrollLine && !sticky){
				// sticky the header
			$('.linkilo-sticky-header').css({'display': 'table-row'});
			sticky = true;
		}else if(scroll < scrollLine && sticky){
				// if we're above the scroll line and the header is sticky, unsticky it
			$('.linkilo-sticky-header').css({'display': 'none'});
			sticky = false;
		}
	});

	var wait;
	$(window).on('resize', function(){
		clearTimeout(wait);
		setTimeout(function(){
			sizeHeaderElements();
			resetScrollLinePositions();
		}, 150);
	});

	setTimeout(function(){
		resetScrollLinePositions();
	}, 1500);
}
	/** /Sticky Header **/

	/*Connection Request*/
$('.btn_req_accept, .btn_req_decline').click(function (e){

	var id = parseInt($(this).data('id'));
	var type = parseInt($(this).data('type'));

	var r_url = "";
	if (type == 1) {
		r_url = $(this).data('url');
	}

	linkilo_swal({
		title: 'Confirmation',
		text: "Before processing please confirm that, \n Linkilo is installed and active on other site \n and \n \"Add external site for link suggestions\" \n is enabled in Linkilo settings.\n\n If both options are set then proceed else perform this process after enabling them.",
		icon: 'info',
		dangerMode: true,
		buttons: {
			cancel: {
				text: "Cancel",
				value: null,
				visible: true,
				className: "swal-site-con-btn",
				closeModal: true,
			},
			confirm: {
				text: "Proceed",
				value: true,
				visible: true,
				className: "",
				closeModal: true
			}
		},
	}).then((match) => {
		if (match) {
			$('.admin_notice_table').hide();
			$('.admin_notice_loader').show();

			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'linkilo_handle_connection_entry',
					req_id: id,
					req_type: type,
					c_url: r_url
				},
				success: function (response) {
					$('.admin_notice_loader').hide();
					$('.admin_notice_table').show();
					if(response.error){
			            	// if there was an error
			                // output the error message
						linkilo_swal(response.error.title, response.error.text, 'error').then(
							(value) => {
									// reload on ok click
								if (value) {
									location.reload();
								}else{
									// reload on click outside popup window and popup hides
									setTimeout(function(){ location.reload(); }, 100);
								}
							});
								// Auto reload after several seconds
								// setTimeout(function(){ location.reload(); }, 5000);

			                // and exit
						return;
					}else if(response.info){
			            	// if there was no error and info provided
			                // output the info message
						linkilo_swal(response.info.title, response.info.text, 'info').then(
							(value) => {
									// reload on ok click
								if (value) {
									location.reload();
								}else{
									// reload on click outside popup window and popup hides
									setTimeout(function(){ location.reload(); }, 100);
								}
							});
								// Auto reload after several seconds
								// setTimeout(function(){ location.reload(); }, 5000);

			                // and exit
						return;
					}else if(response.success){
			            	// if request was success
			                // output the success message
						linkilo_swal(response.success.title, response.success.text, 'success').then(
							(value) => {
									// reload on ok click
								if (value) {
									location.reload();
								}else{
									// reload on click outside popup window and popup hides
									setTimeout(function(){ location.reload(); }, 100);
								}
							});
								// Auto reload after several seconds
								// setTimeout(function(){ location.reload(); }, 5000);

			                // and exit
						return;
					}else if(response = null){
						console.log("The reposnse is null");
					}
				},
				error: function (jqXHR, textStatus, errorThrown) {
					console.log(jqXHR, textStatus, errorThrown);
				},
				complete: function(){
					console.log('complete');
				}
			});
		}
	});

	
});
})(jQuery);
