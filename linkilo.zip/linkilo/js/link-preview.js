jQuery(document).ready(function($) {
    // Helper function to determine if a URL is external
    function isExternal(url) {
        var host = window.location.hostname;        
        return url.hostname !== host;        
    }
    
    // Helper function to determine if a URL is internal
    function isInternal(url) {
        var host = window.location.hostname;
        return url.hostname == host;
    }

    // Helper function to determine if a URL's domain is excluded
    function isExcluded(url) {
        console.log(LinkPreview.excludedDomains);
        console.log(url.hostname);

        return LinkPreview.excludedDomains.includes(url.hostname);
    }

    // Add the "link-preview-anchor" class to every link based on configuration
    $('a').each(function() {
        var $link = $(this);
        if( $link.parents('header').length == 0 && $link.parents('footer').length == 0 ){

            var isLinkExternal = isExternal(this);
            var isLinkInternal = isInternal(this);
            var isLinkExcluded = isExcluded(this);

            // Check if the link preview should be applied based on configuration
            if (!isLinkExcluded && isLinkExternal && LinkPreview.enableExternalLinks == '1' ) {
                $link.addClass('link-preview-anchor');
            }

            // Check if the link preview should be applied based on configuration
            if (!isLinkExcluded && isLinkInternal && LinkPreview.enableInternalLinks == '1' ) {           
                $link.addClass('link-preview-anchor');
            }
        }
    });

    // Click on link when clicked on the icon next to it
    $(document).on('click', 'svg.fa-up-right-from-square', function(){
        console.log('clicked');
        var temp = $(this).parent().find('.link-preview-anchor').attr('href');
        console.log(temp)
        $(this).parent().find('.link-preview-anchor')[0].click();
    });

    // Attach hover event to links with class "link-preview-anchor"
    $('a.link-preview-anchor').hover(
        // Mouse enter
        function() {
            var $link = $(this);
            var targetUrl = this.href;
            var hostname = this.hostname;

            let ls_key = btoa(targetUrl).split("").reverse().join("").substring(0, 50);

            let existing_json = localStorage.getItem(ls_key);

            if (existing_json !== null) {
                let parsed_json = JSON.parse(existing_json);

                var $tooltip = $('<div>', { class: 'link-preview-tooltip' });


                if (parsed_json.image) {
                    $tooltip.append($('<img>', { src: parsed_json.image }));
                }
                $tooltip.append($('<div>', { class: 'title', text: parsed_json.title }));
                $tooltip.append($('<div>', { class: 'hostname', text: hostname }));

                $tooltip.append($('<div>', { class: 'description', text: parsed_json.description }));

                // Append tooltip to link and position it
                $tooltip.appendTo($link);
                
                var position = $link.position();
                $tooltip.css({
                    top: position.top + $link.outerHeight() + 10,
                    left: position.left
                });
            }else{
                // Make AJAX request to fetch link preview data
                $.ajax({
                    type: 'POST',
                    url: LinkPreview.ajax_url,
                    data: {
                        action: 'link_preview',
                        url: targetUrl
                    },
                    success: function(response) {

                        var data = JSON.parse(response);

                        localStorage.setItem(ls_key, response);

                        // Create tooltip element
                        var $tooltip = $('<div>', { class: 'link-preview-tooltip' });


                        if (data.image) {
                            $tooltip.append($('<img>', { src: data.image }));
                        }
                        $tooltip.append($('<div>', { class: 'title', text: data.title }));
                        $tooltip.append($('<div>', { class: 'hostname', text: hostname }));

                        $tooltip.append($('<div>', { class: 'description', text: data.description }));

                        // Append tooltip to link and position it
                        $tooltip.appendTo($link);

                        var position = $link.position();
                        $tooltip.css({
                            top: position.top + $link.outerHeight() + 10,
                            left: position.left
                        });
                    }
                });
            }
        },
        // Mouse leave
        function() {
            // Remove tooltip element
            $(this).find('.link-preview-tooltip').remove();
        }
        );
});
