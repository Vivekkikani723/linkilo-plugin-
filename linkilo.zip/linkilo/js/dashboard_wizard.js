"use strict";
(function ($) {
      /* External links */
      jQuery( document ).ready(function(){
        var linkilo_icon_type = $(document).find('#linkilo_icon_type').val();
        // alert('On Load ' + linkilo_icon_type);
        externalLinkOption( linkilo_icon_type );
    });

    jQuery( document ).on('click','#linkilo-external-url',function(){
        var linkilo_icon_type = $(document).find('#linkilo_icon_type').val();
        // alert('On Click ' + linkilo_icon_type);
        externalLinkOption( linkilo_icon_type );
    });

    /* External Links */

    /* Internal Links */

    jQuery( document ).ready(function(){
        var linkilo_icon_type = $(document).find('#linkilo_internal_icon_type').val();
        internalLinkOption( linkilo_icon_type );
    });

    jQuery( document ).on('click','#linkilo-internal-url',function(){
        var linkilo_icon_type = $(document).find('#linkilo_internal_icon_type').val();
        internalLinkOption( linkilo_icon_type );
    });


    function internalLinkOption( linkilo_icon_type ){
        let selecter = $('#linkilo_internal_icon_type').closest('tr').next();
        // if ($('#linkilo-internal-url').hasClass('nav-tab-active')) {
           
            if(linkilo_icon_type == 'linkilo_internal_icon')
            {
                $(selecter).show();
                $(".linkilo_radio_internal_lbl1").show();
                $(".linkilo_radio_internal_lbl2").hide();
            }
            else if(linkilo_icon_type == 'linkilo_internal_verified_icon')
            {
                $(selecter).show();
                $(".linkilo_radio_internal_lbl2").show();
                $(".linkilo_radio_internal_lbl1").hide();
            }
            else{
                $(selecter).hide();
                
            }
        // }
    }
    jQuery( document ).ready(function(){
    $('#linkilo_internal_icon_type').on('change',function(){
        var icon_type_val = $(this).val();
        internalLinkOption( icon_type_val );
    
    });
});

    /* Internal Links */


    function externalLinkOption( linkilo_icon_type ){
        let selecter = $('#linkilo_icon_type').closest('tr').next();
        // if ($('#linkilo-external-url').hasClass('nav-tab-active')) {
           
            if(linkilo_icon_type == 'linkilo_external_icon')
            {
                //$("#linkilo_icon_image_row").show();
                $(selecter).show();
                $(".linkilo_radio_lbl1").show();
                $(".linkilo_radio_lbl2").hide();
                // alert('a');
            }
            else if(linkilo_icon_type == 'linkilo_verified_icon')
            {
                //$("#linkilo_icon_image_row").show();
                $(selecter).show();

                $(".linkilo_radio_lbl2").show();
                $(".linkilo_radio_lbl1").hide();
                // alert('b');
            }
            else{
                $(selecter).hide();
                
            }
        // }
    }
    jQuery( document ).ready(function(){
    $('#linkilo_icon_type').on('change',function(){
        var icon_type_val = $(this).val();
        
        externalLinkOption( icon_type_val );
    
    });
});


})(jQuery);
