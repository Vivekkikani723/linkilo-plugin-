<?php

/**
 * Class Linkilo_Build_Stemmer for Hebrew language
 */
class Linkilo_Build_Stemmer {

    static $stemmer = null;

    //Hebrew words can not be stemmed
    public static function Stem($word){
        return $word;
    }
}