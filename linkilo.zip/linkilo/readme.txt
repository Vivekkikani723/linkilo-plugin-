=== Linkilo ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://wordpressfoundation.org/donate/
Tags: wordpress, plugin, linkilo, internal link, link
Requires at least: 5.6
Tested up to: 6.2.2
Stable tag: 1.9.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Set internal links in post for other posts and pages, check for report for each link and export data to excel.


== Description ==

Linkilo is and on-site internal linking plugin which helps the user to manage the internal linking structure of website through its functions and functionalities.

Linkilo offers to :
* Create Internal, External Links 
* Manage Internal, External Links 
* Remove Internal, External Links 
* Review Links on post/page
* Add/Edit new links from plugin menu page
* Set Bulk Links for specific keyword
* Overview the whole data with beautiful dashboard (plugin generated menu)
* Anchor Report 
* Website Link Cannibalization Report 


For further information about features please see the [Features YOU Need](https://linkilo.co/features/).

For instructions and guides please see the [Knowledge Base
](https://linkilo.co/knowledge-base/)

== Installation ==

The quickest method for installing Linkilo is:

1. Visit Plugins -> Add New -> In Search Box(Type "Linkilo" without quotes)
2. Click "Install Now" On "Linkilo"
3. Finally click on "Activate"
4. Start Using Linkilo.

If you would prefer to do things manually then follow these you can do from either Option-1 or Option-2:

Option-1
	1. Go to Plugins -> Add New. 
	2. Click on "Upload Plugin" -> "Choose" the file to upload (i.e plugin's zip file)
	3. Click "Install Now"
	4. After Uploading and intallation completed Click on Activate Plugin
	4. Start Using linkilo.

Option-2
	1. Unzip the downloaded linkilo plugin zip. 
	2. Upload the `linkilo` folder to the `/wp-content/plugins/` directory
	3. Activate the plugin through the 'Plugins' menu in WordPress
	4. Start Using linkilo.

== Changelog ==
	
= 1.0 = 
* Initial release.

== Frequently Asked Questions ==

= Getting memory errors while uploading or activating the plugin. =
	-> This can ouccur because of PHP memory limit or wordpress default memory limit.

	-> A message like "Fatal error: Allowed memory size of 21345692 bytes exhausted (tried to allocate 2983781 bytes) in /home/xxx/public_html/wp-includes/plugin.php on line xxx"

	-> This indicates that the plugin can't successfully be installed at the moment under the current PHP memory limit or wordpress upload limit. 

	-> Paste the below code between double quotes in "wp-config.php" file before the line 'That’s all, stop editing! Happy blogging.'
		- "define( 'WP_MEMORY_LIMIT', '256M' )";

	-> Further, if you have access to the php.ini file, you can manually increase the limits; if you do not (your WordPress installation is hosted on a shared server, for instance), you can ask the server support.

	-> For those with shared hosting, the best alternative may be to consult hosting support to determine the safest approach for running the installation.

	-> Another option is to increase limits through ".htaccess" of your wordpress intallation. 
	[Note: This is something to be done with proper knowledge of .htaccess or under better guidence of a expert wordpress developer.]